#!/bin/sh
# Dangis VR 5.77.6 test runner (simulated: mocked MoonLoader/GTA/SA-MP/Windows).
#
#   sh development/run_tests.sh                 texlua, plus luajit if installed
#   sh development/run_tests.sh texlua          one interpreter only
#   JOBS=8 sh development/run_tests.sh          tests in parallel (default 4)
#   ONLY="test_panel test_passage" sh ...       a subset (quick runs)
#
# Run from the package root (the folder with moonloader/, defaults/, tools/
# and development/). The runtime files are staged into a temporary folder
# laid out like a MoonLoader folder, every test runs there with every
# interpreter, and nothing stops at the first failure. The exit status is 1
# if ANY step failed: a test, the compile/upvalue check, or a missing tool.
ROOT=$(cd "$(dirname "$0")/.." && pwd)
INTERPRETERS=${*:-"texlua luajit"}
JOBS=${JOBS:-4}
STAGE=$(mktemp -d "${TMPDIR:-/tmp}/dangis_tests.XXXXXX")
LOG="$STAGE/_logs"
mkdir -p "$LOG"

cp -R "$ROOT/moonloader/." "$STAGE/"
cp "$ROOT/defaults/"* "$STAGE/"
cp "$ROOT/tools/test_rotate.lua" "$STAGE/"
cp -R "$ROOT/development" "$STAGE/development"
cp "$ROOT/development/lib/"*.lua "$STAGE/lib/"
cd "$STAGE" || exit 1

TESTS="test_driving_identity test_rotation test_rotation_modern test_probe test_audit_r4 test_session_routes
test_rotate_tool test_obstacles test_roadworks test_accessories test_recovery_rejoin test_telemetry
test_driving test_expansion test_admin_chat test_panel test_control_ownership test_route_storage
test_dialog_companion test_dialog_events test_input_ownership test_passage test_package"
TESTS=${ONLY:-$TESTS}
export PACKAGE_ROOT="$ROOT"

# one line per job: <interpreter> <label> <env> <file> <args>
JOBLIST="$LOG/jobs.txt"
: > "$JOBLIST"
for lua in $INTERPRETERS; do
    if ! command -v "$lua" >/dev/null 2>&1; then
        if [ $# -gt 0 ]; then echo "MISSING interpreter $lua" >> "$LOG/missing.txt"; fi
        continue
    fi
    for t in $TESTS; do
        args=""; [ "$t" = test_dialog_events ] && args="arbotas_auto.lua"
        echo "$lua $t - development/$t.lua $args" >> "$JOBLIST"
    done
    if [ -z "$ONLY" ]; then
        echo "$lua test_roadworks[RW_POOL=1] RW_POOL=1 development/test_roadworks.lua" >> "$JOBLIST"
        echo "$lua test_roadworks[RW_POOL=nodims] RW_POOL=nodims development/test_roadworks.lua" >> "$JOBLIST"
    fi
done

run_job() {
    lua=$1; label=$2; envset=$3; file=$4; shift 4
    out="$LOG/$lua.$(echo "$label" | tr -c 'A-Za-z0-9_\n' '_').log"
    start=$(date +%s)
    if [ "$envset" = "-" ]; then "$lua" "$file" "$@" > "$out" 2>&1; else env "$envset" "$lua" "$file" "$@" > "$out" 2>&1; fi
    status=$?
    secs=$(( $(date +%s) - start ))
    last=$(tail -1 "$out")
    if [ $status -eq 0 ] && echo "$last" | grep -q -E "passed|, 0 failed"; then result=PASS; else result=FAIL; fi
    printf '%s\t%-7s %-34s %4ss  %s\n' "$result" "$lua" "$label" "$secs" "$last" >> "$LOG/results.txt"
}

STARTED=$(date +%s)
running=0
while read -r lua label envset file args; do
    run_job "$lua" "$label" "$envset" "$file" $args &
    running=$((running + 1))
    if [ $running -ge "$JOBS" ]; then wait; running=0; fi
done < "$JOBLIST"
wait

echo "== Tests (simulated; not in-game)"
sort -k2,2 -k3,3 "$LOG/results.txt" | sed 's/^PASS\t/PASS  /; s/^FAIL\t/FAIL  /'
FAILED=$(grep -c '^FAIL' "$LOG/results.txt")
PASSED=$(grep -c '^PASS' "$LOG/results.txt")
for f in $(grep '^FAIL' "$LOG/results.txt" | awk '{print $2"."$3}' | tr -c 'A-Za-z0-9_.\n' '_'); do
    echo "---- $f"; tail -6 "$LOG/$f.log" 2>/dev/null
done
[ -f "$LOG/missing.txt" ] && cat "$LOG/missing.txt" && FAILED=$((FAILED + 1))

echo "== Compile and MoonLoader limits"
if (cd "$ROOT" && python3 development/check_moonloader_upvalues.py); then PASSED=$((PASSED + 1)); else FAILED=$((FAILED + 1)); fi

echo "== Summary: $PASSED passed, $FAILED failed, $(( $(date +%s) - STARTED ))s (logs: $LOG)"
[ "$FAILED" -eq 0 ]
