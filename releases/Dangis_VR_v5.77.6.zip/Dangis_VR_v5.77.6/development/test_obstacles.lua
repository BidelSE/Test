-- 5.77.4 obstacle avoidance scenarios (simulated, keyboard input, your INI).
-- Objects are map objects of models that are NOT on the 5.77 list unless
-- noted. Each run reports the closest the car body came to any object, the
-- largest side offset from the route, and whether it is back on the route.
-- Usage: texlua development/test_obstacles.lua [check]
package.path = "development/?.lua;" .. package.path
local Sim = require("sim_harness")
local INI = Sim.read("development/user_v577/dangis_vr.ini")
local strict = true
local total, failures = 0, {}

local function route(speed, spacing)
    local pts = {}
    for i = 0, math.floor(1000/spacing) do pts[#pts+1] = {x=0, y=i*spacing, z=10, speed=speed, heading=0, drive="FWD"} end
    return Sim.routeText(pts)
end

local function run(name, opts)
    local objects = {}
    for i, o in ipairs(opts.objects) do objects[i] = {x=o[1], y=o[2], r=o.r or 0.6, h=o.h or 1.0, model=o.model or 3578} end
    local sim = Sim.new({root=".", tag="obst_" .. name:gsub("%W", "_"), files={{"dangis_vr.ini", INI},
        {"dangis_paths/route1.txt", route(opts.speed or 25, opts.spacing or 4.3)}}, x=0, y=0, z=10.6, heading=0,
        obstacles=objects, grip=opts.grip})
    sim.groundZ = 10
    sim.bot.loop.initialize()
    sim.bot.CONFIG.controls.input = opts.input or (os.getenv("OBST_INPUT") or "keyboard"); if os.getenv("OBST_STEER") then sim.bot.CONFIG.controls.steering = os.getenv("OBST_STEER") end
    if opts.configure then opts.configure(sim.bot) end
    sim:frame(1/30, {[0x79]=true})
    local closest, maxOff, endY = math.huge, 0, opts.endY or 520
    local hitAt
    for i = 1, 30*60 do
        sim:frame(1/30)
        local h = math.rad(sim.car.heading)
        local fx, fy = -math.sin(h), math.cos(h)
        for _, o in ipairs(objects) do
            local dx, dy = o.x - sim.car.x, o.y - sim.car.y
            local along, side = dx*fx + dy*fy, dx*(-fy) + dy*fx
            local ex, ey = math.max(0, math.abs(along) - 2.4), math.max(0, math.abs(side) - 1.0)
            local d = math.sqrt(ex*ex + ey*ey) - o.r
            if d < closest then closest = d end
            if d <= 0 and not hitAt then hitAt = o.y end
        end
        maxOff = math.max(maxOff, math.abs(sim.car.x))
        if sim.car.y > endY then break end
    end
    local backOnRoute = math.abs(sim.car.x) < 3.6 and math.abs((sim.car.heading + 180) % 360 - 180) < 12
    local ok = closest > (opts.minClear or 0.2) and backOnRoute and (not opts.maxOffset or maxOff <= opts.maxOffset)
    total = total + 1
    if not ok then failures[#failures+1] = name end
    print(string.format("%s %-58s closest %5.2f m, max side offset %4.1f m, back on route %s%s",
        ok and "PASS" or "FAIL", name, closest, maxOff, tostring(backOnRoute), hitAt and string.format("  (touched at y=%.0f)", hitAt) or ""))
    return sim
end

for _, speed in ipairs({15, 25, 35}) do
    run(speed .. " m/s: one block in the middle of the lane", {speed=speed, objects={{0.3, 260}}})
    run(speed .. " m/s: low tyre stack (0.5 m tall)", {speed=speed, objects={{-0.4, 260, h=0.5, model=1327}}})
    run(speed .. " m/s: three blocks across the right half", {speed=speed, objects={{0.4, 260}, {1.6, 260}, {2.8, 260}}})
    run(speed .. " m/s: slalom - blocks left, right, left 35 m apart", {speed=speed, objects={{-1.0, 240}, {1.0, 275}, {-1.0, 310}}, minClear=0.2})
    run(speed .. " m/s: cluster of 5 bollards", {speed=speed, objects={{-0.6, 255, r=0.3, model=1237}, {0.6, 258, r=0.3, model=1237},
        {0, 262, r=0.3, model=1237}, {-1.2, 266, r=0.3, model=1237}, {1.2, 266, r=0.3, model=1237}}})
end
run("25 m/s: bollards along the roadside at 4.5 m (must NOT swerve)", {speed=25, objects={{4.5, 200, r=0.3}, {4.5, 230, r=0.3}, {4.5, 260, r=0.3},
    {-4.5, 215, r=0.3}, {-4.5, 245, r=0.3}}, maxOffset=1.6})  -- gamepad input wanders up to 1.5 m by design
run("25 m/s: switch off (avoid_all_objects = false) - 5.77 behaviour", {speed=25, objects={{0.3, 260}},
    configure=function(bot) bot.CONFIG.driving.avoidAllObjects = false end, minClear=-99})
print(string.format("%d obstacle scenarios, %d failed%s", total, #failures, #failures > 0 and (": " .. table.concat(failures, "; ")) or ""))
if strict and #failures > 0 then os.exit(1) end
