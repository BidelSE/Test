script_name('dangis_vr')
script_version('5.77')
require 'lib.moonloader'
local UI = require 'lib.dangis_ui'

local VR_VERSION = "5.77"

local recording = false
local playing = false
local repeating = false
local paused = false
local current_route = {}
local play_index = 1
local current_name -- from CONFIG.route.defaultName
local paths_dir = getWorkingDirectory() .. "/dangis_paths/"
local shared_state_file = getWorkingDirectory() .. "/dangis_vr_state.txt"
local freeze_flag_file = getWorkingDirectory() .. "/dangis_vr_freeze.flag"
local rotate_flag_file = getWorkingDirectory() .. "/dangis_vr_rotate.flag"
local dialog_flag_file = getWorkingDirectory() .. "/dangis_vr_dialog.flag"
local debug_log_file = getWorkingDirectory() .. "/dangis_vr_debug.log"
local start_x, start_y = 0, 0
local recordLeftStart = false
-- routeRadius, recordingDelay, LOOKAHEAD and current_name are loaded from CONFIG.route.
local routeRadius
local tick = 0
local recordingDelay
local lastRecordHeading = 0

local lastSteerValue = 0
local steerNoiseDuration = 0
local steerNoiseCooldown = 0
local collisionCooldown = 0
local avoidSteerDir = 0
local overrideActive = false

local lastX, lastY = 0.0, 0.0
local freezeTimer = 0
local lastCarHeading = 0

local steerBuf = {0, 0}
local gasLevel = 0
local brakeLevel = 0
local pauseReleaseReason = ""
local lastDriveSpeed = 0.0
local suddenStopFrames = 0
local recordReverseFrames = 0
local recordForwardBrakeFrames = 0
local DRIVE_FORWARD = "FWD"
local DRIVE_BACK = "BACK"
local COLOR_ROUTE_FORWARD = 0xFFFF0000
local COLOR_ROUTE_BACK = 0xFF000000
local COLOR_ROUTE_BACK_OUTLINE = 0xFFFFFFFF
local recordDriveMode = DRIVE_FORWARD
local playbackDriveMode = DRIVE_FORWARD
local reverseActive = false
-- Playback thresholds were tuned in frames; frameScale converts the real frame
-- time into those reference frames so behaviour does not change with FPS.
local frameScale = 1.0
local lastPlaybackTickAt = nil
local commandJob = nil



local showTrail = false
local currentTrail = {}
local lastTrail = {}
local trailTick = 0

local samp = 0

local S = {
    gasLiftFrames = 0, nextGasLift = 0,
    lapWander = 0.0,
    routeObstacleDist = math.huge, routeAvoidDir = 0, routeObstacleTimer = 0,
    routeObstacleUrgency = 0.0,
    avoidRouteDir = 0, avoidSideHit = false,
    avoidLateralTarget = 0.0, avoidHoldUntil = 0.0,
    bypassActive = false, bypassDir = 0, bypassOffset = 0.0,
    bypassHoldUntil = 0.0, bypassLastSeen = 0.0,
    bypassReturning = false,
    avoidClusterCount = 0,
    showObstacleDots = true, obstacleDebugMode = 2, obstacleFont = nil, obstacleHits = {}, obstacleProbes = {},
    currentLateral = 0.0, nudgeOffset = 0.0, nudgeFrames = 0, nextNudge = 0,
    manualPaused = false,
    -- Legacy name: this means freeze/recovery owns controls, not only admin state.
    frozenByAdmin = false, refreshSent = false,
    -- A test_freeze flag that recovery already handled; cleared when the flag goes away.
    externalFreezeAck = false,
    recentDriveSpeed = 0.0, recentDriveUntil = 0.0,
    testArbotasPaused = false,
    dialogPaused = false,
    dialogReleaseUntil = 0.0,
    freezeTestLatched = false,
    freezeRecoveryMode = "",
    freezeRefreshSentAt = 0.0,
    freezeReleaseUntil = 0.0,
    freezeRefreshAt = 0.0,
    freezeResumeDelay = 0.0,
    freezeRecoveryGraceUntil = 0.0,
    rotateFightUntil = 0.0,
    rotateReleaseUntil = 0.0,
    rotateIgnoreUntil = 0.0,
    reversePlaybackGraceUntil = 0.0,
    backToForwardUntil = 0.0,
    bumpActive = false,
    bumpPhase = "",
    bumpReason = "",
    bumpUntil = 0.0,
    bumpStartedAt = 0.0,
    bumpCooldownUntil = 0.0,
    bumpGraceUntil = 0.0,
    bumpStartX = 0.0,
    bumpStartY = 0.0,
    bumpMinDistance = 0.0,
    bumpMaxDistance = 0.0,
    bumpSteer = 0,
    forwardNoProgressFrames = 0,
    forwardNoProgressDist = 0.0,
    forwardNoProgressIndex = 0,
    rejoinCooldownUntil = 0.0,
    rejoinDisableUntil = 0.0,
}

local LOOKAHEAD = 6
local AVOID_OBJECT_MODELS = {
    [1238] = true, -- cone
    [1459] = true, -- road barrier
    [1423] = true, -- road barrier
    [19951] = true, -- road sign
    [19952] = true, -- road sign
    [19974] = true, -- road sign
    [19961] = true, -- road sign
    [19960] = true, -- road sign
}

-- Architecture map:
-- Utils/Debug: small shared helpers and optional debug output.
-- RouteStorage/RouteRecorder/RouteFollower: route files, recording, playback.
-- ObstacleAvoidance: existing probe scanner and bypass state.
-- RecoverySystem/AdminProtection/DialogBridge: pause and safety gates.
-- ControlManager: single-owner, complete CPad commands with live safety gates.
-- InputHandler/MainLoop: hotkeys and the ordered frame loop.
local CONFIG = {
    route = {
        radius = 12.0,          -- distance that counts as reaching a waypoint
        recordingDelay = 80,    -- ms between recorded points
        lookahead = LOOKAHEAD,  -- points ahead used for the steering target
        pathsDir = paths_dir,
        defaultName = "route1", -- saved as <name>.txt; the previous copy is kept as .txt.bak
    },
    controls = {
        nitroEnabled=true, nitroInterval=60, nitroVariation=15,
        lookEnabled=true, lookInterval=25,
        input = "keyboard",
        steerKey = 0,
        -- CPad NewState buttons (GTA SA 1.0 US). In a car: Cross = accelerate,
        -- Square = brake (reverses once the car has stopped), RightShoulder1 = handbrake.
        gasAddress = 0xB73458 + 0x20,
        footBrakeAddress = 0xB73458 + 0x1C,
        handbrakeAddress = 0xB73458 + 0x0C,
        -- "foot": slow down with the real brake. "hand": pre-5.49 behaviour,
        -- which (unintentionally) braked with the handbrake.
        brakeMode = "foot",
        footBrakeMinSpeed = 1.0, -- never hold the brake below this forward speed (it would reverse)
        -- "bangbang": full-lock steering as before. "smooth": proportional steering.
        steering = "bangbang",
        smoothFullLockDegrees = 25.0,
        smoothResponseSeconds = 0.12,
        smoothRatePerSecond = 320.0,
    },
    driving = {
        enabled = true,
        cornerBraking = false,
        lowFpsTolerance = true,
        lateralTolerance = 2.5,
        steeringPointStride = 5,
        sampleMeters = 4.0,
        lateralAcceleration = 3.0, -- m/s^2; tuning estimate, not a vehicle model.
        brakingDeceleration = 4.5,
        reactionSeconds = 0.5,
        previewMeters = 120.0, maxPreviewMeters = 400.0,
        cornerMarginMeters = 3.0,
        minCornerSpeed = 4.0, -- m/s; the recorded speed can still be lower.
        minLookaheadMeters = 3.0,
        maxLookaheadMeters = 14.0,
        lookaheadSeconds = 0.35,
    },
    timing = {
        -- The frame-counted thresholds were tuned at about this FPS (measured
        -- from dangis_vr_debug.log); they now follow real frame time instead.
        referenceFps = 30,
        minFrameScale = 0.25,
        maxFrameScale = 2.0,
    },
    obstacle = {
        models = AVOID_OBJECT_MODELS,
        scanEveryFrames = 6,
        -- Route points further away are not ray-cast; hits beyond ~62 m are ignored anyway.
        corridorRadius = 70.0,
        maxTrailPoints = 30000,
    },
    escape = {
        enabled = true, probeDistance = 4.0, margin = 0.30,
        lateralOffset = 0.5, steering = 32, maxSpeed = 3.0,
        recheckSeconds = 0.15, requireGround = true,
    },
    vehicle = {defaultProfile = "standard", maxSpeedKmh = 0, modelProfiles = {}},
    diagnostics = {enabled = true, x = 24, y = 140},
    recovery = {
        rotateStartIgnoreSeconds = 0.8,
        freezeRecoveryGraceSeconds = 2.1,
        freezeWaitBeforeRefreshMinSeconds = 2.0,
        freezeWaitBeforeRefreshMaxSeconds = 3.0,
        freezeResumeDelayMinSeconds = 0.5,
        freezeResumeDelayMaxSeconds = 1.0,
        reverseTransitionGraceSeconds = 2.4,
        backToForwardCoastSeconds = 0.85,
        reverseLookaheadPoints = 90,
        reverseLookaheadRadius = 16.0,
        bumpEnabled = true,
        repeatedAttemptLimit = 2,
        recoveryMemorySeconds = 60.0,
        recoveryAreaRadius = 15.0,
        recoveryEscapeDistance = 8.0,
        repeatedReverseExtraMeters = 2.0,
        repeatedReverseExtraSeconds = 0.5,
        rejoinMaxArcMeters = 60.0,
        rejoinHeadingMaxDegrees = 70.0,
        bumpCooldownSeconds = 3.4,
        bumpCoastSeconds = 0.32,
        bumpFreezeGraceSeconds = 1.8,
        bumpReverseMinSeconds = 0.85,
        bumpReverseMaxSeconds = 1.65,
        bumpReverseHardMaxSeconds = 2.6,
        bumpReverseDistanceMin = 2.0,
        bumpReverseDistanceMax = 6.0,
        bumpMinRecentSpeed = 2.0,
        bumpResyncBackPoints = 10,
        bumpResyncAheadPoints = 45,
        bumpResyncMaxDistance = 28.0,
        bumpFreezeEscalateSeconds = 1.2,
        bumpFreezeEscalateDistance = 0.25,
        forwardNoProgressFrames = 44,
        forwardNoProgressGas = 80,
        forwardNoProgressSpeed = 8.0,
        forwardProgressEpsilon = 0.06,
        refreshRetrySeconds = 0.75,
        inferredRefreshCooldownSeconds = 30.0,
        -- Freezes started by test_freeze.lua go through the same states but
        -- only send a real /refresh to the server when this is true.
        typeRefreshInFreezeTest = true,
        refreshAfterArbotas = false,
    },
    dialog = {
        sharedFile = dialog_flag_file,
    },
    adminChat = {
        enabled = true, contextual = true, replyChance = 100, quitEnabled = true,
        generalPhrases = true, repeatPhrases = true, recentJoinPhrases = true,
        frequentPhrases = true, historicalPhrases = false, waitingPhrases = false,
        recentJoinSeconds = 180,
        phraseFile = getWorkingDirectory() .. "/dangis_admin_phrases.txt",
        eventFile = getWorkingDirectory() .. "/dangis_admin_dialog.event",
        delayMinSeconds = 0.8, delayMaxSeconds = 1.8,
        betweenMessagesSeconds = 5.0,
        rotationSequenceReplies = true, rotationMinTurns = 2,
        rotationQuietSeconds = 4.0, rotationReplyCooldownSeconds = 60.0,
        quitAfterPhrase = "ai nx as taip nezaisiu", -- Empty string disables this action.
        quitDelaySeconds = 0.5, quitExpireSeconds = 3.0,
        expireSeconds = 30.0, maxQueued = 8, typingTimeoutSeconds = 15.0,
        -- F8/F4 are local harnesses, not server/admin tests.
        includeLocalTests = false,
        includeInferredTests = true, -- Inferred freeze and completed rotation-sequence replies; individual turns are silent.
        -- Same 0.3.7-R1 layout as the existing dialog reader. No API import.
        chatInputPointerOffset = 0x21A0E8, chatEnabledOffset = 0x14E0,
    },
    telemetry = {
        -- F5 starts/stops an optional capture. Disabled until explicitly enabled.
        sampleSeconds = 0.10,
        flushSeconds = 1.0,
        maxBytes = 2 * 1024 * 1024,
        file = getWorkingDirectory() .. "/dangis_vr_telemetry.csv",
    },
    debug = {
        enabled = false,
        logToFile = true,
        logFile = debug_log_file,
        maxLogBytes = 65536,
        trimCheckEvery = 50,
        categories = {
            route = true,
            obstacle = false,
            recovery = true,
            dialog = true,
            admin = true,
            input = true,
        },
    },
}

routeRadius = CONFIG.route.radius
recordingDelay = CONFIG.route.recordingDelay
LOOKAHEAD = CONFIG.route.lookahead
current_name = CONFIG.route.defaultName

-- Guarded raw memory reads (IsBadReadPtr) for dialog, entity and vehicle data.
-- Plain FFI reads are used because readMemory inside pcall can kill a
-- MoonLoader coroutine.
local Mem = { ffi = nil, k32 = nil }

function Mem.init()
    if Mem.ffi ~= nil then return Mem.ffi ~= false end
    local ok, ffi = pcall(require, "ffi")
    if not ok then
        Mem.ffi = false
        return false
    end
    pcall(ffi.cdef, "int IsBadReadPtr(const void* lp, unsigned int ucb);")
    local k32ok, k32 = pcall(ffi.load, "kernel32")
    if not k32ok then
        Mem.ffi = false
        return false
    end
    Mem.ffi, Mem.k32 = ffi, k32
    return true
end

function Mem.read(ctype, addr, size)
    if not addr or addr < 0x10000 or addr > 0x7FFFFFFF then return nil end
    if not Mem.init() then return nil end
    if Mem.k32.IsBadReadPtr(Mem.ffi.cast("void*", addr), size) ~= 0 then return nil end
    return tonumber(Mem.ffi.cast(ctype, addr)[0])
end

function Mem.readByte(addr) return Mem.read("uint8_t*", addr, 1) end
function Mem.readWord(addr) return Mem.read("uint16_t*", addr, 2) end
function Mem.readDword(addr) return Mem.read("uint32_t*", addr, 4) end
function Mem.readFloat(addr) return Mem.read("float*", addr, 4) end

-- Keyboard and focus helpers. Synthetic keys are only used to type chat
-- commands, and only while this game's window is the active window, so
-- nothing is ever typed into another program.
local Win32 = { ready = nil, held = {}, focusCheckedAt = -1.0, focusCached = true }

function Win32.init()
    if Win32.ready ~= nil then return Win32.ready end
    Win32.ready = false
    local ok, ffi = pcall(require, "ffi")
    if not ok then return false end
    pcall(ffi.cdef, "void keybd_event(unsigned char bVk, unsigned char bScan, unsigned long dwFlags, unsigned long* dwExtraInfo);")
    pcall(ffi.cdef, "short GetAsyncKeyState(int vKey);")
    pcall(ffi.cdef, "short VkKeyScanA(char ch);")
    pcall(ffi.cdef, "unsigned int MapVirtualKeyA(unsigned int uCode, unsigned int uMapType);")
    pcall(ffi.cdef, "void* GetForegroundWindow(void);")
    pcall(ffi.cdef, "unsigned long GetWindowThreadProcessId(void* hWnd, unsigned long* lpdwProcessId);")
    pcall(ffi.cdef, "unsigned long GetCurrentProcessId(void);")
    local u32ok, u32 = pcall(ffi.load, "user32")
    if not u32ok then return false end
    local k32ok, k32 = pcall(ffi.load, "kernel32")
    Win32.ffi, Win32.u32 = ffi, u32
    Win32.k32 = k32ok and k32 or nil
    Win32.ready = true
    return true
end

-- True while a window of this process (the game or SA-MP) is in front.
-- Unknown -> true, which keeps the pre-5.49 behaviour.
function Win32.isGameForeground(strict)
    local now = os.clock()
    if not strict and now - Win32.focusCheckedAt < 0.05 then return Win32.focusCached end
    if not strict then Win32.focusCheckedAt = now end
    local focused = not strict
    if Win32.init() and Win32.k32 then
        local ok, result = pcall(function()
            local hwnd = Win32.u32.GetForegroundWindow()
            if hwnd == nil then return false end
            local pid = Win32.ffi.new("unsigned long[1]")
            Win32.u32.GetWindowThreadProcessId(hwnd, pid)
            return tonumber(pid[0]) == tonumber(Win32.k32.GetCurrentProcessId())
        end)
        if ok then focused = result end
    end
    if not strict then Win32.focusCached = focused end
    return focused
end

function Win32.keyDown(vk)
    if not Win32.init() then return false end
    local ok, state = pcall(Win32.u32.GetAsyncKeyState, vk)
    state = ok and tonumber(state) or 0
    return state < 0
end

-- Real keyboards always send a hardware scan code; games reading the
-- keyboard through DirectInput ignore key events without one.
function Win32.scanCode(vk)
    local ok, scan = pcall(Win32.u32.MapVirtualKeyA, vk, 0)
    scan = ok and tonumber(scan) or 0
    return scan % 256
end

function Win32.press(vk)
    if not Win32.init() then return false end
    Win32.u32.keybd_event(vk, Win32.scanCode(vk), 0, nil)
    Win32.held[vk] = true
    return true
end

function Win32.release(vk)
    if not Win32.init() then return false end
    Win32.u32.keybd_event(vk, Win32.scanCode(vk), 2, nil) -- KEYEVENTF_KEYUP
    Win32.held[vk] = nil
    return true
end

function Win32.releaseHeld()
    for vk in pairs(Win32.held) do
        Win32.release(vk)
    end
end

function Win32.releaseKeys(keys)
    for _, vk in ipairs(keys) do
        Win32.release(vk)
    end
end

-- Optional MoonLoader functions, looked up once instead of on every call.
local API = {}
local function optionalApi(...)
    for _, name in ipairs({...}) do
        local fn = _G[name]
        if type(fn) == "function" then return fn, name end
    end
    return nil, nil
end
API.objectModel, API.objectModelName = optionalApi("getObjectModel", "getObjectModelId", "getObjectModelID", "getObjectModelIndex")
API.closestObject = optionalApi("getClosestObject")
API.closestCar = optionalApi("getClosestCar")
API.allObjects = optionalApi("getAllObjects")
API.carPointer = optionalApi("getCarPointer")
API.playerControlOn = optionalApi("isPlayerControlOn")

local RouteStorage = {}
local RouteRecorder = {}
local RouteFollower = {}
local ObstacleAvoidance = {}
local RecoverySystem = {rotation = require("lib.dangis_rotation").new()}
local MotionClassifier = {}
local DrivingPlanner = {}
local Settings = {path=getWorkingDirectory() .. "/dangis_vr.ini", status="defaults"}
local VehicleProfiles = {activeName="standard", model=nil}
local EscapePlanner = {}
local Diagnostics = {status="starting"}
local AdminChat = {queue = {}, seen = {}, seenOrder = {}, phrases = {}, bag = {}, serial = 0, lastSent = -100, rotation = nil}
local RecoveryMemory = {route = nil, attempts = 0, active = false, blocked = false}
local AdminProtection = {}
local DialogBridge = {}
local InputHandler = {}
local MainLoop = {}
local Telemetry = {enabled = false, handle = nil, bytes = 0, lastSample = -1, lastFlush = -1, lastOwner = nil, target = nil}

local lastLoggedSharedState = nil

-- Keeps the newest half of the log when it grows past maxLogBytes, instead of
-- wiping it. Checked at startup and every trimCheckEvery writes.
local function trimDebugLogFile()
    if not CONFIG.debug.logToFile then return end
    local path = CONFIG.debug.logFile or debug_log_file
    local maxBytes = CONFIG.debug.maxLogBytes or 65536
    local file = io.open(path, "rb")
    if not file then return end
    local size = file:seek("end") or 0
    if size <= maxBytes then
        file:close()
        return
    end
    local keep = math.floor(maxBytes / 2)
    file:seek("set", size - keep)
    local tail = file:read("*a") or ""
    file:close()
    local firstNewline = tail:find("\n", 1, true)
    if firstNewline then
        tail = tail:sub(firstNewline + 1)
    end
    local out = io.open(path, "wb")
    if not out then return end
    out:write(string.format("[%.3f] [LOG] trimmed older entries\n", os.clock()))
    out:write(tail)
    out:close()
end

local logWritesSinceTrim = 0

local function logEvent(category, message)
    if not CONFIG.debug.logToFile then return end
    local file = io.open(CONFIG.debug.logFile or debug_log_file, "a")
    if not file then return end
    file:write(string.format("[%.3f] [%s] %s\n", os.clock(), tostring(category or "INFO"), tostring(message or "")))
    file:close()
    logWritesSinceTrim = logWritesSinceTrim + 1
    if logWritesSinceTrim >= (CONFIG.debug.trimCheckEvery or 50) then
        logWritesSinceTrim = 0
        trimDebugLogFile()
    end
end

local function clampPadValue(value)
    value = math.floor(tonumber(value) or 0)
    if value < 0 then return 0 end
    if value > 255 then return 255 end
    return value
end

-- CONTROL_MANAGER_BEGIN
-- Every CPad/steering write goes through this manager. Producers identify
-- themselves; live safety gates choose the owner, never the last caller.
-- No method below yields: owner selection and the complete pad write stay
-- together within one MoonLoader coroutine turn.
local sharedFreezeActive, resetBumpState
local ControlManager = {
    owner = "IDLE", wrote = false,
    intent = {gas = 0, brake = 0, steer = 0, reverse = false},
    applied = {gas = 0, brake = 0, steer = 0, reverse = false},
}

function ControlManager.clearIntent()
    ControlManager.intent = {gas = 0, brake = 0, steer = 0, reverse = false}
end

-- The sole low-level writer. A complete command prevents one owner's steering
-- from being combined with another owner's pedals, including the handbrake.
function ControlManager.apply(command)
    local controls = CONFIG.controls
    local gas = clampPadValue(command.gas)
    local brake = clampPadValue(command.brake)
    local steer = math.max(-128, math.min(128, math.floor(tonumber(command.steer) or 0)))
    -- Keyboard-style route driving has only left, released and right states.
    -- Cover obstacle and recorded reverse steering as well as the forward turner.
    if controls.steering == "bangbang" and ControlManager.owner == "ROUTE" then
        steer = steer < 0 and -128 or (steer > 0 and 128 or 0)
    end
    local footBrake, handbrake = 0, 0
    local reverse = command.reverse == true
    if reverse then
        gas, footBrake = 0, 255
    elseif brake > 0 then
        if controls.brakeMode == "foot" and S.forwardSpeed ~= nil then
            if S.forwardSpeed > (controls.footBrakeMinSpeed or 1.0) then
                footBrake = brake
            end
        else
            handbrake = brake
        end
    end
    if controls.input == "keyboard" then
        local out = Win32.drive(gas,math.max(footBrake,handbrake),steer,reverse)
        ControlManager.applied = out
        reverseActive = out.reverse
    else
        writeMemory(controls.gasAddress, 2, gas, false)
        writeMemory(controls.footBrakeAddress, 2, footBrake, false)
        writeMemory(controls.handbrakeAddress, 2, handbrake, false)
        setGameKeyState(controls.steerKey, steer)
        ControlManager.applied = {gas = gas, brake = math.max(footBrake, handbrake), steer = steer, reverse = reverse}
        reverseActive = reverse
    end
    ControlManager.wrote = true
end

function ControlManager.sync()
    local owner = ControlManager.resolveOwner()
    if owner~="ROUTE" and Win32.accessories then Win32.accessories:release() end
    if owner ~= ControlManager.owner then
        logEvent("CONTROL", ControlManager.owner .. " -> " .. owner)
        ControlManager.owner = owner
        S.smoothSteerValue = 0
        S.keyboardController = nil
        S.digitalSteer = 0
        S.digitalReverseAfter = 0
        ControlManager.clearIntent()
        -- Retain only the already-held steering during this specific handoff.
        -- Freeze, UI, manual input and all other ownership changes stay neutral.
        if owner=="ROTATE" and RecoverySystem.rotation.phase=="REACT"
            and os.clock()<(RecoverySystem.rotation.reactUntil or 0) then
            ControlManager.intent.steer=RecoverySystem.rotation.heldSteer
        end
        -- Release once on handoff to the player or on stop. Subsequent manual
        -- and idle ticks must leave the player's pad completely alone.
        if ControlManager.wrote or (owner ~= "IDLE" and owner ~= "MANUAL") then
            ControlManager.apply(ControlManager.intent)
        end
        if owner == "IDLE" or owner == "MANUAL" then
            ControlManager.wrote = false
        end
    end
    return owner
end

function ControlManager.request(source, command)
    local owner = ControlManager.sync()
    if source ~= owner or owner == "IDLE" or owner == "MANUAL" then return false end
    if owner ~= "ROUTE" and owner ~= "BUMP" and owner ~= "ROTATE" then return false end
    for key, value in pairs(command) do
        ControlManager.intent[key] = value
    end
    ControlManager.apply(ControlManager.intent)
    return true
end

-- Safety callers can release, but cannot acquire another owner's authority.
function ControlManager.neutralize()
    local owner = ControlManager.sync()
    ControlManager.clearIntent()
    if owner ~= "IDLE" and owner ~= "MANUAL" then
        ControlManager.apply(ControlManager.intent)
    elseif ControlManager.wrote then
        ControlManager.apply(ControlManager.intent)
        ControlManager.wrote = false
    end
    reverseActive = false
end

local function writeDriveControls(gas, brake, reverse, source)
    return ControlManager.request(source or "ROUTE", {
        gas = gas or 0, brake = brake or 0, reverse = reverse == true,
    })
end

local function writeSteerControls(steer, source)
    return ControlManager.request(source or "ROUTE", {steer = steer or 0})
end
-- CONTROL_MANAGER_END

function dbg(category, message)
    category = tostring(category or "INFO")
    logEvent(category:upper(), message)
    if not CONFIG.debug.enabled then return end
    if not CONFIG.debug.categories[category:lower()] then return end
    UI.notify(string.format("~w~[%s] %s", category, tostring(message)), 1000)
end

function resetObstacleBypass()
    S.avoidLateralTarget = 0.0
    S.avoidHoldUntil = 0.0
    S.bypassActive = false
    S.bypassDir = 0
    S.bypassOffset = 0.0
    S.bypassHoldUntil = 0.0
    S.bypassLastSeen = 0.0
    S.bypassReturning = false
end

local function shouldAvoidObjectModel(modelId)
    modelId = tonumber(modelId)
    return modelId ~= nil and AVOID_OBJECT_MODELS[modelId] == true
end

local function getAvoidObjectModel(obj)
    if not obj or obj == 0 or not API.objectModel then return nil end
    local ok, modelId = pcall(API.objectModel, obj)
    modelId = ok and tonumber(modelId) or nil
    if modelId and modelId > 0 then return modelId end
    return nil
end

local function isAvoidableObject(obj)
    local modelId = getAvoidObjectModel(obj)
    return shouldAvoidObjectModel(modelId), modelId
end

local function readObjectCoordinates(obj)
    local ok, a, b, c, d = pcall(getObjectCoordinates, obj)
    if not ok then return false end
    if type(a) == "boolean" then
        if not a then return false end
        return true, b, c, d
    end
    if a == nil then return false end
    return true, a, b, c
end

-- processLineOfSight reports the hit entity as a raw CEntity pointer, not a
-- script handle, so its type and model are read from the entity itself.
local function collisionEntityPointer(colPoint)
    if not colPoint then return nil end
    local ok, entity = pcall(function() return colPoint.entity end)
    entity = ok and tonumber(entity) or nil
    if entity and entity >= 0x10000 then return entity end
    return nil
end

local function collisionObjectModelId(colPoint)
    local entity = collisionEntityPointer(colPoint)
    if not entity then return nil end
    local modelId = Mem.readWord(entity + 0x22) -- CEntity::m_nModelIndex
    if modelId and modelId > 0 then return modelId end
    return nil
end

-- GTA entity types: 1 building, 2 vehicle, 3 ped, 4 object, 5 dummy.
local function collisionEntityType(colPoint)
    if not colPoint then return nil end
    local ok, entityType = pcall(function() return colPoint.entityType end)
    entityType = ok and tonumber(entityType) or nil
    if entityType then return entityType end
    local entity = collisionEntityPointer(colPoint)
    local typeByte = entity and Mem.readByte(entity + 0x36) -- low 3 bits = m_nType
    return typeByte and (typeByte % 8) or nil
end

local function normalizeDriveMode(value)
    if value == true or value == 1 then return DRIVE_BACK end
    local text = tostring(value or ""):upper()
    if text == "1" or text == "TRUE" or text == "R" or text == "REV" or text == "REVERSE" or text == "BACK" or text == "B" then
        return DRIVE_BACK
    end
    return DRIVE_FORWARD
end

local function applyDriveModeToPoint(point, mode)
    if type(point) ~= "table" then return point end
    point.drive = normalizeDriveMode(mode or point.drive or point.mode or point.reverse)
    point.reverse = point.drive == DRIVE_BACK
    return point
end

local function isRoutePointReverse(point)
    if type(point) ~= "table" then return false end
    return normalizeDriveMode(point.drive or point.mode or point.reverse) == DRIVE_BACK
end

local function routeDriveModeAt(route, idx)
    local p = type(route) == "table" and route[idx] or nil
    return normalizeDriveMode(p and (p.drive or p.mode or p.reverse) or DRIVE_FORWARD)
end

local function getPlaybackDriveMode(route, idx)
    -- Playback must obey the recorded route mode exactly. Smoothing this caused
    -- BACK to leak into FWD sections and made reverse paths unpredictable.
    playbackDriveMode = routeDriveModeAt(route, idx)
    return playbackDriveMode
end

local function storageFileExists(path)
    local file = io.open(path, "r")
    if file then
        file:close()
        return true
    end
    return false
end

local function copyStorageFile(src, dst)
    local input = io.open(src, "r")
    if not input then return false end
    local data = input:read("*a") or ""
    input:close()

    local output = io.open(dst, "w")
    if not output then return false end
    output:write(data)
    output:close()
    return true
end

-- GTA headings run counter-clockwise from north: the nose points along
-- (-sin h, cos h).
local function getRecordingForwardAxes(heading)
    local h = math.rad(heading or 0.0)
    return -math.sin(h), math.cos(h)
end

local function normalizeRouteReverseFlags(route)
    -- Reverse is now an explicit recorded drive mode. Normalize only the
    -- string/legacy boolean representation; never infer it from geometry.
    if type(route) == "table" then
        for _, p in ipairs(route) do
            applyDriveModeToPoint(p)
        end
    end
    return route
end

local function saveRoute(name, route)
    route = normalizeRouteReverseFlags(route)
    if RouteStorage.validateRoute and not RouteStorage.validateRoute(route) then return false end
    local path = paths_dir .. name .. ".txt"
    local tmpPath = path .. ".tmp"
    local bakPath = path .. ".bak"
    local file = io.open(tmpPath, "w")
    if file then
        for _, p in ipairs(route) do
            local drive = normalizeDriveMode(p.drive or p.reverse)
            file:write(string.format('{%s}:{%s}:{%s}:{%s}:{%s}:{%s}\n',
                p.x, p.y, p.z, p.speed, p.heading, drive))
        end
        file:close()
        -- The previous recording stays available as <name>.txt.bak.
        os.remove(bakPath)
        if storageFileExists(path) then
            if not os.rename(path, bakPath) then
                copyStorageFile(path, bakPath)
                os.remove(path)
            end
        end
        if os.rename(tmpPath, path) then
            return true
        end
        if copyStorageFile(tmpPath, path) then
            os.remove(tmpPath)
            return true
        end
        if storageFileExists(bakPath) then
            copyStorageFile(bakPath, path)
        end
        os.remove(tmpPath)
    end
    return false
end

local function loadRoute(name)
    local path = paths_dir .. name .. ".txt"
    local function readRouteFile(filePath)
        local file = io.open(filePath, "r")
        if not file then return nil end
        local route = {}
        for line in file:lines() do
            local x, y, z, speed, heading, drive = line:match('^{([^}]*)}:{([^}]*)}:{([^}]*)}:{([^}]*)}:{([^}]*)}:{([^}]*)}$')
            if x then
                local mode = normalizeDriveMode(drive)
                table.insert(route, {x=tonumber(x), y=tonumber(y), z=tonumber(z) or 0, speed=tonumber(speed) or 0, heading=tonumber(heading) or 0, drive=mode, reverse=mode == DRIVE_BACK})
            else
                x, y, z, speed, heading = line:match('^{([^}]*)}:{([^}]*)}:{([^}]*)}:{([^}]*)}:{([^}]*)}$')
                if x then
                    table.insert(route, {x=tonumber(x), y=tonumber(y), z=tonumber(z) or 0, speed=tonumber(speed) or 0, heading=tonumber(heading) or 0, drive=DRIVE_FORWARD, reverse=false})
                else
                    local ox, oy, os2 = line:match('^{([^}]*)}:{([^}]*)}:{([^}]*)}$')
                    if ox then
                        table.insert(route, {x=tonumber(ox), y=tonumber(oy), z=0, speed=tonumber(os2) or 0, heading=0, drive=DRIVE_FORWARD, reverse=false})
                    end
                end
            end
        end
        file:close()
        return route
    end

    local route = normalizeRouteReverseFlags(readRouteFile(path))
    local tmpRoute = normalizeRouteReverseFlags(readRouteFile(path .. ".tmp"))
    local bakRoute = normalizeRouteReverseFlags(readRouteFile(path .. ".bak"))
    local routeOk = RouteStorage.validateRoute == nil or RouteStorage.validateRoute(route)
    local tmpOk = RouteStorage.validateRoute ~= nil and RouteStorage.validateRoute(tmpRoute)

    if tmpOk and not routeOk then
        return tmpRoute
    end
    if routeOk then return route end
    if RouteStorage.validateRoute == nil or RouteStorage.validateRoute(bakRoute) then return bakRoute end
    return nil
end

local function cr(p0, p1, p2, p3, t)
    local t2 = t * t
    local t3 = t2 * t
    return 0.5 * ((2*p1) + (-p0+p2)*t + (2*p0-5*p1+4*p2-p3)*t2 + (-p0+3*p1-3*p2+p3)*t3)
end

-- User settings are data only. Unknown/invalid entries reject the entire reload.
Settings.spec = {
    ["controls.nitro_enabled"]={"controls","nitroEnabled","bool"},
    ["controls.nitro_interval_seconds"]={"controls","nitroInterval","number",30,300},
    ["controls.nitro_variation_seconds"]={"controls","nitroVariation","number",0,25},
    ["controls.look_enabled"]={"controls","lookEnabled","bool"},
    ["controls.look_interval_seconds"]={"controls","lookInterval","number",15,180},
    ["driving.steering_point_stride"]={"driving","steeringPointStride","integer",1,10},
    ["driving.low_fps_tolerance"]={"driving","lowFpsTolerance","bool"},
    ["driving.waypoint_radius"]={"route","radius","number",3,25},
    ["driving.lateral_tolerance"]={"driving","lateralTolerance","number",1,5},
    ["driving.corner_braking"]={"driving","cornerBraking","bool"},
    ["driving.enabled"]={"driving","enabled","bool"},
    ["driving.lateral_acceleration"]={"driving","lateralAcceleration","number",1,8},
    ["driving.braking_deceleration"]={"driving","brakingDeceleration","number",1,10},
    ["driving.reaction_seconds"]={"driving","reactionSeconds","number",0.1,2},
    ["driving.lookahead_seconds"]={"driving","lookaheadSeconds","number",0.1,0.8},
    ["driving.max_speed_kmh"]={"vehicle","maxSpeedKmh","number",0,250},
    ["controls.input"]={"controls","input","enum","keyboard","gamepad"},
    ["controls.steering"]={"controls","steering","enum","smooth","bangbang"},
    ["chat.enabled"]={"adminChat","enabled","bool"},
    ["chat.rotation_sequence_replies"]={"adminChat","rotationSequenceReplies","bool"},
    ["chat.rotation_min_turns"]={"adminChat","rotationMinTurns","integer",2,3},
    ["chat.rotation_quiet_seconds"]={"adminChat","rotationQuietSeconds","number",2,15},
    ["chat.rotation_reply_cooldown_seconds"]={"adminChat","rotationReplyCooldownSeconds","number",15,180},
    ["chat.contextual"]={"adminChat","contextual","bool"},
    ["chat.reply_chance"]={"adminChat","replyChance","number",0,100},
    ["chat.between_messages_seconds"]={"adminChat","betweenMessagesSeconds","number",3,120},
    ["chat.delay_min_seconds"]={"adminChat","delayMinSeconds","number",0.3,10},
    ["chat.delay_max_seconds"]={"adminChat","delayMaxSeconds","number",0.3,10},
    ["chat.quit_enabled"]={"adminChat","quitEnabled","bool"},
    ["chat.include_local_tests"]={"adminChat","includeLocalTests","bool"},
    ["chat.include_inferred_tests"]={"adminChat","includeInferredTests","bool"},
    ["chat.general_phrases"]={"adminChat","generalPhrases","bool"},
    ["chat.repeat_phrases"]={"adminChat","repeatPhrases","bool"},
    ["chat.recent_join_phrases"]={"adminChat","recentJoinPhrases","bool"},
    ["chat.frequent_phrases"]={"adminChat","frequentPhrases","bool"},
    ["chat.historical_phrases"]={"adminChat","historicalPhrases","bool"},
    ["chat.waiting_phrases"]={"adminChat","waitingPhrases","bool"},
    ["chat.recent_join_seconds"]={"adminChat","recentJoinSeconds","number",30,600},
    ["recovery.escape_checks"]={"escape","enabled","bool"},
    ["recovery.probe_distance"]={"escape","probeDistance","number",2,8},
    ["recovery.reverse_max_speed"]={"escape","maxSpeed","number",1,5},
    ["recovery.refresh_after_arbotas"]={"recovery","refreshAfterArbotas","bool"},
    ["recovery.refresh_in_freeze_test"]={"recovery","typeRefreshInFreezeTest","bool"},
    ["recovery.require_ground"]={"escape","requireGround","bool"},
    ["recovery.attempt_limit"]={"recovery","repeatedAttemptLimit","integer",1,4},
    ["diagnostics.enabled"]={"diagnostics","enabled","bool"},
    ["diagnostics.x"]={"diagnostics","x","integer",0,4000},
    ["diagnostics.y"]={"diagnostics","y","integer",0,3000},
    ["vehicles.default_profile"]={"vehicle","defaultProfile","profile"},
}
VehicleProfiles.defaults = {
    standard={lateral_scale=1,braking_scale=1,steering_rate_scale=1,full_lock_scale=1,speed_scale=1,half_width=1.1,half_length=2.7},
    cautious={lateral_scale=0.8,braking_scale=0.85,steering_rate_scale=0.85,full_lock_scale=1.1,speed_scale=0.85,half_width=1.15,half_length=2.9},
    sport={lateral_scale=1.15,braking_scale=1.15,steering_rate_scale=1.1,full_lock_scale=1,speed_scale=1,half_width=1.1,half_length=2.7},
    heavy={lateral_scale=0.6,braking_scale=0.65,steering_rate_scale=0.75,full_lock_scale=1.2,speed_scale=0.75,half_width=1.5,half_length=4.2},
}
Settings.profileRanges = {lateral_scale={0.4,1.5},braking_scale={0.4,1.5},steering_rate_scale={0.4,1.5},
    full_lock_scale={0.7,1.8},speed_scale={0.3,1},half_width={0.7,2.5},half_length={1.5,8}}
function Settings.copy(value)
    if type(value) ~= "table" then return value end
    local result={};for key,item in pairs(value) do result[key]=Settings.copy(item) end;return result
end
Settings.defaults = Settings.copy(CONFIG)
VehicleProfiles.presets = Settings.copy(VehicleProfiles.defaults)
function Settings.parse(text)
    local candidate=Settings.copy(Settings.defaults)
    local profiles=Settings.copy(VehicleProfiles.defaults)
    local section,seen,lineNumber="",{},0
    for raw in (text.."\n"):gmatch("(.-)\n") do
        lineNumber=lineNumber+1
        local line=raw:gsub("\r$",""):match("^%s*(.-)%s*$")
        if line~="" and not line:match("^[#;]") then
            local header=line:match("^%[([%w_%.]+)%]$")
            if header then
                section=header:lower()
                if not ({driving=true,controls=true,chat=true,recovery=true,diagnostics=true,vehicles=true})[section]
                    and not VehicleProfiles.defaults[section:match("^profile%.([%w_]+)$") or ""] then
                    return nil,"line "..lineNumber..": unknown section"
                end
            else
                local key,value=line:match("^([%w_]+)%s*=%s*(.-)%s*$")
                if not key then return nil,"line "..lineNumber..": expected key = value" end
                key=key:lower();local full=section.."."..key
                if seen[full] then return nil,"line "..lineNumber..": duplicate "..full end
                seen[full]=true
                local spec=Settings.spec[full]
                local profile=section:match("^profile%.([%w_]+)$")
                local model=section=="vehicles" and key:match("^model_(%d+)$") or nil
                if profile then
                    local range=Settings.profileRanges[key];local number=tonumber(value)
                    if not range or not number or number~=number or number<range[1] or number>range[2] then
                        return nil,"line "..lineNumber..": invalid profile value"
                    end
                    profiles[profile][key]=number
                elseif model then
                    model=tonumber(model);value=value:lower()
                    if model<400 or model>611 or not profiles[value] then return nil,"line "..lineNumber..": invalid vehicle mapping" end
                    candidate.vehicle.modelProfiles[model]=value
                elseif spec then
                    if spec[3]=="bool" then
                        if value=="true" then value=true elseif value=="false" then value=false else return nil,"line "..lineNumber..": expected true/false" end
                    elseif spec[3]=="enum" then
                        if value~=spec[4] and value~=spec[5] then return nil,"line "..lineNumber..": invalid option" end
                    elseif spec[3]=="profile" then
                        if not profiles[value] then return nil,"line "..lineNumber..": unknown profile" end
                    else
                        value=tonumber(value)
                        if not value or value~=value or value<spec[4] or value>spec[5]
                            or (spec[3]=="integer" and value~=math.floor(value)) then return nil,"line "..lineNumber..": number outside allowed range" end
                    end
                    candidate[spec[1]][spec[2]]=value
                else return nil,"line "..lineNumber..": unknown "..full end
            end
        end
    end
    if candidate.adminChat.delayMinSeconds>candidate.adminChat.delayMaxSeconds then return nil,"chat delay minimum exceeds maximum" end
    if candidate.controls.input == "keyboard" then candidate.controls.steering = "bangbang" end
    return candidate,profiles
end
function Settings.load()
    local file=io.open(Settings.path,"rb")
    if not file then Settings.status="INI missing; settings unchanged";return false,Settings.status end
    local content=file:read(65537) or "";file:close()
    if #content>65536 then Settings.status="settings too large";return false,Settings.status end
    local candidate,profiles=Settings.parse(content)
    if not candidate then Settings.status=profiles;logEvent("SETTINGS",profiles);return false,profiles end
    if CONFIG.controls.input ~= candidate.controls.input then ControlManager.neutralize() end
    for key,value in pairs(candidate) do CONFIG[key]=value end
    routeRadius = CONFIG.route.radius
    VehicleProfiles.presets=profiles
    VehicleProfiles.activeName=CONFIG.vehicle.defaultProfile
    VehicleProfiles.lastUpdate=nil
    DrivingPlanner.cache=nil
    AdminChat.bag,AdminChat.bagKey={},nil
    S.smoothSteerValue=0
    if Settings.panel then Settings.panel.pending={} end
    Settings.status="loaded"
    logEvent("SETTINGS","INI loaded input="..CONFIG.controls.input.." steering="..CONFIG.controls.steering)
    return true
end
function VehicleProfiles.profile()
    return VehicleProfiles.presets[VehicleProfiles.activeName] or VehicleProfiles.presets.standard
end
function VehicleProfiles.driving(key)
    local factor=({lateralAcceleration="lateral_scale",brakingDeceleration="braking_scale"})[key]
    return CONFIG.driving[key]*(factor and VehicleProfiles.profile()[factor] or 1)
end
function VehicleProfiles.speedLimit(recorded)
    local limit=math.max(0,recorded or 0)*VehicleProfiles.profile().speed_scale
    if CONFIG.vehicle.maxSpeedKmh>0 then limit=math.min(limit,CONFIG.vehicle.maxSpeedKmh/3.6) end
    return limit
end
function VehicleProfiles.update(force)
    local now=os.clock()
    if not force and VehicleProfiles.lastUpdate and now-VehicleProfiles.lastUpdate<0.5 then return end
    VehicleProfiles.lastUpdate=now
    local car,model
    if isCharInAnyCar(PLAYER_PED) then
        car=storeCarCharIsInNoSave(PLAYER_PED)
        if API.carPointer then
            local ok,pointer=pcall(API.carPointer,car)
            pointer=ok and tonumber(pointer) or nil
            if pointer and pointer>=0x10000 then model=Mem.readWord(pointer+0x22) end
            if model and (model<400 or model>611) then model=nil end
        end
    end
    local name=CONFIG.vehicle.modelProfiles[model] or CONFIG.vehicle.defaultProfile
    if name~=VehicleProfiles.activeName or car~=VehicleProfiles.car or model~=VehicleProfiles.model then
        if S.bumpActive and VehicleProfiles.car~=nil and (car~=VehicleProfiles.car or model~=VehicleProfiles.model or name~=VehicleProfiles.activeName) then
            EscapePlanner.pause("vehicle changed during recovery",false)
        end
        VehicleProfiles.activeName,VehicleProfiles.car,VehicleProfiles.model=name,car,model
        DrivingPlanner.cache=nil;S.smoothSteerValue=0
        logEvent("VEHICLE",name.." model="..tostring(model or "unknown"))
    end
end

-- Cache route geometry by contiguous FWD/BACK leg. Distances are metres,
-- speeds m/s. Sample spacing removes dependence on recording point density.
function DrivingPlanner.build(route)
    local cache = {route=route, count=#route, legs={}, atIndex={}}
    local leg, previousMode
    local samplesTotal = 0
    for index, point in ipairs(route) do
        if type(point.x) ~= "number" or type(point.y) ~= "number"
            or point.x ~= point.x or point.y ~= point.y
            or math.abs(point.x) > 10000000 or math.abs(point.y) > 10000000 then return nil end
        local mode = routeDriveModeAt(route, index)
        if not leg or mode ~= previousMode then
            leg = {mode=mode, points={}, samples={}, curves={}, length=0, first=index, last=index}
            cache.legs[#cache.legs+1] = leg
        end
        local previous = leg.points[#leg.points]
        if previous then
            leg.length = leg.length + getDistanceBetweenCoords2d(point.x,point.y,previous.x,previous.y)
        end
        local entry = {x=point.x,y=point.y,s=leg.length,index=index}
        if not previous or entry.s-previous.s > 0.0001 then leg.points[#leg.points+1] = entry end
        leg.last = index
        cache.atIndex[index] = {leg=leg, offset=#leg.points}
        previousMode = mode
    end
    for _, item in ipairs(cache.legs) do
        local spacing = math.max(1, CONFIG.driving.sampleMeters)
        local nextSample = 0
        for i=2,#item.points do
            local a, b = item.points[i-1], item.points[i]
            local distance = b.s-a.s
            if distance > 0.001 then
                while nextSample <= b.s do
                    local t = clamp((nextSample-a.s)/distance,0,1)
                    item.samples[#item.samples+1] = {x=a.x+(b.x-a.x)*t,y=a.y+(b.y-a.y)*t,s=nextSample}
                    nextSample = nextSample+spacing
                    samplesTotal = samplesTotal+1
                    if samplesTotal > 50000 then return nil end
                end
            end
        end
        local last = item.points[#item.points]
        if last and (#item.samples == 0 or last.s-item.samples[#item.samples].s > 0.5) then
            item.samples[#item.samples+1] = last
        end
        if item.mode == DRIVE_FORWARD then
            for i=2,#item.samples-1 do
                local a,b,c = item.samples[i-1],item.samples[i],item.samples[i+1]
                local ab = getDistanceBetweenCoords2d(a.x,a.y,b.x,b.y)
                local bc = getDistanceBetweenCoords2d(b.x,b.y,c.x,c.y)
                local ac = getDistanceBetweenCoords2d(a.x,a.y,c.x,c.y)
                local cross = math.abs((b.x-a.x)*(c.y-a.y)-(b.y-a.y)*(c.x-a.x))
                local curvature = (ab*bc*ac > 0.001) and 2*cross/(ab*bc*ac) or 0
                local dot = (b.x-a.x)*(c.x-b.x)+(b.y-a.y)*(c.y-b.y)
                -- A reversal can be collinear, where the triangle area is zero.
                if dot < 0 and ab > 0.1 and bc > 0.1 then curvature = math.max(curvature,1/math.max(1,math.min(ab,bc))) end
                if curvature > 0.0001 then
                    item.curves[#item.curves+1] = {s=b.s, speed=math.max(CONFIG.driving.minCornerSpeed,
                        math.sqrt(VehicleProfiles.driving("lateralAcceleration")/curvature))}
                end
            end
        end
    end
    return cache
end

function DrivingPlanner.ensure(route)
    if not DrivingPlanner.cache or DrivingPlanner.cache.route ~= route or DrivingPlanner.cache.count ~= #route then
        DrivingPlanner.cache = DrivingPlanner.build(route) or {route=route,count=#route,atIndex={}}
    end
    return DrivingPlanner.cache
end

function DrivingPlanner.project(cache, index, x, y)
    local slot = cache.atIndex[index]
    if not slot then return nil end
    local leg, offset = slot.leg, slot.offset
    local bestS, bestDistance = leg.points[offset].s, math.huge
    -- Waypoint acceptance can run several metres ahead of the car. Project
    -- within a short backward arc of this leg, not across the whole route.
    local first = math.max(1,offset-1)
    while first > 1 and leg.points[offset].s-leg.points[first-1].s <= 25 do first=first-1 end
    for i=first,math.min(#leg.points-1,offset) do
        local a,b = leg.points[i],leg.points[i+1]
        local dx,dy = b.x-a.x,b.y-a.y
        local length2 = dx*dx+dy*dy
        local t = length2 > 0.000001 and clamp(((x-a.x)*dx+(y-a.y)*dy)/length2,0,1) or 0
        local px,py = a.x+t*dx,a.y+t*dy
        local distance = (x-px)^2+(y-py)^2
        if distance < bestDistance then bestDistance=distance;bestS=a.s+t*(b.s-a.s) end
    end
    return leg,bestS
end

function DrivingPlanner.pointAt(leg, distance)
    local points = leg.points
    distance = clamp(distance,0,leg.length)
    local lo,hi = 1,#points
    while lo < hi do
        local mid = math.floor((lo+hi+1)/2)
        if points[mid].s <= distance then lo=mid else hi=mid-1 end
    end
    local a,b = points[lo],points[math.min(#points,lo+1)]
    local t = b.s-a.s > 0.000001 and (distance-a.s)/(b.s-a.s) or 0
    return a.x+(b.x-a.x)*t,a.y+(b.y-a.y)*t
end

function DrivingPlanner.speedLimit(leg, progress, currentSpeed, recordedSpeed)
    local limit = math.max(0,recordedSpeed or 0)
    local reason = "route"
    if not CONFIG.driving.cornerBraking or leg.mode ~= DRIVE_FORWARD then return limit,reason end
    local curves = leg.curves
    local preview = math.min(CONFIG.driving.maxPreviewMeters,math.max(CONFIG.driving.previewMeters,
        currentSpeed^2/(2*VehicleProfiles.driving("brakingDeceleration"))+math.max(0,currentSpeed)*CONFIG.driving.reactionSeconds
        +CONFIG.driving.cornerMarginMeters))
    local lo,hi = 1,#curves+1
    while lo < hi do
        local mid = math.floor((lo+hi)/2)
        if curves[mid].s < progress-CONFIG.driving.sampleMeters then lo=mid+1 else hi=mid end
    end
    for i=lo,#curves do
        local corner = curves[i]
        local distance = corner.s-progress
        if distance > preview then break end
        local available = math.max(0,distance-CONFIG.driving.cornerMarginMeters
            -math.max(0,currentSpeed)*CONFIG.driving.reactionSeconds)
        local allowed = math.sqrt(corner.speed^2+2*VehicleProfiles.driving("brakingDeceleration")*available)
        if allowed < limit then limit,reason=allowed,"corner_braking" end
    end
    return limit,reason
end

function DrivingPlanner.target(route, index, x, y, speed)
    local cache = DrivingPlanner.ensure(route)
    local leg,progress = DrivingPlanner.project(cache,index,x,y)
    if not leg then return nil end
    local limit,reason = DrivingPlanner.speedLimit(leg,progress,speed,VehicleProfiles.speedLimit(route[index].speed))
    local lookahead = clamp(CONFIG.driving.minLookaheadMeters+math.min(math.max(0,speed),limit)*CONFIG.driving.lookaheadSeconds,
        CONFIG.driving.minLookaheadMeters,CONFIG.driving.maxLookaheadMeters)
    if CONFIG.driving.lowFpsTolerance then
        lookahead = math.min(24,lookahead+math.max(0,speed)*math.max(0,(S.playbackDt or 1/30)-1/30)*2)
    end
    local stride = CONFIG.driving.steeringPointStride
    if CONFIG.controls.input == "keyboard" then
        -- Follow a point along the continuous path instead of jumping targets
        -- at sample-group boundaries. Stride provides a minimum preview distance.
        lookahead=math.max(lookahead,8+stride*0.4)
        local tx,ty=DrivingPlanner.pointAt(leg,math.min(leg.length,progress+lookahead))
        DrivingPlanner.heldTarget=nil
        return tx,ty,limit,reason
    end
    local offset = cache.atIndex[index].offset
    local group = math.floor((offset-1)/stride)
    local held = DrivingPlanner.heldTarget
    -- Hold the steering aim for this group, but refresh before it falls behind.
    if stride == 1 or not held or held.route ~= route or held.leg ~= leg or held.group ~= group
        or held.stride ~= stride or progress+CONFIG.driving.minLookaheadMeters >= held.distance
        or (held.x-x)^2+(held.y-y)^2 <= CONFIG.driving.minLookaheadMeters^2 then
        local distance = math.min(leg.length,progress+lookahead)
        local tx,ty = DrivingPlanner.pointAt(leg,distance)
        held = {route=route,leg=leg,group=group,stride=stride,distance=distance,x=tx,y=ty}
        DrivingPlanner.heldTarget = held
    end
    return held.x,held.y,limit,reason
end

function DrivingPlanner.steering(errorDegrees, speed, previous, dt)
    local fullLock = CONFIG.controls.smoothFullLockDegrees*VehicleProfiles.profile().full_lock_scale+math.min(20,math.max(0,speed-10)*0.35)
    local desired = math.abs(errorDegrees) < 0.75 and 0 or clamp(errorDegrees/fullLock*128,-128,128)
    local alpha = 1-math.exp(-dt/CONFIG.controls.smoothResponseSeconds)
    local change = (desired-previous)*alpha
    local maxChange = CONFIG.controls.smoothRatePerSecond*VehicleProfiles.profile().steering_rate_scale*dt
    return clamp(previous+clamp(change,-maxChange,maxChange),-128,128)
end

local function getSplineTarget(route, idx)
    local n = #route
    local i0 = math.max(1, idx - 1)
    local i1 = math.max(1, idx)
    local i2 = math.min(n, idx + LOOKAHEAD)
    local i3 = math.min(n, idx + LOOKAHEAD + 1)
    return cr(route[i0].x, route[i1].x, route[i2].x, route[i3].x, 0.5),
           cr(route[i0].y, route[i1].y, route[i2].y, route[i3].y, 0.5),
           cr(route[i0].z, route[i1].z, route[i2].z, route[i3].z, 0.5)
end

-- Binary keyboard corrections with anticipation and time-based neutral intervals.
-- No analogue pad values: output is always -128, 0 or 128.
function DrivingPlanner.keyboardSteer(err,speed,dt)
    local now=os.clock()
    dt=clamp(dt or 1/30,1/120,0.2)
    local c=S.keyboardController
    if not c or now-(c.at or now)>0.35 then
        c={at=now,error=err,rate=0,lastDirection=0,output=0,restUntil=0}
        S.keyboardController=c
    end
    local delta=(err-c.error+180)%360-180
    -- A changed target or teleport is not vehicle rotation.
    if math.abs(delta)>35 then c.rate=0
    else c.rate=c.rate+(clamp(delta/dt,-100,100)-c.rate)*(1-math.exp(-dt/0.16)) end
    c.error,c.at=err,now
    local predicted=err+c.rate*0.20
    local engage=clamp(7+CONFIG.driving.lateralTolerance,9,12)
    local release=engage*0.45
    local wanted=0
    if math.abs(err)>=engage and err*predicted>0 and math.abs(predicted)>release then
        wanted=err<0 and -128 or 128
    end
    -- Hold a useful same-direction correction down to the wider release band.
    if c.output~=0 and err*c.output>0 and predicted*c.output>0 and math.abs(predicted)>release then wanted=c.output end
    if wanted~=0 and c.lastDirection~=0 and wanted~=c.lastDirection then
        if c.opposite~=wanted then c.opposite=wanted;c.oppositeSince=now end
        c.output=0
        c.restUntil=math.max(c.restUntil, c.oppositeSince+0.24)
        if now-c.oppositeSince<0.24 then return 0 end
    else c.opposite=nil;c.oppositeSince=nil end
    if wanted==0 then
        if c.output~=0 then c.restUntil=math.max(c.restUntil,now+0.14) end
        c.output=0;return 0
    end
    if now<c.restUntil then c.output=0;return 0 end
    if c.output~=0 and now>=c.pulseUntil then
        c.output=0
        c.restUntil=now+clamp(0.12+math.max(0,speed-10)*0.003,0.12,0.22)
        return 0
    end
    if c.output==0 then
        c.pulseUntil=now+clamp(0.08+math.abs(predicted)*0.002-math.max(0,speed-10)*0.001,0.07,0.24)
        c.lastDirection=wanted
    end
    c.output=wanted
    return wanted
end

local function turning_mechanism(posX, posY, carPosX, carPosY, car)
    local relative = math.rad(getHeadingFromVector2d(posX - carPosX, posY - carPosY) + math.abs(getCarHeading(car) - 360.0))
    local heading = getHeadingFromVector2d(math.deg(math.sin(relative)), math.deg(math.cos(relative)))
    local steer
    if CONFIG.controls.input == "keyboard" then
        local err = heading <= 180 and heading or heading-360
        steer = DrivingPlanner.keyboardSteer(err,math.abs(S.forwardSpeed or getCarSpeed(car)),S.playbackDt)
    elseif CONFIG.controls.steering == "smooth" then
        -- Signed angle to the target: positive = target on the right.
        local err = heading <= 180.0 and heading or heading - 360.0
        local dt = frameScale/(CONFIG.timing.referenceFps or 30)
        S.smoothSteerValue = DrivingPlanner.steering(err,math.abs(S.forwardSpeed or getCarSpeed(car)),S.smoothSteerValue or 0,dt)
        steer = math.floor(S.smoothSteerValue+0.5)
    elseif CONFIG.driving.lowFpsTolerance then
        local err = heading <= 180 and heading or heading-360
        local distance = math.sqrt((posX-carPosX)^2+(posY-carPosY)^2)
        local slow = clamp(((S.playbackDt or 1/30)-1/30)/(0.1-1/30),0,1)
        local threshold = clamp(math.deg(math.atan(CONFIG.driving.lateralTolerance/math.max(4,distance))),5,10)+slow*4
        local previous = S.digitalSteer or 0
        local wanted = math.abs(err) >= threshold and (err < 0 and -128 or 128) or 0
        if previous ~= 0 and err*previous > 0 and math.abs(err) > threshold*0.8 then wanted=previous end
        -- Release before reversing direction; never replay a stale two-frame turn.
        if previous*wanted < 0 then
            S.digitalReverseAfter = os.clock()+0.12
            steer = 0
        elseif previous == 0 and os.clock() < (S.digitalReverseAfter or 0) then
            steer = 0
        else
            steer = wanted
        end
        S.digitalSteer = steer
    elseif heading > 180.0 and 355.0 > heading then
        steer = -128
    elseif heading > 5.0 and 180.0 >= heading then
        steer = 128
    else
        steer = 0
    end
    if CONFIG.controls.input ~= "keyboard" and CONFIG.controls.steering ~= "smooth" and not CONFIG.driving.lowFpsTolerance then
        table.insert(steerBuf, steer)
        steer = table.remove(steerBuf, 1)
    end
    lastSteerValue = steer
    writeSteerControls(steer)
end

-- Player input only counts while the game window is active; keys typed into
-- other programs must not trigger OVERRIDE.
local function isPhysicalKeyDown(vk)
    if not Win32.isGameForeground() then return false end
    if Win32.held[vk] then return false end
    if isKeyDown(vk) then return true end
    return Win32.keyDown(vk)
end

local function fileExists(path)
    local file = io.open(path, "r")
    if file then
        file:close()
        return true
    end
    return false
end

local function readSharedFile(path)
    local file = io.open(path, "r")
    if not file then return nil end
    local value = file:read("*l")
    file:close()
    return value
end

local lastSharedStateText = nil
local lastSharedStateWriteAt = -1.0

-- Read by hud_aswd.lua and test_freeze.lua. A new state is written at once;
-- an unchanged one at most every 50 ms instead of every frame.
-- Lines: state, applied gas/brake/steer, timestamp, reversing (1/0), owner.
local function writeSharedState(state)
    state = ControlManager.sharedState(tostring(state or "IDLE"))
    local now = os.clock()
    if state == lastSharedStateText and now - lastSharedStateWriteAt < 0.05 then return end
    local file = io.open(shared_state_file, "w")
    if not file then return end
    file:write(state .. "\n")
    file:write(tostring(math.floor(ControlManager.applied.gas or 0)) .. "\n")
    file:write(tostring(math.floor(ControlManager.applied.brake or 0)) .. "\n")
    file:write(tostring(math.floor(ControlManager.applied.steer or 0)) .. "\n")
    file:write(string.format("%.3f\n", now))
    file:write((reverseActive and "1" or "0") .. "\n")
    file:write(ControlManager.owner .. "\n")
    file:close()
    lastSharedStateText = state
    lastSharedStateWriteAt = now
    if state ~= lastLoggedSharedState then
        logEvent("STATE", tostring(lastLoggedSharedState or "nil") .. " -> " .. state)
        lastLoggedSharedState = state
    end
end

-- Another script can create the flag after the control thread's poll and
-- before playback. Safety gates and writers must never reuse a cached false.
-- Keep forceRead accepted for the existing control-thread call; all reads are live.
sharedFreezeActive = function(forceRead)
    return fileExists(freeze_flag_file)
end

local function freezeRecoveryOwnsControls()
    return S.freezeTestLatched == true
        or S.frozenByAdmin == true
        or sharedFreezeActive()
end

local function consumeRotateFlag()
    local file = io.open(rotate_flag_file, "r")
    if not file then return nil end
    local mode = file:read("*l")
    local stamp = tonumber(file:read("*l") or "")
    file:close()
    os.remove(rotate_flag_file)
    if mode ~= "safe" and mode ~= "rotate" then return nil end
    if stamp and os.clock() - stamp > 3.0 then return nil end
    return mode
end

function clearRotateTrigger()
    os.remove(rotate_flag_file)
end

local function sharedDialogMode()
    return readSharedFile(dialog_flag_file)
end

local function isSampDialogActive()
    if samp == 0 then return false end
    local dPtr = Mem.readDword(samp + 0x21A0B8)
    if not dPtr or dPtr == 0 then return false end
    if dPtr < 0x01000000 or dPtr > 0x7FFFFFFF then return false end
    return Mem.readDword(dPtr + 0x28) == 1
end

-- Checked against the primary R1 CInput packed layout: three pointers,
-- 144 command pointers, 144*33 name bytes, count, then BOOL enabled.
-- Unknown returns nil so automatic reactions fail closed.
local function isSampChatInputActive()
    if samp == 0 then return nil end
    local pointer = Mem.readDword(samp + CONFIG.adminChat.chatInputPointerOffset)
    if not pointer or pointer < 0x01000000 or pointer > 0x7FFFFFFF then return nil end
    local enabled = Mem.readDword(pointer + CONFIG.adminChat.chatEnabledOffset)
    if enabled ~= 0 and enabled ~= 1 then return nil end
    return enabled == 1
end

-- Driving owns its own held-key set, separate from the chat typing job.
Win32.driveHeld = {}
function Win32.drive(gas,brake,steer,reverse)
    local wanted = {}
    local owner = ControlManager.owner
    local allowed = owner == "ROUTE" or owner == "BUMP" or owner == "ROTATE"
    allowed = allowed and Win32.isGameForeground(true) and not isSampDialogActive()
        and isSampChatInputActive() == false and not S.adminChatTyping
    if allowed then
        if reverse or (brake > 0 and (S.forwardSpeed or 0) > CONFIG.controls.footBrakeMinSpeed) then
            wanted[0x53] = true
        elseif gas > 0 then wanted[0x57] = true end
        if steer < 0 then wanted[0x41] = true elseif steer > 0 then wanted[0x44] = true end
    end
    -- Release before pressing the opposite direction/pedal. Unrelated human or
    -- chat keys are not released here; only keys this driving job owns.
    for vk in pairs(Win32.driveHeld) do
        if not wanted[vk] then
            if Win32.held[vk] then Win32.release(vk) end
            Win32.driveHeld[vk] = nil
        end
    end
    for vk in pairs(wanted) do
        if not Win32.driveHeld[vk] or not Win32.held[vk] then
            if Win32.press(vk) then Win32.driveHeld[vk] = true end
        end
    end
    return {gas=Win32.driveHeld[0x57] and 255 or 0,
        brake=Win32.driveHeld[0x53] and 255 or 0,
        steer=Win32.driveHeld[0x41] and -128 or (Win32.driveHeld[0x44] and 128 or 0),
        reverse=reverse and Win32.driveHeld[0x53] == true}
end

-- 09E7, documented by MoonLoader: true means player movement is enabled.
-- nil is unavailable or UI-suppressed; do not mistake chat/dialogs for freezes.
function RecoverySystem.controlLockState()
    if not playing or not isCharInAnyCar(PLAYER_PED) then return nil end
    if not API.playerControlOn or PLAYER_HANDLE == nil then return nil end
    if not Win32.isGameForeground(true) or isSampDialogActive()
        or S.dialogPaused or S.testArbotasPaused or sharedDialogMode() == "fake_arbotas"
        or os.clock() < (S.dialogReleaseUntil or 0) or S.adminChatTyping
        or isSampChatInputActive() ~= false then return nil end
    local ok,enabled = pcall(API.playerControlOn,PLAYER_HANDLE)
    if not ok or type(enabled) ~= "boolean" then return nil end
    return not enabled
end

function hasPauseSource(now, ignoreChatHold)
    now = now or os.clock()
    -- Bump recovery and R >> FWD are not pause sources: the playback thread
    -- must keep ticking so those recovery mini-states can finish cleanly.
    return (S.adminChatTyping and not ignoreChatHold)
        or isSampChatInputActive() == true
        or S.manualPaused
        or S.dialogPaused
        or S.testArbotasPaused
        or now < S.dialogReleaseUntil
        or S.frozenByAdmin
        or S.freezeTestLatched
        or now < S.rotateFightUntil
        or now < S.rotateReleaseUntil
end

function syncPausedState(now)
    paused = hasPauseSource(now)
    if not paused then
        pauseReleaseReason = ""
    end
    return paused
end

local function releaseControls(reason)
    pauseReleaseReason = reason or pauseReleaseReason or "SAFE"
    gasLevel = 0
    brakeLevel = 0
    lastSteerValue = 0
    ControlManager.neutralize()
    reverseActive = false
    writeSharedState(pauseReleaseReason)
end

local function pressRotateReaction()
    -- Compatibility entry point: the old forced-throttle reaction is removed.
    releaseControls("ROTATE_HOLD")
end

-- Only inspect the contiguous recorded leg around the current index.
-- A nearby coordinate on a distant/crossing leg is not a valid fallback.
function RouteFollower.findRejoin(route, cx, cy, center, back, ahead, maxDist, heading, predicate)
    if #route == 0 then return 1, false end
    center = math.max(1, math.min(center or 1, #route))
    local mode = routeDriveModeAt(route, center)
    local best, bestScore = center, math.huge
    local accepted = false
    local arcLimit = CONFIG.recovery.rejoinMaxArcMeters or 60.0
    local minDot = math.cos(math.rad(CONFIG.recovery.rejoinHeadingMaxDegrees or 70.0))
    local function candidate(i, arc)
        local point = route[i]
        local distance = getDistanceBetweenCoords2d(cx, cy, point.x, point.y)
        if distance > maxDist then return end
        local alignmentCost = 0
        if heading ~= nil then
            local other = route[i + 1]
            local dx, dy
            if other and routeDriveModeAt(route, i + 1) == mode then
                dx, dy = other.x - point.x, other.y - point.y
            elseif i > 1 and routeDriveModeAt(route, i - 1) == mode then
                dx, dy = point.x - route[i - 1].x, point.y - route[i - 1].y
            end
            local length = dx and math.sqrt(dx * dx + dy * dy) or 0
            if length > 0.05 then
                local angle = math.rad(heading)
                local fx, fy = -math.sin(angle), math.cos(angle)
                if mode == DRIVE_BACK then fx, fy = -fx, -fy end
                local dot = (dx * fx + dy * fy) / length
                if dot < minDot then return end
                alignmentCost = (1 - dot) * 2.0
            end
        end
        local score = distance
        if predicate then
            score = predicate(i, point, distance)
            if score == nil then return end
        end
        score = score + arc * 0.05 + alignmentCost
        if score < bestScore then best, bestScore, accepted = i, score, true end
    end
    candidate(center, 0)
    for _, direction in ipairs({-1, 1}) do
        local count = direction < 0 and back or ahead
        local arc, previous = 0, route[center]
        for offset = 1, count do
            local i = center + direction * offset
            local point = route[i]
            if not point or routeDriveModeAt(route, i) ~= mode then break end
            arc = arc + getDistanceBetweenCoords2d(previous.x, previous.y, point.x, point.y)
            if arc > arcLimit then break end
            candidate(i, arc)
            previous = point
        end
    end
    return best, accepted
end

local function findNearestWaypointNear(route, carX, carY, centerIdx, back, ahead, maxDist, heading)
    return RouteFollower.findRejoin(route, carX, carY, centerIdx, back, ahead, maxDist, heading)
end

-- One bounded, session-local trouble area. Completed attempts remain pending
-- until actual forward movement plus route progress confirms escape.
function RecoveryMemory.reset(reason)
    if reason and (RecoveryMemory.attempts or 0) > 0 then logEvent("RECOVERY", "memory cleared: " .. reason) end
    RecoveryMemory.route, RecoveryMemory.attempts = nil, 0
    RecoveryMemory.active, RecoveryMemory.blocked = false, false
    S.recoveryBlockedReason, S.recoveryBlockedCode = nil, nil
end

function RecoveryMemory.plan(route, index, x, y, now)
    if RecoveryMemory.route ~= route
        or now - (RecoveryMemory.updatedAt or now) > (CONFIG.recovery.recoveryMemorySeconds or 60)
        or (RecoveryMemory.x and getDistanceBetweenCoords2d(x, y, RecoveryMemory.x, RecoveryMemory.y)
            > (CONFIG.recovery.recoveryAreaRadius or 15)) then
        RecoveryMemory.reset()
    end
    if not RecoveryMemory.route then
        RecoveryMemory.route, RecoveryMemory.index = route, index
        RecoveryMemory.x, RecoveryMemory.y = x, y
        RecoveryMemory.attempts = 0
    end
    RecoveryMemory.updatedAt = now
    if RecoveryMemory.attempts >= (CONFIG.recovery.repeatedAttemptLimit or 2) then
        RecoveryMemory.blocked = true
        return nil
    end
    RecoveryMemory.active = true
    return RecoveryMemory.attempts + 1
end

function RecoveryMemory.finish(outcome)
    if not RecoveryMemory.active then return end
    RecoveryMemory.active = false
    RecoveryMemory.attempts = RecoveryMemory.attempts + 1
    RecoveryMemory.updatedAt = os.clock()
    logEvent("RECOVERY", string.format("attempt %d outcome=%s; awaiting forward escape", RecoveryMemory.attempts, outcome))
end

function RecoveryMemory.cancel()
    -- Manual/dialog/freeze-test interruption is not a failed attempt.
    RecoveryMemory.active = false
end

function RecoveryMemory.observe(route, index, x, y, forwardSpeed)
    if RecoveryMemory.route ~= route or RecoveryMemory.active or RecoveryMemory.blocked
        or S.bumpActive or freezeRecoveryOwnsControls() then return end
    if routeDriveModeAt(route, index) ~= DRIVE_FORWARD then return end
    local forward = forwardSpeed and forwardSpeed > 2.0
        or (forwardSpeed == nil and ControlManager.applied.gas > 0)
    if forward and index >= (RecoveryMemory.index or index) + 3
        and getDistanceBetweenCoords2d(x, y, RecoveryMemory.x, RecoveryMemory.y)
            >= (CONFIG.recovery.recoveryEscapeDistance or 8) then
        RecoveryMemory.reset("forward escape confirmed")
    end
end

local function resetForwardNoProgress()
    S.forwardNoProgressFrames = 0
    S.forwardNoProgressDist = 0.0
    S.forwardNoProgressIndex = 0
end

resetBumpState = function(clearCooldown)
    RecoveryMemory.cancel()
    S.bumpActive = false
    S.bumpPhase = ""
    S.bumpReason = ""
    S.bumpUntil = 0.0
    S.bumpStartedAt = 0.0
    S.bumpStartX = 0.0
    S.bumpStartY = 0.0
    S.bumpMinDistance = 0.0
    S.bumpMaxDistance = 0.0
    S.bumpSteer = 0
    S.bumpPlan = nil
    S.bumpNextProbeAt = 0
    if clearCooldown then
        S.bumpCooldownUntil = 0.0
        S.bumpGraceUntil = 0.0
    end
    resetForwardNoProgress()
end

local function startFreezeRecovery(mode)
    local now = os.clock()
    if S.freezeTestLatched then
        releaseControls(pauseReleaseReason ~= "" and pauseReleaseReason or "FREEZE_WAIT")
        return true
    end
    local waitBeforeRefresh = math.random(
        math.floor((CONFIG.recovery.freezeWaitBeforeRefreshMinSeconds or 2.0) * 1000),
        math.floor((CONFIG.recovery.freezeWaitBeforeRefreshMaxSeconds or 3.0) * 1000)
    ) / 1000.0
    local resumeDelay = math.random(
        math.floor((CONFIG.recovery.freezeResumeDelayMinSeconds or 0.5) * 1000),
        math.floor((CONFIG.recovery.freezeResumeDelayMaxSeconds or 1.0) * 1000)
    ) / 1000.0
    resetBumpState(false)
    S.backToForwardUntil = 0.0
    S.freezeTestLatched = true
    S.freezeRecoveryMode = mode or "real"
    S.freezeChatToken = S.freezeRecoveryMode ~= "arbotas" and (S.freezeRecoveryMode == "test" or S.freezeRecoveryMode == "control_lock" or CONFIG.adminChat.includeInferredTests)
        and AdminChat.begin("freeze") or nil
    S.freezeStartX, S.freezeStartY = lastX, lastY
    if isCharInAnyCar(PLAYER_PED) then
        S.freezeStartX, S.freezeStartY = getCarCoordinates(storeCarCharIsInNoSave(PLAYER_PED))
    end
    S.frozenByAdmin = true
    S.refreshSent = false
    S.refreshJob = nil
    S.refreshBlockedReason = nil
    S.freezeRefreshSentAt = 0.0
    S.freezeRefreshAt = now + waitBeforeRefresh
    S.freezeReleaseUntil = 0.0
    S.freezeResumeDelay = resumeDelay
    releaseControls("FREEZE_WAIT")
    freezeTimer = 0
    suddenStopFrames = 0
    syncPausedState(now)
    logEvent("RECOVERY", string.format("freeze recovery wait %.2fs resume %.2fs mode=%s",
        waitBeforeRefresh, resumeDelay, tostring(S.freezeRecoveryMode)))
    return true
end

local function resetFreezeRecovery()
    local chatToken, localTest = S.freezeChatToken, S.freezeRecoveryMode == "test"
    local afterDialog = S.freezeRecoveryMode == "arbotas"
    local controlLock = S.freezeRecoveryMode == "control_lock"
    S.freezeChatToken = nil
    local cx, cy = lastX, lastY
    if isCharInAnyCar(PLAYER_PED) then
        local car = storeCarCharIsInNoSave(PLAYER_PED)
        cx, cy = getCarCoordinates(car)
        if playing and #current_route > 0 and not afterDialog then
            play_index = findNearestWaypointNear(current_route, cx, cy, play_index, 20, 150, 25.0, getCarHeading(car))
        end
    end

    S.freezeTestLatched = false
    S.freezeRecoveryMode = ""
    S.frozenByAdmin = false
    S.refreshSent = false
    S.refreshJob = nil
    -- A test flag that is still set has been handled: hold still until it is
    -- removed instead of starting another recovery (and another /refresh).
    S.externalFreezeAck = sharedFreezeActive()
    S.freezeRefreshSentAt = 0.0
    S.freezeReleaseUntil = 0.0
    S.freezeRefreshAt = 0.0
    S.freezeResumeDelay = 0.0
    S.freezeRecoveryGraceUntil = os.clock() + (CONFIG.recovery.freezeRecoveryGraceSeconds or 2.1)
    S.reversePlaybackGraceUntil = 0.0
    S.backToForwardUntil = 0.0
    resetBumpState(true)
    S.currentLateral = 0.0
    S.nudgeFrames = 0
    S.nudgeOffset = 0.0
    S.routeObstacleDist = math.huge
    S.routeAvoidDir = 0
    S.routeObstacleUrgency = 0.0
    S.routeObstacleTimer = 0
    S.obstacleHits = {}
    S.obstacleProbes = {}
    S.rejoinCooldownUntil = 0.0
    S.rejoinDisableUntil = os.clock() + 2.5
    resetObstacleBypass()
    S.avoidClusterCount = 0
    collisionCooldown = 0
    avoidSteerDir = 0
    S.avoidRouteDir = 0
    S.avoidSideHit = false
    gasLevel = 0
    brakeLevel = 0
    lastSteerValue = 0
    steerBuf = {0, 0}
    freezeTimer = 0
    suddenStopFrames = 0
    lastDriveSpeed = 0.0
    S.recentDriveSpeed = 0.0
    S.recentDriveUntil = 0.0
    lastX, lastY = cx, cy
    syncPausedState()
    if chatToken then
        local queued = AdminChat.complete("freeze", chatToken, localTest)
        if controlLock and queued then S.controlLockReplyPending = chatToken end
    end
end

local function obstacleColor(kind, urgent, sideScan)
    if urgent then return 0xFFFF4444 end
    if kind == "car" then return sideScan and 0xFFFFCC55 or 0xFFFFAA33 end
    if kind == "solid" then return sideScan and 0xFFFFFF99 or 0xFFFFFF55 end
    if kind == "ped" then return 0xFFFF66FF end
    return sideScan and 0xFF66FFFF or 0xFF33DDFF
end

local function obstacleTag(kind)
    if kind == "car" then return "C" end
    if kind == "solid" then return "W" end
    if kind == "ped" then return "P" end
    if kind == "obj" then return "O" end
    return "?"
end

local function obstacleLabel(hit)
    if hit and hit.modelId then return "O" .. tostring(hit.modelId) end
    if not hit then return "?" end
    return obstacleTag(hit.kind)
end

local function clamp01(value)
    if value < 0.0 then return 0.0 end
    if value > 1.0 then return 1.0 end
    return value
end

function clamp(value, low, high)
    if value < low then return low end
    if value > high then return high end
    return value
end

-- Per-frame smoothing rates were tuned at CONFIG.timing.referenceFps; this
-- gives the same response per second at any frame rate.
local function scaledLerp(rate)
    return 1.0 - (1.0 - rate) ^ frameScale
end

local function obstacleUrgency(hit)
    if not hit then return 0.0 end
    local worldDist = hit.worldDist or 999.0
    local lateral = hit.lateral or 99.0
    if hit.sideScan then
        local clearance = hit.clearance or lateral
        local near = clamp01((18.0 - worldDist) / 13.0)
        local scrape = clamp01((3.4 - clearance) / 3.4)
        return clamp01(near * (0.20 + scrape * 0.80))
    end

    local near = clamp01((42.0 - worldDist) / 36.0)
    local center = clamp01((2.8 - lateral) / 2.8)
    return clamp01(near * (0.25 + center * 0.75))
end

function computeObstacleClusterPlan()
    local bestDist = math.huge
    local weightedSide = 0.0
    local weightSum = 0.0
    local leftThreat = 0.0
    local rightThreat = 0.0
    local centerThreat = 0.0
    local count = 0

    for i = 1, math.min(#S.obstacleHits, 28) do
        local hit = S.obstacleHits[i]
        local modelOk = hit.kind == "car" or (hit.kind == "obj" and shouldAvoidObjectModel(hit.modelId))
        local d = hit.worldDist or 999.0
        local forward = hit.forward or d
        local lateral = hit.carLateral or 0.0
        local clearance = math.abs(lateral)
        if modelOk and d > 2.0 and d < 62.0 and forward > -1.0 and clearance < 5.4 then
            local corridor = clamp01((5.4 - clearance) / 5.4)
            local approach = clamp01((62.0 - d) / 56.0)
            local weight = (0.35 + corridor * 1.45) * (0.35 + approach)
            if clearance < 2.8 then weight = weight + 0.65 end
            if clearance < 1.4 then centerThreat = centerThreat + weight end
            if lateral >= 0.0 then
                leftThreat = leftThreat + weight
            else
                rightThreat = rightThreat + weight
            end
            weightedSide = weightedSide + lateral * weight
            weightSum = weightSum + weight
            count = count + 1
            if d < bestDist then bestDist = d end
        end
    end

    if count == 0 then return math.huge, 0, 0.0, 0 end

    local dir = 0
    if math.abs(weightedSide) < 0.35 or centerThreat > 0.75 then
        dir = leftThreat <= rightThreat and 1 or -1
    elseif weightedSide > 0.0 then
        dir = -1
    else
        dir = 1
    end

    local urgency = clamp01((62.0 - bestDist) / 56.0 + math.min(0.45, weightSum * 0.055))
    if bestDist < 36.0 then urgency = math.max(urgency, 0.38) end
    if bestDist < 18.0 then urgency = math.max(urgency, 0.62) end
    return bestDist, dir, urgency, count
end

function updateObstacleBypass(now)
    local seen = S.routeObstacleDist < 62.0
        and S.routeAvoidDir ~= 0
        and (S.routeObstacleUrgency or 0.0) > 0.04

    if seen then
        local dir = S.routeAvoidDir > 0 and 1 or -1
        if not S.bypassActive or now > (S.bypassHoldUntil or 0.0) + 0.8 or S.bypassDir == 0 then
            S.bypassDir = dir
            S.bypassOffset = math.max(math.abs(S.currentLateral or 0.0), 2.15)
        elseif dir ~= S.bypassDir then
            -- A cone line can produce alternating side hits; keep the committed
            -- lane choice instead of zig-zagging through the divider.
            dir = S.bypassDir
        end

        S.bypassActive = true
        S.bypassReturning = false
        S.bypassLastSeen = now

        local urgency = clamp01(S.routeObstacleUrgency or 0.0)
        local distFactor = clamp01((58.0 - S.routeObstacleDist) / 52.0)
        local countFactor = clamp01(((S.avoidClusterCount or 0) - 1) / 7.0)
        local wantedOffset = 2.30 + urgency * 0.35 + distFactor * 0.25 + countFactor * 0.35
        if S.routeObstacleDist < 28.0 then wantedOffset = math.max(wantedOffset, 2.65) end
        if S.routeObstacleDist < 14.0 then wantedOffset = math.max(wantedOffset, 2.90) end
        wantedOffset = clamp(wantedOffset, 2.20, 3.25)

        S.bypassOffset = S.bypassOffset + (wantedOffset - S.bypassOffset) * scaledLerp(0.16)
        S.bypassOffset = clamp(S.bypassOffset, 0.0, 3.25)
        local hold = math.max(2.6, math.min(5.4, 1.9 + S.routeObstacleDist * 0.05 + (S.avoidClusterCount or 0) * 0.22))
        S.bypassHoldUntil = math.max(S.bypassHoldUntil or 0.0, now + hold)
        S.avoidHoldUntil = S.bypassHoldUntil
        S.avoidLateralTarget = S.bypassDir * S.bypassOffset
        return true
    end

    if S.bypassActive then
        if now <= (S.bypassHoldUntil or 0.0) then
            S.avoidLateralTarget = (S.bypassDir or 0) * (S.bypassOffset or 0.0)
            return true
        end

        S.bypassReturning = true
        S.avoidLateralTarget = (S.avoidLateralTarget or 0.0) * (0.985 ^ frameScale)
        S.bypassOffset = math.abs(S.avoidLateralTarget)
        if math.abs(S.avoidLateralTarget) < 0.08 and math.abs(S.currentLateral or 0.0) < 0.18 then
            resetObstacleBypass()
            return false
        end
        return true
    end

    return false
end

local function draw_line(posX, posY, carX, carY, carZ, color)
    color = color or COLOR_ROUTE_FORWARD
    local chPosX, chPosY, chPosZ = getCharCoordinates(PLAYER_PED)
    if isPointOnScreen(posX, posY, chPosZ, 0.0) then
        local wPosX, wPosY = convert3DCoordsToScreen(posX, posY, chPosZ)
        local wPosX1, wPosY1 = convert3DCoordsToScreen(chPosX, chPosY, chPosZ)
        if color == COLOR_ROUTE_BACK then
            renderDrawLine(wPosX1, wPosY1, wPosX, wPosY, 4, COLOR_ROUTE_BACK_OUTLINE)
        end
        renderDrawLine(wPosX1, wPosY1, wPosX, wPosY, 2, color)
        renderDrawPolygon(wPosX, wPosY, 10, 10, 14, 0.0, 0xFF000000)
        renderDrawPolygon(wPosX1, wPosY1, 10, 10, 14, 0.0, 0xFF000000)
    end
    if not S.showObstacleDots or (S.obstacleDebugMode or 0) <= 0 then return end
    if not S.obstacleFont then
        S.obstacleFont = renderCreateFont("Segoe UI", 10, 0)
    end

    carX = carX or chPosX
    carY = carY or chPosY
    carZ = carZ or chPosZ

    local debugMode = S.obstacleDebugMode or 1
    for i = 1, math.min(#S.obstacleProbes, debugMode >= 2 and 140 or 60) do
        local probe = S.obstacleProbes[i]
        local pz = probe.z or carZ
        if getDistanceBetweenCoords2d(carX, carY, probe.x, probe.y) < 160 and isPointOnScreen(probe.x, probe.y, pz, 0.0) then
            local psx, psy = convert3DCoordsToScreen(probe.x, probe.y, pz)
            if debugMode >= 2 and probe.fromX and isPointOnScreen(probe.fromX, probe.fromY, probe.fromZ or pz, 0.0) then
                local fsx, fsy = convert3DCoordsToScreen(probe.fromX, probe.fromY, probe.fromZ or pz)
                local probeColor = probe.hit
                    and obstacleColor(probe.kind or "obj", false, probe.sideScan == true)
                    or (probe.sideScan and 0x8855DDFF or 0x8855FF55)
                renderDrawLine(fsx, fsy, psx, psy, probe.hit and 1.2 or 0.8, probeColor)
            end
            local dotColor = probe.hit
                and obstacleColor(probe.kind or "obj", false, probe.sideScan == true)
                or (probe.sideScan and 0xAA55DDFF or 0xAA55FF55)
            renderDrawPolygon(psx, psy, probe.hit and 5 or 3, probe.hit and 5 or 3, 10, 0.0, dotColor)
        end
    end

    if #S.obstacleHits == 0 then return end

    local best = S.obstacleHits[1]
    local csx, csy = convert3DCoordsToScreen(chPosX, chPosY, chPosZ)
    for i = 1, math.min(#S.obstacleHits, 6) do
        local hit = S.obstacleHits[i]
        if getDistanceBetweenCoords2d(carX, carY, hit.x, hit.y) < 140 and isPointOnScreen(hit.x, hit.y, hit.z or carZ, 0.0) then
            local sx, sy = convert3DCoordsToScreen(hit.x, hit.y, hit.z or chPosZ)
            renderDrawLine(csx, csy, sx, sy, i == 1 and 1.8 or 1.0, i == 1 and 0xFFFF66FF or 0xAAFF66FF)
            if i == 1 and S.obstacleFont then
                renderFontDrawText(S.obstacleFont, "KLIUTIS", sx + 6, sy + 8, 0xFFFFAAFF)
            end
        end
    end

    for i = 1, math.min(#S.obstacleHits, 18) do
        local hit = S.obstacleHits[i]
        local hz = hit.z or carZ
        if getDistanceBetweenCoords2d(carX, carY, hit.x, hit.y) < 140 and isPointOnScreen(hit.x, hit.y, hz, 0.0) then
            local sx, sy = convert3DCoordsToScreen(hit.x, hit.y, hz)
            local urgent = hit.worldDist < 18 or hit.lateral < 2.2
            local color = obstacleColor(hit.kind, urgent, hit.sideScan == true)
            local size = urgent and 9 or 6
            renderDrawPolygon(sx, sy, size, size, 14, 0.0, color)
            local sideText = hit.cross > 0 and "L" or "R"
            local tag = hit.lowBlockScan and (hit.modelId and ("O" .. tostring(hit.modelId)) or "B") or obstacleLabel(hit)
            renderFontDrawText(S.obstacleFont, string.format("%s %d %s", tag, math.floor(hit.worldDist), sideText), sx + 8, sy - 6, color)
        end
    end

    if debugMode >= 2 and best then
        local bx, by = 230, 420
        local sideText = best.cross > 0 and "KAIRE" or "DESINE"
        local sourceText = best.sideScan and "SONAS" or "KELIAS"
        local tag = best.lowBlockScan and (best.modelId and ("O" .. tostring(best.modelId)) or "B") or obstacleLabel(best)
        local latText = best.sideScan and (best.clearance or best.lateral or 0.0) or (best.lateral or 0.0)
        local latName = best.sideScan and "clr" or "lat"
        local showAvoid = math.abs(S.avoidLateralTarget or 0.0) > 0.05
        renderDrawBox(bx, by, 190, showAvoid and 52 or 36, 0xAA000000)
        renderFontDrawText(S.obstacleFont, string.format("KLIUTIS %s %dm %s", tag, math.floor(best.worldDist), sideText), bx + 6, by + 4, 0xFFFFFFFF)
        renderFontDrawText(S.obstacleFont, string.format("%s u%.2f %s %.1f n%d", sourceText, best.urgency or obstacleUrgency(best), latName, latText, S.avoidClusterCount or 0), bx + 6, by + 18, 0xFFCCCCCC)
        if showAvoid then
            local hold = math.max(0.0, (S.avoidHoldUntil or 0.0) - os.clock())
            local mode = S.bypassActive and "APVAZIAVIMAS" or "VENGIMAS"
            renderFontDrawText(S.obstacleFont, string.format("%s %.1fm laukti %.1fs", mode, S.avoidLateralTarget or 0.0, hold), bx + 6, by + 32, 0xFF66FF66)
        end
    end
end

local function showMsg(text)
    UI.notify(text, 2000)
end

local function applySteerNoise()
    if CONFIG.controls.input == "keyboard" or CONFIG.controls.steering == "smooth" then return end
    if steerNoiseDuration > 0 then
        steerNoiseDuration = steerNoiseDuration - 1
        lastSteerValue = 0
        writeSteerControls(0)
    elseif steerNoiseCooldown > 0 then
        steerNoiseCooldown = steerNoiseCooldown - 1
    elseif math.random(100) <= 10 then
        steerNoiseDuration = math.random(1, 3)
        steerNoiseCooldown = math.random(8, 30)
        lastSteerValue = 0
        writeSteerControls(0)
    end
end

local function getObstacleAhead(car, targetX, targetY)
    local bestHit = nil
    local bestScore = -999.0
    for i = 1, math.min(#S.obstacleHits, 32) do
        local hit = S.obstacleHits[i]
        local sideScan = hit.sideScan == true
        local objectLike = hit.nearObjectScan == true or hit.kind == "obj" or hit.lowBlockScan == true
        local maxDist = sideScan and 6.5 or 8.0
        local maxLateral = sideScan and 2.55 or 2.6
        local lateral = sideScan and (hit.clearance or hit.lateral or 99.0) or (hit.lateral or 99.0)
        local forward = hit.forward or hit.worldDist or 0.0
        local urgency = hit.urgency or obstacleUrgency(hit)
        local minUrgency = sideScan and 0.46 or 0.42
        if objectLike then
            maxDist = sideScan and 12.0 or 15.0
            maxLateral = sideScan and 3.0 or 3.15
            minUrgency = sideScan and 0.18 or 0.16
        end
        if urgency >= minUrgency
            and hit.worldDist < maxDist
            and lateral < maxLateral
            and forward > -0.75
            and (not hit.zDelta or hit.zDelta < 2.2) then
            local score = urgency * 2.4 - hit.worldDist * 0.08 - lateral * 0.18
            if hit.lowBlockScan then score = score + 0.12 end
            if hit.avoidDir and hit.avoidDir ~= 0 then score = score + 0.08 end
            if score > bestScore then
                bestScore = score
                bestHit = hit
            end
        end
    end
    if bestHit then
        return bestHit.x, bestHit.y, bestHit.avoidDir or 0, bestHit.worldDist, bestHit.sideScan == true, bestHit.urgency or obstacleUrgency(bestHit)
    end

    local carX, carY, carZ = getCarCoordinates(car)
    local dx = targetX - carX
    local dy = targetY - carY
    local d = math.sqrt(dx * dx + dy * dy)
    if d < 0.1 then return nil end
    local nx, ny = dx / d, dy / d
    local checkX = carX + nx * 12
    local checkY = carY + ny * 12
    if API.closestCar then
        local ok1, nearest = pcall(API.closestCar, checkX, checkY, carZ, 5.0, {}, 0)
        if ok1 and nearest and nearest ~= 0 and nearest ~= car then
            local ox, oy = getCarCoordinates(nearest)
            return ox, oy, 0, getDistanceBetweenCoords2d(carX, carY, ox, oy), false, 0.65
        end
    end
    if API.closestObject then
        local ok2, nearObj = pcall(API.closestObject, checkX, checkY, carZ, 4.0, false, false)
        if ok2 and nearObj and nearObj ~= 0 then
            local avoidable = isAvoidableObject(nearObj)
            if not avoidable then return nil end
            local ok3, ox, oy = readObjectCoordinates(nearObj)
            if ok3 and ox then return ox, oy, 0, getDistanceBetweenCoords2d(carX, carY, ox, oy), false, 0.60 end
        end
    end
    return nil
end

local function avoidDir(car, obsX, obsY, targetX, targetY)
    local carX, carY = getCarCoordinates(car)
    local dx = targetX - carX
    local dy = targetY - carY
    local d = math.sqrt(dx * dx + dy * dy)
    if d < 0.1 then return 128 end
    local nx, ny = dx / d, dy / d
    local dot = (obsX - carX) * ny + (obsY - carY) * (-nx)
    return dot > 0 and -128 or 128
end

function routeAvoidDirFromPoint(carX, carY, targetX, targetY, obsX, obsY)
    local dx = targetX - carX
    local dy = targetY - carY
    local d = math.sqrt(dx * dx + dy * dy)
    if d < 0.1 then return 0 end
    local cross = dx * (obsY - carY) - dy * (obsX - carX)
    return cross > 0 and -1 or 1
end

local function sharpTurnAhead(route, idx)
    local n = #route
    for i = idx, math.min(idx + LOOKAHEAD, n - 1) do
        local ax = route[i].x - route[math.max(1, i-1)].x
        local ay = route[i].y - route[math.max(1, i-1)].y
        local bx = route[math.min(n, i+1)].x - route[i].x
        local by = route[math.min(n, i+1)].y - route[i].y
        local da = math.sqrt(ax*ax + ay*ay)
        local db = math.sqrt(bx*bx + by*by)
        if da > 0.1 and db > 0.1 then
            local dot = (ax/da)*(bx/db) + (ay/da)*(by/db)
            if dot < -0.3 then return true end
        end
    end
    return false
end

-- GTA headings run counter-clockwise from north, so the nose points along
-- (-sin h, cos h). Returns forward x/y and left x/y.
local function getCarForwardAxes(car)
    local heading = math.rad(getCarHeading(car))
    local nx = -math.sin(heading)
    local ny = math.cos(heading)
    return nx, ny, -ny, nx
end

-- Signed speed along the car's nose in getCarSpeed units (m/s): positive =
-- rolling forward, negative = rolling backward, nil if it cannot be read.
local function getCarForwardSpeed(car)
    if not API.carPointer then return nil end
    local ok, ptr = pcall(API.carPointer, car)
    ptr = ok and tonumber(ptr) or nil
    if not ptr or ptr == 0 then return nil end
    local vx = Mem.readFloat(ptr + 0x44) -- CPhysical::m_vecMoveSpeed
    local vy = Mem.readFloat(ptr + 0x48)
    if not vx or not vy then return nil end
    local fx, fy = getCarForwardAxes(car)
    return (vx * fx + vy * fy) * 50.0
end

-- Skips play_index ahead when the car has already passed its target point.
function handleRouteRejoinRecovery(car, carX, carY, targetX, targetY, currentSpeed)
    local now = os.clock()
    if now < (S.rejoinDisableUntil or 0.0) or now < (S.rejoinCooldownUntil or 0.0) then
        return
    end
    if play_index <= 20 or #current_route == 0 or currentSpeed > 25.0 then
        return
    end

    local fx, fy, lx, ly = getCarForwardAxes(car)
    local relX = targetX - carX
    local relY = targetY - carY
    local forward = relX * fx + relY * fy
    local lateral = relX * lx + relY * ly
    local dist = math.sqrt(relX * relX + relY * relY)

    if forward > -1.5 or dist > 22.0 or math.abs(lateral) < 2.0 then
        return
    end

    local bestIdx, accepted = RouteFollower.findRejoin(current_route, carX, carY,
        play_index, 0, 120, 45.0, getCarHeading(car), function(i, p)
            if i <= play_index then return nil end
            local px, py = p.x - carX, p.y - carY
            local pf, pl = px * fx + py * fy, math.abs(px * lx + py * ly)
            if pf > 2.5 and pf < 45.0 and pl < 14.0 then
                return pl * 1.45 + math.abs(pf - 14.0) * 0.35
            end
            return nil
        end)
    if accepted and bestIdx ~= play_index then
        local oldIndex = play_index
        play_index = bestIdx
        playbackDriveMode = routeDriveModeAt(current_route, play_index)
        S.rejoinCooldownUntil = now + 1.5
        S.currentLateral = 0.0
        steerBuf = {0, 0}
        resetObstacleBypass()
        S.avoidClusterCount = 0
        releaseControls("REJOIN_SKIP")
        logEvent("RECOVERY", string.format("bounded rejoin %d -> %d", oldIndex, bestIdx))
        return true
    end
    return false
end

local function pointSegmentProjection(ax, ay, bx, by, px, py)
    local sx = bx - ax
    local sy = by - ay
    local len2 = sx * sx + sy * sy
    if len2 < 0.0001 then
        return 0.0, getDistanceBetweenCoords2d(px, py, ax, ay)
    end
    local t = ((px - ax) * sx + (py - ay) * sy) / len2
    local nearestX = ax + sx * clamp(t, 0.0, 1.0)
    local nearestY = ay + sy * clamp(t, 0.0, 1.0)
    return t, getDistanceBetweenCoords2d(px, py, nearestX, nearestY)
end

local function syncReversePlaybackIndex(route, idx, carX, carY)
    if type(route) ~= "table" or #route == 0 then return idx end
    idx = math.max(1, math.min(tonumber(idx) or 1, #route))
    if routeDriveModeAt(route, idx) ~= DRIVE_BACK then return idx end

    local bestIdx = idx
    local bestDist = math.huge
    local last = idx
    while last < #route and routeDriveModeAt(route, last + 1) == DRIVE_BACK do
        last = last + 1
    end

    for i = idx, last do
        local p = route[i]
        local d = p and getDistanceBetweenCoords2d(carX, carY, p.x, p.y) or math.huge
        if d < bestDist then
            bestDist = d
            bestIdx = i
        end
    end

    if bestIdx > idx and bestDist < 9.0 then
        return bestIdx
    end
    return idx
end

local function advanceReversePlaybackIndex(route, idx, carX, carY, allowFinish)
    if type(route) ~= "table" or #route == 0 then return idx end
    idx = math.max(1, math.min(tonumber(idx) or 1, #route))
    if routeDriveModeAt(route, idx) ~= DRIVE_BACK then return idx end

    if allowFinish and idx == #route then
        local finalPoint = route[idx]
        if finalPoint and getDistanceBetweenCoords2d(carX, carY, finalPoint.x, finalPoint.y) <= 2.8 then
            return idx + 1
        end
    end

    local advanced = 0
    while idx < #route and advanced < 4 do
        local point = route[idx]
        local nextPoint = route[idx + 1]
        if not point or not nextPoint then break end

        local dist = getDistanceBetweenCoords2d(carX, carY, point.x, point.y)
        local nextDist = getDistanceBetweenCoords2d(carX, carY, nextPoint.x, nextPoint.y)
        local nextIsBack = routeDriveModeAt(route, idx + 1) == DRIVE_BACK

        if dist <= 2.8 then
            idx = idx + 1
            advanced = advanced + 1
        elseif nextIsBack then
            local t, segmentDist = pointSegmentProjection(point.x, point.y, nextPoint.x, nextPoint.y, carX, carY)
            if (t > 0.55 and segmentDist < 7.0) or (dist > 4.0 and nextDist + 0.45 < dist) then
                idx = idx + 1
                advanced = advanced + 1
            else
                break
            end
        elseif dist > 5.0 and nextDist + 0.45 < dist then
            -- Last BACK point before FWD: do not chase a missed boundary point forever.
            idx = idx + 1
            advanced = advanced + 1
        else
            break
        end
    end

    return idx
end

local function getReversePathSegment(route, idx)
    local point = route[idx]
    if not point then return nil, nil end
    local nextPoint = route[idx + 1]
    if nextPoint and routeDriveModeAt(route, idx + 1) == DRIVE_BACK then
        return point, nextPoint
    end

    local prevPoint = route[idx - 1]
    if prevPoint and routeDriveModeAt(route, idx - 1) == DRIVE_BACK then
        return prevPoint, point
    end

    return point, point
end

local function applyReverseSteering(car, carX, carY, route, idx)
    local a, b = getReversePathSegment(route, idx)
    if not a or not b then
        lastSteerValue = 0
        writeSteerControls(0)
        return
    end

    local sx = (b.x or a.x) - (a.x or carX)
    local sy = (b.y or a.y) - (a.y or carY)
    local segLen = math.sqrt(sx * sx + sy * sy)
    if segLen < 0.08 then
        lastSteerValue = 0
        writeSteerControls(0)
        return
    end

    sx, sy = sx / segLen, sy / segLen
    local leftX, leftY = -sy, sx
    local lateral = ((carX - a.x) * leftX) + ((carY - a.y) * leftY)
    local absLateral = math.abs(lateral)
    local steer = 0

    if absLateral > 1.05 then
        local strength = math.min(82, math.max(18, math.floor((absLateral - 0.65) * 34)))
        steer = lateral > 0 and -strength or strength
    end

    lastSteerValue = steer
    writeSteerControls(steer)
end

local function applyReverseAssist(car, carX, carY, targetX, targetY, currentSpeed, targetSpeed)
    local dx = targetX - carX
    local dy = targetY - carY
    local dist = math.sqrt(dx * dx + dy * dy)
    if dist < 0.65 then return end

    targetSpeed = math.max(8.0, math.min(targetSpeed or 12.0, 32.0))
    if currentSpeed > targetSpeed * 0.92 then return end

    -- Keep this as a tiny unstuck nudge only. A strong target-vector velocity
    -- shove makes the car slide sideways and miss the recorded reverse path.
    if currentSpeed > 0.6 or dist < 3.5 then return end
    local fx, fy = getCarForwardAxes(car)
    local backwardDot = dx * (-fx) + dy * (-fy)
    if backwardDot <= 0.4 then return end
    local desiredVelocity = 0.08
    pcall(setCarVelocity, car, -fx * desiredVelocity, -fy * desiredVelocity, 0.0)
end

local function readControlByte(address)
    local ok, value = pcall(readMemory, address, 1, false)
    if not ok then return 0 end
    return tonumber(value) or 0
end

local function isReverseRecordingInputActive()
    local sDown = isPhysicalKeyDown(0x53)
    local wDown = isPhysicalKeyDown(0x57)
    -- Pad Square is the brake/reverse button (keyboard S or a gamepad).
    local brakeInput = readControlByte(CONFIG.controls.footBrakeAddress)
    return (sDown or brakeInput > 150) and not wDown
end

local function getRecordedForwardMotion(car, heading, prev, x, y)
    local velocityNames = {
        "getCarVelocity",
        "getCarSpeedVector",
        "getVehicleVelocity",
        "getVehicleSpeedVector",
        "getCarMoveSpeed",
    }
    local fx, fy = getRecordingForwardAxes(heading)

    for _, name in ipairs(velocityNames) do
        local fn = _G and _G[name] or nil
        if type(fn) == "function" then
            local ok, a, b, c = pcall(fn, car)
            if ok then
                local vx, vy = nil, nil
                if type(a) == "boolean" then
                    vx, vy = tonumber(b), tonumber(c)
                elseif type(a) == "table" then
                    vx, vy = tonumber(a.x or a[1]), tonumber(a.y or a[2])
                else
                    vx, vy = tonumber(a), tonumber(b)
                end
                if vx and vy then
                    return vx * fx + vy * fy
                end
            end
        end
    end

    if prev then
        return ((x or 0.0) - (prev.x or 0.0)) * fx + ((y or 0.0) - (prev.y or 0.0)) * fy
    end
    return nil
end

local function scanRouteAhead(route, idx, car)
    local n = #route
    local carX, carY, carZ = getCarCoordinates(car)
    local carForwardX, carForwardY, carLeftX, carLeftY = getCarForwardAxes(car)
    local scanPoint = route[math.min(idx + LOOKAHEAD, n)] or route[idx]
    if scanPoint then
        local rdx = scanPoint.x - carX
        local rdy = scanPoint.y - carY
        local rLen = math.sqrt(rdx * rdx + rdy * rdy)
        if rLen > 2.0 then
            carForwardX, carForwardY = rdx / rLen, rdy / rLen
            carLeftX, carLeftY = -carForwardY, carForwardX
        end
    end
    S.obstacleHits = {}
    S.obstacleProbes = {}
    local best = math.huge
    local bestDir = 0
    local bestThreat = math.huge
    local found = {}
    local originZ = carZ + 0.75

    local function lateralFromSegment(ax, ay, bx, by, px, py)
        local rx = bx - ax
        local ry = by - ay
        local rLen = math.sqrt(rx*rx + ry*ry)
        if rLen < 0.1 then return 99, 0 end
        local cross = rx * (py - ay) - ry * (px - ax)
        return math.abs(cross) / rLen, cross
    end

    local function registerHit(kind, ox, oy, oz, segX, segY, prevX, prevY, routeIdx, avoidDirHint, modelId)
        modelId = tonumber(modelId)
        if kind == "obj" and not shouldAvoidObjectModel(modelId) then return end
        if kind ~= "obj" and kind ~= "car" then return end
        local lateralDist, cross = lateralFromSegment(prevX, prevY, segX, segY, ox, oy)
        local worldDist = getDistanceBetweenCoords2d(carX, carY, ox, oy)
        local relX = ox - carX
        local relY = oy - carY
        local forwardDist = relX * carForwardX + relY * carForwardY
        local carLateral = relX * carLeftX + relY * carLeftY
        local clearance = math.abs(carLateral)
        local key = string.format("%s:%d:%d:%d", kind, math.floor(ox * 2), math.floor(oy * 2), math.floor((oz or carZ) * 2))
        local sideScan = math.abs(avoidDirHint or 0) > 1
        local lowBlockScan = math.abs(avoidDirHint or 0) >= 3
        local maxLateral = sideScan and 4.4 or 3.2
        local minWorldDist = sideScan and 1.0 or 3.0
        if sideScan and forwardDist < -1.5 then return end
        local sidePenalty = sideScan and math.max(0.0, clearance - 1.1) or lateralDist
        local threat = worldDist + sidePenalty * (sideScan and 14 or 16) + math.max(0, routeIdx - idx) * 0.30 + (sideScan and 0.4 or 0.0)
        if lowBlockScan then
            threat = threat + 1.8
        end
        if sideScan and worldDist < 8.0 and clearance < 2.8 then
            threat = threat - 2.8
        end
        local existing = found[key]

        if worldDist > minWorldDist and lateralDist < maxLateral and (not sideScan or clearance < 5.2) and (not existing or threat < existing.threat) then
            found[key] = {
                kind = kind,
                modelId = modelId,
                x = ox, y = oy, z = oz or carZ,
                worldDist = worldDist,
                lateral = lateralDist,
                clearance = clearance,
                forward = forwardDist,
                carLateral = carLateral,
                cross = cross,
                threat = threat,
                urgency = 0.0,
                routeIdx = routeIdx,
                avoidDir = avoidDirHint or 0,
                zDelta = 0.0,
                sideScan = sideScan,
                lowBlockScan = lowBlockScan,
            }
        end
    end

    -- GTA entity types: 1 building, 2 vehicle, 3 ped, 4 object, 5 dummy.
    local function classifyEntityType(entityType)
        if entityType == 2 then return "car" end
        if entityType == 3 then return "ped" end
        if entityType == 4 then return "obj" end
        return "solid"
    end

    local function samplePoint(fromX, fromY, fromZ, sampleX, sampleY, sampleZ, routeIdx, avoidDirHint)
        local probeFromZ = fromZ or originZ
        local probeToZ = sampleZ or probeFromZ
        local sideScan = math.abs(avoidDirHint or 0) > 1
        local lowBlockScan = math.abs(avoidDirHint or 0) >= 3
        if #S.obstacleProbes < 280 then
            table.insert(S.obstacleProbes, {
                x = sampleX, y = sampleY, z = probeToZ, hit = false,
                fromX = fromX, fromY = fromY, fromZ = probeFromZ,
                sideScan = sideScan,
                lowBlockScan = lowBlockScan,
                laneHint = avoidDirHint or 0,
            })
        end

        local ok, result, colPoint = pcall(processLineOfSight,
            fromX, fromY, probeFromZ,
            sampleX, sampleY, probeToZ,
            true, true, false, true, true, false, false, false)
        if ok and result and colPoint and colPoint.pos then
            local entityType = collisionEntityType(colPoint)
            local kind = classifyEntityType(entityType)
            local modelId = collisionObjectModelId(colPoint)
            if (entityType == 4 or entityType == nil) and shouldAvoidObjectModel(modelId) then
                kind = "obj"
            elseif kind ~= "car" then
                return
            end
            local hx, hy, hz = colPoint.pos[1], colPoint.pos[2], colPoint.pos[3]
            local nz = (colPoint.normal and colPoint.normal[3]) or 0.0
            local expectedZ = probeToZ
            local hitWorldDist = getDistanceBetweenCoords2d(carX, carY, hx, hy)
            local hitZ = hz or expectedZ
            local heightAboveCar = hitZ - carZ
            if kind == "car" and hitWorldDist < 2.6 then
                return
            end
            if lowBlockScan then
                if heightAboveCar < 0.20 or heightAboveCar > 1.05 then
                    return
                end
                if kind == "solid" and nz > 0.78 and math.abs(hitZ - expectedZ) < 0.55 then
                    return
                end
            elseif kind == "solid" and nz > 0.62 and math.abs(hitZ - expectedZ) < 1.45 then
                return
            elseif kind ~= "car" and hitZ < carZ + 0.15 then
                return
            end
            if #S.obstacleProbes > 0 then
                local probe = S.obstacleProbes[#S.obstacleProbes]
                probe.x, probe.y, probe.z, probe.hit, probe.kind = hx, hy, hitZ, true, kind
                probe.modelId = modelId
            end
            registerHit(kind, hx, hy, hitZ, sampleX, sampleY, fromX, fromY, routeIdx, avoidDirHint, modelId)
            local key = string.format("%s:%d:%d:%d", kind, math.floor(hx * 2), math.floor(hy * 2), math.floor(hitZ * 2))
            if found[key] then
                found[key].zDelta = math.abs((hz or probeToZ) - expectedZ)
                found[key].urgency = obstacleUrgency(found[key])
            end
        end
    end

    local function sampleNearbyObject(centerX, centerY, centerZ, routeIdx, avoidDirHint, radius)
        local sideScan = math.abs(avoidDirHint or 0) > 1
        if not API.closestObject then return end
        local ok, obj = pcall(API.closestObject, centerX, centerY, centerZ, radius or 1.85, false, false)
        if not ok or not obj or obj == 0 then return end
        local avoidable, modelId = isAvoidableObject(obj)
        if not avoidable then return end

        local ok2, ox, oy, oz = readObjectCoordinates(obj)
        if not ok2 or not ox then return end

        local objZ = oz or centerZ
        if objZ < carZ - 1.2 or objZ > carZ + 2.0 then return end

        local markerZ = objZ + 0.55
        if #S.obstacleProbes < 280 then
            table.insert(S.obstacleProbes, {
                x = ox, y = oy, z = markerZ, hit = true, kind = "obj", modelId = modelId,
                fromX = centerX, fromY = centerY, fromZ = centerZ,
                sideScan = sideScan,
                laneHint = avoidDirHint or 0,
            })
        end

        local ax = centerX - carForwardX
        local ay = centerY - carForwardY
        local bx = centerX + carForwardX
        local by = centerY + carForwardY
        registerHit("obj", ox, oy, markerZ, bx, by, ax, ay, routeIdx, avoidDirHint, modelId)

        local key = string.format("%s:%d:%d:%d", "obj", math.floor(ox * 2), math.floor(oy * 2), math.floor(markerZ * 2))
        if found[key] then
            found[key].zDelta = math.abs(objZ - centerZ)
            found[key].urgency = obstacleUrgency(found[key])
            found[key].nearObjectScan = true
            found[key].threat = found[key].threat - 1.2
        end
    end

    local function registerStreamedObject(ox, oy, oz, modelId)
        if not shouldAvoidObjectModel(modelId) then return end
        local objZ = oz or carZ
        if objZ < carZ - 1.2 or objZ > carZ + 2.2 then return end

        local relX = ox - carX
        local relY = oy - carY
        local forward = relX * carForwardX + relY * carForwardY
        local lateral = relX * carLeftX + relY * carLeftY
        local clearance = math.abs(lateral)
        if forward < 1.5 or forward > 55.0 or clearance > 5.2 then return end

        local hint = 0
        if lateral > 0.85 then
            hint = -2
        elseif lateral < -0.85 then
            hint = 2
        end

        local markerZ = objZ + 0.55
        local ax = ox - carForwardX
        local ay = oy - carForwardY
        local bx = ox + carForwardX
        local by = oy + carForwardY
        registerHit("obj", ox, oy, markerZ, bx, by, ax, ay, idx + forward * 0.25, hint, modelId)

        local key = string.format("%s:%d:%d:%d", "obj", math.floor(ox * 2), math.floor(oy * 2), math.floor(markerZ * 2))
        if found[key] then
            found[key].zDelta = math.abs(objZ - carZ)
            found[key].nearObjectScan = true
            found[key].streamedObjectScan = true
            found[key].urgency = obstacleUrgency(found[key])
            found[key].threat = found[key].threat - 2.4
        end

        if #S.obstacleProbes < 280 then
            table.insert(S.obstacleProbes, {
                x = ox, y = oy, z = markerZ, hit = true, kind = "obj", modelId = modelId,
                fromX = carX, fromY = carY, fromZ = carZ + 0.65,
                sideScan = hint ~= 0,
                laneHint = hint,
            })
        end
    end

    local function scanStreamedObjects()
        if not API.allObjects then return end
        local ok, objects = pcall(API.allObjects)
        if not ok or type(objects) ~= "table" then return end
        local scanned = 0
        for _, obj in pairs(objects) do
            if obj and obj ~= 0 then
                local avoidable, modelId = isAvoidableObject(obj)
                if avoidable then
                    local ok2, ox, oy, oz = readObjectCoordinates(obj)
                    if ok2 and ox then
                        registerStreamedObject(ox, oy, oz, modelId)
                    end
                    scanned = scanned + 1
                    if scanned >= 220 then return end
                end
            end
        end
    end

    do
        local frontIdx = math.min(idx + LOOKAHEAD, n)
        local frontPoint = route[frontIdx] or route[idx]
        if frontPoint then
            local fx = carForwardX
            local fy = carForwardY
            local fLen = math.sqrt(fx * fx + fy * fy)
            if fLen > 0.1 then
                local nx = fx / fLen
                local ny = fy / fLen
                local lx = carLeftX
                local ly = carLeftY
                local frontOffset = 1.15
                local shoulderOffset = 2.35
                local outerOffset = 3.55
                local frontZ = (frontPoint.z or carZ) + 0.65
                local carSpeed = getCarSpeed(car)
                local forwardReach = math.max(48.0, math.min(72.0, 36.0 + carSpeed * 0.22))
                local coneOffsets = {-2.4, -1.8, -1.2, -0.6, 0.0, 0.6, 1.2, 1.8, 2.4}
                for dist = 6, forwardReach, 4 do
                    local fromDist = math.max(0.0, dist - 4.0)
                    local distAlpha = dist / forwardReach
                    local fromAlpha = fromDist / forwardReach
                    local fromCX = carX + nx * fromDist
                    local fromCY = carY + ny * fromDist
                    local fromCZ = originZ + (frontZ - originZ) * fromAlpha
                    local toCX = carX + nx * dist
                    local toCY = carY + ny * dist
                    local toCZ = originZ + (frontZ - originZ) * distAlpha
                    samplePoint(fromCX, fromCY, fromCZ, toCX, toCY, toCZ, idx + dist * 0.25, 0)
                    samplePoint(fromCX + lx * frontOffset, fromCY + ly * frontOffset, fromCZ, toCX + lx * frontOffset, toCY + ly * frontOffset, toCZ, idx + dist * 0.25, -1)
                    samplePoint(fromCX - lx * frontOffset, fromCY - ly * frontOffset, fromCZ, toCX - lx * frontOffset, toCY - ly * frontOffset, toCZ, idx + dist * 0.25, 1)
                    if dist >= 10 then
                        samplePoint(fromCX + lx * shoulderOffset, fromCY + ly * shoulderOffset, fromCZ, toCX + lx * shoulderOffset, toCY + ly * shoulderOffset, toCZ, idx + dist * 0.25, -2)
                        samplePoint(fromCX - lx * shoulderOffset, fromCY - ly * shoulderOffset, fromCZ, toCX - lx * shoulderOffset, toCY - ly * shoulderOffset, toCZ, idx + dist * 0.25, 2)
                    end
                    if dist >= 18 then
                        samplePoint(fromCX + lx * outerOffset, fromCY + ly * outerOffset, fromCZ, toCX + lx * outerOffset, toCY + ly * outerOffset, toCZ, idx + dist * 0.25, -2)
                        samplePoint(fromCX - lx * outerOffset, fromCY - ly * outerOffset, fromCZ, toCX - lx * outerOffset, toCY - ly * outerOffset, toCZ, idx + dist * 0.25, 2)
                    end

                    if dist <= 48 then
                        local objZ = carZ + 0.65
                        sampleNearbyObject(toCX, toCY, objZ, idx + dist * 0.25, 0, 1.85)
                        sampleNearbyObject(toCX + lx * frontOffset, toCY + ly * frontOffset, objZ, idx + dist * 0.25, -1, 1.65)
                        sampleNearbyObject(toCX - lx * frontOffset, toCY - ly * frontOffset, objZ, idx + dist * 0.25, 1, 1.65)
                        if dist >= 10 then
                            sampleNearbyObject(toCX + lx * shoulderOffset, toCY + ly * shoulderOffset, objZ, idx + dist * 0.25, -2, 1.45)
                            sampleNearbyObject(toCX - lx * shoulderOffset, toCY - ly * shoulderOffset, objZ, idx + dist * 0.25, 2, 1.45)
                        end
                    end
                end

                for dist = 3.0, math.min(forwardReach, 34.0), 2.0 do
                    local fromDist = math.max(0.0, dist - 2.0)
                    for _, off in ipairs(coneOffsets) do
                        local hint = 0
                        if off > 0.75 then
                            hint = -3
                        elseif off < -0.75 then
                            hint = 3
                        end
                        local fromX = carX + nx * fromDist + lx * off
                        local fromY = carY + ny * fromDist + ly * off
                        local toX = carX + nx * dist + lx * off
                        local toY = carY + ny * dist + ly * off
                        samplePoint(fromX, fromY, carZ + 0.82, toX, toY, carZ + 0.82, idx + dist * 0.25, hint)
                    end
                end
            end
        end
    end

    scanStreamedObjects()

    do
        local sideIdx = math.min(idx + 2, n)
        local sidePoint = route[sideIdx] or route[idx]
        if sidePoint then
            local fx = carForwardX
            local fy = carForwardY
            local fLen = math.sqrt(fx * fx + fy * fy)
            if fLen > 0.1 then
                local nx = fx / fLen
                local ny = fy / fLen
                local lx = carLeftX
                local ly = carLeftY
                local sideTopZ = (sidePoint.z or carZ) + 0.55
                for dist = 0, 8, 2 do
                    local alpha = dist / 8.0
                    local baseX = carX + nx * dist
                    local baseY = carY + ny * dist
                    local baseZ = originZ + (sideTopZ - originZ) * alpha
                    local sideReach = 2.1 + dist * 0.12
                    samplePoint(baseX, baseY, baseZ, baseX + lx * sideReach, baseY + ly * sideReach, baseZ, idx + dist * 0.2, -2)
                    samplePoint(baseX, baseY, baseZ, baseX - lx * sideReach, baseY - ly * sideReach, baseZ, idx + dist * 0.2, 2)
                    samplePoint(baseX + nx * 0.9, baseY + ny * 0.9, baseZ, baseX + nx * 1.8 + lx * (sideReach + 0.6), baseY + ny * 1.8 + ly * (sideReach + 0.6), baseZ, idx + dist * 0.2, -2)
                    samplePoint(baseX + nx * 0.9, baseY + ny * 0.9, baseZ, baseX + nx * 1.8 - lx * (sideReach + 0.6), baseY + ny * 1.8 - ly * (sideReach + 0.6), baseZ, idx + dist * 0.2, 2)
                end
            end
        end
    end

    do
        local nearIdx = math.min(idx + 1, n)
        local nearPoint = route[nearIdx] or route[idx]
        if nearPoint then
            local fx = carForwardX
            local fy = carForwardY
            local fLen = math.sqrt(fx * fx + fy * fy)
            if fLen > 0.1 then
                local nx = fx / fLen
                local ny = fy / fLen
                local lx = carLeftX
                local ly = carLeftY
                local cornerForward = 1.6
                local cornerSide = 1.25
                local cornerZ = originZ + 0.05

                samplePoint(
                    carX + nx * cornerForward + lx * cornerSide,
                    carY + ny * cornerForward + ly * cornerSide,
                    cornerZ,
                    carX + nx * 2.8 + lx * 2.9,
                    carY + ny * 2.8 + ly * 2.9,
                    cornerZ,
                    idx + 0.2,
                    -2
                )
                samplePoint(
                    carX + nx * cornerForward - lx * cornerSide,
                    carY + ny * cornerForward - ly * cornerSide,
                    cornerZ,
                    carX + nx * 2.8 - lx * 2.9,
                    carY + ny * 2.8 - ly * 2.9,
                    cornerZ,
                    idx + 0.2,
                    2
                )
                samplePoint(
                    carX + nx * 0.9 + lx * 1.45,
                    carY + ny * 0.9 + ly * 1.45,
                    cornerZ,
                    carX + nx * 1.3 + lx * 2.4,
                    carY + ny * 1.3 + ly * 2.4,
                    cornerZ,
                    idx + 0.1,
                    -2
                )
                samplePoint(
                    carX + nx * 0.9 - lx * 1.45,
                    carY + ny * 0.9 - ly * 1.45,
                    cornerZ,
                    carX + nx * 1.3 - lx * 2.4,
                    carY + ny * 1.3 - ly * 2.4,
                    cornerZ,
                    idx + 0.1,
                    2
                )
            end
        end
    end

    do
        local nx, ny = carForwardX, carForwardY
        local lx, ly = carLeftX, carLeftY
        local sweepTopZ = carZ + 1.35
        for dist = 3.0, 9.0, 1.5 do
            local baseX = carX + nx * dist
            local baseY = carY + ny * dist
            local lowZ = carZ + 0.65
            local highZ = sweepTopZ
            samplePoint(baseX, baseY, lowZ, baseX + lx * 3.15, baseY + ly * 3.15, lowZ, idx + dist * 0.2, -2)
            samplePoint(baseX, baseY, lowZ, baseX - lx * 3.15, baseY - ly * 3.15, lowZ, idx + dist * 0.2, 2)
            samplePoint(baseX, baseY, highZ, baseX + lx * 3.30, baseY + ly * 3.30, highZ, idx + dist * 0.2, -2)
            samplePoint(baseX, baseY, highZ, baseX - lx * 3.30, baseY - ly * 3.30, highZ, idx + dist * 0.2, 2)
        end
    end

    do
        local nx, ny = carForwardX, carForwardY
        local lx, ly = carLeftX, carLeftY
        local lowZ = carZ + 0.38
        for dist = 4.0, 34.0, 3.0 do
            local fromDist = math.max(0.0, dist - 2.5)
            local fromX = carX + nx * fromDist
            local fromY = carY + ny * fromDist
            local toX = carX + nx * dist
            local toY = carY + ny * dist
            samplePoint(fromX, fromY, lowZ, toX, toY, lowZ, idx + dist * 0.18, 0)
            samplePoint(fromX + lx * 1.35, fromY + ly * 1.35, lowZ, toX + lx * 1.35, toY + ly * 1.35, lowZ, idx + dist * 0.18, -3)
            samplePoint(fromX - lx * 1.35, fromY - ly * 1.35, lowZ, toX - lx * 1.35, toY - ly * 1.35, lowZ, idx + dist * 0.18, 3)
            sampleNearbyObject(toX, toY, carZ + 0.45, idx + dist * 0.18, 0, 1.9)
            sampleNearbyObject(toX + lx * 1.35, toY + ly * 1.35, carZ + 0.45, idx + dist * 0.18, -3, 1.55)
            sampleNearbyObject(toX - lx * 1.35, toY - ly * 1.35, carZ + 0.45, idx + dist * 0.18, 3, 1.55)
            if dist <= 18.0 then
                samplePoint(toX, toY, lowZ, toX + lx * 3.3, toY + ly * 3.3, lowZ, idx + dist * 0.18, -3)
                samplePoint(toX, toY, lowZ, toX - lx * 3.3, toY - ly * 3.3, lowZ, idx + dist * 0.18, 3)
            end
        end
    end

    local routePoint = route[math.min(idx + LOOKAHEAD, n)] or route[idx]
    local routeDx = routePoint and routePoint.x - carX or carForwardX
    local routeDy = routePoint and routePoint.y - carY or carForwardY
    local routeLen = math.sqrt(routeDx * routeDx + routeDy * routeDy)
    local routeDot = routeLen > 0.1 and ((routeDx / routeLen) * carForwardX + (routeDy / routeLen) * carForwardY) or 1.0
    local scanRouteCorridor = routeDot > -0.25 or getCarSpeed(car) < 5.0

    -- Only ray-cast route points near the car: hits further than ~62 m never
    -- influence avoidance, and the far corridor was most of the scan cost.
    local corridorRadius = CONFIG.obstacle.corridorRadius or 70.0
    for i = idx + 6, scanRouteCorridor and math.min(idx + 320, n) or idx + 5, 3 do
        local p = route[i]
        local prev = route[math.max(1, i - 1)]
        if getDistanceBetweenCoords2d(carX, carY, p.x, p.y) <= corridorRadius then
            local prevZ = (prev.z or carZ) + 0.45
            local pz = (p.z or carZ) + 0.45
            samplePoint(prev.x, prev.y, prevZ, p.x, p.y, pz, i, 0)
            local segX = p.x - prev.x
            local segY = p.y - prev.y
            local segLen = math.sqrt(segX * segX + segY * segY)
            if segLen > 0.1 then
                local lx = -segY / segLen
                local ly = segX / segLen
                local laneOffset = 1.2
                local shoulderOffset = 2.3
                local outerOffset = 3.4
                samplePoint(prev.x + lx * laneOffset, prev.y + ly * laneOffset, prevZ, p.x + lx * laneOffset, p.y + ly * laneOffset, pz, i, -1)
                samplePoint(prev.x - lx * laneOffset, prev.y - ly * laneOffset, prevZ, p.x - lx * laneOffset, p.y - ly * laneOffset, pz, i, 1)
                if ((i - idx) % 6) == 0 and (i - idx) <= 180 then
                    sampleNearbyObject(p.x, p.y, pz, i, 0, 1.8)
                    sampleNearbyObject(p.x + lx * laneOffset, p.y + ly * laneOffset, pz, i, -1, 1.55)
                    sampleNearbyObject(p.x - lx * laneOffset, p.y - ly * laneOffset, pz, i, 1, 1.55)
                end
                if ((i - idx) % 6) == 0 then
                    samplePoint(prev.x + lx * shoulderOffset, prev.y + ly * shoulderOffset, prevZ, p.x + lx * shoulderOffset, p.y + ly * shoulderOffset, pz, i, -2)
                    samplePoint(prev.x - lx * shoulderOffset, prev.y - ly * shoulderOffset, prevZ, p.x - lx * shoulderOffset, p.y - ly * shoulderOffset, pz, i, 2)
                end
                if ((i - idx) % 9) == 0 then
                    samplePoint(prev.x + lx * outerOffset, prev.y + ly * outerOffset, prevZ, p.x + lx * outerOffset, p.y + ly * outerOffset, pz, i, -2)
                    samplePoint(prev.x - lx * outerOffset, prev.y - ly * outerOffset, prevZ, p.x - lx * outerOffset, p.y - ly * outerOffset, pz, i, 2)
                end
            end
        end
    end

    local bestUrgency = 0.0
    for _, hit in pairs(found) do
        hit.urgency = obstacleUrgency(hit)
        local clearance = hit.clearance or hit.lateral or 99.0
        local usable = (hit.sideScan and hit.lateral < 4.4 and clearance < 3.4 and hit.worldDist < 22.0 and hit.urgency >= (hit.lowBlockScan and 0.26 or 0.14))
            or (not hit.sideScan and hit.lateral < 2.8 and hit.urgency >= 0.10)
        if usable and hit.threat < bestThreat then
            bestThreat = hit.threat
            best = hit.worldDist
            bestUrgency = hit.urgency
            if hit.avoidDir and hit.avoidDir ~= 0 then
                bestDir = hit.avoidDir
            else
                bestDir = hit.cross > 0 and -1 or 1
            end
        end
        table.insert(S.obstacleHits, hit)
    end

    table.sort(S.obstacleHits, function(a, b)
        return a.threat < b.threat
    end)

    local planDist, planDir, planUrgency, planCount = computeObstacleClusterPlan()
    S.avoidClusterCount = planCount or 0
    if planDir ~= 0 and (bestDir == 0 or planDist < best + 18.0 or planUrgency > bestUrgency * 0.75) then
        best = planDist
        bestDir = planDir
        bestUrgency = math.max(bestUrgency, planUrgency)
    end

    if #S.obstacleHits == 0 then
        best = math.huge
        bestDir = 0
        bestUrgency = 0.0
        S.avoidClusterCount = 0
    elseif bestDir > 0 then
        bestDir = 1
    elseif bestDir < 0 then
        bestDir = -1
    end

    return best, bestDir, bestUrgency
end

-- The bot reverses through the pad, not the S key, so any W/A/S/D/Space
-- press seen here is the player.
local function isPlayerControlling()
    return isPhysicalKeyDown(0x57)
        or isPhysicalKeyDown(0x53)
        or isPhysicalKeyDown(0x41)
        or isPhysicalKeyDown(0x44)
        or isPhysicalKeyDown(0x20)
end

-- Priority is explicit and evaluated immediately before every pad write.
-- Freeze may cancel a bump even if a test flag appears between frame stages.
function ControlManager.resolveOwner()
    if not playing then return "IDLE" end
    local now = os.clock()
    local explicitFreeze = sharedFreezeActive() or RecoverySystem.controlLockState() == true
    if explicitFreeze or S.freezeTestLatched or S.frozenByAdmin then
        if explicitFreeze then
            resetBumpState(false)
            S.backToForwardUntil = 0.0
        end
        return "FREEZE"
    end
    if S.dialogPaused or S.testArbotasPaused or now < S.dialogReleaseUntil
        or sharedDialogMode() == "fake_arbotas" or isSampDialogActive() then
        return "DIALOG"
    end
    if S.adminChatTyping or isSampChatInputActive() == true then return "CHAT" end
    if isPlayerControlling() then return "MANUAL" end
    if S.manualPaused then return "PAUSE" end
    if now < S.rotateFightUntil then return "ROTATE" end
    if AdminChat.holdsRecoveryReply() then return "CHAT" end
    if now < S.rotateReleaseUntil then return "ROTATE_WAIT" end
    if now < (S.backToForwardUntil or 0.0) then return "TRANSITION" end
    if S.bumpActive then return "BUMP" end
    return "ROUTE"
end

-- Keep the existing first six IPC lines; append ownership for diagnostics.
-- Safety state names override a stale producer's PLAYING/BUMP_BACK label.
function ControlManager.sharedState(state)
    local owner = ControlManager.owner
    if owner == "FREEZE" then
        if S.externalFreezeAck and not S.freezeTestLatched then return "FREEZE_HOLD" end
        if S.refreshSent then
            return os.clock() < (S.freezeReleaseUntil or 0) and "FREEZE_REFRESH" or "FREEZE_RESUME"
        end
        return "FREEZE_WAIT"
    elseif owner == "DIALOG" then
        if S.testArbotasPaused or sharedDialogMode() == "fake_arbotas" then return "AR_BOTAS_TEST" end
        return os.clock() < S.dialogReleaseUntil and "DIALOG_WAIT" or "DIALOG"
    elseif owner == "CHAT" then return "CHAT_WAIT"
    elseif owner == "MANUAL" then return "OVERRIDE"
    elseif owner == "PAUSE" then return S.recoveryBlockedReason and (S.recoveryBlockedCode or "RECOVERY_LIMIT") or "PAUSED"
    elseif owner == "ROTATE" then return "ROTATE_"..(RecoverySystem.rotation.phase or "HOLD")
    elseif owner == "ROTATE_WAIT" then return "ROTATE_CONFUSED"
    elseif owner == "TRANSITION" then return "R_TO_FWD"
    end
    return state
end

local function isReversePlaybackContext(route, pidx)
    if not playing or type(route) ~= "table" or #route == 0 then return false end
    pidx = math.max(1, math.min(tonumber(pidx) or 1, #route))
    local first = math.max(1, pidx - 2)
    local last = math.min(#route, pidx + (CONFIG.recovery.reverseLookaheadPoints or 90))
    local here = route[pidx]
    for i = first, last do
        local p = route[i]
        if isRoutePointReverse(p) then
            if i <= pidx + 8 then return true end
            if here and here.x and here.y and p.x and p.y then
                local d = getDistanceBetweenCoords2d(here.x, here.y, p.x, p.y)
                if d <= (CONFIG.recovery.reverseLookaheadRadius or 16.0) then
                    return true
                end
            end
        end
    end
    return false
end

local function suppressFreezeForIntentionalReverse(now, route, pidx)
    if isReversePlaybackContext(route, pidx) then
        S.reversePlaybackGraceUntil = math.max(
            S.reversePlaybackGraceUntil or 0.0,
            now + (CONFIG.recovery.reverseTransitionGraceSeconds or 2.4)
        )
    end
    return now < (S.reversePlaybackGraceUntil or 0.0)
end

local function clearFreezeRecoveryOnly(now)
    now = now or os.clock()
    S.freezeTestLatched = false
    S.freezeRecoveryMode = ""
    S.frozenByAdmin = false
    S.refreshSent = false
    S.refreshJob = nil
    S.freezeRefreshSentAt = 0.0
    S.freezeReleaseUntil = 0.0
    S.freezeRefreshAt = 0.0
    S.freezeResumeDelay = 0.0
    freezeTimer = 0
    suddenStopFrames = 0
    if pauseReleaseReason == "FROZEN"
        or pauseReleaseReason == "FREEZE_TEST"
        or pauseReleaseReason == "FREEZE_WAIT"
        or pauseReleaseReason == "FREEZE_REFRESH"
        or pauseReleaseReason == "FREEZE_RESUME" then
        pauseReleaseReason = ""
    end
    syncPausedState(now)
end

local function startBackToForwardTransition()
    local now = os.clock()
    if freezeRecoveryOwnsControls() then
        releaseControls(pauseReleaseReason ~= "" and pauseReleaseReason or "FREEZE_WAIT")
        return false
    end
    if not sharedFreezeActive() then
        clearFreezeRecoveryOnly(now)
    end
    S.backToForwardUntil = math.max(
        S.backToForwardUntil or 0.0,
        now + (CONFIG.recovery.backToForwardCoastSeconds or 0.85)
    )
    S.freezeRecoveryGraceUntil = math.max(S.freezeRecoveryGraceUntil or 0.0, S.backToForwardUntil + 0.8)
    S.gasLiftFrames = 0
    gasLevel = 0
    brakeLevel = 0
    lastSteerValue = 0
    ControlManager.neutralize()
    return true
end

local function handleBackToForwardTransition()
    local now = os.clock()
    if freezeRecoveryOwnsControls() then
        S.backToForwardUntil = 0.0
        releaseControls(pauseReleaseReason ~= "" and pauseReleaseReason or "FREEZE_WAIT")
        return true
    end
    if now >= (S.backToForwardUntil or 0.0) then return false end
    releaseControls("R_TO_FWD")
    UI.notify("~y~R >> FWD", 100)
    return true
end

local function stopBumpRecovery(reason)
    resetBumpState(false)
    gasLevel = 0
    brakeLevel = 0
    lastSteerValue = 0
    ControlManager.neutralize()
    if reason then
        writeSharedState(reason)
    end
end

-- Conservative ray corridors. A missing/failed query is unknown, never clear.
function EscapePlanner.ray(ax,ay,az,bx,by,bz)
    if type(processLineOfSight)~="function" then return nil,"collision API unavailable" end
    local ok,hit=pcall(processLineOfSight,ax,ay,az,bx,by,bz,true,true,true,true,true,false,false,false)
    if not ok or type(hit)~="boolean" then return nil,"collision query failed" end
    return not hit,hit and "obstacle in escape corridor" or "clear"
end
function EscapePlanner.ground(x,y,z)
    if not CONFIG.escape.requireGround then return true end
    if type(processLineOfSight)~="function" then return nil,"ground query unavailable" end
    local ok,hit,point=pcall(processLineOfSight,x,y,z+0.5,x,y,z-3.0,true,false,false,true,true,false,false,false)
    if not ok or type(hit)~="boolean" then return nil,"ground query failed" end
    if not hit then return false,"no ground behind vehicle" end
    local valid,height,normal=pcall(function() return tonumber(point.pos[3]),tonumber(point.normal[3]) end)
    if not valid or not height or not normal then return nil,"ground result incomplete" end
    if height>z+0.15 or height<z-2.5 or normal<0.65 then return false,"unsafe slope or step behind vehicle" end
    return true
end
function EscapePlanner.scan(car,side,distance)
    local x,y,z=getCarCoordinates(car)
    local fx,fy,lx,ly=getCarForwardAxes(car)
    local profile=VehicleProfiles.profile()
    local width=profile.half_width+CONFIG.escape.margin
    local length=profile.half_length+CONFIG.escape.margin
    local sideways=side*CONFIG.escape.lateralOffset*(distance/4)^2*2.7/profile.half_length
    local function point(back,lateral,height)
        return x-fx*back+lx*lateral,y-fy*back+ly*lateral,z+height
    end
    local function ray(backA,latA,backB,latB,height)
        local ax,ay,az=point(backA,latA,height);local bx,by,bz=point(backB,latB,height)
        return EscapePlanner.ray(ax,ay,az,bx,by,bz)
    end
    for _,height in ipairs({0.25,0.85}) do
        for _,offset in ipairs({-width,0,width}) do
            for step=1,3 do
                local a,b=(step-1)/3,step/3
                local clear,reason=ray(length+distance*a,offset+sideways*a*a,length+distance*b,offset+sideways*b*b,height)
                if clear~=true then return clear,reason end
            end
        end
        -- Side rails cover body clearance. Curved paths also require room for
        -- the nose to swing opposite to the rear, outside the present body.
        for _,edge in ipairs({-1,1}) do
            local clear,reason=ray(-length,edge*width,length,edge*width,height)
            if clear~=true then return clear,reason end
        end
        if side~=0 then
            local clear,reason=ray(-length,-side*width,-length+distance*0.25,-side*(width+math.abs(sideways)+0.5),height)
            if clear~=true then return clear,reason end
        end
    end
    for _,fraction in ipairs({0.5,1}) do
        local gx,gy=point(length+distance*fraction,sideways*fraction*fraction,0)
        local clear,reason=EscapePlanner.ground(gx,gy,z)
        if clear~=true then return clear,reason end
    end
    return true,"clear"
end
function EscapePlanner.choose(car,attempt,distance)
    local order=attempt>1 and {1,-1,0} or {0,1,-1}
    if attempt>1 and EscapePlanner.lastSide==1 then order={-1,1,0} end
    local lastReason="no clear escape"
    for _,side in ipairs(order) do
        local clear,reason=EscapePlanner.scan(car,side,distance)
        if clear==true then
            EscapePlanner.lastSide=side
            EscapePlanner.status=side==0 and "reverse straight" or (side==1 and "reverse left" or "reverse right")
            return {side=side,steer=-side*CONFIG.escape.steering,distance=distance,label=EscapePlanner.status}
        end
        lastReason=reason or lastReason
    end
    return nil,lastReason
end
function EscapePlanner.pause(reason,consumeAttempt)
    if consumeAttempt then RecoveryMemory.finish("escape_blocked") end
    stopBumpRecovery(nil)
    S.manualPaused=true
    S.recoveryBlockedReason=reason
    S.recoveryBlockedCode="RECOVERY_BLOCKED"
    EscapePlanner.status=reason
    syncPausedState()
    releaseControls("RECOVERY_BLOCKED")
    logEvent("ESCAPE","paused: "..reason)
    UI.notify("~r~Escape blocked ~w~- take over; F6 to retry",2500)
end

local function isBumpRecoveryAllowed(route, pidx, now)
    now = now or os.clock()
    if not CONFIG.recovery.bumpEnabled then return false end
    if freezeRecoveryOwnsControls() then return false end
    if not playing or paused or recording then return false end
    if S.bumpActive or now < (S.bumpCooldownUntil or 0.0) then return false end
    if sharedFreezeActive() then return false end
    if S.dialogPaused or S.testArbotasPaused or now < S.dialogReleaseUntil then return false end
    if now < S.rotateFightUntil or now < S.rotateReleaseUntil then return false end
    if now < (S.backToForwardUntil or 0.0) then return false end
    if isPlayerControlling() then return false end
    if type(route) ~= "table" or #route == 0 then return false end
    if routeDriveModeAt(route, pidx) == DRIVE_BACK then return false end
    return true
end

local function startBumpRecovery(car, route, pidx, reason)
    local now = os.clock()
    if freezeRecoveryOwnsControls() then
        releaseControls(pauseReleaseReason ~= "" and pauseReleaseReason or "FREEZE_WAIT")
        return false
    end
    if not isBumpRecoveryAllowed(route, pidx, now) then return false end

    local cx, cy = getCarCoordinates(car)
    local recent = math.max(math.abs(lastDriveSpeed or 0.0), S.recentDriveSpeed or 0.0)
    local botPushingForward = (gasLevel or 0) > 45 or (S.routeObstacleUrgency or 0.0) > 0.08
    if recent < (CONFIG.recovery.bumpMinRecentSpeed or 2.0) and not botPushingForward then return false end

    local attempt = RecoveryMemory.plan(route, pidx, cx, cy, now)
    if not attempt then
        S.manualPaused = true
        S.recoveryBlockedReason = "repeated recovery without forward escape"
        syncPausedState(now)
        releaseControls("RECOVERY_LIMIT")
        logEvent("RECOVERY", "attempt limit: neutral pause; F6 resumes with fresh recovery history")
        UI.notify("~r~Recovery limit ~w~- take over; F6 to retry", 2500)
        return true
    end
    local speedFactor = clamp01(recent / 42.0)
    local minDistance = (CONFIG.recovery.bumpReverseDistanceMin or 2.0) + speedFactor * 0.9
    local maxDistance = (CONFIG.recovery.bumpReverseDistanceMax or 6.0) + speedFactor * 0.8
    local reverseMin = CONFIG.recovery.bumpReverseMinSeconds or 0.85
    local reverseSeconds = reverseMin + speedFactor * ((CONFIG.recovery.bumpReverseMaxSeconds or 1.65) - reverseMin)

    if attempt > 1 then
        minDistance = minDistance + (CONFIG.recovery.repeatedReverseExtraMeters or 2.0)
        maxDistance = maxDistance + (CONFIG.recovery.repeatedReverseExtraMeters or 2.0)
        reverseSeconds = math.min(reverseSeconds + (CONFIG.recovery.repeatedReverseExtraSeconds or 0.5),
            CONFIG.recovery.bumpReverseHardMaxSeconds or 2.6)
    end
    local escapePlan
    if CONFIG.escape.enabled then
        local distance=math.min(8,math.max(CONFIG.escape.probeDistance,minDistance+0.8))
        local reason
        escapePlan,reason=EscapePlanner.choose(car,attempt,distance)
        if not escapePlan then EscapePlanner.pause(reason or "no clear escape",false);return true end
        maxDistance=math.min(maxDistance,distance-CONFIG.escape.margin)
        minDistance=math.min(minDistance,maxDistance-0.1)
        logEvent("ESCAPE",escapePlan.label.." checked="..string.format("%.1fm",distance))
    end
    S.bumpPlan=escapePlan
    S.bumpNextProbeAt=now+CONFIG.escape.recheckSeconds
    S.bumpActive = true
    S.bumpPhase = "reverse"
    S.bumpReason = reason or "stuck"
    S.bumpStartedAt = now
    S.bumpUntil = now + reverseSeconds
    S.bumpCooldownUntil = now + (CONFIG.recovery.bumpCooldownSeconds or 3.4)
    S.bumpGraceUntil = now + reverseSeconds + (CONFIG.recovery.bumpFreezeGraceSeconds or 1.8)
    S.freezeRecoveryGraceUntil = math.max(S.freezeRecoveryGraceUntil or 0.0, S.bumpGraceUntil)
    S.bumpStartX = cx
    S.bumpStartY = cy
    S.bumpMinDistance = minDistance
    S.bumpMaxDistance = maxDistance
    S.bumpSteer = escapePlan and escapePlan.steer or 0
    resetForwardNoProgress()
    gasLevel = 0
    brakeLevel = 0
    lastSteerValue = 0
    writeDriveControls(0, 0, false, "BUMP")
    freezeTimer = 0
    suddenStopFrames = 0
    collisionCooldown = 0
    resetObstacleBypass()

    dbg("recovery", string.format("bump attempt=%d plan=%s reason=%s", attempt, attempt == 1 and "normal_reverse" or "extended_reverse", tostring(S.bumpReason)))
    return true
end

local resyncAfterBump

local function updateBumpRecovery(car, carX, carY)
    if not S.bumpActive then return false end
    local now = os.clock()

    if S.freezeTestLatched or S.frozenByAdmin or sharedFreezeActive()
        or S.dialogPaused or S.testArbotasPaused or now < S.dialogReleaseUntil
        or now < S.rotateFightUntil or now < S.rotateReleaseUntil
        or isPlayerControlling() then
        stopBumpRecovery("BUMP_CANCEL")
        return false
    end

    local backed = getDistanceBetweenCoords2d(carX, carY, S.bumpStartX or carX, S.bumpStartY or carY)
    if S.bumpPhase == "reverse" then
        if CONFIG.escape.enabled and backed<(S.bumpMaxDistance or 6) and now>=(S.bumpNextProbeAt or 0) then
            local distance=math.max(1.2,math.min(2.5,(S.bumpMaxDistance or 6)-backed+CONFIG.escape.margin))
            local clear,reason=EscapePlanner.scan(car,S.bumpPlan and S.bumpPlan.side or 0,distance)
            if clear~=true then EscapePlanner.pause(reason or "escape no longer clear",true);return true end
            S.bumpNextProbeAt=now+CONFIG.escape.recheckSeconds
        end
        gasLevel = 0
        brakeLevel = 0
        lastSteerValue = S.bumpSteer or 0
        writeSteerControls(lastSteerValue, "BUMP")
        local reverseAllowed=true
        if CONFIG.escape.enabled then
            local speed=math.abs(S.forwardSpeed or getCarSpeed(car))
            reverseAllowed=speed<CONFIG.escape.maxSpeed or (S.forwardSpeed and S.forwardSpeed>0) or false
        end
        writeDriveControls(0, 0, reverseAllowed, "BUMP")
        writeSharedState("BUMP_BACK")
        UI.notify(string.format("~y~BUMP BACK ~w~%.1fm", backed), 100)

        local reverseElapsed = now - (S.bumpStartedAt or now)
        if reverseElapsed >= (CONFIG.recovery.bumpFreezeEscalateSeconds or 1.2)
            and backed <= (CONFIG.recovery.bumpFreezeEscalateDistance or 0.25) then
            logEvent("RECOVERY", string.format("reverse blocked: moved %.2fm in %.2fs; neutral pause", backed, reverseElapsed))
            RecoveryMemory.finish("reverse_blocked")
            stopBumpRecovery(nil)
            S.manualPaused = true
            S.recoveryBlockedReason = "reverse blocked; cause unknown"
            S.recoveryBlockedCode = "RECOVERY_BLOCKED"
            syncPausedState(now)
            releaseControls("RECOVERY_BLOCKED")
            UI.notify("~r~Reverse blocked ~w~- take over; F6 to retry", 2500)
            return true
        end

        local backedEnough = backed >= (S.bumpMinDistance or 2.0)
        local backedTooFar = backed >= (S.bumpMaxDistance or 6.0)
        local hardTimeDone = now >= ((S.bumpStartedAt or now) + (CONFIG.recovery.bumpReverseHardMaxSeconds or 2.6))
        local plannedTimeDone = now >= (S.bumpUntil or now)
        if backedTooFar or hardTimeDone or (plannedTimeDone and backedEnough) then
            S.bumpPhase = "coast"
            S.bumpUntil = now + (CONFIG.recovery.bumpCoastSeconds or 0.32)
            gasLevel = 0
            brakeLevel = 0
            lastSteerValue = 0
            writeSteerControls(0, "BUMP")
            writeDriveControls(0, 0, false, "BUMP")
        end
        return true
    end

    if S.bumpPhase == "coast" then
        gasLevel = 0
        brakeLevel = 0
        lastSteerValue = 0
        writeSteerControls(0, "BUMP")
        writeDriveControls(0, 0, false, "BUMP")
        writeSharedState("BUMP_WAIT")
        UI.notify("~y~BUMP WAIT", 100)
        if now >= (S.bumpUntil or 0.0) then
            S.freezeRecoveryGraceUntil = math.max(S.freezeRecoveryGraceUntil or 0.0, now + (CONFIG.recovery.bumpFreezeGraceSeconds or 1.8))
            S.rejoinDisableUntil = math.max(S.rejoinDisableUntil or 0.0, now + 1.0)
            freezeTimer = 0
            suddenStopFrames = 0
            S.recentDriveSpeed = 0.0
            S.recentDriveUntil = 0.0
            lastDriveSpeed = 0.0
            RecoveryMemory.finish(backed >= (S.bumpMinDistance or 2.0) and "backed_away" or "short_reverse")
            resyncAfterBump(carX, carY, getCarHeading(car))
            stopBumpRecovery("BUMP_DONE")
            startBackToForwardTransition()
            dbg("recovery", "bump recovery finished")
            return true
        end
        return true
    end

    RecoveryMemory.finish("unexpected_phase")
    stopBumpRecovery("BUMP_DONE")
    resyncAfterBump(carX, carY, getCarHeading(car))
    startBackToForwardTransition()
    return true
end

resyncAfterBump = function(carX, carY, heading)
    if type(current_route) ~= "table" or #current_route == 0 then return false end
    local oldIndex = play_index
    local index, accepted = RouteFollower.findRejoin(current_route, carX, carY, play_index,
        CONFIG.recovery.bumpResyncBackPoints or 10, CONFIG.recovery.bumpResyncAheadPoints or 45,
        CONFIG.recovery.bumpResyncMaxDistance or 28.0, heading)
    if accepted and index ~= oldIndex then
        play_index = index
        playbackDriveMode = routeDriveModeAt(current_route, index)
        steerBuf = {0, 0}
        S.currentLateral = 0.0
        resetObstacleBypass()
        collisionCooldown = 0
        resetForwardNoProgress()
        logEvent("RECOVERY", string.format("bounded bump rejoin %d -> %d", oldIndex, index))
        return true
    end
    resetForwardNoProgress()
    return false
end

local function updateForwardNoProgress(route, pidx, cx, cy, absSpeed)
    if type(route) ~= "table" or #route == 0 then
        resetForwardNoProgress()
        return false
    end

    pidx = math.max(1, math.min(tonumber(pidx) or 1, #route))
    local point = route[pidx]
    if not point or routeDriveModeAt(route, pidx) == DRIVE_BACK then
        resetForwardNoProgress()
        return false
    end

    local pushingForward = (gasLevel or 0) >= (CONFIG.recovery.forwardNoProgressGas or 80)
    local movingEnough = (absSpeed or 0.0) > (CONFIG.recovery.forwardNoProgressSpeed or 8.0)
    if not pushingForward or movingEnough or S.bumpActive or S.freezeTestLatched or S.frozenByAdmin then
        resetForwardNoProgress()
        return false
    end

    local dist = getDistanceBetweenCoords2d(cx, cy, point.x, point.y)
    if (S.forwardNoProgressIndex or 0) ~= pidx then
        S.forwardNoProgressIndex = pidx
        S.forwardNoProgressDist = dist
        S.forwardNoProgressFrames = 0
        return false
    end

    -- Expected progress per frame shrinks with shorter frames, so both the
    -- epsilon and the counter are in reference frames.
    local epsilon = (CONFIG.recovery.forwardProgressEpsilon or 0.06) * frameScale
    local lastDist = S.forwardNoProgressDist or dist
    if dist >= lastDist - epsilon then
        S.forwardNoProgressFrames = (S.forwardNoProgressFrames or 0) + frameScale
    else
        S.forwardNoProgressFrames = math.max(0, (S.forwardNoProgressFrames or 0) - 3 * frameScale)
    end
    S.forwardNoProgressDist = dist

    return (S.forwardNoProgressFrames or 0) >= (CONFIG.recovery.forwardNoProgressFrames or 44)
end

-- Types a chat command with the keyboard. Returns a job whose done / ok /
-- finishedAt fields the caller polls, or nil and a reason when typing cannot
-- start. It never types while another window is active or a SA-MP dialog is
-- open, and it stops (releasing every key) if either happens mid-way.
local function typeSAMPCommand(cmd, options)
    options = options or {}
    cmd = tostring(cmd or "")
    if cmd == "" then return nil, "empty command" end
    if commandJob and not commandJob.done then return nil, "already typing" end
    if not Win32.init() then return nil, "user32 unavailable" end
    if not Win32.isGameForeground(options.reaction) then return nil, "game window not active" end
    if isSampDialogActive() then return nil, "dialog open" end
    local chatOpen = isSampChatInputActive()
    if chatOpen == true then return nil, "chat already open" end
    if options.reaction and chatOpen ~= false then return nil, "chat state unknown" end

    local job = { cmd = cmd, done = false, ok = false, cancelled = false, startedAt = os.clock() }
    commandJob = job

    local function blockedReason()
        if job.cancelled then return "cancelled" end
        if not Win32.isGameForeground(options.reaction) then return "game window lost focus" end
        if isSampDialogActive() then return "dialog opened" end
        if options.reaction then
            if freezeRecoveryOwnsControls() or fileExists(rotate_flag_file)
                or os.clock() < S.rotateReleaseUntil then return "recovery interrupted typing" end
            if S.manualPaused then return "manually paused" end
            if not playing then return "playback stopped" end
            if AdminChat.userInputActive() then return "user input" end
        end
        return nil
    end

    local function tapKey(vk, holdMs)
        Win32.press(vk)
        wait(holdMs or 35)
        Win32.release(vk)
    end

    local function tapCharacter(ch)
        local byte = string.byte(ch)
        if not byte then return false end
        local vk
        local needShift = false
        if byte >= 97 and byte <= 122 then
            vk = byte - 32
        elseif byte >= 65 and byte <= 90 then
            vk = byte
            needShift = true
        elseif byte >= 48 and byte <= 57 then
            vk = byte
        else
            local ok, scan = pcall(Win32.u32.VkKeyScanA, byte)
            scan = ok and tonumber(scan) or -1
            if scan >= 0 and math.floor(scan / 256) <= 1 then
                vk = scan % 256
                needShift = math.floor(scan / 256) % 2 == 1
            elseif ch == "/" then
                vk = 0xBF -- VK_OEM_2, slash on common GTA/SA-MP keyboard layouts.
            else
                return false
            end
        end
        if options.reaction and blockedReason() then return false end
        if needShift then Win32.press(0x10) end
        tapKey(vk, 30)
        if needShift then Win32.release(0x10) end
        return true
    end

    lua_thread.create(function()
        Win32.releaseKeys({0x10, 0x11, 0x12})
        local reason = blockedReason()
        if not reason then
            tapKey(0x54, 50) -- T opens SA-MP chat in this setup.
            job.openedChat = true
            wait(350)
            if options.reaction and isSampChatInputActive() ~= true then
                reason = "chat did not open"
            end
        end
        for i = 1, #cmd do
            reason = reason or blockedReason()
            if reason then break end
            if not tapCharacter(cmd:sub(i, i)) then
                logEvent("INPUT", "typeSAMPCommand skipped character at " .. tostring(i))
                if options.reaction then reason = blockedReason() or "unsupported character" end
            end
            wait(45)
        end
        if not reason then
            wait(180)
            reason = blockedReason()
        end
        if not reason then
            tapKey(0x0D, 40)
            job.submitted = true
        elseif options.reaction and job.openedChat and reason ~= "user input"
            and Win32.isGameForeground(options.reaction) and not isSampDialogActive()
            and isSampChatInputActive() == true then
            tapKey(0x1B, 30) -- Close our partial chat only while ownership is safe.
        end
        Win32.releaseHeld()
        job.reason = reason
        job.ok = reason == nil
        job.finishedAt = os.clock()
        job.done = true
        if reason then
            logEvent("INPUT", "typing '" .. cmd .. "' stopped: " .. reason)
        end
    end)
    return job
end

-- Local motion is evidence, never a verified server/admin verdict.
function MotionClassifier.reset()
    MotionClassifier.previous = nil
    MotionClassifier.candidateUntil = nil
    MotionClassifier.obstacleUntil = nil
    MotionClassifier.kind = nil
end

function MotionClassifier.observe(now, x, y, speed, heading, obstacleDistance, gas, brake)
    local previous = MotionClassifier.previous
    local kind, reason = "stuck", "immobile without conclusive freeze evidence"
    local nearObstacle = (obstacleDistance or math.huge) <= 5.5
    if nearObstacle then MotionClassifier.obstacleUntil = now + 0.75 end
    local obstructed = now < (MotionClassifier.obstacleUntil or -1)
    local dt = previous and now - previous.at or nil
    local moved = previous and getDistanceBetweenCoords2d(x,y,previous.x,previous.y) or 0
    local angle = previous and math.abs((heading-previous.heading+180)%360-180) or 0
    local validSample = dt and dt > 0 and dt <= 0.25
    if not validSample then MotionClassifier.candidateUntil = nil end
    if speed >= 0.75 or moved > 0.25 then
        MotionClassifier.candidateUntil = nil
        kind, reason = "moving", "vehicle moving"
    elseif brake > 0 or gas <= 45 then
        MotionClassifier.candidateUntil = nil
        kind, reason = "intentional_stop", "no forward throttle or braking"
    elseif obstructed then
        MotionClassifier.candidateUntil = nil
        kind, reason = "obstructed", "nearby obstacle; possible collision"
    elseif validSample and previous.speed >= 8 and speed < 0.75
        and moved < 0.14 and angle < 12 and previous.gas > 45 and previous.brake == 0 then
        MotionClassifier.candidateUntil = now + 2.4
        kind, reason = "suspected_freeze", "abrupt stationary stop under throttle; no nearby obstacle"
    elseif now < (MotionClassifier.candidateUntil or -1) then
        kind, reason = "suspected_freeze", "abrupt stop remains stationary"
    elseif not validSample then
        kind, reason = "uncertain", "missing or stale motion sample"
    end
    MotionClassifier.previous = {at=now,x=x,y=y,speed=speed,heading=heading,gas=gas,brake=brake}
    if kind ~= MotionClassifier.kind then
        MotionClassifier.kind = kind
        logEvent("MOTION", kind .. ": " .. reason)
    end
    return kind
end

local function handleFreeze(car, route, pidx)
    local cx, cy = getCarCoordinates(car)
    local speed = getCarSpeed(car)
    local absSpeed = math.abs(speed or 0.0)
    local moved = getDistanceBetweenCoords2d(cx, cy, lastX, lastY)
    local now = os.clock()
    local externalFreeze = sharedFreezeActive()
    if RecoverySystem.controlLockState() == true then
        releaseControls("FREEZE_WAIT")
        return true
    end

    if externalFreeze then
        if not S.freezeTestLatched and not S.externalFreezeAck then
            logEvent("RECOVERY", "external freeze detected")
            startFreezeRecovery("test")
        end
        resetForwardNoProgress()
        lastDriveSpeed = speed
        lastX, lastY = cx, cy
        return true
    end

    if S.dialogPaused or S.testArbotasPaused or now < S.dialogReleaseUntil
        or now < S.rotateFightUntil or now < S.rotateReleaseUntil
        or now < (S.backToForwardUntil or 0.0)
        or ((S.bumpActive or now < (S.bumpGraceUntil or 0.0)) and not externalFreeze)
        or isPlayerControlling() then
        freezeTimer = 0
        suddenStopFrames = 0
        S.recentDriveSpeed = 0.0
        S.recentDriveUntil = 0.0
        resetForwardNoProgress()
        lastDriveSpeed = speed
        lastX, lastY = cx, cy
        return false
    end

    if S.freezeTestLatched and S.freezeRecoveryMode == "test" then
        resetFreezeRecovery()
        resetForwardNoProgress()
        lastDriveSpeed = speed
        lastX, lastY = cx, cy
        return false
    end

    if suppressFreezeForIntentionalReverse(now, route, pidx) then
        freezeTimer = 0
        suddenStopFrames = 0
        S.frozenByAdmin = false
        S.refreshSent = false
        S.recentDriveSpeed = 0.0
        S.recentDriveUntil = 0.0
        resetForwardNoProgress()
        lastDriveSpeed = speed
        lastX, lastY = cx, cy
        return false
    end

    if now < S.freezeRecoveryGraceUntil then
        freezeTimer = 0
        suddenStopFrames = 0
        S.frozenByAdmin = false
        S.refreshSent = false
        resetForwardNoProgress()
        lastDriveSpeed = speed
        lastX, lastY = cx, cy
        return false
    end

    local motionKind = MotionClassifier.observe(now, cx, cy, absSpeed, getCarHeading(car),
        S.routeObstacleDist, ControlManager.applied.gas, ControlManager.applied.brake)
    if motionKind == "intentional_stop" then
        freezeTimer, suddenStopFrames = 0, 0
        S.recentDriveSpeed, S.recentDriveUntil = 0, 0
        resetForwardNoProgress()
        lastDriveSpeed = speed
        lastX,lastY = cx,cy
        return false
    end

    if absSpeed > 8.0 or moved > 0.45 then
        S.recentDriveSpeed = math.max((S.recentDriveSpeed or 0.0) * 0.82, absSpeed)
        S.recentDriveUntil = now + 2.4
    end

    local stoppedNow = absSpeed < 0.75 and moved < 0.14
    if stoppedNow then
        suddenStopFrames = suddenStopFrames + frameScale
    elseif absSpeed > 2.0 or moved > 0.35 then
        suddenStopFrames = 0
    end

    local stoppedAfterMoving = suddenStopFrames >= 8
        and (S.recentDriveSpeed or 0.0) > 18.0
        and now < (S.recentDriveUntil or 0.0)

    if stoppedAfterMoving then
        freezeTimer = math.max(freezeTimer, 4)
        if motionKind == "suspected_freeze" then
            startFreezeRecovery("suspected")
            lastDriveSpeed = speed
            lastX, lastY = cx, cy
            return true
        end
        if startBumpRecovery(car, route, pidx, "sudden_stop") then
            lastDriveSpeed = speed
            lastX, lastY = cx, cy
            return false
        end
        -- A failed/cooling-down recovery is not evidence of a freeze.
    end

    if updateForwardNoProgress(route, pidx, cx, cy, absSpeed) then
        if startBumpRecovery(car, route, pidx, "no_progress") then
            lastDriveSpeed = speed
            lastX, lastY = cx, cy
            return false
        end
    end

    if stoppedNow then
        freezeTimer = freezeTimer + frameScale
        local botTryingForward = (gasLevel or 0) > 70
            or (S.recentDriveSpeed or 0.0) > 1.2
            or math.abs(lastDriveSpeed or 0.0) > 1.0
        if freezeTimer > 12 and motionKind == "suspected_freeze" then
            startFreezeRecovery("suspected")
            lastDriveSpeed = speed
            lastX, lastY = cx, cy
            return true
        end
        if freezeTimer > 12 and botTryingForward and motionKind ~= "intentional_stop" then
            if startBumpRecovery(car, route, pidx, "stuck") then
                lastDriveSpeed = speed
                lastX, lastY = cx, cy
                return false
            end
        end
        if freezeTimer > 150 then
            local point = route[pidx]
            if point then
                local th = getHeadingFromVector2d(point.x - cx, point.y - cy)
                local diff = math.abs(getCarHeading(car) - th)
                if diff > 180 then diff = 360 - diff end
                if diff > 100 and startBumpRecovery(car, route, pidx, "misaligned") then
                    lastDriveSpeed = speed
                    lastX, lastY = cx, cy
                    return false
                end
            end
        end
    else
        freezeTimer = 0
        suddenStopFrames = 0
        resetForwardNoProgress()
        S.frozenByAdmin = false
        S.refreshSent = false
        if pauseReleaseReason == "FROZEN" or pauseReleaseReason == "FREEZE_TEST" or pauseReleaseReason == "SUDDEN_STOP" then
            pauseReleaseReason = ""
        end
    end
    lastDriveSpeed = speed
    lastX, lastY = cx, cy
    return S.frozenByAdmin
end

-- Poll before playback's paused gate, including during an existing rotation.
local function handleAdminRotate(car)
    if not playing then return end
    local now=os.clock()
    local r=RecoverySystem.rotation
    local mode=consumeRotateFlag()
    local enabled=now>=(S.rotateIgnoreUntil or 0) and not isPlayerControlling()
    local triggered=r:observe(now,car,getCarHeading(car),mode~=nil,enabled,ControlManager.applied.steer)
    if not triggered then return end
    S.rotateFightUntil,S.rotateReleaseUntil=math.huge,math.huge
    resetBumpState(false)
    S.backToForwardUntil=0
    S.keyboardController=nil;S.digitalSteer=0;S.digitalReverseAfter=0
    S.smoothSteerValue=0;steerBuf={0,0};DrivingPlanner.heldTarget=nil
    resetObstacleBypass()
    freezeTimer,suddenStopFrames=0,0
    AdminChat.noteRotation(mode~=nil)
    syncPausedState(now)
    if r.phase=="REACT" then
        ControlManager.request("ROTATE",{gas=0,brake=0,steer=r.heldSteer,reverse=false})
    else releaseControls("ROTATE_HOLD") end
    logEvent("ROTATION",string.format("disturbance %d; %s",r.count,r.phase))
end

function RecoverySystem.rotationTarget(car,x,y)
    local index,accepted=RouteFollower.findRejoin(current_route,x,y,play_index,0,512,28,nil)
    if not accepted then return nil end
    local tx,ty=DrivingPlanner.target(current_route,index,x,y,0)
    if not tx or (tx-x)^2+(ty-y)^2<4 then return nil end
    -- GTA heading increases leftwards; positive steering is rightwards.
    local desired=getHeadingFromVector2d(tx-x,ty-y)
    if routeDriveModeAt(current_route,index)~=DRIVE_FORWARD then desired=desired+180 end
    local err=(getCarHeading(car)-desired+180)%360-180
    return {index=index,x=tx,y=ty,error=err}
end

function RecoverySystem.rotationCorridor(car)
    local x,y,z=getCarCoordinates(car)
    local fx,fy,lx,ly=getCarForwardAxes(car)
    local profile=VehicleProfiles.profile()
    local halfLength,halfWidth=profile.half_length,profile.half_width+0.4
    -- Probe beyond the nose and alongside both sides before each slow step.
    for _,side in ipairs({-1,0,1}) do
        local ax,ay=x+fx*(halfLength+0.3)+lx*side*halfWidth,y+fy*(halfLength+0.3)+ly*side*halfWidth
        local clear=EscapePlanner.ray(ax,ay,z+0.4,ax+fx*3,ay+fy*3,z+0.4)
        if clear~=true then return false end
    end
    for _,side in ipairs({-1,1}) do
        local ax,ay=x+lx*side*halfWidth,y+ly*side*halfWidth
        if EscapePlanner.ray(ax-fx*halfLength,ay-fy*halfLength,z+0.4,
            ax+fx*(halfLength+2),ay+fy*(halfLength+2),z+0.4)~=true then return false end
    end
    for _,side in ipairs({-1,1}) do
        for _,height in ipairs({0.25,0.85}) do
            local ax,ay=x+fx*halfLength+lx*side*halfWidth,y+fy*halfLength+ly*side*halfWidth
            if EscapePlanner.ray(ax,ay,z+height,ax+fx*2+lx*side*2,ay+fy*2+ly*side*2,z+height)~=true then return false end
        end
        if EscapePlanner.ground(x+fx*(halfLength+2)+lx*side*2,y+fy*(halfLength+2)+ly*side*2,z)~=true then return false end
    end
    return EscapePlanner.ground(x+fx*(halfLength+3),y+fy*(halfLength+3),z)==true
end

function RecoverySystem.finishRotation(reason,target)
    local r=RecoverySystem.rotation
    if reason~="ready" or not target then
        r:retry(os.clock(),reason)
        releaseControls("ROTATE_WAIT")
        return
    end
    local count=r.count or 0
    releaseControls("ROTATE_SETTLE")
    S.rotateFightUntil,S.rotateReleaseUntil=0,0
    r:reset()
    S.keyboardController=nil;S.digitalSteer=0;S.digitalReverseAfter=0
    S.smoothSteerValue=0;steerBuf={0,0};DrivingPlanner.heldTarget=nil
    freezeTimer,suddenStopFrames,lastDriveSpeed=0,0,0
    S.recentDriveSpeed,S.recentDriveUntil=0,0
    MotionClassifier.reset()
    do
        local old=play_index
        play_index=target.index
        playbackDriveMode=routeDriveModeAt(current_route,play_index)
        RecoveryMemory.reset("rotation resume")
        S.dialogRejoinPending=nil -- this rejoin already accounts for the current position
        S.chatRouteActive=nil
        lastX,lastY=getCarCoordinates(storeCarCharIsInNoSave(PLAYER_PED))
        S.freezeRecoveryGraceUntil=os.clock()+2.1
        S.rejoinDisableUntil=os.clock()+1
        AdminChat.finishRotationSequence(true)
        logEvent("ROTATION",string.format("stable rejoin %d -> %d after %d disturbances",old,play_index,count))
    end
    syncPausedState()
end

function RecoverySystem.updateRotation(now)
    local r=RecoverySystem.rotation
    if not r.phase then return end
    local car=storeCarCharIsInNoSave(PLAYER_PED)
    local x,y=getCarCoordinates(car)
    local speed=math.abs(getCarSpeed(car))
    local allowed=ControlManager.resolveOwner()=="ROTATE" and Win32.isGameForeground(true)
        and isSampChatInputActive()==false
    local target
    if allowed and r.phase~="HOLD" and r.phase~="REACT" and r.phase~="WAIT" then target=RecoverySystem.rotationTarget(car,x,y) end
    local oldPhase=r.phase
    local clear=allowed and r.phase=="ALIGN" and target and math.abs(target.error)>22
        and RecoverySystem.rotationCorridor(car)
    local direction=r.direction or (target and target.error<0 and -128 or 128)
    local reverseClear=allowed and target and (r.phase=="ALIGN" or r.phase=="REVERSE")
        and EscapePlanner.scan(car,direction/128,2)==true
    local forwardSpeed=getCarForwardSpeed(car)
    -- Position deltas provide a fallback when vehicle memory is unavailable.
    local previous=r.motion
    local slip=0
    if previous and previous.car==car and now>previous.at and now-previous.at<=0.35 then
        local dx,dy=x-previous.x,y-previous.y
        local fx,fy=getCarForwardAxes(car)
        forwardSpeed=forwardSpeed or (dx*fx+dy*fy)/(now-previous.at)
        if dx*dx+dy*dy>0.0025 then
            local facing=math.abs((getCarHeading(car)-getHeadingFromVector2d(dx,dy)+180)%360-180)
            slip=math.min(facing,180-facing)
        end
    end
    r.motion={x=x,y=y,at=now,car=car}
    local command,result=r:step(now,{x=x,y=y,speed=speed,allowed=allowed,clear=clear,
        reverseClear=reverseClear,forwardSpeed=forwardSpeed,slip=slip},target and target.error)
    if oldPhase~=r.phase then logEvent("ROTATION",oldPhase.." -> "..r.phase) end
    if result then RecoverySystem.finishRotation(result,target);return end
    gasLevel,brakeLevel,lastSteerValue=command.gas,command.brake,command.steer
    ControlManager.request("ROTATE",command)
    writeSharedState("ROTATE_"..r.phase)
end

local function finishDialogPause()
    S.dialogRejoinPending = true
    if S.fakeDialogChatToken then
        AdminChat.complete("arbotas", S.fakeDialogChatToken, true)
        S.fakeDialogChatToken = nil
    end
    local now = os.clock()
    if S.bumpActive then
        stopBumpRecovery("BUMP_DIALOG")
    end
    S.testArbotasPaused = false
    S.dialogPaused = false
    S.dialogReleaseUntil = now + (math.random(500, 1000) / 1000.0)
    freezeTimer = 0
    suddenStopFrames = 0
    S.recentDriveSpeed = 0.0
    S.recentDriveUntil = 0.0
    lastDriveSpeed = 0.0
    pauseReleaseReason = "DIALOG_WAIT"
    syncPausedState(now)
    releaseControls("DIALOG_WAIT")
end

local function handleArbotas()
    -- Other scripts can only signal through files: each MoonLoader script has
    -- its own Lua state, so their _G values are never visible here.
    local fakeDialogMode = sharedDialogMode()
    if fakeDialogMode == "fake_arbotas" then
        if not S.testArbotasPaused then S.fakeDialogChatToken = AdminChat.begin("arbotas") end
        if S.bumpActive then
            stopBumpRecovery("BUMP_DIALOG")
        end
        S.testArbotasPaused = true
        S.dialogPaused = true
        S.dialogReleaseUntil = 0.0
        syncPausedState()
        releaseControls("AR_BOTAS_TEST")
        return
    end
    if S.testArbotasPaused then
        finishDialogPause()
        return
    end
    if not playing or samp == 0 then return end
    if not isSampDialogActive() then
        if S.dialogPaused then
            finishDialogPause()
        end
        return
    end
    S.dialogPaused = true
    S.dialogReleaseUntil = 0.0
    if S.bumpActive then
        stopBumpRecovery("BUMP_DIALOG")
    end
    syncPausedState()
    releaseControls("DIALOG")
    return
end

RouteStorage.save = saveRoute
RouteStorage.load = loadRoute
RouteStorage.saveRoute = RouteStorage.save
RouteStorage.loadRoute = RouteStorage.load

function RouteStorage.ensurePathsDir()
    if not doesDirectoryExist(paths_dir) then
        createDirectory(paths_dir)
    end
end

function RouteStorage.validateRoute(route)
    if type(route) ~= "table" or #route < 2 then return false end
    for _, p in ipairs(route) do
        if type(p) ~= "table"
            or type(p.x) ~= "number"
            or type(p.y) ~= "number"
            or type(p.z) ~= "number"
            or type(p.speed) ~= "number"
            or type(p.heading) ~= "number" then
            return false
        end
        if p.reverse ~= nil and type(p.reverse) ~= "boolean" then
            return false
        end
        if p.drive ~= nil and type(p.drive) ~= "string" then
            return false
        end
    end
    return true
end

function RouteStorage.inspectRoute(route)
    local summary = { total = 0, forward = 0, back = 0, bad = 0 }
    if type(route) ~= "table" then
        summary.bad = 1
        return summary
    end
    summary.total = #route
    for _, p in ipairs(route) do
        if type(p) ~= "table" or type(p.x) ~= "number" or type(p.y) ~= "number" then
            summary.bad = summary.bad + 1
        elseif isRoutePointReverse(p) then
            summary.back = summary.back + 1
        else
            summary.forward = summary.forward + 1
        end
    end
    return summary
end

function RouteStorage.logRouteSummary(name, route, action)
    local s = RouteStorage.inspectRoute(route)
    logEvent("ROUTE", string.format("%s %s points=%d fwd=%d back=%d bad=%d",
        tostring(action or "route"),
        tostring(name or current_name),
        s.total or 0,
        s.forward or 0,
        s.back or 0,
        s.bad or 0))
    if (s.bad or 0) > 0 then
        UI.notify("~y~Dangis VR: route has invalid points, check debug log.", 3000)
    end
end

function RouteRecorder.startRecording()
    if not isCharInAnyCar(PLAYER_PED) then
        showMsg("~r~Turi buti masinos viduje!")
        return false
    end
    RouteFollower.clearTransientState()
    releaseControls("REC_START")
    recording = true
    playing = false
    current_route = {}
    recordReverseFrames = 0
    recordForwardBrakeFrames = 0
    recordDriveMode = DRIVE_FORWARD
    recordLeftStart = false
    start_x, start_y = getCharCoordinates(PLAYER_PED)
    lastRecordHeading = getCarHeading(storeCarCharIsInNoSave(PLAYER_PED))
    tick = os.clock() * 1000
    dbg("route", "recording started")
    showMsg("~g~Irasymas pradetas! Grizk i starta uzdaryt kilpa!")
    return true
end

-- prefix: optional text shown before the "saved" message.
function RouteRecorder.stopRecording(prefix)
    recording = false
    current_route = normalizeRouteReverseFlags(current_route)
    if #current_route < 2 then
        showMsg((prefix or "") .. "~r~Per mazai tasku - kelias neissaugotas!")
    elseif RouteStorage.save(current_name, current_route) then
        RouteStorage.logRouteSummary(current_name, current_route, "saved")
        showMsg((prefix or "") .. "~g~Kelias issaugotas! Tasku: " .. #current_route)
    else
        logEvent("ROUTE", "saving " .. tostring(current_name) .. " failed")
        showMsg((prefix or "") .. "~r~Nepavyko issaugoti kelio!")
    end
end

function RouteRecorder.recordTick()
    if not recording then return end
    if not isCharInAnyCar(PLAYER_PED) then
        -- Keep what was recorded instead of silently dropping it.
        RouteRecorder.stopRecording("~r~Irasymas sustabdytas - islejai masina!~n~")
        return
    end

    local time = os.clock() * 1000
    local car = storeCarCharIsInNoSave(PLAYER_PED)
    local posX, posY, posZ = getCarCoordinates(car)
    local currentH = getCarHeading(car)
    local hDiff = math.abs(currentH - lastRecordHeading)
    if hDiff > 180 then hDiff = 360 - hDiff end
    if hDiff > 15 or (time - tick > recordingDelay) then
        local speed = getCarSpeed(car)
        local reverseIntent = isReverseRecordingInputActive()
        local prev = current_route[#current_route]
        local absSpeed = math.abs(speed or 0.0)
        local prevSpeed = prev and math.abs(prev.speed or 0.0) or 0.0
        local forwardMotion = nil
        local recordHudState = ""

        if prev then
            local dx = posX - prev.x
            local dy = posY - prev.y
            if dx * dx + dy * dy > 0.0025 then
                forwardMotion = getRecordedForwardMotion(car, currentH, prev, posX, posY) or 0.0
            end
        end

        local rollingForwardBrake = recordDriveMode ~= DRIVE_BACK
            and reverseIntent
            and (absSpeed > 2.0 or prevSpeed > 2.0 or (forwardMotion and forwardMotion > 0.04))
        local movingBackward = forwardMotion and forwardMotion < -0.025
        local stoppedForReverse = absSpeed < 1.15 and prevSpeed < 1.6
        local settledAfterBrake = absSpeed < 0.95 and (not forwardMotion or math.abs(forwardMotion) < 0.045)

        if not reverseIntent then
            recordDriveMode = DRIVE_FORWARD
            recordReverseFrames = 0
            recordForwardBrakeFrames = 0
            recordHudState = ""
        elseif rollingForwardBrake then
            -- In GTA, S means brake while rolling forward. Do not record BACK
            -- until the forward braking phase has genuinely settled.
            recordDriveMode = DRIVE_FORWARD
            recordReverseFrames = 0
            recordForwardBrakeFrames = 6
            recordHudState = "BRAKE"
        elseif recordDriveMode == DRIVE_BACK then
            recordReverseFrames = 10
            recordForwardBrakeFrames = 0
            recordHudState = "BACK"
        elseif recordForwardBrakeFrames > 0 then
            if movingBackward or stoppedForReverse or settledAfterBrake then
                recordForwardBrakeFrames = 0
                recordReverseFrames = math.min(10, recordReverseFrames + 4)
                recordDriveMode = recordReverseFrames >= 4 and DRIVE_BACK or DRIVE_FORWARD
                recordHudState = recordDriveMode == DRIVE_BACK and "BACK" or "S"
            else
                recordDriveMode = DRIVE_FORWARD
                recordReverseFrames = 0
                recordHudState = "WAIT"
            end
        else
            if stoppedForReverse or movingBackward then
                recordReverseFrames = math.min(10, recordReverseFrames + 4)
            else
                recordReverseFrames = math.max(0, recordReverseFrames - 1)
            end
            recordDriveMode = recordReverseFrames >= 4 and DRIVE_BACK or DRIVE_FORWARD
            recordHudState = recordDriveMode == DRIVE_BACK and "BACK" or "S"
        end

        local reverse = recordDriveMode == DRIVE_BACK
        table.insert(current_route, {x=posX, y=posY, z=posZ, speed=speed, heading=currentH, drive=recordDriveMode, reverse=reverse})
        lastRecordHeading = currentH
        tick = os.clock() * 1000
        local modeText = ""
        if reverse then
            modeText = " ~b~BACK"
        elseif reverseIntent then
            modeText = recordHudState == "BRAKE" and " ~y~BRAKE" or (recordHudState == "WAIT" and " ~y~WAIT" or " ~y~S")
        end
        UI.notify('~g~Irasymas ~w~X:'..math.floor(posX)..' Y:'..math.floor(posY)..' G:'..math.floor(speed * 3.6)..modeText, 1000)
        local dist = getDistanceBetweenCoords2d(posX, posY, start_x, start_y)
        if dist > 20.0 then
            recordLeftStart = true
        end
        -- Close the loop only after the car has left the start area; points are
        -- recorded while standing still, so waiting ~4 s at the start used to
        -- end the recording immediately.
        if recordLeftStart and dist < 5.0 and #current_route > 50 then
            recording = false
            current_route = normalizeRouteReverseFlags(current_route)
            if RouteStorage.save(current_name, current_route) then
                RouteStorage.logRouteSummary(current_name, current_route, "saved_loop")
                showMsg("~g~Kilpa uzdaryta! Issaugota: " .. current_name)
            end
        end
    end
end

ObstacleAvoidance.scanObstacles = scanRouteAhead
ObstacleAvoidance.updateBypass = updateObstacleBypass
ObstacleAvoidance.getObstacleAhead = getObstacleAhead

RecoverySystem.handleFreeze = handleFreeze
RecoverySystem.resetFreezeRecovery = resetFreezeRecovery
RecoverySystem.updateBumpRecovery = updateBumpRecovery

local function freezeResumeDelay()
    local delay = tonumber(S.freezeResumeDelay) or 0.0
    if delay <= 0.0 then
        delay = CONFIG.recovery.freezeResumeDelayMinSeconds or 0.5
    end
    return delay
end

-- State name while the car is held still because of a freeze.
local function frozenHoldReason()
    if S.externalFreezeAck and not S.freezeTestLatched then return "FREEZE_HOLD" end
    return pauseReleaseReason ~= "" and pauseReleaseReason or "FREEZE_WAIT"
end

local function updateRefreshStep(now)
    local retry = CONFIG.recovery.refreshRetrySeconds or 0.75
    if S.freezeRecoveryMode == "suspected" and not S.refreshSent and isCharInAnyCar(PLAYER_PED) then
        local cx, cy = getCarCoordinates(storeCarCharIsInNoSave(PLAYER_PED))
        if getDistanceBetweenCoords2d(cx,cy,S.freezeStartX or cx,S.freezeStartY or cy) > 0.5 then
            logEvent("MOTION", "suspected freeze cleared by movement before /refresh")
            resetFreezeRecovery()
            return
        end
    end
    if not S.refreshSent then
        releaseControls("FREEZE_WAIT")
        if now < (S.freezeRefreshAt or 0.0) then return end
        local inferredCooldown = S.freezeRecoveryMode == "suspected"
            and now < (MotionClassifier.lastRefreshAt or -math.huge) + CONFIG.recovery.inferredRefreshCooldownSeconds
        if inferredCooldown or (S.freezeRecoveryMode == "test" and not CONFIG.recovery.typeRefreshInFreezeTest) then
            logEvent("RECOVERY", inferredCooldown and "suspected freeze: /refresh cooldown" or "freeze test: /refresh disabled")
            S.refreshSent = true
            S.refreshJob = nil
            S.freezeRefreshSentAt = now
            S.freezeReleaseUntil = now + freezeResumeDelay()
            return
        end
        local job, reason = typeSAMPCommand("/refresh")
        if job then
            if S.freezeRecoveryMode == "suspected" then MotionClassifier.lastRefreshAt = now end
            logEvent("RECOVERY", "freeze recovery sending /refresh")
            S.refreshSent = true
            S.refreshJob = job
            S.refreshBlockedReason = nil
            S.freezeRefreshSentAt = now
            S.freezeReleaseUntil = math.huge -- set once typing has finished
        else
            S.freezeRefreshAt = now + retry
            if reason ~= S.refreshBlockedReason then
                S.refreshBlockedReason = reason
                logEvent("RECOVERY", "freeze recovery waiting to send /refresh: " .. tostring(reason))
            end
        end
        return
    end

    local job = S.refreshJob
    if job and not job.done then
        releaseControls("FREEZE_REFRESH")
        return
    end
    if job and not job.ok then
        logEvent("RECOVERY", "freeze recovery /refresh interrupted (" .. tostring(job.reason) .. "); retry scheduled")
        S.refreshJob = nil
        S.refreshSent = false
        S.freezeRefreshAt = now + retry
        releaseControls("FREEZE_WAIT")
        return
    end
    if job then
        -- Resume only after the command has actually been typed and sent.
        local finishedAt = job.finishedAt or now
        logEvent("RECOVERY", string.format("freeze recovery /refresh typed in %.2fs", finishedAt - (job.startedAt or finishedAt)))
        S.freezeReleaseUntil = finishedAt + freezeResumeDelay()
        S.refreshJob = nil
    end
    if S.freezeRecoveryMode == "control_lock" and now >= (S.freezeReleaseUntil or 0)
        and RecoverySystem.controlLockState() ~= false then
        releaseControls("FREEZE_HOLD")
        return
    end
    if now < (S.freezeReleaseUntil or 0.0) then
        releaseControls("FREEZE_REFRESH")
    else
        releaseControls("FREEZE_RESUME")
        resetFreezeRecovery()
    end
end

function RecoverySystem.pollControlLock(now)
    local locked = RecoverySystem.controlLockState()
    if locked == false then
        S.controlLockSince,S.controlLockHandled = nil,nil
    elseif locked == true then
        if not S.controlLockSince then
            S.controlLockSince = now
            logEvent("RECOVERY", "player controls disabled; holding neutral")
        end
        if now-S.controlLockSince >= 0.2 and not S.controlLockHandled and not S.freezeTestLatched then
            S.controlLockHandled = true
            logEvent("RECOVERY", "player control lock confirmed; starting /refresh recovery")
            startFreezeRecovery("control_lock")
        end
    else
        -- UI-only disabled controls must not accumulate confirmation time.
        S.controlLockSince = nil
    end
end

function RecoverySystem.updateControlThread()
    local now = os.clock()
    RecoverySystem.pollControlLock(now)
    if playing and isCharInAnyCar(PLAYER_PED) then
        handleAdminRotate(storeCarCharIsInNoSave(PLAYER_PED))
    elseif RecoverySystem.rotation.phase then
        RecoverySystem.rotation:reset()
        S.rotateFightUntil,S.rotateReleaseUntil=0,0
        AdminChat.rotation=nil
    end
    syncPausedState(now)
    -- This thread can run before test_freeze.lua creates its flag; playback
    -- and the control writers also read it live rather than relying on this poll.
    local freezeActive = sharedFreezeActive(true)
    if not freezeActive then
        S.externalFreezeAck = false
    end

    if freezeActive and playing and not S.freezeTestLatched and not S.externalFreezeAck then
        logEvent("RECOVERY", "external freeze detected by control thread")
        startFreezeRecovery("test")
        now = os.clock()
    end

    RecoverySystem.updateRotation(now)

    if (S.bumpActive or now < (S.backToForwardUntil or 0.0))
        and not freezeActive
        and not S.freezeTestLatched
        and not S.frozenByAdmin then
        return
    end

    if S.freezeTestLatched then
        updateRefreshStep(now)
    elseif RecoverySystem.rotation.phase then
        -- The rotation state machine already submitted this frame's command.
    elseif now < S.rotateFightUntil then
        pressRotateReaction()
    elseif now < S.rotateReleaseUntil then
        releaseControls("ROTATE_CONFUSED")
    elseif playing and (paused or freezeActive) then
        -- Only an active route holds the controls; a stopped bot never does.
        if freezeActive and not paused then
            releaseControls(frozenHoldReason())
        else
            releaseControls(pauseReleaseReason ~= "" and pauseReleaseReason or "SAFE")
        end
    end
end

AdminProtection.handleAdminCheck = handleAdminRotate
DialogBridge.update = handleArbotas
DialogBridge.writeBotState = writeSharedState

function RouteFollower.resetPlaybackStartState()
    RecoverySystem.rotation:reset()
    S.controlLockSince,S.controlLockHandled = nil,nil
    AdminChat.clear()
    MotionClassifier.reset()
    DrivingPlanner.cache = nil
    S.smoothSteerValue = 0
    S.freezeChatToken, S.fakeDialogChatToken = nil, nil
    RecoveryMemory.reset()
    writeDriveControls(0, 0)
    playbackDriveMode = DRIVE_FORWARD
    S.lapWander = (math.random() * 3.0) - 1.5
    gasLevel = 0; brakeLevel = 0
    S.gasLiftFrames = 0
    S.nextGasLift = os.clock() + math.random(20, 60)
    S.nudgeFrames = 0; S.nudgeOffset = 0.0
    S.nextNudge = os.clock() + math.random(12, 40)
    S.currentLateral = 0.0
    S.manualPaused = false
    S.dialogPaused = false
    S.testArbotasPaused = false
    S.dialogReleaseUntil = 0.0
    S.frozenByAdmin = false
    S.freezeTestLatched = false
    S.freezeRecoveryMode = ""
    S.refreshSent = false
    S.refreshJob = nil
    S.externalFreezeAck = false
    S.forwardSpeed = nil
    S.freezeRefreshSentAt = 0.0
    S.freezeReleaseUntil = 0.0
    S.freezeRefreshAt = 0.0
    S.freezeResumeDelay = 0.0
    S.freezeRecoveryGraceUntil = 0.0
    S.reversePlaybackGraceUntil = 0.0
    S.backToForwardUntil = 0.0
    resetBumpState(true)
    S.routeObstacleDist = math.huge
    S.routeAvoidDir = 0
    S.routeObstacleUrgency = 0.0
    S.routeObstacleTimer = 0
    S.obstacleHits = {}
    S.obstacleProbes = {}
    S.rejoinCooldownUntil = 0.0
    S.rejoinDisableUntil = os.clock() + 4.0
    resetObstacleBypass()
    S.avoidClusterCount = 0
    suddenStopFrames = 0
    freezeTimer = 0
    S.recentDriveSpeed = 0.0
    S.recentDriveUntil = 0.0
    collisionCooldown = 0
    avoidSteerDir = 0
    S.avoidRouteDir = 0
    S.avoidSideHit = false
    lastDriveSpeed = 0.0
    pauseReleaseReason = ""
    S.rotateFightUntil = 0.0
    S.rotateReleaseUntil = 0.0
    clearRotateTrigger()
    S.rotateIgnoreUntil = os.clock() + CONFIG.recovery.rotateStartIgnoreSeconds
    steerBuf = {0, 0}
    if isCharInAnyCar(PLAYER_PED) then
        lastCarHeading = getCarHeading(storeCarCharIsInNoSave(PLAYER_PED))
    end
end

-- Clears every pause and recovery source. Used whenever playback ends so a
-- stopped bot cannot keep holding the controls (e.g. stopping while paused or
-- while a dialog was open used to leave the car without throttle until F7).
function RouteFollower.clearTransientState()
    RecoverySystem.rotation:reset()
    S.controlLockSince,S.controlLockHandled = nil,nil
    S.dialogRejoinPending = nil
    S.chatRouteActive = nil
    AdminChat.clear()
    MotionClassifier.reset()
    DrivingPlanner.cache = nil
    S.smoothSteerValue = 0
    S.freezeChatToken, S.fakeDialogChatToken = nil, nil
    RecoveryMemory.reset()
    if S.bumpActive then
        stopBumpRecovery(nil)
    end
    resetBumpState(true)
    if commandJob and not commandJob.done then
        commandJob.cancelled = true
    end
    S.refreshJob = nil
    S.refreshSent = false
    S.manualPaused = false
    S.dialogPaused = false
    S.testArbotasPaused = false
    S.dialogReleaseUntil = 0.0
    S.freezeTestLatched = false
    S.freezeRecoveryMode = ""
    S.frozenByAdmin = false
    S.freezeRefreshSentAt = 0.0
    S.freezeReleaseUntil = 0.0
    S.freezeRefreshAt = 0.0
    S.freezeResumeDelay = 0.0
    S.freezeRecoveryGraceUntil = 0.0
    S.reversePlaybackGraceUntil = 0.0
    S.backToForwardUntil = 0.0
    S.rotateFightUntil = 0.0
    S.rotateReleaseUntil = 0.0
    overrideActive = false
    freezeTimer = 0
    suddenStopFrames = 0
    syncPausedState()
end

-- Global nearest-point selection is allowed only on an explicit playback start.
-- Recovery continues to use its bounded, contiguous-leg rejoin search.
function RouteFollower.startIndex(route)
    if not isCharInAnyCar(PLAYER_PED) then return 1 end
    local car = storeCarCharIsInNoSave(PLAYER_PED)
    local x,y = getCarCoordinates(car)
    local best,distance = 1,math.huge
    for i,point in ipairs(route) do
        local d = (point.x-x)^2+(point.y-y)^2
        if d < distance then best,distance = i,d end
    end
    return best
end

-- After a dialog, account for coasting/relocation before issuing route input.
-- Explicit dialog resume may scan the entire remaining route; stuck recovery
-- continues to use the bounded contiguous-leg search.
function RouteFollower.resumeAfterDialog()
    if not S.dialogRejoinPending then return end
    if not playing or #current_route == 0 or not isCharInAnyCar(PLAYER_PED) then return end
    local car = storeCarCharIsInNoSave(PLAYER_PED)
    local x,y = getCarCoordinates(car)
    local old = play_index
    local best,distance = old,math.huge
    for i=old,#current_route do
        local point = current_route[i]
        local d = (point.x-x)^2+(point.y-y)^2
        if d < distance then best,distance = i,d end
    end
    play_index = best
    playbackDriveMode = routeDriveModeAt(current_route,best)
    steerBuf = {0,0}; S.smoothSteerValue = 0
    gasLevel,brakeLevel,lastSteerValue = 0,0,0
    lastX,lastY = x,y
    freezeTimer,suddenStopFrames = 0,0
    S.forwardNoProgressFrames = 0
    RecoveryMemory.reset("dialog resume")
    S.dialogRejoinPending = nil
    logEvent("REJOIN", string.format("dialog resume %d -> %d distance=%.1fm",old,best,math.sqrt(distance)))
end

function RouteFollower.startPlayback()
    RouteFollower.resetPlaybackStartState()
    if #currentTrail > 0 then
        lastTrail = currentTrail
        currentTrail = {}
    end
    current_route = normalizeRouteReverseFlags(current_route)
    if #current_route > 5 then
        RouteStorage.logRouteSummary(current_name, current_route, "play_memory")
        play_index = RouteFollower.startIndex(current_route); playbackDriveMode = routeDriveModeAt(current_route, play_index); playing = true; syncPausedState()
        showMsg("~g~Vaziavimas pradetas!")
        return true
    end

    local route = RouteStorage.load(current_name)
    if RouteStorage.validateRoute(route) then
        RouteStorage.logRouteSummary(current_name, route, "play_file")
        current_route = route; play_index = RouteFollower.startIndex(current_route); playbackDriveMode = routeDriveModeAt(current_route, play_index); playing = true; syncPausedState()
        showMsg("~g~Kelias ikrautas ir paleistas: " .. current_name)
        return true
    end

    showMsg("~r~Nera irasyto kelio!")
    return false
end

function RouteFollower.stopPlayback()
    RouteFollower.clearTransientState()
    playing = false
    releaseControls("STOPPED")
    showMsg("~r~Vaziavimas sustabdytas!")
end

function RouteFollower.stopAll()
    if Win32.accessories then Win32.accessories:reset() end
    if recording then
        RouteRecorder.stopRecording()
    end
    RouteFollower.clearTransientState()
    recording = false; playing = false; repeating = false
    playbackDriveMode = DRIVE_FORWARD
    recordDriveMode = DRIVE_FORWARD
    recordReverseFrames = 0
    recordForwardBrakeFrames = 0
    S.manualPaused = false; play_index = 1
    S.dialogPaused = false; S.testArbotasPaused = false; S.frozenByAdmin = false; S.freezeTestLatched = false
    S.dialogReleaseUntil = 0.0
    S.freezeRecoveryMode = ""
    S.freezeRefreshSentAt = 0.0
    S.freezeReleaseUntil = 0.0
    S.freezeRefreshAt = 0.0
    S.freezeResumeDelay = 0.0
    S.freezeRecoveryGraceUntil = 0.0
    S.reversePlaybackGraceUntil = 0.0
    S.backToForwardUntil = 0.0
    resetBumpState(true)
    S.currentLateral = 0.0
    S.nudgeFrames = 0
    S.nudgeOffset = 0.0
    S.routeObstacleDist = math.huge
    S.routeAvoidDir = 0
    S.routeObstacleUrgency = 0.0
    S.routeObstacleTimer = 0
    S.obstacleHits = {}
    S.obstacleProbes = {}
    S.rejoinCooldownUntil = 0.0
    S.rejoinDisableUntil = 0.0
    resetObstacleBypass()
    S.avoidClusterCount = 0
    suddenStopFrames = 0
    freezeTimer = 0
    lastDriveSpeed = 0.0
    S.recentDriveSpeed = 0.0
    S.recentDriveUntil = 0.0
    steerBuf = {0, 0}
    collisionCooldown = 0
    avoidSteerDir = 0
    S.avoidRouteDir = 0
    S.avoidSideHit = false
    pauseReleaseReason = ""
    S.rotateFightUntil = 0.0
    S.rotateReleaseUntil = 0.0
    S.rotateIgnoreUntil = 0.0
    clearRotateTrigger()
    syncPausedState()
    releaseControls("ALL_STOP")
    showMsg("~r~Viskas sustabdyta!")
end

function RouteFollower.updateTrail(carX, carY, carZ)
    trailTick = trailTick + 1
    if trailTick >= 8 then
        trailTick = 0
        if #currentTrail < CONFIG.obstacle.maxTrailPoints then
            table.insert(currentTrail, {x=carX, y=carY, z=carZ})
        end
    end
end

function ObstacleAvoidance.updateScan(car)
    if routeDriveModeAt(current_route, play_index) == DRIVE_BACK then
        S.routeObstacleTimer = 0
        S.routeObstacleDist = math.huge
        S.routeAvoidDir = 0
        S.routeObstacleUrgency = 0.0
        S.obstacleHits = {}
        S.obstacleProbes = {}
        resetObstacleBypass()
        return
    end

    S.routeObstacleTimer = S.routeObstacleTimer + frameScale
    if S.routeObstacleTimer >= CONFIG.obstacle.scanEveryFrames then
        S.routeObstacleTimer = 0
        local scannedDist, scannedDir, scannedUrgency = scanRouteAhead(current_route, play_index, car)
        S.routeObstacleDist = scannedDist
        S.routeObstacleUrgency = scannedUrgency or 0.0
        if collisionCooldown <= 0 or S.routeAvoidDir == 0 then
            S.routeAvoidDir = scannedDir
        end
    end
end

-- frameScale = real frame time in reference frames (1.0 at referenceFps).
-- A long gap (pause, override, lag spike) is clamped so it cannot count as
-- many frames at once.
local function updateFrameScale()
    local now = os.clock()
    if not playing or lastPlaybackTickAt == nil then
        frameScale = 1.0
    else
        frameScale = clamp((now - lastPlaybackTickAt) * (CONFIG.timing.referenceFps or 30),
            CONFIG.timing.minFrameScale or 0.25, CONFIG.timing.maxFrameScale or 2.0)
    end
    S.playbackDt = playing and lastPlaybackTickAt and clamp(now-lastPlaybackTickAt,1/120,0.2) or 1/30
    lastPlaybackTickAt = playing and now or nil
end

-- Group playback helpers to stay below MoonLoader LuaJIT's 60-upvalue limit.
RouteFollower.playbackHelpers = {
    updateFrameScale = updateFrameScale,
    getPlaybackDriveMode = getPlaybackDriveMode,
    syncReversePlaybackIndex = syncReversePlaybackIndex,
    routeDriveModeAt = routeDriveModeAt,
    advanceReversePlaybackIndex = advanceReversePlaybackIndex,
    getSplineTarget = getSplineTarget,
    scaledLerp = scaledLerp,
    draw_line = draw_line,
    sharpTurnAhead = sharpTurnAhead,
    applyReverseSteering = applyReverseSteering,
    applyReverseAssist = applyReverseAssist,
    findNearestWaypointNear = findNearestWaypointNear,
}

-- Advance through nearby dense samples in one frame, staying on this forward leg.
function RouteFollower.advanceForward(route,index,x,y,speed)
    if not CONFIG.driving.lowFpsTolerance and CONFIG.controls.input ~= "keyboard" then return index end
    local radius = routeRadius+math.min(2,math.max(0,speed)*math.max(0,(S.playbackDt or 1/30)-1/30))
    local arc = 0
    for count=1,128 do
        local point,nextPoint = route[index],route[index+1]
        if not point or not nextPoint or routeDriveModeAt(route,index) ~= DRIVE_FORWARD
            or routeDriveModeAt(route,index+1) ~= DRIVE_FORWARD then break end
        local dx,dy = point.x-x,point.y-y
        if dx*dx+dy*dy > radius*radius then
            if CONFIG.controls.input ~= "keyboard" then break end
            -- A waypoint counts as passed beyond its perpendicular plane,
            -- provided the car remains in a bounded corridor of this leg.
            -- Never search another branch at an intersection or reverse boundary.
            local previous=route[index-1]
            local ax,ay=nextPoint.x-point.x,nextPoint.y-point.y
            if previous and routeDriveModeAt(route,index-1)==DRIVE_FORWARD then
                ax,ay=point.x-previous.x,point.y-previous.y
            end
            local length=math.sqrt(ax*ax+ay*ay)
            if length<0.001 then break end
            local along=((-dx)*ax+(-dy)*ay)/length
            local cross=math.abs((-dx)*ay-(-dy)*ax)/length
            local corridor=clamp(CONFIG.driving.lateralTolerance*2,6,10)
            if along<0 or along>40 or cross>corridor then break end
        end
        local segment = getDistanceBetweenCoords2d(point.x,point.y,nextPoint.x,nextPoint.y)
        if arc+segment > 40 then break end
        arc=arc+segment;index=index+1
    end
    return index
end

-- Keep route progress current while chat owns the controls. This uses the
-- same bounded forward-leg advancement as playback; it never searches a later
-- lap or crosses a recorded reverse section, and writes no driving input.
function RouteFollower.updateChatProgress()
    if not playing or #current_route==0 then S.chatRouteActive=nil;return end
    local open=isSampChatInputActive()
    if open==true or S.adminChatTyping then S.chatRouteActive=true end
    if not S.chatRouteActive then return end
    if open==nil or not isCharInAnyCar(PLAYER_PED) or S.manualPaused
        or S.dialogPaused or isSampDialogActive() then return end
    local car=storeCarCharIsInNoSave(PLAYER_PED)
    local x,y=getCarCoordinates(car)
    local old=play_index
    play_index=RouteFollower.advanceForward(current_route,play_index,x,y,math.abs(getCarSpeed(car)))
    if play_index~=old then
        playbackDriveMode=routeDriveModeAt(current_route,play_index)
        DrivingPlanner.heldTarget=nil
    end
    if open==false and not S.adminChatTyping and not paused then
        S.chatRouteActive=nil
        S.keyboardController=nil;S.digitalSteer=0;S.digitalReverseAfter=0
        S.smoothSteerValue=0;steerBuf={0,0};DrivingPlanner.heldTarget=nil
        lastX,lastY=x,y;lastPlaybackTickAt=nil
        freezeTimer,suddenStopFrames=0,0;S.forwardNoProgressFrames=0
        MotionClassifier.reset()
        logEvent("REJOIN",string.format("chat resume at point %d",play_index))
    end
end

function RouteFollower.updatePlayback()
    RouteFollower.playbackHelpers.updateFrameScale()
    if playing and #current_route > 0 and sharedFreezeActive() and not S.freezeTestLatched and not S.externalFreezeAck then
        logEvent("RECOVERY", "external freeze detected by playback gate")
        startFreezeRecovery("test")
    end
    if playing and (freezeRecoveryOwnsControls() or RecoverySystem.controlLockState() == true) then
        releaseControls(frozenHoldReason())
        return
    end

    RouteFollower.updateChatProgress()
    if not (playing and not paused and #current_route > 0) then return end
    if AdminChat.holdsRecoveryReply() and not isPlayerControlling() then
        releaseControls("CHAT_WAIT")
        return
    end
    RouteFollower.resumeAfterDialog()

    if not isCharInAnyCar(PLAYER_PED) then
        RouteFollower.clearTransientState()
        playing = false; repeating = false
        releaseControls("NO_CAR")
        showMsg("~r~Vaziavimas sustabdytas - islejei masina!")
        return
    end

    local car = storeCarCharIsInNoSave(PLAYER_PED)
    local carX, carY, carZ = getCarCoordinates(car)
    S.forwardSpeed = getCarForwardSpeed(car)

    if isPlayerControlling() then
        if not overrideActive then
            overrideActive = true
            if S.bumpActive then
                stopBumpRecovery("BUMP_OVERRIDE")
            end
            releaseControls("OVERRIDE")
        end
        UI.notify("~y~OVERRIDE ACTIVE", 100)
        return
    end

    overrideActive = false
    RecoveryMemory.observe(current_route, play_index, carX, carY, S.forwardSpeed)

    -- Recovery mini-states must run before normal playback systems; otherwise
    -- freeze/obstacle/route logic can write controls during bump or R >> FWD.
    if S.bumpActive then
        if RecoverySystem.updateBumpRecovery(car, carX, carY) then
            return
        end
    end

    if handleBackToForwardTransition() then
        return
    end

    RouteFollower.updateTrail(carX, carY, carZ)
    ObstacleAvoidance.updateScan(car)
    RecoverySystem.handleFreeze(car, current_route, play_index)

    if S.bumpActive then
        if RecoverySystem.updateBumpRecovery(car, carX, carY) then
            return
        end
    end

    if S.freezeTestLatched then
        -- Freeze recovery thread owns inputs so real and test freezes behave identically.
    elseif S.frozenByAdmin or sharedFreezeActive() then
        releaseControls(pauseReleaseReason ~= "" and pauseReleaseReason or "FROZEN")
    elseif not paused then
        play_index = RouteFollower.advanceForward(current_route,play_index,carX,carY,math.abs(S.forwardSpeed or 0))
        local point = current_route[play_index]
        local driveMode = RouteFollower.playbackHelpers.getPlaybackDriveMode(current_route, play_index)
        local reverseMode = driveMode == DRIVE_BACK
        local tX, tY, plannedSpeed, planningReason

        if reverseMode then
            local syncedIndex = RouteFollower.playbackHelpers.syncReversePlaybackIndex(current_route, play_index, carX, carY)
            if syncedIndex ~= play_index then
                play_index = syncedIndex
                playbackDriveMode = RouteFollower.playbackHelpers.routeDriveModeAt(current_route, play_index)
                point = current_route[play_index]
                if not point then return end
                driveMode = playbackDriveMode
                reverseMode = driveMode == DRIVE_BACK
                steerBuf = {0, 0}
            end
            local advancedIndex = RouteFollower.playbackHelpers.advanceReversePlaybackIndex(current_route, play_index, carX, carY, false)
            if advancedIndex ~= play_index then
                local oldMode = driveMode
                play_index = advancedIndex
                playbackDriveMode = RouteFollower.playbackHelpers.routeDriveModeAt(current_route, play_index)
                point = current_route[play_index]
                if not point then return end
                driveMode = playbackDriveMode
                reverseMode = driveMode == DRIVE_BACK
                steerBuf = {0, 0}
                if oldMode == DRIVE_BACK and driveMode == DRIVE_FORWARD then
                    startBackToForwardTransition()
                    return
                end
            end
        end

        if reverseMode then
            -- Backing up needs the exact recorded waypoint. Forward driving can
            -- keep the smoothed spline/lateral route behavior.
            tX, tY = point.x, point.y
            if S.bypassActive or math.abs(S.currentLateral or 0.0) > 0.05 then
                resetObstacleBypass()
                S.currentLateral = 0.0
            end
            collisionCooldown = 0
        else
            if CONFIG.driving.enabled then
                tX,tY,plannedSpeed,planningReason = DrivingPlanner.target(current_route,play_index,carX,carY,
                    math.abs(S.forwardSpeed or getCarSpeed(car)))
            end
            if tX == nil then tX,tY = RouteFollower.playbackHelpers.getSplineTarget(current_route,play_index) end
        end

        if not reverseMode and play_index < #current_route then
            local ndx = current_route[play_index + 1].x - current_route[play_index].x
            local ndy = current_route[play_index + 1].y - current_route[play_index].y
            local nd = math.sqrt(ndx * ndx + ndy * ndy)
            if nd > 0.1 then
                if CONFIG.controls.input == "keyboard" then
                    S.nudgeFrames=0;S.nudgeOffset=0;S.lapWander=0
                elseif S.nudgeFrames > 0 then
                    S.nudgeFrames = S.nudgeFrames - 1
                    if S.nudgeFrames == 0 then S.nudgeOffset = 0.0 end
                elseif os.clock() >= S.nextNudge then
                    S.nudgeOffset = (math.random() * 2.4) - 1.2
                    S.nudgeFrames = math.random(80, 160)
                    S.nextNudge = os.clock() + math.random(15, 45)
                end
                local now = os.clock()
                local targetLateral = S.lapWander + S.nudgeOffset
                local obstacleAvoidActive = updateObstacleBypass(now)
                if S.bypassActive and collisionCooldown > 0 then
                    collisionCooldown = 0
                end
                if math.abs(S.avoidLateralTarget or 0.0) > 0.05 then
                    obstacleAvoidActive = now < (S.avoidHoldUntil or 0.0) or math.abs(S.avoidLateralTarget) > 0.35
                    if obstacleAvoidActive then
                        targetLateral = S.lapWander * 0.12
                    end
                    targetLateral = targetLateral + S.avoidLateralTarget
                end
                if collisionCooldown > 0 then
                    local collisionDir = S.avoidRouteDir ~= 0 and S.avoidRouteDir or (S.routeAvoidDir ~= 0 and S.routeAvoidDir or 0)
                    local urgency = math.max(S.routeObstacleUrgency or 0.0, 0.50)
                    local collisionPush = S.bypassActive
                        and math.min(0.35, 0.12 + urgency * 0.22)
                        or (0.45 + urgency * 0.70 + math.min(0.20, collisionCooldown * 0.010))
                    if collisionDir ~= 0 then
                        targetLateral = targetLateral + collisionDir * collisionPush
                    end
                end
                if S.bypassActive then
                    targetLateral = clamp(targetLateral, -3.35, 3.35)
                end
                local lateralLerp = obstacleAvoidActive
                    and (S.bypassReturning and 0.030 or (S.routeObstacleDist > 28.0 and 0.050 or 0.070))
                    or (S.routeObstacleUrgency > 0.65 and 0.11 or (S.routeObstacleUrgency > 0.35 and 0.08 or 0.045))
                S.currentLateral = S.currentLateral + (targetLateral - S.currentLateral) * RouteFollower.playbackHelpers.scaledLerp(lateralLerp)
                tX = tX + (-ndy / nd) * S.currentLateral
                tY = tY + (ndx / nd) * S.currentLateral
            end
        end

        RouteFollower.playbackHelpers.draw_line(tX, tY, carX, carY, carZ, reverseMode and COLOR_ROUTE_BACK or COLOR_ROUTE_FORWARD)

        local rawCurrentSpeed = getCarSpeed(car)
        local currentSpeed = reverseMode and math.abs(rawCurrentSpeed) or rawCurrentSpeed
        local targetSpeed = reverseMode and math.abs(point.speed or 0) or (point.speed or 0)
        targetSpeed = VehicleProfiles.speedLimit(targetSpeed)
        if plannedSpeed then targetSpeed = math.min(targetSpeed,plannedSpeed) end
        local steerTargetX, steerTargetY = tX, tY
        local reverseDrive = false
        if S.bypassActive then
            targetSpeed = math.min(targetSpeed, 46.0)
        end

        Telemetry.target = {index = play_index, x = tX, y = tY,
            speed = targetSpeed, reverse = reverseMode,
            branch = reverseMode and "reverse_route" or (S.bypassActive and "bypass" or (planningReason or "route"))}
        if not reverseMode then
            if handleRouteRejoinRecovery(car, carX, carY, tX, tY, currentSpeed) then
                Telemetry.target = nil
                return
            end
        end
        do
            local obsX, obsY, obsDir, obsDist, obsSide, obsUrgency = nil, nil, nil, nil, nil, nil
            if not reverseMode then
                obsX, obsY, obsDir, obsDist, obsSide, obsUrgency = getObstacleAhead(car, tX, tY)
            end
            if obsX and collisionCooldown <= 0 and not reverseMode then
                S.avoidSideHit = obsSide == true
                avoidSteerDir = avoidDir(car, obsX, obsY, tX, tY)
                S.avoidRouteDir = (obsDir and obsDir ~= 0)
                    and (obsDir < 0 and -1 or 1)
                    or routeAvoidDirFromPoint(carX, carY, tX, tY, obsX, obsY)
                S.routeAvoidDir = S.avoidRouteDir
                if obsDist then
                    S.routeObstacleDist = math.min(S.routeObstacleDist, obsDist)
                end
                local closeUrgency = obsDist and ((18.0 - obsDist) / 14.0) or 0.55
                if closeUrgency < 0.0 then closeUrgency = 0.0 end
                if closeUrgency > 1.0 then closeUrgency = 1.0 end
                S.routeObstacleUrgency = math.max(S.routeObstacleUrgency or 0.0, obsUrgency or closeUrgency)
                if not S.bypassActive and ((obsDist and obsDist < 5.5) or (obsUrgency and obsUrgency > 0.78)) then
                    collisionCooldown = (obsDist and obsDist < 4.0) and 30 or 18
                end
            end

            if (S.bypassActive or reverseMode) and collisionCooldown > 0 then
                collisionCooldown = 0
            end

            if collisionCooldown > 0 then
                if Telemetry.target then Telemetry.target.branch = "obstacle_reaction" end
                collisionCooldown = math.max(0, collisionCooldown - frameScale)
                if S.avoidRouteDir ~= 0 then
                    S.routeAvoidDir = S.avoidRouteDir
                end
                local avoidSteerOut = avoidSteerDir
                if S.avoidSideHit then
                    avoidSteerOut = avoidSteerDir < 0 and -128 or 128
                end
                lastSteerValue = avoidSteerOut
                writeSteerControls(avoidSteerOut)
                if S.avoidSideHit then
                    if currentSpeed < 16 then
                        gasLevel = 135
                    elseif currentSpeed < 34 then
                        gasLevel = 75
                    else
                        gasLevel = 0
                    end
                else
                    if currentSpeed < 12 then
                        gasLevel = 145
                    elseif currentSpeed < 28 then
                        gasLevel = 85
                    elseif currentSpeed < 42 then
                        gasLevel = 35
                    else
                        gasLevel = 0
                    end
                end
                brakeLevel = 0
                writeDriveControls(gasLevel, 0)
            elseif CONFIG.driving.cornerBraking and (not CONFIG.driving.enabled or plannedSpeed == nil) and not reverseMode and not S.bypassActive and RouteFollower.playbackHelpers.sharpTurnAhead(current_route, play_index) and currentSpeed > targetSpeed * 0.7 then
                if Telemetry.target then
                    Telemetry.target.speed = targetSpeed * 0.7
                    Telemetry.target.branch = "sharp_turn_braking"
                end
                turning_mechanism(steerTargetX, steerTargetY, carX, carY, car)
                if os.clock() > (S.avoidHoldUntil or 0.0) then
                    applySteerNoise()
                end
                local excess = math.max(0, currentSpeed - targetSpeed * 0.7)
                brakeLevel = math.min(255, math.floor(excess * 30))
                gasLevel = math.max(0, gasLevel - 25 * frameScale)
                writeDriveControls(gasLevel, brakeLevel)
            else
                if reverseMode then
                    RouteFollower.playbackHelpers.applyReverseSteering(car, carX, carY, current_route, play_index)
                else
                    turning_mechanism(steerTargetX, steerTargetY, carX, carY, car)
                end
                if not reverseMode and os.clock() > (S.avoidHoldUntil or 0.0) then
                    applySteerNoise()
                end
                if reverseMode then
                    gasLevel = 0
                    brakeLevel = 0
                    -- Reverse = brake button held with no gas (it brakes first
                    -- while still rolling forward). Ease off only when already
                    -- backing faster than the recorded reverse speed.
                    local reverseLimit = math.max(3.0, targetSpeed) + 1.0
                    reverseDrive = S.forwardSpeed == nil or S.forwardSpeed > -reverseLimit
                    RouteFollower.playbackHelpers.applyReverseAssist(car, carX, carY, tX, tY, currentSpeed, targetSpeed)
                else
                    if planningReason == "corner_braking" and currentSpeed > targetSpeed+0.5 then
                        -- Planned braking takes priority over cosmetic throttle lifts.
                        gasLevel = 0
                        brakeLevel = math.min(255,math.floor((currentSpeed-targetSpeed)*30))
                    elseif S.gasLiftFrames > 0 then
                        if Telemetry.target then Telemetry.target.branch = "gas_lift" end
                        S.gasLiftFrames = S.gasLiftFrames - 1
                        gasLevel = 0
                        brakeLevel = 0
                    elseif os.clock() >= S.nextGasLift then
                        S.gasLiftFrames = math.random(18, 45)
                        S.nextGasLift = os.clock() + math.random(20, 60)
                    else
                        if currentSpeed < targetSpeed then
                            gasLevel = math.min(255, gasLevel + 18 * frameScale)
                            brakeLevel = math.max(0, brakeLevel - 50 * frameScale)
                        elseif currentSpeed < targetSpeed + 1.5 then
                            brakeLevel = math.max(0, brakeLevel - 50 * frameScale)
                        else
                            local excess = currentSpeed - (targetSpeed + 1.5)
                            local brakeCap = S.bypassActive and 95 or 255
                            local brakeGain = S.bypassActive and 12 or 30
                            brakeLevel = math.min(brakeCap, math.floor(excess * brakeGain))
                            gasLevel = math.max(0, gasLevel - 25 * frameScale)
                        end
                    end
                end
                writeDriveControls(gasLevel, brakeLevel, reverseDrive)
            end
        end

        -- getCarSpeed is in m/s.
        UI.notify('~g~VR Bot ~w~' .. play_index .. '/' .. #current_route .. ' ~y~' .. math.floor(currentSpeed * 3.6) .. 'km/h' .. (reverseMode and ' ~b~BACK' or ''), 100)
        writeSharedState("PLAYING")

        if reverseMode then
            local advancedIndex = RouteFollower.playbackHelpers.advanceReversePlaybackIndex(current_route, play_index, carX, carY, true)
            if advancedIndex ~= play_index then
                local oldMode = playbackDriveMode
                play_index = advancedIndex
                playbackDriveMode = RouteFollower.playbackHelpers.routeDriveModeAt(current_route, play_index)
                steerBuf = {0, 0}
                if oldMode == DRIVE_BACK and playbackDriveMode == DRIVE_FORWARD then
                    startBackToForwardTransition()
                end
            end
        elseif locateCharInCar2d(PLAYER_PED, point.x, point.y, routeRadius, routeRadius, false) then
            play_index = play_index + 1
        else
            local carDist = getDistanceBetweenCoords2d(carX, carY, point.x, point.y)
            if carDist > 30.0 then
                play_index = RouteFollower.playbackHelpers.findNearestWaypointNear(current_route, carX, carY, play_index, 40, 300, 30.0, getCarHeading(car))
            else
                play_index = RouteFollower.findRejoin(current_route, carX, carY,
                    play_index, 0, 10, carDist, getCarHeading(car))
            end
        end

        if play_index > #current_route then
            if repeating then
                RecoveryMemory.reset("lap completed")
                play_index = 1
                playbackDriveMode = RouteFollower.playbackHelpers.routeDriveModeAt(current_route, 1)
                S.lapWander = (math.random() * 3.0) - 1.5
                gasLevel = 0; brakeLevel = 0
                S.gasLiftFrames = 0
                S.nudgeFrames = 0; S.nudgeOffset = 0.0
                S.currentLateral = 0.0
                S.reversePlaybackGraceUntil = 0.0
                S.backToForwardUntil = 0.0
                resetBumpState(true)
                S.rejoinCooldownUntil = 0.0
                S.rejoinDisableUntil = os.clock() + 2.5
                resetObstacleBypass()
                S.avoidClusterCount = 0
                local delayFrames = math.random(1, 2)
                steerBuf = {}
                for i = 1, delayFrames do steerBuf[i] = 0 end
                showMsg("~g~Kilpa baigta! Kartojama!")
            else
                RouteFollower.clearTransientState()
                playing = false; play_index = 1
                releaseControls("DONE")
                showMsg("~g~Kelias baigtas!")
            end
        end
    end
end

function Settings.reloadAllowed()
    if commandJob and not commandJob.done or AdminChat.pendingQuit then return false,"finish typing first" end
    local now=os.clock()
    if S.bumpActive or freezeRecoveryOwnsControls() or isSampDialogActive() or S.dialogPaused
        or now<S.rotateReleaseUntil or now<S.backToForwardUntil then return false,"finish recovery first" end
    if playing and not S.manualPaused then return false,"pause with F6 or stop with F7 first" end
    return true
end
-- Built-in rendered panel: no imgui dependency, no player-control lock.
Settings.panel = {open=false, cursor=false, page=1, pending={}, status="Changes apply live; Save INI makes them permanent."}
function Settings.panel.serialize(config, profiles)
    local lines={"# Dangis VR "..VR_VERSION.." - saved by in-game settings", "# Ctrl+I: live settings panel. F12: reload while paused/stopped."}
    for _,section in ipairs({"driving","controls","recovery","chat","diagnostics","vehicles"}) do
        lines[#lines+1]="\n["..section.."]"
        local keys={}
        for key in pairs(Settings.spec) do if key:match("^([^.]+)")==section then keys[#keys+1]=key end end
        table.sort(keys)
        for _,key in ipairs(keys) do
            local spec=Settings.spec[key]
            lines[#lines+1]=key:match("%.(.+)$").." = "..tostring(config[spec[1]][spec[2]])
        end
        if section=="vehicles" then
            local models={};for model in pairs(config.vehicle.modelProfiles) do models[#models+1]=model end
            table.sort(models)
            for _,model in ipairs(models) do lines[#lines+1]="model_"..model.." = "..config.vehicle.modelProfiles[model] end
        end
    end
    for _,name in ipairs({"standard","cautious","sport","heavy"}) do
        lines[#lines+1]="\n[profile."..name.."]"
        local keys={};for key in pairs(Settings.profileRanges) do keys[#keys+1]=key end;table.sort(keys)
        for _,key in ipairs(keys) do lines[#lines+1]=key.." = "..tostring(profiles[name][key]) end
    end
    return table.concat(lines,"\n").."\n"
end
function Settings.panel.desired()
    local candidate=Settings.copy(CONFIG)
    for key,value in pairs(Settings.panel.pending) do
        local spec=Settings.spec[key];candidate[spec[1]][spec[2]]=value
    end
    return candidate
end
function Settings.panel.busy(key)
    if key:match("^controls%.") then return not Settings.reloadAllowed() end
    if key:match("^recovery%.") or key:match("^chat%.") or key:match("^vehicles%.") then
        return S.bumpActive or freezeRecoveryOwnsControls() or S.dialogPaused or isSampDialogActive()
            or (commandJob and not commandJob.done) or AdminChat.job~=nil or AdminChat.pendingQuit~=nil
            or #AdminChat.queue>0 or os.clock()<S.backToForwardUntil or os.clock()<S.rotateReleaseUntil
    end
    return false
end
function Settings.panel.flush()
    local changed=false
    for key,value in pairs(Settings.panel.pending) do
        if not Settings.panel.busy(key) then
            local spec=Settings.spec[key]
            if key:match("^controls%.") then ControlManager.neutralize() end
            CONFIG[spec[1]][spec[2]]=value
            Settings.panel.pending[key]=nil;changed=true
        end
    end
    if changed then
        if CONFIG.controls.input=="keyboard" then CONFIG.controls.steering="bangbang" end
        routeRadius=CONFIG.route.radius
        DrivingPlanner.cache=nil;DrivingPlanner.heldTarget=nil
        VehicleProfiles.lastUpdate=nil
        AdminChat.bag,AdminChat.bagKey={},nil
        S.smoothSteerValue=0
        Settings.status="panel changes applied"
    end
end
function Settings.panel.set(key,value)
    local spec=Settings.spec[key]
    if not spec then return false,"unknown setting" end
    local candidate=Settings.panel.desired()
    candidate[spec[1]][spec[2]]=value
    local validated,err=Settings.parse(Settings.panel.serialize(candidate,VehicleProfiles.presets))
    if not validated then Settings.panel.status=err;return false,err end
    Settings.panel.pending[key]=validated[spec[1]][spec[2]]
    Settings.panel.flush()
    Settings.panel.status=next(Settings.panel.pending) and "Pending: pause/stop for controls; finish active chat/recovery." or "Applied live. Click Save INI to keep changes."
    return true
end
function Settings.panel.save()
    local text=Settings.panel.serialize(Settings.panel.desired(),VehicleProfiles.presets)
    local candidate,err=Settings.parse(text)
    if not candidate then Settings.panel.status=err;return false end
    -- Normalize keyboard mode before saving; retain all profile/model mappings.
    text=Settings.panel.serialize(candidate,VehicleProfiles.presets)
    local path=Settings.path
    local file,openErr=io.open(path..".tmp","wb")
    if not file then Settings.panel.status="Save failed: "..tostring(openErr);return false end
    local written,writeErr=file:write(text)
    local closed,closeErr=file:close()
    if not written or not closed then
        os.remove(path..".tmp");Settings.panel.status="Save failed: "..tostring(writeErr or closeErr);return false
    end
    local old=io.open(path,"rb")
    if old then
        old:close();os.remove(path..".bak")
        local moved,moveErr=os.rename(path,path..".bak")
        if not moved then os.remove(path..".tmp");Settings.panel.status="Backup failed: "..tostring(moveErr);return false end
    end
    local moved,moveErr=os.rename(path..".tmp",path)
    if not moved then
        if old then os.rename(path..".bak",path) end
        Settings.panel.status="Save failed: "..tostring(moveErr);return false
    end
    Settings.panel.status=next(Settings.panel.pending) and "Saved INI. Pending changes still wait for a safe moment." or "Saved INI; previous file is dangis_vr.ini.bak."
    logEvent("SETTINGS","panel saved INI")
    return true
end
function Settings.panel.close(reason)
    Settings.panel.open=false
    if Settings.panel.cursor then pcall(showCursor,false,false) end
    Settings.panel.cursor=false
    if reason then Settings.panel.status=reason end
end
function Settings.panel.blocked()
    return not Win32.isGameForeground(true) or (type(isGamePaused)=="function" and isGamePaused())
        or isSampDialogActive() or S.dialogPaused or isSampChatInputActive()~=false
        or freezeRecoveryOwnsControls() or RecoverySystem.controlLockState()==true
        or (commandJob and not commandJob.done) or AdminChat.job~=nil or #AdminChat.queue>0
end
function Settings.panel.toggle()
    if Settings.panel.open then Settings.panel.close();return end
    if Settings.panel.blocked() then showMsg("~y~Settings: finish chat/dialog/recovery first");return end
    if type(showCursor)~="function" or type(getCursorPos)~="function" then
        Settings.panel.status="Panel unavailable: cursor API missing";showMsg("~r~"..Settings.panel.status);return
    end
    local ok,err=pcall(showCursor,true,false)
    if not ok then Settings.panel.status=tostring(err);return end
    Settings.panel.open,Settings.panel.cursor=true,true
    Settings.panel.mouseDown=Win32.keyDown(1)
end
function Settings.panel.rows()
    local rows={}
    for key in pairs(Settings.spec) do
        if key:match("^([^.]+)")==(Settings.panel.section or "driving") then rows[#rows+1]=key end
    end
    local order={driving=1,controls=2,recovery=3,chat=4,diagnostics=5,vehicles=6}
    table.sort(rows,function(a,b)
        local x,y=order[a:match("^([^.]+)")],order[b:match("^([^.]+)")]
        return x==y and a<b or x<y
    end)
    return rows
end
function Settings.panel.resetPage(rowCount)
    local desired=Settings.panel.desired()
    local keys={};local rows=Settings.panel.rows()
    for i=(Settings.panel.page-1)*rowCount+1,Settings.panel.page*rowCount do
        local key=rows[i]
        if key then
            local spec=Settings.spec[key];keys[#keys+1]=key
            desired[spec[1]][spec[2]]=Settings.defaults[spec[1]][spec[2]]
        end
    end
    local candidate,err=Settings.parse(Settings.panel.serialize(desired,VehicleProfiles.presets))
    if not candidate then Settings.panel.status=err;return false end
    for _,key in ipairs(keys) do
        local spec=Settings.spec[key];Settings.panel.pending[key]=candidate[spec[1]][spec[2]]
    end
    Settings.panel.flush()
    Settings.panel.status="Page defaults selected. Save INI to keep them."
    return true
end
function Settings.panel.adjust(key,direction)
    local spec=Settings.spec[key]
    local value=Settings.panel.desired()[spec[1]][spec[2]]
    if spec[3]=="bool" then value=not value
    elseif spec[3]=="enum" then value=value==spec[4] and spec[5] or spec[4]
    elseif spec[3]=="profile" then
        local names={"standard","cautious","sport","heavy"};local index=1
        for i,name in ipairs(names) do if name==value then index=i end end
        value=names[(index-1+direction)%#names+1]
    else
        local step=spec[3]=="integer" and 1 or (spec[5]<=10 and 0.1 or 1)
        if key=="driving.max_speed_kmh" then step=5 end
        value=math.max(spec[4],math.min(spec[5],math.floor((value+direction*step)*100+0.5)/100))
    end
    return Settings.panel.set(key,value)
end
function Settings.panel.draw()
    if not Settings.panel.open then return end
    if Settings.panel.blocked() then Settings.panel.close("Closed for chat/dialog/recovery. Ctrl+I opens again.");return end
    local ok,err=pcall(function()
        local p=Settings.panel
        local sw,sh=getScreenResolution()
        local width=math.min(700,sw-24)
        local rowCount=math.max(1,math.min(8,math.floor((sh-220)/34)))
        local height=210+rowCount*34
        local x,y=(sw-width)/2,math.max(6,(sh-height)/2)
        local mx,my=getCursorPos()
        local down=Win32.keyDown(1)
        local clicked=down and not p.mouseDown;p.mouseDown=down
        local function button(text,bx,by,bw,fn,active)
            local over=mx>=bx and mx<=bx+bw and my>=by and my<=by+28
            renderDrawBox(bx,by,bw,28,over and UI.colors.hover or UI.colors.panel)
            if active then renderDrawBox(bx,by+27,bw,1,UI.colors.accent) end
            UI.text(text,bx+9,by+5,10,active and UI.colors.accent or UI.colors.text,bw-14,true)
            if clicked and over then clicked=false;fn() end
        end
        UI.card(x,y,width,height)
        UI.text("Dangis",x+20,y+17,14,UI.colors.text,width-170,true)
        UI.text("Nustatymai",x+20,y+44,9,UI.colors.muted,width-40)
        UI.text("Ctrl + I  /  uždaryti",x+width-160,y+23,9,UI.colors.muted,145)
        local sections={{"driving","Važiavimas"},{"controls","Valdymas"},{"recovery","Atkūrimas"},{"chat","Žinutės"},{"diagnostics","Skydelis"},{"vehicles","Profilis"}}
        local tabW=(width-40)/#sections
        p.section=p.section or "driving"
        for i,item in ipairs(sections) do
            button(item[2],x+20+(i-1)*tabW,y+72,tabW-4,function() p.section=item[1];p.page=1 end,p.section==item[1])
        end
        local rows=p.rows();local pages=math.max(1,math.ceil(#rows/rowCount))
        p.page=math.max(1,math.min(p.page,pages))
        local desired=p.desired()
        for row=1,rowCount do
            local key=rows[(p.page-1)*rowCount+row]
            if key then
                local spec=Settings.spec[key];local ry=y+112+(row-1)*34
                renderDrawBox(x+20,ry+33,width-40,1,UI.colors.edge)
                UI.text(UI.labels[key] or "Nustatymas",x+30,ry+8,10,nil,width-295)
                local value=UI.value(desired[spec[1]][spec[2]],key)
                UI.text(value..(p.pending[key]~=nil and " *" or ""),x+width-250,ry+8,10,UI.colors.text,155)
                button("-",x+width-86,ry+2,28,function() p.adjust(key,-1) end)
                button("+",x+width-54,ry+2,28,function() p.adjust(key,1) end)
            end
        end
        local by=y+height-87
        button("Išsaugoti",x+20,by,108,p.save,true)
        button("Atkurti puslapį",x+138,by,142,function() p.resetPage(rowCount) end)
        button("<",x+width-146,by,28,function() p.page=math.max(1,p.page-1) end)
        UI.text(p.page.." / "..pages,x+width-108,by+6,10,UI.colors.muted,48)
        button(">",x+width-54,by,28,function() p.page=math.min(pages,p.page+1) end)
        UI.text(UI.status(p.status),x+20,by+38,9,UI.colors.muted,width-40)
        UI.text("* Laukia pritaikymo   |   Valdymo pakeitimams: F6 arba F7",x+20,by+57,9,UI.colors.muted,width-40)
    end)
    if not ok then
        Settings.panel.close("Panel error: "..tostring(err))
        logEvent("SETTINGS",Settings.panel.status)
        showMsg("~r~Settings panel error; see debug log")
    end
end
-- Consume mouse messages only; keyboard driving keys remain untouched.
function onWindowMessage(message,wparam,lparam)
    if Settings.panel.open and Settings.panel.cursor and not Settings.panel.blocked()
        and message>=0x200 and message<=0x20E then
        consumeWindowMessage(true,false)
    end
end

function Diagnostics.lines()
    local owner=ControlManager.owner
    local target=owner=="ROUTE" and Telemetry.target or nil
    local speed
    if isCharInAnyCar(PLAYER_PED) and type(getCarSpeed)=="function" then
        local ok,value=pcall(getCarSpeed,storeCarCharIsInNoSave(PLAYER_PED))
        if ok and type(value)=="number" then speed=math.floor(math.abs(value)*3.6+0.5) end
    end
    local why=S.recoveryBlockedReason or (target and target.branch) or ControlManager.sharedState(owner)
    local recovery=S.bumpActive and ((S.bumpPlan and S.bumpPlan.label) or S.bumpPhase) or S.recoveryBlockedReason or "idle"
    local chat=AdminChat.status or "ready"
    if not CONFIG.adminChat.enabled then chat="off"
    elseif AdminChat.pendingQuit then chat="quit follow-up pending"
    elseif AdminChat.job then chat=AdminChat.job.isQuit and "typing /q" or "typing reaction"
    elseif #AdminChat.queue>0 and os.clock()<AdminChat.queue[1].readyAt then chat="reaction delay" end
    local session=AdminChat.session
    return {
        "Dangis VR "..VR_VERSION.." | Ctrl+I settings | F1 hide",
        owner.." | "..VehicleProfiles.activeName.." | model "..tostring(VehicleProfiles.model or "?"),
        "Speed "..tostring(speed or "--").." / target "..(target and string.format("%.0f",target.speed*3.6) or "--").." km/h",
        "Reason: "..tostring(why),
        "Recovery: "..tostring(recovery),
        "Chat: "..chat.." | queued "..#AdminChat.queue,
        string.format("Session: %d events, %d replies | %s",session.checks,session.sent,session.joinedAt and "join marked" or "join time unknown"),
        "Settings: "..Settings.status,
    }
end
function Diagnostics.draw()
    if not CONFIG.diagnostics.enabled or Diagnostics.unavailable or Settings.panel.open then return end
    local ok,err=pcall(function()
        local sw,sh=800,600
        if type(getScreenResolution)=="function" then sw,sh=getScreenResolution() end
        local width=math.min(260,sw-24)
        local x=math.max(12,math.min(CONFIG.diagnostics.x,sw-width-12))
        local y=math.max(12,math.min(CONFIG.diagnostics.y,sh-140))
        UI.card(x,y,width,128)
        UI.text("Dangis",x+14,y+11,11,UI.colors.text,width-90,true)
        UI.text("v"..VR_VERSION,x+width-52,y+13,8,UI.colors.muted,42)
        local owner=ControlManager.owner
        UI.text(recording and "Įrašomas maršrutas" or UI.state(owner),x+14,y+34,9,UI.colors.accent,width-28)
        local speed=0
        if isCharInAnyCar(PLAYER_PED) and type(getCarSpeed)=="function" then
            local valid,value=pcall(getCarSpeed,storeCarCharIsInNoSave(PLAYER_PED))
            if valid and type(value)=="number" then speed=math.floor(math.abs(value)*3.6+0.5) end
        end
        UI.text(tostring(speed).." km/h",x+14,y+59,14,UI.colors.text,110,true)
        UI.text(tostring(math.min(play_index,#current_route)).." / "..#current_route,x+130,y+63,10,UI.colors.muted,width-144)
        renderDrawBox(x+14,y+89,width-28,2,UI.colors.edge)
        if #current_route>0 then renderDrawBox(x+14,y+89,(width-28)*math.min(1,play_index/#current_route),2,UI.colors.accent) end
        UI.text("Ctrl+I  Nustatymai    F1  Slėpti",x+14,y+105,8,UI.colors.muted,width-28)
    end)
    if not ok then
        Diagnostics.unavailable=true
        logEvent("HUD","diagnostics disabled: "..tostring(err))
    end
end

function InputHandler.handleHotkeys()
    if isKeyJustPressed(0x49) and isPhysicalKeyDown(0x11) and Win32.isGameForeground(true) then Settings.panel.toggle() end
    if VK_F1 and isKeyJustPressed(VK_F1) and Win32.isGameForeground(true) then
        CONFIG.diagnostics.enabled=not CONFIG.diagnostics.enabled
        Diagnostics.unavailable=nil
    end
    if VK_F12 and isKeyJustPressed(VK_F12) and Win32.isGameForeground(true) then
        local allowed,reason=Settings.reloadAllowed()
        if not allowed then Settings.status="reload deferred: "..reason;showMsg("~y~"..reason)
        elseif isPhysicalKeyDown(0x11) then
            AdminChat.markJoined()
            showMsg("~g~New session marked")
        else
            local ok,message=Settings.load()
            if ok then
                VehicleProfiles.update(true)
                AdminChat.loadPhrases()
                Diagnostics.unavailable=nil
                showMsg("~g~Settings and phrases reloaded")
            else showMsg("~r~Settings: "..tostring(message)) end
        end
    end
    if isKeyJustPressed(VK_F5) and Win32.isGameForeground() then
        if Telemetry.enabled then Telemetry.stop("OFF", true) else Telemetry.start() end
    end
    if isKeyJustPressed(VK_F2) then
        if not recording then
            RouteRecorder.startRecording()
        else
            RouteRecorder.stopRecording()
        end
    end

    if isKeyJustPressed(VK_F10) then
        if recording then
            RouteRecorder.stopRecording()
        end
        if not playing then
            RouteFollower.startPlayback()
        else
            RouteFollower.stopPlayback()
        end
    end

    if isKeyJustPressed(VK_F11) then
        repeating = not repeating
        showMsg(repeating and "~g~Kartojimas IJUNGTAS!" or "~r~Kartojimas ISJUNGTAS!")
    end

    if isKeyJustPressed(VK_F6) then
        if playing then
            S.manualPaused = not S.manualPaused
            syncPausedState()
            if S.manualPaused then
                if S.bumpActive then
                    stopBumpRecovery("BUMP_PAUSED")
                end
                releaseControls("PAUSED")
                showMsg("~y~Pristabdyta!")
            else
                RecoveryMemory.reset("manual resume")
                MotionClassifier.reset()
                EscapePlanner.status="idle"
                showMsg("~g~Tesiama!")
            end
        end
    end

    if isKeyJustPressed(VK_F7) then
        RouteFollower.stopAll()
    end

    if isKeyJustPressed(VK_F9) then
        showTrail = not showTrail
        if not showTrail then
            currentTrail = {}
            lastTrail = {}
        end
        showMsg(showTrail and "~g~Trajektorija IJUNGTA!" or "~r~Trajektorija ISJUNGTA!")
    end

    if isKeyJustPressed(VK_F3) then
        if not S.showObstacleDots then
            S.showObstacleDots = true
            S.obstacleDebugMode = 1
        elseif (S.obstacleDebugMode or 1) == 1 then
            S.obstacleDebugMode = 2
        else
            S.showObstacleDots = false
            S.obstacleDebugMode = 0
        end
        if not S.showObstacleDots then
            S.obstacleHits = {}
            S.obstacleProbes = {}
        end
        if not S.showObstacleDots then
            showMsg("~r~Kliuciu debug ISJUNGTAS!")
        elseif S.obstacleDebugMode == 2 then
            showMsg("~g~Kliuciu debug PILNAS!")
        else
            showMsg("~g~Kliuciu taskai IJUNGTI!")
        end
    end
end

function MainLoop.drawTrailDebug()
    if not showTrail then return end
    local px, py, pz = getCharCoordinates(PLAYER_PED)
    local spacing = 8
    local phase = math.floor((os.clock() % 0.2) / 0.2 * spacing)
    local function drawTrailArrows(trail, color)
        if #trail < 2 then return end
        local i = 1 + phase
        while i <= #trail - 1 do
            local p  = trail[i]
            local p2 = trail[i + 1]
            if p and p2 and getDistanceBetweenCoords2d(px, py, p.x, p.y) < 200 then
                if isPointOnScreen(p.x, p.y, p.z, 0.0) then
                    local sx,  sy  = convert3DCoordsToScreen(p.x,  p.y,  p.z)
                    local sx2, sy2 = convert3DCoordsToScreen(p2.x, p2.y, p2.z)
                    local dx, dy = sx2 - sx, sy2 - sy
                    local len = math.sqrt(dx*dx + dy*dy)
                    if len > 0.5 then
                        local nx, ny = dx/len, dy/len
                        local wx1 = sx - nx*9 + (-ny)*5
                        local wy1 = sy - ny*9 + nx*5
                        local wx2 = sx - nx*9 - (-ny)*5
                        local wy2 = sy - ny*9 - nx*5
                        renderDrawLine(sx, sy, wx1, wy1, 1.5, color)
                        renderDrawLine(sx, sy, wx2, wy2, 1.5, color)
                    end
                end
            end
            i = i + spacing
        end
    end

    local function drawRouteString(route)
        if type(route) ~= "table" or #route < 2 then return end
        local step = math.max(1, math.floor(#route / 1400))
        for i = 1, #route - 1, step do
            local p = route[i]
            local p2 = route[math.min(#route, i + step)]
            if p and p2 and getDistanceBetweenCoords2d(px, py, p.x, p.y) < 230 then
                local z1 = p.z or pz
                local z2 = p2.z or pz
                if isPointOnScreen(p.x, p.y, z1, 0.0) or isPointOnScreen(p2.x, p2.y, z2, 0.0) then
                    local sx, sy = convert3DCoordsToScreen(p.x, p.y, z1)
                    local sx2, sy2 = convert3DCoordsToScreen(p2.x, p2.y, z2)
                    local color = isRoutePointReverse(p2) and COLOR_ROUTE_BACK or COLOR_ROUTE_FORWARD
                    if color == COLOR_ROUTE_BACK then
                        renderDrawLine(sx, sy, sx2, sy2, 4, COLOR_ROUTE_BACK_OUTLINE)
                    end
                    renderDrawLine(sx, sy, sx2, sy2, 2, color)
                end
            end
        end
    end

    if not playing then
        drawRouteString(current_route)
    end
    drawTrailArrows(lastTrail,    0xCCFFFF00)
    drawTrailArrows(currentTrail, 0xCC00FFFF)
end

-- Running scripts named dangis_vr (an old copy under another file name would
-- make two bots fight over the controls).
local function findActiveDangisScripts()
    local ok, list = pcall(function() return script.list() end)
    if not ok or type(list) ~= "table" then return nil end
    local found = {}
    for _, s in ipairs(list) do
        local okName, name = pcall(function() return s.name end)
        if okName and name == "dangis_vr" then
            local okPath, path = pcall(function() return s.path end)
            table.insert(found, tostring(okPath and path or name))
        end
    end
    return found
end

-- Returns the warning text when more than one copy is running.
local function checkDuplicateDangisScripts()
    local scripts = findActiveDangisScripts()
    if not scripts then
        logEvent("STARTUP", "duplicate scan unavailable")
        return nil
    end
    if #scripts <= 1 then
        logEvent("STARTUP", "duplicate scan ok: " .. tostring(#scripts) .. " running dangis_vr script")
        return nil
    end
    logEvent("STARTUP", "duplicate dangis_vr scripts running: " .. table.concat(scripts, ", "))
    return "~r~Veikia kelios boto kopijos. Išjunkite senas dangis_vr kopijas."
end

local function logApiAvailability()
    local function has(value) return value and "yes" or "MISSING" end
    logEvent("STARTUP", string.format(
        "api: objectModel=%s closestObject=%s closestCar=%s allObjects=%s carPointer=%s user32=%s",
        API.objectModelName or "MISSING", has(API.closestObject), has(API.closestCar),
        has(API.allObjects), has(API.carPointer), has(Win32.init())))
end

local function performSafeStartupReset()
    RecoverySystem.rotation:reset()
    S.manualPaused = false
    S.dialogPaused = false
    S.testArbotasPaused = false
    S.dialogReleaseUntil = 0.0
    S.rotateFightUntil = 0.0
    S.rotateReleaseUntil = 0.0
    S.rotateIgnoreUntil = 0.0
    S.backToForwardUntil = 0.0
    S.reversePlaybackGraceUntil = 0.0
    S.freezeRecoveryGraceUntil = 0.0
    resetBumpState(true)
    clearFreezeRecoveryOnly(os.clock())
    clearRotateTrigger()
    os.remove(freeze_flag_file)
    gasLevel = 0
    brakeLevel = 0
    lastSteerValue = 0
    pauseReleaseReason = ""
    writeSharedState("IDLE")
    logEvent("STARTUP", "safe startup reset complete")
end

-- Completion-triggered chat, bounded queue, and one shared keyboard job.
-- Phrases come from a plain text file: one message per line, no Lua editing.
function AdminChat.begin(kind)
    AdminChat.serial = AdminChat.serial + 1
    return kind .. ":" .. tostring(AdminChat.serial) .. ":" .. string.format("%.3f", os.clock())
end

function AdminChat.normalize(text)
    text = tostring(text or "")
    local replacements = { ["ą"]="a", ["č"]="c", ["ę"]="e", ["ė"]="e", ["į"]="i", ["š"]="s", ["ų"]="u", ["ū"]="u", ["ž"]="z",
        ["Ą"]="A", ["Č"]="C", ["Ę"]="E", ["Ė"]="E", ["Į"]="I", ["Š"]="S", ["Ų"]="U", ["Ū"]="U", ["Ž"]="Z" }
    for from, to in pairs(replacements) do text = text:gsub(from, to) end
    text = text:match("^%s*(.-)%s*$")
    if #text == 0 or #text > 96 or text:find("[^ -~]") or text:sub(1,1) == "/" then return nil end
    return text
end

AdminChat.defaultGroups = {
    ["kiek jus galit tikrint bl"]="repeat",
    ["bl vel jus"]="repeat",
    ["kiek galima nx"]="repeat",
    ["nu davai greiciau bl"]="waiting",
    ["zjbs tik prisijungiau"]="recent",
    ["kas vel negerai bl"]="repeat",
    ["as nesuprantu ko jus norit"]="waiting",
    ["nu tikrink greiciau tada"]="waiting",
    ["blet kiek cia sedesim, valink netikrines"]="waiting",
    ["ka vel testas?"]="repeat",
    ["davai davai"]="waiting",
    ["ka tu cia tikrini :D"]="waiting",
    ["nx kiekviena diena tas pats"]="history",
    ["aisku bl kaip visada"]="repeat",
    ["vel testas bl"]="repeat",
    ["kiek jus galit mane tikrint nx"]="repeat",
    ["as jau vakar buvau tikrintas"]="history",
    ["nu blet ir vel jus :D"]="repeat",
    ["kiek kartu dar tikrinsit"]="repeat",
    ["ka vel kazkas nepatiko?"]="repeat",
    ["nu davai tikrink greiciau"]="waiting",
    ["as jau zinau sita testa mintinai :DD"]="frequent",
    ["blet kiek galima tu testu"]="repeat",
    ["vel mane issirinkot nx"]="repeat",
    ["nu ka dabar turiu daryt"]="waiting",
    ["sakyk greiciau ka spaust"]="waiting",
    ["as gi jau buvau praeita karta"]="repeat",
    ["nu rimtai vel tikrinimas?"]="repeat",
    ["kiek adminu mane dar tikrins :D"]="repeat",
    ["nu davai dar karta tikrinkit"]="waiting",
    ["nx kasdien tas pats"]="history",
    ["as tik prisijungiau ir jau testas"]="recent",
    ["nu ko vel prikibot"]="repeat",
    ["ka vel ne taip padariau"]="repeat",
    ["vel kazkam uzkliuvau :D"]="repeat",
    ["nu gerai tikrink"]="waiting",
    ["tik greiciau bl"]="waiting",
    ["kiek cia sedesim dabar"]="waiting",
    ["as visa diena testuose nx"]="long_session",
    ["jus mane specialiai gaudot ar ka :DD"]="repeat",
    ["nu davai ka ten reikia"]="waiting",
    ["vel adminas ir vel testas"]="repeat",
    ["blet jau atsibodo rimtai"]="repeat",
    ["kiek galima mane tampyt"]="repeat",
    ["nu jau trecia karta bl"]="third",
    ["as nieko nedarau o jus vel tikrinat"]="repeat",
    ["ka jus ten vis ieskot nx"]="repeat",
    ["nu neradot praeita karta nieko"]="repeat",
    ["ir vel nuo pradziu?"]="repeat",
    ["ble vel tuos pacius klausimus"]="repeat",
    ["nu as jau atsakinejau i sita"]="repeat",
    ["ka vel parodyt reikia"]="waiting",
    ["kiek dar klausimu bus bl"]="waiting",
    ["nu davai paskutini ir paleisk"]="waiting",
    ["as jau pavargau nuo situ testu :D"]="frequent",
    ["nu vel sustabdet mane"]="repeat",
    ["nx mane vis tikrina"]="repeat",
    ["dar karta tikrinsi? :DDD"]="repeat",
    ["blet cia daugiau testu nei zaidimo"]="frequent",
    ["nu kiek adminu dar ateis"]="repeat",
    ["vienas patikrino dabar kitas :D"]="repeat",
    ["jus tarpusavy nesusikalbat ar ka"]="repeat",
    ["nu davai paklausk dar to pacio"]="repeat",
    ["vel ta pati procedura nx"]="repeat",
    ["as jau zinau ka tu dabar sakysi :D"]="repeat",
    ["nu gerai pradek savo testa"]="waiting",
    ["kiek uztruks sitas kartas"]="waiting",
    ["blet vel negaliu vaziuot del testo"]="repeat",
    ["as jau buvau patikrintas siandien"]="repeat",
    ["kam mane vel trauki tikrint"]="repeat",
    ["nu tikrink bet nepisk proto"]="waiting",
    ["kiek galima trukdyt zaist nx"]="repeat",
    ["blet tik ne dar vienas testas"]="repeat",
    ["nu jo aisku vel mane :DD"]="repeat",
    ["is visu zaideju vel as nx"]="repeat",
    ["gerai sakyk ka daryt ir baigiam"]="waiting",
    ["nu davai greitai praeinam sita"]="waiting",
}
AdminChat.session={startedAt=os.clock(),checks=0,sent=0,joinedAt=nil}
AdminChat.groupNames={general=true,repeat_check=true,third=true,recent=true,frequent=true,long_session=true,history=true,waiting=true}
-- The internal spelling "repeat" is accepted as a tag, despite being a Lua keyword.
AdminChat.groupNames["repeat"]=true
function AdminChat.markJoined()
    AdminChat.clear()
    AdminChat.session={startedAt=os.clock(),checks=0,sent=0,joinedAt=os.clock()}
    AdminChat.seen,AdminChat.seenOrder={},{}
    AdminChat.bag,AdminChat.bagKey={},nil
    AdminChat.status="new session marked"
    logEvent("ADMIN_CHAT","new session explicitly marked")
end
function AdminChat.eligible(text,event)
    if event and event.kind=="rotation_sequence" and text==CONFIG.adminChat.quitAfterPhrase then return false end
    if not CONFIG.adminChat.contextual or not event then return true end
    local group=(AdminChat.groups and AdminChat.groups[text]) or AdminChat.defaultGroups[text] or "general"
    local checks=event.checkNumber or AdminChat.session.checks
    if group=="general" then return CONFIG.adminChat.generalPhrases end
    if group=="repeat" or group=="repeat_check" then return CONFIG.adminChat.repeatPhrases and checks>=2 end
    if group=="third" then return CONFIG.adminChat.repeatPhrases and checks==3 end
    if group=="recent" then
        local joined=AdminChat.session.joinedAt
        return CONFIG.adminChat.recentJoinPhrases and joined~=nil and os.clock()-joined>=0
            and os.clock()-joined<=CONFIG.adminChat.recentJoinSeconds
    end
    if group=="frequent" then return CONFIG.adminChat.frequentPhrases and checks>=5 end
    if group=="long_session" then
        return CONFIG.adminChat.frequentPhrases and checks>=5 and os.clock()-AdminChat.session.startedAt>=7200
    end
    if group=="history" then return CONFIG.adminChat.historicalPhrases end
    if group=="waiting" then return CONFIG.adminChat.waitingPhrases end
    return false
end
function AdminChat.blockReason(now)
    if not Win32.isGameForeground(true) then return "waiting for game focus" end
    if isSampDialogActive() then return "waiting for dialog to close" end
    local chat=isSampChatInputActive()
    if chat==nil then return "chat state unknown" end
    if chat then return "waiting for open chat" end
    if AdminChat.userInputActive() then return "player input active" end
    if hasPauseSource(now) or freezeRecoveryOwnsControls() or S.bumpActive or now<S.backToForwardUntil then return "waiting for recovery/pause" end
    if commandJob and not commandJob.done then return "another typing job active" end
    return nil
end

function AdminChat.loadPhrases()
    local file = io.open(CONFIG.adminChat.phraseFile, "rb")
    local phrases, seen, groups = {}, {}, {}
    if file then
        for line in file:lines() do
            if #phrases >= 128 then break end
            if not line:match("^%s*#") then
                local group,body=line:match("^%[([%w_]+)%]%s+(.+)$")
                local text=AdminChat.normalize(body or line)
                if text and not seen[text] and (not group or AdminChat.groupNames[group]) then
                    phrases[#phrases+1],seen[text]=text,true
                    groups[text]=group or AdminChat.defaultGroups[text] or "general"
                end
            end
        end
        file:close()
    end
    AdminChat.phrases, AdminChat.bag, AdminChat.groups, AdminChat.bagKey = phrases, {}, groups, nil
    logEvent("ADMIN_CHAT", "loaded phrases=" .. tostring(#phrases))
    return #phrases
end

function AdminChat.pick(event)
    local eligible={}
    for _,text in ipairs(AdminChat.phrases) do if AdminChat.eligible(text,event) then eligible[#eligible+1]=text end end
    if #eligible==0 then return nil end
    local key=table.concat(eligible,"\n")
    if #AdminChat.bag==0 or AdminChat.bagKey~=key then
        AdminChat.bag,AdminChat.bagKey={},key
        for i,text in ipairs(eligible) do AdminChat.bag[i]=text end
        for i = #AdminChat.bag, 2, -1 do
            local j = math.random(i)
            AdminChat.bag[i], AdminChat.bag[j] = AdminChat.bag[j], AdminChat.bag[i]
        end
        if #AdminChat.bag > 1 and AdminChat.bag[#AdminChat.bag] == AdminChat.lastPhrase then
            AdminChat.bag[1], AdminChat.bag[#AdminChat.bag] = AdminChat.bag[#AdminChat.bag], AdminChat.bag[1]
        end
    end
    local text = table.remove(AdminChat.bag)
    AdminChat.lastPhrase = text
    return text
end

function AdminChat.complete(kind, token, localTest)
    -- Individual turns stay silent; only the completed sequence scheduler can reply.
    if kind == "rotation" then return false end
    if not CONFIG.adminChat.enabled or not playing or not token
        or (localTest and not CONFIG.adminChat.includeLocalTests) or AdminChat.seen[token] then return false end
    AdminChat.seen[token] = true
    AdminChat.seenOrder[#AdminChat.seenOrder+1] = token
    if #AdminChat.seenOrder > 64 then AdminChat.seen[table.remove(AdminChat.seenOrder,1)] = nil end
    if not localTest then AdminChat.session.checks=AdminChat.session.checks+1 end
    if math.random(100)>CONFIG.adminChat.replyChance then AdminChat.status="reply skipped by frequency setting";return false end
    local delay = math.random(math.floor(CONFIG.adminChat.delayMinSeconds*1000), math.floor(CONFIG.adminChat.delayMaxSeconds*1000))/1000
    if #AdminChat.queue >= CONFIG.adminChat.maxQueued then table.remove(AdminChat.queue,1) end
    AdminChat.queue[#AdminChat.queue+1] = {kind=kind, token=token, checkNumber=AdminChat.session.checks, readyAt=os.clock()+delay, expiresAt=os.clock()+CONFIG.adminChat.expireSeconds}
    AdminChat.status="queued "..kind
    logEvent("ADMIN_CHAT", "queued " .. kind .. " token=" .. token)
    return true
end

function AdminChat.userInputActive()
    for vk=0x08,0x7B do
        if not Win32.held[vk] and Win32.keyDown(vk) then return true end
    end
    for vk=1,6 do if Win32.keyDown(vk) then return true end end
    return false
end

function AdminChat.holdsRecoveryReply()
    local token = S.controlLockReplyPending
    if not token then return false end
    if CONFIG.adminChat.enabled and playing then
        if AdminChat.job and AdminChat.job.eventToken == token and not AdminChat.job.done then return true end
        for _,event in ipairs(AdminChat.queue) do
            if event.token == token and os.clock() <= event.expiresAt then return true end
        end
    end
    S.controlLockReplyPending = nil
    return false
end

function AdminChat.clear()
    S.controlLockReplyPending = nil
    AdminChat.queue, AdminChat.rotation, AdminChat.pendingQuit = {}, nil, nil
    AdminChat.rotationSequence=nil
    if AdminChat.job and not AdminChat.job.done then AdminChat.job.cancelled = true end
    AdminChat.job = nil
    S.adminChatTyping = false
end

function AdminChat.pollDialogEvent()
    local now = os.clock()
    if now-(AdminChat.lastEventPoll or -1) < 0.05 then return end
    AdminChat.lastEventPoll=now
    local file = io.open(CONFIG.adminChat.eventFile,"r")
    if not file then return end
    local token, stamp = file:read("*l"), tonumber(file:read("*l"))
    file:close()
    if not token or not stamp then return end
    os.remove(CONFIG.adminChat.eventFile)
    if os.clock()-stamp < 0 or os.clock()-stamp > CONFIG.adminChat.expireSeconds then return end
    local eventToken = "arbotas:" .. token
    -- Recovery commands are independent of optional reaction phrases.
    if playing and CONFIG.recovery.refreshAfterArbotas and S.lastArbotasRefreshToken ~= eventToken then
        S.lastArbotasRefreshToken = eventToken
        if not S.freezeTestLatched then
            logEvent("RECOVERY", "recognized arbotas completed; scheduling /refresh")
            startFreezeRecovery("arbotas")
        else
            logEvent("RECOVERY", "recognized arbotas completed; existing freeze recovery handles /refresh")
        end
    end
    AdminChat.complete("arbotas", eventToken, false)
end

-- Drop obsolete rotation replies, including a typing job already awaiting a tick.
-- Keep coroutine ownership until it performs its normal cancellation cleanup.
function AdminChat.discardRotationReplies()
    AdminChat.rotation=nil
    for i=#AdminChat.queue,1,-1 do
        if AdminChat.queue[i].kind=="rotation" then table.remove(AdminChat.queue,i) end
    end
    local job=AdminChat.job
    if job and (job.eventKind=="rotation" or tostring(job.eventToken):match("^rotation:")) then
        job.cancelled=true
        job.rotationSuppressed=true
    end
    local quit=AdminChat.pendingQuit
    if quit and (quit.eventKind=="rotation" or tostring(quit.eventToken):match("^rotation:")) then
        AdminChat.pendingQuit=nil
        if not job then S.adminChatTyping=false end
    end
end

-- A sequence is accumulated separately from the outgoing queue. A new turn
-- cancels the queued/unfinished reply and requires a fresh completed recovery.
function AdminChat.cancelRotationSequence()
    AdminChat.rotationSequence=nil
    for i=#AdminChat.queue,1,-1 do
        if AdminChat.queue[i].kind=="rotation_sequence" then table.remove(AdminChat.queue,i) end
    end
    if AdminChat.job and AdminChat.job.eventKind=="rotation_sequence" and not AdminChat.job.submitted then
        AdminChat.job.cancelled=true
    end
end

function AdminChat.noteRotation(localTest)
    AdminChat.discardRotationReplies()
    local now=os.clock()
    local sequence=AdminChat.rotationSequence
    local job=AdminChat.job
    if job and job.eventKind=="rotation_sequence" and job.submitted then
        AdminChat.lastRotationReplyAt=job.finishedAt or now
        sequence=nil
    end
    AdminChat.cancelRotationSequence()
    if not CONFIG.adminChat.enabled or not CONFIG.adminChat.rotationSequenceReplies or not playing then return end
    local eligible=localTest and CONFIG.adminChat.includeLocalTests
        or not localTest and CONFIG.adminChat.includeInferredTests
    if not sequence or now-sequence.lastTurn>CONFIG.adminChat.expireSeconds then
        sequence={token=AdminChat.begin("rotation_sequence"),turns=0,localOnly=true}
    end
    if sequence.queued then sequence.token=AdminChat.begin("rotation_sequence") end
    if eligible then
        sequence.turns=sequence.turns+1
        sequence.localOnly=sequence.localOnly and localTest
    end
    sequence.lastTurn=now
    sequence.readyAt=nil;sequence.queued=false;sequence.expiresAt=nil
    AdminChat.rotationSequence=sequence
end

function AdminChat.finishRotationSequence(ok)
    local sequence=AdminChat.rotationSequence
    if not sequence then return end
    if not ok then AdminChat.cancelRotationSequence();return end
    sequence.readyAt=os.clock()+CONFIG.adminChat.rotationQuietSeconds
    sequence.expiresAt=sequence.readyAt+CONFIG.adminChat.expireSeconds
end

function AdminChat.pollRotationSequence(now)
    local sequence=AdminChat.rotationSequence
    if not sequence then return end
    if not CONFIG.adminChat.rotationSequenceReplies then AdminChat.cancelRotationSequence();return end
    if sequence.localOnly and not CONFIG.adminChat.includeLocalTests
        or not sequence.localOnly and not CONFIG.adminChat.includeInferredTests then
        AdminChat.cancelRotationSequence();return
    end
    if not sequence.readyAt or RecoverySystem.rotation.phase then return end
    if now>sequence.expiresAt then AdminChat.cancelRotationSequence();return end
    if sequence.queued or now<sequence.readyAt or sequence.turns<CONFIG.adminChat.rotationMinTurns then return end
    if now-(AdminChat.lastRotationReplyAt or -math.huge)<CONFIG.adminChat.rotationReplyCooldownSeconds then
        AdminChat.cancelRotationSequence();return
    end
    if AdminChat.blockReason(now) then return end
    if AdminChat.complete("rotation_sequence",sequence.token,sequence.localOnly) then
        local event=AdminChat.queue[#AdminChat.queue]
        event.readyAt=now -- already waited the sequence-specific quiet period
        event.expiresAt=sequence.expiresAt
        sequence.queued=true
    else AdminChat.cancelRotationSequence() end
end

function AdminChat.tick()
    AdminChat.discardRotationReplies()
    if not CONFIG.adminChat.rotationSequenceReplies then AdminChat.cancelRotationSequence() end
    local now = os.clock()
    AdminChat.pollDialogEvent()
    if AdminChat.job then
        if not AdminChat.job.done then
            if now-AdminChat.job.startedAt <= CONFIG.adminChat.typingTimeoutSeconds then return end
            AdminChat.job.cancelled = true
            AdminChat.job.done, AdminChat.job.ok = true, false
            AdminChat.job.reason = "typing timeout"
            Win32.releaseHeld()
        end
        local finished = AdminChat.job
        logEvent("ADMIN_CHAT", "typing finished ok=" .. tostring(finished.ok) .. " reason=" .. tostring(finished.reason))
        AdminChat.job = nil
        S.adminChatTyping = false
        AdminChat.lastSent = now
        if finished.ok and finished.submitted and not finished.rotationSuppressed then
            if finished.eventKind=="rotation_sequence" then
                AdminChat.lastRotationReplyAt=finished.finishedAt or now
                if AdminChat.rotationSequence and AdminChat.rotationSequence.token==finished.eventToken then
                    AdminChat.rotationSequence=nil
                end
            end
            if not finished.isQuit then AdminChat.session.sent=AdminChat.session.sent+1 end
            AdminChat.status=finished.isQuit and "quit submitted" or "message submitted"
            if finished.isQuit then
                RouteFollower.stopPlayback()
                return
            elseif finished.eventKind~="rotation_sequence" and CONFIG.adminChat.quitEnabled and CONFIG.adminChat.quitAfterPhrase ~= "" and finished.cmd == CONFIG.adminChat.quitAfterPhrase then
                AdminChat.pendingQuit = {readyAt=now+CONFIG.adminChat.quitDelaySeconds,
                    expiresAt=now+CONFIG.adminChat.quitExpireSeconds,eventKind=finished.eventKind,eventToken=finished.eventToken}
                S.adminChatTyping = true -- Hold neutral between the two chat entries.
            end
        end
    end
    if not CONFIG.adminChat.enabled or not playing then AdminChat.clear(); return end
    AdminChat.pollRotationSequence(now)
    if AdminChat.pendingQuit then
        local quit = AdminChat.pendingQuit
        -- This action belongs to the immediately preceding submitted phrase.
        -- Any interruption cancels it; never leave a delayed quit awaiting focus.
        if now > quit.expiresAt or hasPauseSource(now, true) or freezeRecoveryOwnsControls()
            or S.bumpActive or now < S.backToForwardUntil or (commandJob and not commandJob.done)
            or not Win32.isGameForeground(true) or AdminChat.userInputActive()
            or isSampDialogActive() or isSampChatInputActive() ~= false then
            AdminChat.pendingQuit = nil
            S.adminChatTyping = false
            logEvent("ADMIN_CHAT", "quit follow-up cancelled")
            return
        end
        if now < quit.readyAt then return end
        local job, reason = typeSAMPCommand("/q", {reaction=true})
        AdminChat.pendingQuit = nil
        if not job then
            S.adminChatTyping = false
            logEvent("ADMIN_CHAT", "quit follow-up cancelled: " .. tostring(reason))
            return
        end
        job.isQuit = true
        AdminChat.job = job
        S.adminChatTyping = true
        ControlManager.neutralize()
        return
    end
    while AdminChat.queue[1] and now > AdminChat.queue[1].expiresAt do
        logEvent("ADMIN_CHAT", "expired " .. table.remove(AdminChat.queue,1).kind)
    end
    local event=AdminChat.queue[1]
    if not event or now < event.readyAt or now-AdminChat.lastSent < CONFIG.adminChat.betweenMessagesSeconds then return end
    local blocked=AdminChat.blockReason(now)
    if blocked then AdminChat.status=blocked;return end
    if #AdminChat.phrases == 0 then AdminChat.loadPhrases() end
    if event.text and not AdminChat.eligible(event.text,event) then event.text=nil end
    local text=event.text or AdminChat.pick(event)
    event.text=text
    if not text then
        table.remove(AdminChat.queue,1)
        AdminChat.status="no eligible phrases"
        logEvent("ADMIN_CHAT", "skipped: empty or context-filtered phrase pool")
        return
    end
    local job, reason=typeSAMPCommand(text,{reaction=true})
    if not job then
        AdminChat.status="typing deferred: "..tostring(reason)
        if event.lastDeferReason~=reason then logEvent("ADMIN_CHAT",AdminChat.status);event.lastDeferReason=reason end
        return
    end
    table.remove(AdminChat.queue,1)
    job.eventToken=event.token
    job.eventKind=event.kind
    AdminChat.job=job
    AdminChat.status="typing reaction"
    S.adminChatTyping=true
    ControlManager.neutralize()
end

-- Optional, bounded telemetry. This module observes state; it never owns or
-- writes controls. Any sampling/I/O failure disables capture, not driving.
function Telemetry.cell(value)
    if value == nil then return "" end
    if type(value) == "number" then
        if value ~= value or value == math.huge or value == -math.huge then return "" end
        return string.format("%.3f", value)
    end
    local text = tostring(value):gsub("[\r\n]", " ")
    return '"' .. text:gsub('"', '""') .. '"'
end

function Telemetry.stop(reason, notify)
    Telemetry.enabled = false
    if Telemetry.handle then
        pcall(Telemetry.handle.flush, Telemetry.handle)
        pcall(Telemetry.handle.close, Telemetry.handle)
        Telemetry.handle = nil
    end
    Telemetry.target = nil
    if reason then logEvent("TELEMETRY", reason) end
    if notify then showMsg("~y~Telemetry: " .. (reason or "OFF")) end
end

function Telemetry.line(text)
    if Telemetry.bytes + #text > (CONFIG.telemetry.maxBytes or 2097152) then
        Telemetry.stop("capture limit reached", true)
        return false
    end
    local result, err = Telemetry.handle:write(text)
    if not result then error(err or "telemetry write failed") end
    Telemetry.bytes = Telemetry.bytes + #text
    return true
end

function Telemetry.start()
    if Telemetry.enabled then return true end
    local path = CONFIG.telemetry.file
    -- Keep one previous capture, so toggling F5 does not erase the latest one.
    local old = io.open(path, "rb")
    if old then
        old:close()
        os.remove(path .. ".previous.csv")
        local moved, err = os.rename(path, path .. ".previous.csv")
        if not moved then
            logEvent("TELEMETRY", "cannot preserve previous capture: " .. tostring(err))
            showMsg("~r~Telemetry: cannot preserve previous capture")
            return false
        end
    end
    local file, err = io.open(path, "wb")
    if not file then
        logEvent("TELEMETRY", "cannot open capture: " .. tostring(err))
        showMsg("~r~Telemetry: cannot open capture")
        return false
    end
    Telemetry.handle, Telemetry.bytes = file, 0
    Telemetry.enabled = true
    Telemetry.lastSample, Telemetry.lastFlush, Telemetry.lastOwner = -1, os.clock(), nil
    Telemetry.target = nil
    local header = "time_s,owner,state,route,route_index,route_points,drive_mode,speed_kmh,forward_speed_kmh,x_m,y_m,heading_deg,waypoint_distance_m,target_index,target_speed_kmh,target_x_m,target_y_m,target_bearing_error_deg,controller_branch,planned_lateral_offset_m,last_obstacle_distance_m,last_obstacle_urgency,gas,brake,steer,reverse,bump_phase,bump_reason,frame_scale\n"
    local ok, written = pcall(Telemetry.line, header)
    if not ok or not written then
        Telemetry.stop("cannot write capture header", true)
        return false
    end
    logEvent("TELEMETRY", "capture started")
    showMsg("~g~Telemetry ON ~w~(F5 - stop)")
    return true
end

function Telemetry.sample(now)
    local speed, forward, x, y, heading, distance, bearingError
    local target = Telemetry.target
    local point = current_route[play_index]
    if isCharInAnyCar(PLAYER_PED) then
        local car = storeCarCharIsInNoSave(PLAYER_PED)
        x, y = getCarCoordinates(car)
        speed = getCarSpeed(car) * 3.6
        local fs = getCarForwardSpeed(car)
        forward = fs and fs * 3.6 or nil
        heading = getCarHeading(car)
        if point then distance = getDistanceBetweenCoords2d(x, y, point.x, point.y) end
        if target and target.x and target.y then
            local dx, dy = target.x - x, target.y - y
            if dx * dx + dy * dy > 0.0001 then
                local bearing = getHeadingFromVector2d(dx, dy)
                local motionHeading = heading + (target.reverse and 180 or 0)
                bearingError = (bearing - motionHeading + 180) % 360 - 180
            end
        end
    end
    local applied = ControlManager.applied
    local values = {
        [1]=now, [2]=ControlManager.owner,
        [3]=ControlManager.sharedState(lastSharedStateText or (playing and "PLAYING" or "IDLE")),
        [4]=current_name, [5]=play_index, [6]=#current_route,
        [7]=point and routeDriveModeAt(current_route, play_index) or nil,
        [8]=speed, [9]=forward, [10]=x, [11]=y, [12]=heading, [13]=distance,
        [14]=target and target.index, [15]=target and target.speed * 3.6,
        [16]=target and target.x, [17]=target and target.y, [18]=bearingError,
        [19]=target and target.branch, [20]=S.currentLateral,
        [21]=S.routeObstacleDist, [22]=S.routeObstacleUrgency,
        [23]=applied.gas, [24]=applied.brake, [25]=applied.steer,
        [26]=applied.reverse and 1 or 0, [27]=S.bumpPhase, [28]=S.bumpReason,
        [29]=frameScale,
    }
    local cells = {}
    for i = 1, 29 do cells[i] = Telemetry.cell(values[i]) end
    return Telemetry.line(table.concat(cells, ",") .. "\n")
end

function Telemetry.tick()
    if not Telemetry.enabled then return end
    local now = os.clock()
    local changed = Telemetry.lastOwner ~= ControlManager.owner
    if not changed and now - Telemetry.lastSample < (CONFIG.telemetry.sampleSeconds or 0.1) then return end
    local ok, written = pcall(Telemetry.sample, now)
    if not ok then
        Telemetry.stop("capture error: " .. tostring(written), true)
        return
    end
    if not written then return end
    Telemetry.lastSample, Telemetry.lastOwner = now, ControlManager.owner
    if now - Telemetry.lastFlush >= (CONFIG.telemetry.flushSeconds or 1.0) then
        local flushed, result = pcall(Telemetry.handle.flush, Telemetry.handle)
        if not flushed or not result then
            Telemetry.stop("capture flush failed", true)
            return
        end
        Telemetry.lastFlush = now
    end
end

function MainLoop.initialize()
    -- Release keys an older version (synthetic S) or an interrupted command
    -- may have left pressed; done before the startup wait.
    Win32.releaseKeys({0x53, 0x10, 0x11, 0x12})
    trimDebugLogFile()
    logEvent("STARTUP", string.format("==== %s Dangis VR v%s loading ====", os.date("%Y-%m-%d %H:%M:%S"), VR_VERSION))
    UI.notify("Ruošiama sistema...", 5000)
    wait(8000)
    RouteStorage.ensurePathsDir()
    local duplicateWarning = checkDuplicateDangisScripts()
    samp = getModuleHandle("samp.dll")
    logApiAvailability()
    logEvent("STARTUP", "playerControlOn=" .. (API.playerControlOn and "available" or "MISSING") .. " playerHandle=" .. tostring(PLAYER_HANDLE))
    performSafeStartupReset()
    Settings.load()
    VehicleProfiles.update(true)
    os.remove(CONFIG.adminChat.eventFile)
    AdminChat.loadPhrases()
    -- printStringNow replaces the previous text, so show one combined message.
    UI.notify(duplicateWarning
        or ("Sistema paruošta. Ctrl + I - nustatymai; F10 - važiuoti; F6 - pauzė; F7 - sustabdyti."),
        duplicateWarning and 8000 or 5000)
end

Win32.accessories=require("lib.dangis_accessories").new({
    press=function(key) return Win32.press(key) end,
    release=function(key) return Win32.release(key) end,
    down=function(key) return Win32.keyDown(key) end,
    random=function() return math.random() end,
    event=function(kind,keys) logEvent("ACCESSORY",kind.." keys="..table.concat(keys,",")) end,
})
function MainLoop.accessoryTick()
    local car=isCharInAnyCar(PLAYER_PED) and storeCarCharIsInNoSave(PLAYER_PED) or nil
    local allowed=playing and car and ControlManager.resolveOwner()=="ROUTE"
        and CONFIG.controls.input=="keyboard" and Win32.isGameForeground(true)
        and not Settings.panel.open and isSampChatInputActive()==false
    local applied=ControlManager.applied
    local straight=allowed and not applied.reverse and applied.brake==0
        and applied.gas>0 and applied.steer==0 and getCarSpeed(car)>0.5
    if not straight then Win32.accessoryStraightSince=nil
    else Win32.accessoryStraightSince=Win32.accessoryStraightSince or os.clock() end
    local nitroSafe=straight and os.clock()-Win32.accessoryStraightSince>=1
    -- Probe only when due; unavailable collision data defers the nitro press.
    if nitroSafe and os.clock()>=(Win32.accessories.nextNitro or math.huge) then
        nitroSafe=RecoverySystem.rotationCorridor(car)
    end
    Win32.accessories:tick(os.clock(),CONFIG.controls,{running=playing and car~=nil,
        allowed=allowed,car=car,nitroSafe=nitroSafe})
end

-- One ordered frame loop: UI signals -> recovery -> route -> safety hold.
-- Live checks in the manager still protect against flags created by other
-- MoonLoader scripts between this coroutine's ticks.
function MainLoop.tick()
    Settings.panel.flush()
    if Settings.panel.open and Settings.panel.blocked() then Settings.panel.close() end
    VehicleProfiles.update()
    Telemetry.target = nil
    DialogBridge.update()
    RecoverySystem.updateControlThread()
    AdminChat.tick()
    syncPausedState()
    ControlManager.sync()
    RouteRecorder.recordTick()
    RouteFollower.updatePlayback()
    local owner = ControlManager.sync()
    if owner == "FREEZE" or owner == "DIALOG" or owner == "CHAT" or owner == "PAUSE"
        or owner == "ROTATE_WAIT" or owner == "TRANSITION" then
        ControlManager.neutralize()
    end
    MainLoop.accessoryTick()
    -- Suppressed route producers must not leave a misleading active target.
    if owner ~= "ROUTE" then Telemetry.target = nil end
    Telemetry.tick()
end

function MainLoop.startThreads()
    lua_thread.create(function()
        while true do
            wait(0)
            MainLoop.tick()
        end
    end)
end

-- Runs on unload, reload (Ctrl+R / AutoReboot) and crashes: release every key
-- the typing thread may be holding and leave the HUD a truthful state.
function onScriptTerminate(scr, quitGame)
    if scr ~= thisScript() then return end
    Settings.panel.close()
    UI.release()
    Telemetry.stop()
    AdminChat.clear()
    if commandJob and not commandJob.done then
        commandJob.cancelled = true
    end
    Win32.accessories:reset()
    Win32.releaseHeld()
    if not quitGame then
        playing = false
        ControlManager.neutralize()
        gasLevel, brakeLevel, lastSteerValue = 0, 0, 0
        reverseActive = false
        writeSharedState("IDLE")
        logEvent("STARTUP", "script terminated")
    end
end

function main()
    MainLoop.initialize()
    MainLoop.startThreads()

    while true do
        wait(0)
        InputHandler.handleHotkeys()
        MainLoop.drawTrailDebug()
        Diagnostics.draw()
        Settings.panel.draw()
    end
end
