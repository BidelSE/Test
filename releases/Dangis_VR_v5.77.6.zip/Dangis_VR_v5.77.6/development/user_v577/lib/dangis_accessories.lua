-- Separate optional key scheduler. Only releases keys it acquired itself.
local A={};A.__index=A
function A.new(io)
 return setmetatable({io=io,held={}},A)
end
function A:release()
 for key in pairs(self.held) do self.io.release(key) end
 self.held={};self.untilAt=nil;self.kind=nil
end
function A:reset()
 self:release();self.nextNitro=nil;self.nextLook=nil;self.car=nil
end
function A:interval(base,jitter)
 return math.max(1,base+(self.io.random()*2-1)*jitter)
end
function A:tick(now,c,s)
 if not s.running or self.car and self.car~=s.car then self:reset() end
 if not s.running then return end
 self.car=s.car
 self.nextNitro=self.nextNitro or now+self:interval(c.nitroInterval,c.nitroVariation)
 self.nextLook=self.nextLook or now+self:interval(c.lookInterval,10)
 if not s.allowed then self:release();return end
 if self.kind and (now>=self.untilAt or self.kind=='nitro' and (not c.nitroEnabled or not s.nitroSafe)
     or self.kind=='look' and not c.lookEnabled) then self:release() end
 if self.kind then return end
 local keys,kind,duration
 if c.nitroEnabled and now>=self.nextNitro and s.nitroSafe then
  self.nextNitro=now+self:interval(c.nitroInterval,c.nitroVariation)
  keys={0x11};kind='nitro';duration=.15
 elseif c.lookEnabled and now>=self.nextLook then
  self.nextLook=now+self:interval(c.lookInterval,10)
  local choice=math.floor(self.io.random()*4)
  keys=choice==3 and {0x51,0x45} or (choice==1 and {0x45} or {0x51})
  kind='look';duration=.4+self.io.random()*.5
 end
 if not keys then return end
 -- No synthetic presses when the player is already using any accessory key.
 for _,key in ipairs({0x11,0x51,0x45}) do if self.io.down(key) then return end end
 for _,key in ipairs(keys) do
  if not self.io.press(key) then self:release();return end
  self.held[key]=true
 end
 self.kind=kind;self.untilAt=now+duration
 if self.io.event then self.io.event(kind,keys) end
end
return A
