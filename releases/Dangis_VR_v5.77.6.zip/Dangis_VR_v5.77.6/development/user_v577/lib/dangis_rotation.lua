-- Time-based recovery from an abrupt heading discontinuity. No game APIs.
-- Commands are digital. A second disturbance always cancels the current turn.
local R = {}
R.__index = R
local function angle(a,b) return (a-b+180)%360-180 end
local function neutral() return {gas=0,brake=0,steer=0,reverse=false} end

function R.new() return setmetatable({},R) end
function R:reset()
    for k in pairs(self) do self[k]=nil end
end
function R:hold(now)
    self.reactUntil=nil
    self.phase="HOLD"
    self.lastEvent=now
    self.stableSince=nil
    self.direction=nil
    self.target=nil
    self.settleSince=nil
    self.progressAt=nil
end
function R:observe(now,car,heading,explicit,enabled,priorSteer)
    local previous=self.previous
    local dt=previous and now-previous.at or 0
    local valid=previous and previous.car==car and dt>0 and dt<=0.35
    self.rate=valid and math.abs(angle(heading,previous.heading))/dt or math.huge
    self.previous={at=now,car=car,heading=heading}
    if not valid or not enabled then self.history={} end
    local history=self.history or {}
    self.history=history
    local triggered=explicit and enabled
    if valid and enabled then
        triggered=triggered or math.abs(angle(heading,previous.heading))>=120
        for _,sample in ipairs(history) do
            if now-sample.at<=0.25 and math.abs(angle(heading,sample.heading))>=140 then triggered=true end
        end
    end
    while history[1] and now-history[1].at>0.25 do table.remove(history,1) end
    history[#history+1]={at=now,heading=heading}
    if triggered then
        local first=not self.phase
        self.started=self.started or now
        self.count=(self.count or 0)+1
        self:hold(now)
        if first and priorSteer and priorSteer~=0 then
            self.reactUntil=now+0.20
            self.heldSteer=priorSteer<0 and -128 or 128
            self.phase="REACT"
        else
            self.reactUntil=nil
        end
        self.history={{at=now,heading=heading}}
    elseif self.phase and not valid then
        -- No recovery drive command from stale samples or a different vehicle.
        self:hold(now)
    end
    return triggered
end

-- Failures keep ownership but release every key. Retry at a bounded cadence.
function R:retry(now,reason)
    self.attempts=(self.attempts or 0)+1
    self:hold(now)
    self.phase="WAIT"
    self.retryAt=now+math.min(5,1+self.attempts*0.5)
    self.reason=reason
end

function R:step(now,sample,errorDegrees)
    local cmd=neutral()
    if not self.phase then return cmd end
    if not sample.allowed then
        self:hold(now)
        return cmd
    end
    if self.phase=="REACT" then
        if now<(self.reactUntil or 0) then cmd.steer=self.heldSteer;return cmd end
        self:hold(now)
    end
    if self.phase=="WAIT" then
        if now>=self.retryAt then self:hold(now) end
        return cmd
    end
    if self.phase=="HOLD" then
        if self.rate<=25 and sample.speed<=3 and (sample.slip or 0)<=35 then
            self.stableSince=self.stableSince or now
        else self.stableSince=nil end
        if now-self.lastEvent>=1 and self.stableSince and now-self.stableSince>=0.65 then
            self.phase="ALIGN"
            self.alignStarted=now
            self.progressAt=now
            self.progressX,self.progressY=sample.x,sample.y
        end
        return cmd
    end
    if errorDegrees==nil then self:retry(now,"no route target");return cmd end
    if self.phase=="SETTLE" then
        if math.abs(errorDegrees)>35 or self.rate>35 or sample.speed>4 or (sample.slip or 0)>35 then
            self:hold(now)
        elseif now-self.settleSince>=0.65 then return cmd,"ready" end
        return cmd
    end
    if sample.speed>4 or self.rate>100 or (sample.slip or 0)>50 then self:hold(now);return cmd end
    if now-self.alignStarted>8 then self:retry(now,"alignment timeout");return cmd end
    if math.abs(errorDegrees)<=22 then
        self.phase="SETTLE";self.settleSince=now
        return cmd
    end
    if not self.direction then self.direction=errorDegrees<0 and -128 or 128 end
    if errorDegrees*self.direction<0 and math.abs(errorDegrees)<100 then
        self:hold(now);return cmd
    end
    if self.phase=="REVERSE" then
        if sample.reverseClear~=true then self:retry(now,"reverse blocked");return cmd end
        local distance=math.sqrt((sample.x-self.reverseX)^2+(sample.y-self.reverseY)^2)
        if now-self.reverseAt>=1.5 or distance>=2 then
            if distance<0.3 then self:retry(now,"reverse made no progress")
            else self:hold(now) end
            return cmd
        end
        cmd.steer=-self.direction
        -- Wait for forward motion to stop before engaging S.
        if sample.speed<1.5 and (sample.forwardSpeed or 0)<=0.2 then cmd.reverse=true end
        return cmd
    end
    local moved=math.sqrt((sample.x-self.progressX)^2+(sample.y-self.progressY)^2)
    if moved>=0.6 then
        self.progressAt=now;self.progressX,self.progressY=sample.x,sample.y
    end
    if sample.clear~=true or now-self.progressAt>2.5 then
        if sample.reverseClear==true and sample.speed<0.3 then
            self.phase="REVERSE";self.reverseAt=now
            self.reverseX,self.reverseY=sample.x,sample.y
        else self:retry(now,"no clear manoeuvre or no progress") end
        return cmd
    end
    cmd.steer=self.direction
    if sample.speed<2 and (sample.forwardSpeed or 0)>=-0.2
        and (now-self.alignStarted)%0.5<0.16 then cmd.gas=255 end
    return cmd
end
return R
