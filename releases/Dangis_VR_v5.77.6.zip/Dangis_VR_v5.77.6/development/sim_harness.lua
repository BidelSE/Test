-- Dangis VR simulation harness (development only).
-- Loads one copy of dangis_vr.lua with its own lib/ modules into an isolated
-- Lua environment with mocked MoonLoader/GTA/Windows APIs and a simple
-- deterministic kinematic car. Several copies (e.g. original v5.77 and the
-- modified script) can run side by side with identical inputs.
-- Runs under texlua (Lua 5.3) and LuaJIT 2.1.
local Sim = {}

local unpack = table.unpack or unpack
local atan2 = math.atan2 or math.atan

local function readFile(path)
    local f = assert(io.open(path, "rb")); local d = f:read("*a"); f:close(); return d
end

local function compile(source, name, env)
    if setfenv then
        local fn = assert(loadstring(source, "@" .. name))
        setfenv(fn, env)
        return fn
    end
    return assert(load(source, "@" .. name, "t", env))
end

-- Deterministic LCG so every instance sees the same random sequence.
local function makeRandom(seed)
    local state = seed or 12345
    return function(m, n)
        state = (1103515245 * state + 12345) % 2147483648
        local r = state / 2147483648
        if m == nil then return r end
        if n == nil then n = m; m = 1 end
        return m + math.floor(r * (n - m + 1))
    end
end

Sim.ACCESSOR = [[
return {
    S=S, CONFIG=CONFIG, Win32=Win32, Mem=Mem, manager=ControlManager, loop=MainLoop, route=RouteFollower,
    recovery=RecoverySystem, obstacle=ObstacleAvoidance, chat=AdminChat, settings=Settings, input=InputHandler, storage=RouteStorage,
    recorder=RouteRecorder, planner=DrivingPlanner, escape=EscapePlanner,  select=RouteSelect, memory=RecoveryMemory,
    getIndex=function() return play_index end, setIndex=function(v) play_index=v end,
    getRoute=function() return current_route end, getName=function() return current_name end,
    setRoute=function(r,name) current_route=r; play_index=1; if name then current_name=name end end,
    isPlaying=function() return playing end, setPlaying=function(v) playing=v end,
    isRecording=function() return recording end, isRepeating=function() return repeating end,
    setRepeating=function(v) repeating=v end,
    levels=function() return gasLevel,brakeLevel,lastSteerValue end,
}
]]

function Sim.new(opts)
    opts = opts or {}
    local root = assert(opts.root, "root")
    local work = opts.work or ("/tmp/dangis_sim_" .. tostring(opts.tag or "x"))
    if not opts.keep then os.execute("rm -rf '" .. work .. "'") end
    os.execute("mkdir -p '" .. work .. "/dangis_paths'")
    -- Working-directory content: INI, phrases and route files.
    for _, item in ipairs(opts.files or {}) do
        -- Windows text mode turns CRLF into LF for the script; emulate it.
        local out = assert(io.open(work .. "/" .. item[1], "wb")); out:write((item[2]:gsub("\r\n", "\n"))); out:close()
    end

    local self = {root=root, work=work, now=opts.start or 100, events={}, keyLog={}, pad={}, chatLog={}, threads={},
        messages={}, cancelled={}}
    local env = {}
    setmetatable(env, {__index=_G})
    env._G = env
    local realOs = os
    env.os = setmetatable({clock=function() return self.now end}, {__index=realOs})
    env.math = setmetatable({random=makeRandom(opts.seed or 4242), randomseed=function() end}, {__index=math})

    -- Per-instance module loader so original and modified libs never mix.
    local loaded = {["lib.moonloader"]={}}
    env.require = function(name)
        if loaded[name] ~= nil then return loaded[name] end
        local path = root .. "/" .. name:gsub("%.", "/") .. ".lua"
        local fn = compile(readFile(path), path, env)
        local value = fn(name)
        if value == nil then value = true end
        loaded[name] = value
        return value
    end
    env.package = setmetatable({loaded=loaded}, {__index=package})

    -- Car state ---------------------------------------------------------
    local car = {x=opts.x or 0, y=opts.y or 0, z=opts.z or 0, heading=opts.heading or 0, v=0, inCar=true, handle=1}
    self.car = car
    env.PLAYER_PED, env.PLAYER_HANDLE = 1, 1
    env.script_name = function() end
    env.script_version = function() end
    env.script_properties = function() end
    env.getWorkingDirectory = function() return work end
    env.isCharInAnyCar = function() return car.inCar end
    env.storeCarCharIsInNoSave = function() return car.handle end
    env.getCarCoordinates = function() return car.x, car.y, car.z end
    env.getCharCoordinates = function() return car.x, car.y, car.z end
    env.getCarSpeed = function()
        if self.grip then
            local h = math.rad(car.heading)
            local vx, vy = -math.sin(h)*car.v + (car.sx or 0), math.cos(h)*car.v + (car.sy or 0)
            return math.sqrt(vx*vx + vy*vy)
        end
        return math.abs(car.v)
    end
    env.getCarHeading = function() return car.heading % 360 end
    env.getHeadingFromVector2d = function(x, y) return (math.deg(atan2(-x, y)) + 360) % 360 end
    env.getDistanceBetweenCoords2d = function(x, y, a, b) return math.sqrt((x-a)^2 + (y-b)^2) end
    env.locateCharInCar2d = function(_, x, y, rx, ry) return math.abs(car.x-x) <= rx and math.abs(car.y-y) <= ry end
    env.getCarPointer = function() return 0x05000000 end
    env.isCarInAirProper = function() return car.air == true end
    env.isPointOnScreen = function() return false end
    env.convert3DCoordsToScreen = function() return 0, 0 end
    env.renderDrawLine = function() end
    env.renderDrawBox = function() end
    env.renderDrawPolygon = function() end
    env.renderCreateFont = function() return {} end
    env.renderFontDrawText = function() end
    env.renderGetFontDrawTextLength = function(_, t) return #t * 7 end
    env.getScreenResolution = function() return 1280, 720 end
    env.printStringNow = function() end
    env.doesDirectoryExist = function() return true end
    env.createDirectory = function() end
    env.getModuleHandle = function() return 0x100000 end
    env.isGamePaused = function() return false end
    env.showCursor = function() end
    env.getCursorPos = function() return self.cursorX or 0, self.cursorY or 0 end
    env.consumeWindowMessage = function() end
    local scriptHandle = {}
    env.thisScript = function() return scriptHandle end
    env.wait = function() end
    env.lua_thread = {create=function(fn)
        local co = coroutine.create(fn)
        self.threads[#self.threads+1] = co
        return co
    end}
    -- Coroutine-aware wait for typing threads: yield one frame per call.
    env.wait = function(ms)
        if coroutine.running() and coroutine.isyieldable and coroutine.isyieldable() then coroutine.yield() end
    end
    if not coroutine.isyieldable then
        -- LuaJIT: coroutine.running() returns nil on the main thread.
        env.wait = function() if coroutine.running() then coroutine.yield() end end
    end
    env.isKeyDown = function(vk) return self.physical and self.physical[vk] == true end
    env.isKeyJustPressed = function(vk) return self.pressed and self.pressed[vk] == true end
    for name, code in pairs({VK_F1=0x70,VK_F2=0x71,VK_F3=0x72,VK_F4=0x73,VK_F5=0x74,VK_F6=0x75,VK_F7=0x76,
        VK_F8=0x77,VK_F9=0x78,VK_F10=0x79,VK_F11=0x7A,VK_F12=0x7B}) do env[name] = code end
    env.writeMemory = function(address, size, value) self.pad[address] = value end
    env.setGameKeyState = function(key, value) self.pad.steer = value end
    env.findFirstFile = function(mask)
        local dir = mask:match("^(.*)/[^/]*$")
        local p = io.popen("ls -1 '" .. dir .. "' 2>/dev/null")
        local names = {}
        for line in p:lines() do if line:match("%.txt$") then names[#names+1] = line end end
        p:close()
        if #names == 0 then return nil end
        local handle = {names=names, i=1}
        return handle, names[1]
    end
    env.findNextFile = function(handle) handle.i = handle.i + 1; return handle.names[handle.i] end
    env.findClose = function() end
    if opts.collision ~= false then
        env.processLineOfSight = function(ax, ay, az, bx, by, bz, solid, cars, peds, objects)
            return self:lineOfSight(ax, ay, az, bx, by, bz, solid, cars, peds, objects)
        end
    end

    -- opts.pool: the MoonLoader object pool (getAllObjects and friends) lists
    -- the obstacles that have a model, as in the game.
    if opts.pool then
        local function obstacle(h) return self.obstacles[(h - 0x08000000) / 16] end
        env.getAllObjects = function()
            local list = {}
            for i, o in ipairs(self.obstacles) do if o.model then list[#list+1] = 0x08000000 + i*16 end end
            return list
        end
        env.getObjectModel = function(h) local o = obstacle(h); return o and o.model end
        env.getObjectCoordinates = function(h) local o = obstacle(h); if not o then return false end; return true, o.x, o.y, self.groundZ end
        env.getObjectHeading = function(h) local o = obstacle(h); return o and (o.heading or 0) or 0 end
        if opts.pool ~= "nodims" then
            env.getModelDimensions = function(model)
                for _, o in ipairs(self.obstacles) do
                    if o.model == model then return -(o.r or 0.6), -(o.r or 0.6), 0, (o.r or 0.6), (o.r or 0.6), (o.h or 1.0) end
                end
            end
        end
    end

    -- World: circular vehicle obstacles and wall segments (buildings).
    self.obstacles = opts.obstacles or {}
    self.walls = opts.walls or {}
    self.groundZ = opts.groundZ or (car.z - 0.6)
    self.terrain = opts.terrain
    self.selfCollision = opts.selfCollision
    -- opts.grip (m/s^2): tyre grip. The car keeps its momentum when it turns
    -- faster than the tyres can follow (slides, spins); without it the car
    -- follows its wheels exactly (the original model).
    self.grip = opts.grip
    if self.terrain then car.z = self.terrain(car.x, car.y) + 0.6 end

    local source = readFile(root .. "/dangis_vr.lua") .. Sim.ACCESSOR
    local fn = compile(source, root .. "/dangis_vr.lua", env)
    local bot = fn()
    self.bot, self.env = bot, env

    -- Windows/SA-MP surfaces.
    bot.Win32.ready = true
    -- opts.realKeys: Windows-like keyboard. One shared up/down state per key
    -- (last event wins, as GetAsyncKeyState reports it), every key event is
    -- delivered to onWindowMessage with its dwExtraInfo (GetMessageExtraInfo),
    -- and the player's keys (Sim:humanKey) auto-repeat while held.
    self.realKeys = opts.realKeys
    self.sysKey, self.extraInfo = {}, 0
    local function deliver(vk, down, extra)
        self.sysKey[vk] = down or nil
        if not self.realKeys or self.focus == false then return end
        self.extraInfo = extra or 0
        if type(env.onWindowMessage) == "function" and not self.noKeyMessages then env.onWindowMessage(down and 0x100 or 0x101, vk, 0) end
        self.extraInfo = 0
    end
    self.deliverKey = deliver
    bot.Win32.u32 = {MapVirtualKeyA=function(vk) return vk end, VkKeyScanA=function(b) return b end,
        GetMessageExtraInfo=function() return self.extraInfo or 0 end,
        keybd_event=function(vk, scan, flags, extra)
            self.keyLog[#self.keyLog+1] = {t=self.now, vk=vk, up=flags == 2, extra=extra}
            if self.realKeys then deliver(vk, flags ~= 2, extra) end
            if flags == 2 then return end
            -- SA-MP chat emulation: T opens, characters type, Enter submits, Esc cancels.
            if not self.chatOpen then
                if vk == 0x54 and not self.dialog then self.chatOpen = true; self.chatBuffer = "" end
            elseif vk == 0x0D then
                self.chatOpen = false
                self.messages[#self.messages+1] = {t=self.now, text=self.chatBuffer}
            elseif vk == 0x1B then
                self.chatOpen = false
                self.cancelled[#self.cancelled+1] = {t=self.now, text=self.chatBuffer}
            elseif vk ~= 0x10 and vk ~= 0x11 and vk ~= 0x12 then
                self.chatBuffer = self.chatBuffer .. string.char(vk % 256):lower()
            end
        end}
    bot.Win32.isGameForeground = function() return self.focus ~= false end
    bot.Win32.keyDown = function(vk)
        if self.realKeys then return self.focus ~= false and self.sysKey[vk] == true end
        return self.physical and self.physical[vk] == true
    end
    if self.realKeys then env.isKeyDown = function(vk) return self.focus ~= false and self.sysKey[vk] == true end end
    local samp = 0x100000
    bot.Mem.readDword = function(address)
        if address == samp + 0x21A0B8 then return 0x1000000 end
        if address == 0x1000000 + 0x28 then return self.dialog and 1 or 0 end
        if address == samp + bot.CONFIG.adminChat.chatInputPointerOffset then return 0x2000000 end
        if address == 0x2000000 + bot.CONFIG.adminChat.chatEnabledOffset then return self.chatOpen and 1 or 0 end
        return nil
    end
    bot.Mem.readWord = function(address)
        if address == 0x05000000 + 0x22 then return 400 end
        local i = (address - 0x22 - 0x08000000) / 16
        local o = self.obstacles and self.obstacles[i]
        if o and o.model and i == math.floor(i) then return o.model end
        return nil
    end
    bot.Mem.readByte = function() return nil end
    bot.Mem.readFloat = function(address)
        local h = math.rad(car.heading)
        local fx, fy = -math.sin(h), math.cos(h)
        local vx, vy = fx * car.v + (car.sx or 0), fy * car.v + (car.sy or 0)
        if address == 0x05000000 + 0x44 then return vx / 50 end
        if address == 0x05000000 + 0x48 then return vy / 50 end
        return nil
    end
    return setmetatable(self, {__index=Sim})
end

-- Segment/circle and segment/segment intersection in 2D.
function Sim:lineOfSight(ax, ay, az, bx, by, bz, solid, cars, peds, objects)
    -- Cost accounting and optional fault injection for collision-check tests.
    self.raysThisFrame = (self.raysThisFrame or 0) + 1
    self.raysTotal = (self.raysTotal or 0) + 1
    if self.losFault then
        local fault = self.losFault(self.raysTotal)
        if fault == "error" then error("simulated processLineOfSight failure") end
        if fault == "nil" then return nil end
    end
    local best, hit
    local dx, dy = bx-ax, by-ay
    local len2 = dx*dx + dy*dy
    -- The player's own car is solid to processLineOfSight in GTA (there is no
    -- "ignore this entity" argument). Oriented box, ground to roof height.
    if cars ~= false and self.selfCollision ~= false then
        local car = self.car
        local h = math.rad(car.heading)
        local fx, fy = -math.sin(h), math.cos(h)
        local lx, ly = -fy, fx
        local hl, hw = self.selfHalfLength or 2.4, self.selfHalfWidth or 1.0
        local function local2(px, py) return (px-car.x)*fx+(py-car.y)*fy, (px-car.x)*lx+(py-car.y)*ly end
        local a1, a2 = local2(ax, ay)
        local b1, b2 = local2(bx, by)
        local t0, t1 = 0, 1
        local ok = true
        for _, axis in ipairs({{a1, b1-a1, hl}, {a2, b2-a2, hw}}) do
            local p, d, lim = axis[1], axis[2], axis[3]
            if math.abs(d) < 1e-9 then
                if p < -lim or p > lim then ok = false end
            else
                local ta, tb = (-lim-p)/d, (lim-p)/d
                if ta > tb then ta, tb = tb, ta end
                t0, t1 = math.max(t0, ta), math.min(t1, tb)
                if t0 > t1 then ok = false end
            end
        end
        if ok then
            local floor = self:terrainAt(car.x, car.y)
            local z = az+(bz-az)*t0
            if z >= floor and z <= floor+1.6 then
                best = t0
                hit = {pos={ax+dx*t0, ay+dy*t0, z}, normal={0, 0, 0}, entityType=2, entity=0x05000000}
            end
        end
    end
    -- Terrain (Sim.terrain(x, y) -> ground height): a sloping road or a raised
    -- shoulder is hit by a low horizontal ray, exactly like the game's ground.
    if solid ~= false and self.terrain and (math.abs(dx) > 1e-6 or math.abs(dy) > 1e-6) then
        local len = math.sqrt(len2)
        local n = math.max(1, math.ceil(len/0.25))
        for i = 0, n do
            local t = i/n
            if best and t >= best then break end
            local px, py, pz = ax+dx*t, ay+dy*t, az+(bz-az)*t
            if pz < self.terrain(px, py) then
                best = t
                hit = {pos={px, py, pz}, normal={0, 0, 1}, entityType=1, entity=0x07000000}
                break
            end
        end
    end
    if cars ~= false then
        for _, o in ipairs(self.obstacles) do
            if len2 > 1e-9 then
                local t = math.max(0, math.min(1, ((o.x-ax)*dx + (o.y-ay)*dy)/len2))
                local px, py = ax+dx*t, ay+dy*t
                local pz = az+(bz-az)*t
                -- o.model: a map object (entity type 4) of that model, o.h tall from the ground.
                local tallEnough = not o.model or pz <= self:terrainAt(px, py) + (o.h or 1.0)
                if (px-o.x)^2 + (py-o.y)^2 <= (o.r or 1.2)^2 and tallEnough and (not best or t < best) then
                    best = t
                    if o.model then
                        hit = {pos={px, py, pz}, normal={0, 0, 0}, entityType=4, entity=0x08000000 + _*16}
                    else
                        hit = {pos={px, py, pz}, normal={0, 0, 0}, entityType=2, entity=0x06000000}
                    end
                end
            end
        end
    end
    if solid ~= false then
        for _, w in ipairs(self.walls) do
            local ex, ey = w[3]-w[1], w[4]-w[2]
            local den = dx*ey - dy*ex
            if math.abs(den) > 1e-9 then
                local t = ((w[1]-ax)*ey - (w[2]-ay)*ex)/den
                local u = ((w[1]-ax)*dy - (w[2]-ay)*dx)/den
                if t >= 0 and t <= 1 and u >= 0 and u <= 1 and (not best or t < best) then
                    best = t
                    hit = {pos={ax+dx*t, ay+dy*t, az+(bz-az)*t}, normal={0, 0, 0}, entityType=1, entity=0x07000000}
                end
            end
        end
        -- Ground: a vertical ray reaching below ground level hits the floor.
        local floor = self:terrainAt(ax, ay)
        if math.abs(dx) < 1e-6 and math.abs(dy) < 1e-6 and bz < floor and az >= floor then
            local holes = self.holes or {}
            for _, h in ipairs(holes) do
                if (ax-h.x)^2 + (ay-h.y)^2 <= h.r^2 then return false, nil end
            end
            if not best then
                return true, {pos={ax, ay, floor}, normal={0, 0, 1}, entityType=1, entity=0x07000000}
            end
        end
    end
    if hit then return true, hit end
    return false, nil
end

-- Simple deterministic vehicle response to the applied digital/analogue input.
function Sim:physics(dt)
    local car = self.car
    local a = self.bot.manager.applied
    if self.bot.CONFIG.controls.input == "keyboard" then
        local held = self.bot.Win32.driveHeld
        a = {gas=held[0x57] and 255 or 0, brake=held[0x53] and 255 or 0,
            steer=held[0x41] and -128 or (held[0x44] and 128 or 0), reverse=held[0x53] == true}
    end
    local v = car.v
    local reverse = a.reverse
    if self.bot.CONFIG.controls.input == "keyboard" then reverse = a.brake > 0 end
    if self.grip then return self:gripPhysics(dt, a, reverse) end
    if reverse then
        if v > 0.3 then v = v - 10*dt else v = math.max(v - 4*dt, -7) end
    elseif (a.gas or 0) > 0 then
        if v < -0.3 then v = math.min(0, v + 10*dt) else v = v + (a.gas/255)*7*dt*math.max(0, 1 - v/55) end
    elseif (a.brake or 0) > 0 and v > 0 then
        v = math.max(0, v - 9*dt*(a.brake/255))
    else
        local drag = math.min(math.abs(v), 0.6*dt)
        v = v - (v > 0 and drag or -drag)
    end
    car.v = v
    local steer = (a.steer or 0)/128
    local lock = math.rad(32) * math.max(0.12, math.min(1, 9/math.max(1, math.abs(v))))
    local yaw = v/2.7 * math.tan(steer*lock)
    car.heading = (car.heading - math.deg(yaw*dt)) % 360
    local h = math.rad(car.heading)
    car.x = car.x + (-math.sin(h))*v*dt + (car.sx or 0)*dt
    car.y = car.y + math.cos(h)*v*dt + (car.sy or 0)*dt
    if car.sx then car.sx = car.sx*0.9; car.sy = car.sy*0.9 end
    if self.terrain then car.z = self.terrain(car.x, car.y) + 0.6 end
end

-- Grip model: world velocity = forward speed along the heading + a sideways
-- slide. The wheels turn the body (kinematic yaw from the forward speed); the
-- velocity follows the new heading only as fast as the tyre grip allows, so a
-- fast turn or spin carries its momentum. S above the reverse top speed does
-- not pull the car back to it (it just stops pushing).
function Sim:gripPhysics(dt, a, reverse)
    local car = self.car
    local v = car.v
    if reverse then
        if v > 0.3 then v = v - 10*dt elseif v > -7 then v = math.max(v - 4*dt, -7) else v = v + math.min(-v, 0.6*dt) end
    elseif (a.gas or 0) > 0 then
        if v < -0.3 then v = math.min(0, v + 10*dt) else v = v + (a.gas/255)*7*dt*math.max(0, 1 - v/55) end
    elseif (a.brake or 0) > 0 and v > 0 then
        v = math.max(0, v - 9*dt*(a.brake/255))
    else
        local drag = math.min(math.abs(v), 0.6*dt)
        v = v - (v > 0 and drag or -drag)
    end
    local h = math.rad(car.heading)
    local wx, wy = -math.sin(h)*v + (car.sx or 0), math.cos(h)*v + (car.sy or 0)
    local steer = (a.steer or 0)/128
    local lock = math.rad(32) * math.max(0.12, math.min(1, 9/math.max(1, math.abs(v))))
    local yaw = v/2.7 * math.tan(steer*lock)
    car.heading = (car.heading - math.deg(yaw*dt)) % 360
    h = math.rad(car.heading)
    local fx, fy = -math.sin(h), math.cos(h)
    local lx, ly = -fy, fx
    local along, side = wx*fx + wy*fy, wx*lx + wy*ly
    side = side - (side > 0 and 1 or -1)*math.min(math.abs(side), self.grip*dt)
    car.v = along
    car.sx, car.sy = lx*side, ly*side
    car.x = car.x + (fx*along + lx*side)*dt
    car.y = car.y + (fy*along + ly*side)*dt
    if self.terrain then car.z = self.terrain(car.x, car.y) + 0.6 end
end

function Sim:terrainAt(x, y)
    if self.terrain then return self.terrain(x, y) end
    return self.groundZ
end

-- The player presses (down=true) or releases a key (realKeys mode).
function Sim:humanKey(vk, down)
    self.physical = self.physical or {}
    self.physical[vk] = down or nil
    if down then self.lastHumanKey = vk end
    self.deliverKey(vk, down, 0)
end

-- Focus moves to another window (false) or back (true).
function Sim:setFocus(focused)
    self.focus = focused
    if not focused and self.realKeys and type(self.env.onWindowMessage) == "function" then
        self.env.onWindowMessage(0x0008, 0, 0)
    end
end

-- One game frame: threads (typing jobs), the bot's frame loop, physics.
function Sim:frame(dt, hotkeys)
    self.now = self.now + dt
    -- auto-repeat of the player's most recent key that is still held
    local rk = self.lastHumanKey
    if self.realKeys and rk and self.physical and self.physical[rk] then self.deliverKey(rk, true, 0) end
    self.raysThisFrame = 0
    self.pressed = hotkeys
    if hotkeys then self.bot.input.handleHotkeys() end
    self.pressed = nil
    for i = #self.threads, 1, -1 do
        local co = self.threads[i]
        if coroutine.status(co) == "dead" then table.remove(self.threads, i)
        else
            local ok, err = coroutine.resume(co)
            if not ok then error(err) end
        end
    end
    self.bot.loop.tick()
    self.raysLastFrame = self.raysThisFrame
    if self.bot.manager.owner == "ROTATE" then
        self.maxRotateRays = math.max(self.maxRotateRays or 0, self.raysThisFrame or 0)
    end
    self:physics(dt)
end

function Sim:press(vk, dt)
    self:frame(dt or 1/30, {[vk]=true})
end

-- Record of what the bot asked for this frame.
function Sim:snapshot()
    local a = self.bot.manager.applied
    return string.format("%s g=%d b=%d s=%d r=%s i=%d", self.bot.manager.owner, math.floor(a.gas or 0),
        math.floor(a.brake or 0), math.floor(a.steer or 0), tostring(a.reverse == true), self.bot.getIndex())
end

function Sim.routeText(route)
    local lines = {}
    for _, p in ipairs(route) do
        lines[#lines+1] = string.format("{%s}:{%s}:{%s}:{%s}:{%s}:{%s}", p.x, p.y, p.z or 0, p.speed or 10, p.heading or 0, p.drive or "FWD")
    end
    return table.concat(lines, "\n") .. "\n"
end

function Sim.read(path) return readFile(path) end

return Sim
