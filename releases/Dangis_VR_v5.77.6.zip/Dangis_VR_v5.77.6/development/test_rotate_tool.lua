-- test_rotate.lua ON/OFF switch (Ctrl+9), with mocked MoonLoader APIs.
-- Usage: texlua development/test_rotate_tool.lua
local dir = (os.getenv("TMPDIR") or "/tmp") .. "/dangis_rotate_tool_test"
os.execute("rm -rf '" .. dir .. "'; mkdir -p '" .. dir .. "'")
local now, frame = 100, 0
local down, pressed, notes, threads = {}, {}, {}, {}
local car = {heading = 0, speed = 20}
local env = setmetatable({}, {__index = _G})
env.os = setmetatable({clock = function() return now end}, {__index = os})
env.require = function(name) if name == "memory" then error("no memory module") end return {} end
env.script_name, env.script_author, env.script_version, env.script_description = function() end, function() end, function() end, function() end
env.getWorkingDirectory = function() return dir end
env.PLAYER_PED, env.PLAYER_HANDLE = 1, 1
env.isPlayerPlaying = function() return true end
env.isGamePaused = function() return false end
env.isKeyDown = function(vk) return down[vk] == true end
env.isKeyJustPressed = function(vk) return pressed[vk] == true end
env.isCharInAnyCar = function() return true end
env.storeCarCharIsInNoSave = function() return 7 end
env.doesVehicleExist = function() return true end
env.getDriverOfCar = function() return 1 end
env.getCarPointer = function() return 0 end
env.getCarHeading = function() return car.heading end
env.setCarHeading = function(_, h) car.heading = h end
env.getCarSpeed = function() return car.speed end
env.setCarForwardSpeed = function() end
env.printStringNow = function(t) notes[#notes+1] = t end
env.renderCreateFont = function() return {} end
env.renderFontDrawText = function(_, t) env.lastHud = t end
env.renderGetFontDrawHeight = function() return 12 end
local function yield() coroutine.yield() end
env.wait = function() yield() end
env.lua_thread = {create = function(fn) threads[#threads+1] = coroutine.create(fn) end}
local f = assert(io.open("test_rotate.lua", "rb")); local src = f:read("*a"); f:close()
local chunk = assert((loadstring or load)(src, "@test_rotate.lua", "t", env))
if setfenv then setfenv(chunk, env) end
chunk()
local mainCo = coroutine.create(env.main)
local function step(keys)
    pressed = {}
    for _, vk in ipairs(keys or {}) do pressed[vk] = true end
    down[0x11] = keys ~= nil
    now = now + 1/30
    assert(coroutine.resume(mainCo))
    for i = #threads, 1, -1 do
        local co = threads[i]
        assert(coroutine.resume(co))
        if coroutine.status(co) == "dead" then table.remove(threads, i) end
    end
end
local function readCfg() local g = io.open(dir .. "/test_rotate.cfg"); if not g then return nil end; local v = g:read("*l"); g:close(); return v end
local total = 0
local function test(name, fn) fn(); total = total + 1; print("PASS " .. name) end

step()
test("starts OFF: Ctrl+1/2/3 and Ctrl+6 do nothing, the panel says OFF", function()
    for _, vk in ipairs({0x31, 0x32, 0x33, 0x36}) do step({vk}); for i = 1, 10 do step() end end
    assert(car.heading == 0, "car was not spun")
    assert(env.lastHud:find("OFF", 1, true))
end)
test("Ctrl+9 turns it ON (remembered), Ctrl+1 spins the car", function()
    step({0x39}); assert(readCfg() == "on")
    step({0x31}); for i = 1, 15 do step() end
    assert(math.abs(car.heading - 180) < 1 or math.abs(car.heading + 180) < 1, "spun: " .. car.heading)
    assert(env.lastHud ~= nil)
end)
test("Ctrl+9 during a triple test stops it before the next spin; OFF is remembered", function()
    car.heading = 0
    step({0x33}); for i = 1, 10 do step() end           -- first spin done, waiting 2 s for the second
    local after1 = car.heading
    step({0x39}); assert(readCfg() == "off")
    for i = 1, 120 do step() end
    assert(car.heading == after1, "no further spins after switching off")
end)
test("a reload keeps the saved state", function()
    local g = io.open(dir .. "/test_rotate.cfg", "w"); g:write("on\n"); g:close()
    mainCo = coroutine.create(env.main); step()
    car.heading = 0; step({0x31}); for i = 1, 15 do step() end
    assert(car.heading ~= 0, "ON after reload")
end)
print(total .. " rotate-tool switch scenarios passed")
