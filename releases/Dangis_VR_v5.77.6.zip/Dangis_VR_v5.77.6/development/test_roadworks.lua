-- 5.77.5 road works (simulated, keyboard input, your INI).
-- Motorway at 72 and 130 km/h, straight and in a long bend, with cones
-- (1238), barriers (1423/1459) and signs beside or across the route, like the
-- place in your video. Each run reports, inside the road works:
--   clear   closest the car body came to any object (m)
--   off     largest side offset from the route line (m)
--   swings  how often the car turned from one side of the route to the other
--           by more than 1.5 deg (weaving)
--   angle   largest angle to the route (deg)
--   vmin    lowest speed (m/s), compared with the same run without objects
-- Objects that leave the car's path free must change nothing at all: the
-- run is compared frame by frame with the run without objects.
-- Usage: texlua development/test_roadworks.lua
--   RW_POOL=1       objects are also in getAllObjects (your MoonLoader has it)
--   RW_POOL=nodims  ... but getModelDimensions is missing
--   RW_AVOID=0      avoid_all_objects = false (v5.77 obstacle handling)
package.path = "development/?.lua;" .. package.path
local Sim = require("sim_harness")
local INI = Sim.read("development/user_v577/dangis_vr.ini")
local POOL = os.getenv("RW_POOL") == "nodims" and "nodims" or (os.getenv("RW_POOL") == "1")
local total, failures = 0, {}
-- two-argument arctangent on Lua 5.3 (texlua) and LuaJIT (math.atan2)
local atan2 = math.atan2 or math.atan

-- Route geometry: straight 0-200 m, left bend R=250 m for 300 m, straight.
local R, A0, A1 = 250.0, 200.0, 500.0
local function shapeAt(s, bend)
    if not bend or s <= A0 then return 0.0, s, 0.0, 1.0 end
    local t = math.min(s, A1) - A0
    local th = t / R
    local x, y = -R + R * math.cos(th), A0 + R * math.sin(th)
    local dx, dy = -math.sin(th), math.cos(th)
    if s > A1 then x, y = x + dx * (s - A1), y + dy * (s - A1) end
    return x, y, dx, dy
end
local function world(s, l, bend)
    local x, y, dx, dy = shapeAt(s, bend)
    return x - dy * l, y + dx * l     -- + l = left of the route
end
local function routeText(speed, bend)
    local pts = {}
    for i = 0, 260 do
        local s = i * 4.3
        local x, y, dx, dy = shapeAt(s, bend)
        pts[#pts+1] = {x=x, y=y, z=10, speed=speed, heading=(math.deg(atan2(-dx, dy)) + 360) % 360, drive="FWD"}
    end
    return Sim.routeText(pts)
end
-- Car position in route coordinates (s, l) and the angle to the route.
local function locate(x, y, heading, bend, sHint)
    local best, bs = math.huge, 0
    for s = math.max(0, sHint - 20), sHint + 40, 0.5 do
        local px, py = shapeAt(s, bend)
        local d = (x - px)^2 + (y - py)^2
        if d < best then best, bs = d, s end
    end
    local px, py, dx, dy = shapeAt(bs, bend)
    local l = (x - px) * (-dy) + (y - py) * dx
    local rh = (math.deg(atan2(-dx, dy)) + 360) % 360
    return bs, l, ((heading - rh + 540) % 360) - 180
end

local function drive(speed, bend, objects, tag)
    local obs = {}
    local attached = {}
    for i, o in ipairs(objects) do
        local x, y = world(o[1], o[2], bend)
        obs[i] = {x=x, y=y, r=o.r or 0.25, h=o.h or 0.7, model=not o.car and (o.model or 1238) or nil}
        if o.attached then attached[#attached+1] = {obs[i], o[1], o[2]} end
    end
    local sim = Sim.new({root=".", tag="rw" .. tostring(POOL) .. (os.getenv("RW_AVOID") or "") .. "_" .. tag, files={{"dangis_vr.ini", INI},
        {"dangis_paths/route1.txt", routeText(speed, bend)}}, x=0, y=0, z=10.6, heading=0, obstacles=obs, grip=14, pool=POOL})
    sim.groundZ = 10
    sim.bot.loop.initialize()
    sim.bot.CONFIG.controls.input = "keyboard"
    if os.getenv("RW_AVOID") == "0" then sim.bot.CONFIG.driving.avoidAllObjects = false end
    sim.bot.obstacle.laneGain = tonumber(os.getenv("RW_GAIN") or "") or sim.bot.obstacle.laneGain
    sim.bot.obstacle.laneLook = tonumber(os.getenv("RW_LOOK") or "") or sim.bot.obstacle.laneLook
    sim:frame(1/30, {[0x79]=true})
    local trace, s = {}, 0
    for i = 1, 30*50 do
        -- objects attached to the car (o.attached): {forward, left} from its centre
        for _, a in ipairs(attached) do
            local h = math.rad(sim.car.heading)
            a[1].x = sim.car.x - math.sin(h) * a[2] - math.cos(h) * a[3]
            a[1].y = sim.car.y + math.cos(h) * a[2] - math.sin(h) * a[3]
        end
        sim:frame(1/30)
        local c = sim.car
        local l, angle
        s, l, angle = locate(c.x, c.y, c.heading, bend, s)
        local p = {s=s, l=l, angle=angle, v=c.v, x=c.x, y=c.y,
            steer=sim.bot.Win32.driveHeld[0x41] and -1 or (sim.bot.Win32.driveHeld[0x44] and 1 or 0)}
        local h = math.rad(c.heading)
        local fx, fy = -math.sin(h), math.cos(h)
        for k, o in ipairs(obs) do if not objects[k].attached then
            local dx, dy = o.x - c.x, o.y - c.y
            local along, side = dx*fx + dy*fy, dx*(-fy) + dy*fx
            local ex, ey = math.max(0, math.abs(along) - 2.4), math.max(0, math.abs(side) - 1.0)
            p.clear = math.min(p.clear or math.huge, math.sqrt(ex*ex + ey*ey) - o.r)
        end end
        trace[#trace+1] = p
        if s > 900 then break end
    end
    return trace
end

local function zone(trace, s0, s1)
    local z = {closest=math.huge, maxOff=0, minV=math.huge, maxHead=0, swings=0}
    local lastSign = 0
    for _, p in ipairs(trace) do
        if p.s >= s0 and p.s <= s1 then
            z.closest = math.min(z.closest, p.clear or math.huge)
            z.maxOff = math.max(z.maxOff, math.abs(p.l))
            z.minV = math.min(z.minV, p.v)
            z.maxHead = math.max(z.maxHead, math.abs(p.angle))
            local sign = p.angle > 1.5 and 1 or (p.angle < -1.5 and -1 or 0)
            if sign ~= 0 and lastSign ~= 0 and sign ~= lastSign then z.swings = z.swings + 1 end
            if sign ~= 0 then lastSign = sign end
        end
    end
    return z
end

local baselines = {}
local function check(speed, bend, name, objects, expect)
    local only = os.getenv("RW_ONLY")   -- e.g. RW_ONLY="36 bend parked" (debugging)
    if only then
        local label = speed .. " " .. (bend and "bend " or "") .. name
        for word in only:gmatch("%S+") do if not label:find(word, 1, true) then return end end
    end
    local key = speed .. tostring(bend)
    if not baselines[key] then
        local t = drive(speed, bend, {}, "base_" .. speed .. (bend and "b" or "s"))
        baselines[key] = {trace=t, zone=zone(t, 150, 750)}
    end
    local base = baselines[key]
    local trace = drive(speed, bend, objects, (name:gsub("%W", "_")) .. speed .. (bend and "b" or "s"))
    local z = zone(trace, 150, 750)
    if os.getenv("RW_TRACE") then
        for i, p in ipairs(trace) do
            if i % 6 == 0 and p.s > 200 and p.s < 480 then
                print(string.format("  s=%5.0f l=%5.2f angle=%5.1f v=%4.1f clear=%5.2f", p.s, p.l, p.angle, p.v, p.clear or 99))
            end
        end
    end
    local bad = {}
    local function need(cond, what) if not cond then bad[#bad+1] = what end end
    need(z.closest >= (expect.minClear or 0.5), string.format("clearance %.2f < %.2f", z.closest, expect.minClear or 0.5))
    if expect.maxOff then need(z.maxOff <= expect.maxOff, string.format("side offset %.1f > %.1f", z.maxOff, expect.maxOff)) end
    if expect.minOff then need(z.maxOff >= expect.minOff, string.format("side offset %.1f < %.1f", z.maxOff, expect.minOff)) end
    local swings = (expect.swings or 1) + base.zone.swings
    need(z.swings <= swings, string.format("%d heading swings > %d (weaving)", z.swings, swings))
    local maxHead = math.max(expect.maxHead or 6, base.zone.maxHead + 0.5)
    need(z.maxHead <= maxHead, string.format("angle %.1f deg > %.1f", z.maxHead, maxHead))
    need(z.minV >= base.zone.minV - (expect.speedLoss or 1.0), string.format("speed %.1f m/s vs %.1f without objects", z.minV, base.zone.minV))
    if expect.identical then
        local same = #trace == #base.trace
        for i = 1, math.min(#trace, #base.trace) do
            if trace[i].x ~= base.trace[i].x or trace[i].y ~= base.trace[i].y or trace[i].steer ~= base.trace[i].steer then same = false; break end
        end
        need(same, "the drive differs from the run without objects")
    end
    total = total + 1
    if #bad > 0 then failures[#failures+1] = speed .. " m/s " .. (bend and "bend " or "") .. name end
    print(string.format("%s %2d m/s %-5s %-56s clear %5.2f  off %4.1f  swings %d  angle %4.1f  vmin %4.1f%s",
        #bad == 0 and "PASS" or "FAIL", speed, bend and "bend" or "", name, z.closest, z.maxOff, z.swings, z.maxHead, z.minV,
        #bad == 0 and "" or ("  <- " .. table.concat(bad, ", "))))
end

-- Object lists in route coordinates {s, l (+ left), r=, h=, model=}.
local function row(s0, s1, step, l, extra)
    local t = extra or {}
    for s = s0, s1, step do t[#t+1] = {s, l} end
    return t
end
local VIDEO = row(260, 420, 9, 2.6)           -- your place: cones along the left
for s = 300, 400, 25 do VIDEO[#VIDEO+1] = {s, 3.4, r=0.9, h=1.1, model=1423} end
VIDEO[#VIDEO+1] = {250, 3.0, r=0.35, h=1.3, model=19961}
local RIGHT = row(260, 420, 9, -2.6)
local TAPER = {}
do
    local l = 3.5
    for s = 260, 330, 7 do TAPER[#TAPER+1] = {s, l}; l = l - 0.39 end
    row(337, 430, 7, -0.4, TAPER)
    TAPER[#TAPER+1] = {300, 1.2, r=0.9, h=1.1, model=1423}
    TAPER[#TAPER+1] = {360, 1.0, r=0.9, h=1.1, model=1459}
end

-- Straight road: strict. In the bend, v5.77 itself runs 3-4 m off the line
-- in the simulator (its keyboard steering corrects only from about 10 deg),
-- so objects 2.6 m beside the line are in the car's own way there and are
-- avoided; the bend checks are: no contact (0.25 m), no weaving beyond what
-- v5.77 does there anyway, no speed lost.
-- There the car also lags behind the side offset it wants (keyboard
-- steering in a continuous turn), and when that brings it too close to an
-- object it slows down; that is allowed in the bend, and how far aside it
-- goes is not checked there (v5.77 alone is already 3-4 m off).
local function bendRule(t, bend)
    if not bend then return t end
    return {minClear=math.min(t.minClear or 0.5, 0.25), maxHead=(t.maxHead or 6) + 3, swings=(t.swings or 1) + 3,
        speedLoss=30.0}
end
for _, speed in ipairs({20, 36}) do
    for _, bend in ipairs({false, true}) do
        check(speed, bend, bend and "cones 2.6 m left + barriers + sign" or "cones 2.6 m left + barriers + sign: nothing changes",
            VIDEO, bendRule({identical=true, swings=0, minClear=1.0}, bend))
        check(speed, bend, bend and "cones 2.6 m right" or "cones 2.6 m right: nothing changes",
            RIGHT, bendRule({identical=true, swings=0, minClear=1.0}, bend))
        check(speed, bend, "taper closing the lane, 90 m closed: one move, hold", TAPER,
            bendRule({minClear=0.5, minOff=1.5, maxOff=3.8, maxHead=9, speedLoss=1.5}, bend))
        check(speed, bend, "cones 1.55 m left (0.3 m from the body)", row(260, 420, 9, 1.55),
            bendRule({minClear=0.5, maxOff=2.2, maxHead=7}, bend))
        check(speed, bend, "one cone on the route line", {{300, -0.2}},
            bendRule({minClear=0.3, maxOff=3.2, maxHead=10, speedLoss=1.5}, bend))
        -- Objects on alternate sides: the car has to cross ~3.5 m between
        -- them. At 72 km/h that is done at speed; at 130 km/h 40-60 m is
        -- too short for keyboard steering, so there it slows down as much
        -- as needed (and only there).
        local alternate = speed > 30 and 16.0 or 1.5
        check(speed, bend, "parked cars 1.6 m left and right, 60 m apart", {{280, 1.6, r=1.3, car=true},
            {340, -1.6, r=1.3, car=true}, {400, 1.6, r=1.3, car=true}},
            bendRule({minClear=0.3, maxOff=3.8, maxHead=12, swings=4, speedLoss=alternate}, bend))
        check(speed, bend, "slalom cones left 1 m / right 1 m, 40 m apart", {{280, 1.0}, {320, -1.0}, {360, 1.0}},
            bendRule({minClear=0.3, maxOff=3.8, maxHead=12, swings=4, speedLoss=alternate}, bend))
    end
end

-- Objects the server attaches to your car (lights, signs) move with it and
-- are never obstacles; the drive is identical to one without them.
check(36, false, "objects attached to the car (roof sign, bumper light)",
    {{0, 0, attached=true, model=19961, r=0.3, h=1.6}, {2.4, 0.6, attached=true, model=1238, r=0.2, h=0.5}},
    {identical=true, swings=0, minClear=-99})

print(string.format("%d road-works scenarios, %d failed%s", total, #failures, #failures > 0 and (": " .. table.concat(failures, "; ")) or ""))
if #failures > 0 then os.exit(1) end
