-- Execute the actual shipped script with mocked game/Windows surfaces.
-- No copied manager implementation and no GTA/SA-MP installation required.
local sourcePath = arg[1] or 'dangis_vr.lua'
local file = assert(io.open(sourcePath, 'rb'))
local source = file:read('*a'); file:close()
local testRoot = '/tmp/dangis_driving_test'
os.execute('mkdir -p ' .. testRoot)
local fakeNow = 10
os.clock = function() return fakeNow end
package.preload['lib.moonloader'] = function() return {} end
script_name = function() end
script_version = function() end
getWorkingDirectory = function() return testRoot end
PLAYER_PED = 1
local inCar = true
local carX,carY,carSpeed,carHeading=0,0,20,0
isCharInAnyCar = function() return inCar end
storeCarCharIsInNoSave = function() return 1 end
getCarCoordinates = function() return carX, carY, 0 end
getCarSpeed=function() return carSpeed end
getCharCoordinates=getCarCoordinates
isPointOnScreen=function() return false end
-- 5.77.6: two-argument arctangent on LuaJIT too (its math.atan takes one)
getHeadingFromVector2d=function(x,y) return (math.deg((math.atan2 or math.atan)(-x,y))+360)%360 end
locateCharInCar2d=function() return false end
getCarHeading = function() return carHeading end
getDistanceBetweenCoords2d = function(x,y,a,b) return math.sqrt((x-a)^2+(y-b)^2) end
printStringNow = function() end
local writes, pad = {}, {}
writeMemory = function(address, size, value)
    assert(size == 2)
    writes[#writes+1] = {address=address, value=value}
    pad[address] = value
end
setGameKeyState = function(key, value)
    assert(key == 0)
    writes[#writes+1] = {steer=value}
    pad.steer = value
end
local appended = [[
return {
    classifier=MotionClassifier, planner=DrivingPlanner, chat=AdminChat, telemetry=Telemetry,
    turn=turning_mechanism, noise=applySteerNoise,
    setFrame=function(value) frameScale=value end,
    setMotion=function(speed,x,y,gas,brake)
        lastDriveSpeed=speed; lastX=x; lastY=y; gasLevel=gas; brakeLevel=brake
        ControlManager.apply({gas=gas,brake=brake,steer=0})
    end,
    getLevels=function() return gasLevel,brakeLevel end,
    skipScans=function() ObstacleAvoidance.updateScan=function() end end,
    manager=ControlManager, memory=RecoveryMemory, S=S, config=CONFIG, Win32=Win32, Mem=Mem, input=InputHandler,
    stopBump=stopBumpRecovery, resync=resyncAfterBump, rejoin=handleRouteRejoinRecovery,
    setIndex=function(index) play_index=index end, getIndex=function() return play_index end,
    route=RouteFollower, storage=RouteStorage, recovery=RecoverySystem, loop=MainLoop,
    release=releaseControls, pedals=writeDriveControls, steering=writeSteerControls,
    state=writeSharedState, bump=startBumpRecovery, updateBump=updateBumpRecovery,
    transition=startBackToForwardTransition, freeze=startFreezeRecovery,
    rotate=handleAdminRotate, rotation=pressRotateReaction,
    setPlaying=function(value) playing=value end,
    setSamp=function(value) samp=value end,
    setRoute=function(value) current_route=value; play_index=1 end,
    setSpeed=function(value) lastDriveSpeed=value; S.forwardSpeed=value end,
    applied=function() return ControlManager.applied end,
    owner=function() return ControlManager.owner end,
    clearSharedThrottle=function() lastSharedStateWriteAt=-1 end,
    setLoopStages=function(dialog, recovery, recorder, playback)
        DialogBridge.update=dialog; RecoverySystem.updateControlThread=recovery
        RouteRecorder.recordTick=recorder; RouteFollower.updatePlayback=playback
    end,
}
]]
-- 5.77.6: an empty world for these planner tests (nothing to hit). With no
-- collision function at all the passage check cannot verify the path and the
-- car holds, which development/test_passage.lua checks.
processLineOfSight = function() return false end
local bot = assert((loadstring or load)(source .. appended, '@'..sourcePath))()
bot.config.controls.input="gamepad"
local physical, dialog = false, false
isKeyDown = function() return physical end
bot.Win32.isGameForeground = function() return true end
bot.Win32.keyDown = function() return physical end
bot.Mem.readDword = function(address)
    if address == 0x100000 + 0x21A0B8 then return 0x1000000 end
    if address == 0x1000000 + 0x28 then return dialog and 1 or 0 end
end
bot.setSamp(0x100000)
local function flag(name, value)
    local path=testRoot..'/dangis_vr_'..name..'.flag'
    if value then local f=assert(io.open(path,'w')); f:write(value); f:close()
    else os.remove(path) end
end
local function reset()
    flag('freeze'); flag('dialog'); flag('rotate')
    physical, dialog, inCar = false, false, true
    bot.config.controls.brakeMode="foot"
    if bot.config.escape then bot.config.escape.enabled=false end
    bot.setPlaying(false)
    bot.route.clearTransientState()
    bot.manager.neutralize()
    bot.setPlaying(true)
    bot.setRoute({{x=0,y=0,z=0,speed=10,drive='FWD'}, {x=10,y=0,z=0,speed=10,drive='FWD'}})
    bot.setSpeed(20)
    bot.manager.sync()
    bot.S.rejoinCooldownUntil=0; bot.S.rejoinDisableUntil=0
    writes={}
    carX,carY,carSpeed,carHeading=0,0,20,0
    bot.classifier.reset();bot.planner.cache=nil
    bot.config.adminChat.includeInferredTests=false
    bot.config.adminChat.includeLocalTests=false
    bot.config.controls.steering='smooth'
    bot.config.driving.enabled=true
    bot.config.driving.cornerBraking=true
    bot.config.driving.lowFpsTolerance=true;bot.S.playbackDt=1/30;bot.S.digitalSteer=0;bot.S.digitalReverseAfter=0;bot.planner.heldTarget=nil;bot.config.driving.steeringPointStride=1
    bot.S.showObstacleDots=false;bot.S.nextNudge=fakeNow+100
    bot.S.lapWander=0;bot.S.currentLateral=0
    bot.S.nextGasLift=fakeNow+100;bot.S.gasLiftFrames=0
    bot.telemetry.enabled=false
end
local function equal(value, expected, message)
    assert(value==expected, (message or 'value')..': expected '..tostring(expected)..', got '..tostring(value))
end
local function neutral()
    equal(pad[bot.config.controls.gasAddress],0,'gas')
    equal(pad[bot.config.controls.footBrakeAddress],0,'foot brake')
    equal(pad[bot.config.controls.handbrakeAddress],0,'handbrake')
    equal(pad.steer,0,'steer')
    equal(bot.applied().reverse,false,'reverse')
end
local total=0
local function test(name,fn)
 reset(); fn(); total=total+1; print('PASS '..name)
end
local function line(count, mode)
 local result={}
 for i=1,count do result[i]={x=0,y=(i-1)*2,z=0,speed=10,heading=0,drive=mode or 'FWD'} end
 return result
end
local function begin(route)
 bot.setRoute(route); bot.setSpeed(20)
 assert(bot.bump(1,route,1,'test'))
 assert(bot.S.bumpActive)
end
local function finish(route,distance)
 fakeNow=fakeNow+3
 bot.updateBump(1,0,-distance)
 equal(bot.S.bumpPhase,'coast')
 fakeNow=fakeNow+0.4
 bot.updateBump(1,0,-distance)
 equal(bot.S.bumpActive,false)
 fakeNow=fakeNow+4
 bot.setSpeed(20)
end

local function close(a,b,eps) assert(math.abs(a-b)<(eps or 0.001),tostring(a)..' differs from '..tostring(b)) end
local function observe(speed,gas,brake,obstacle,heading,elapsed,x)
 fakeNow=fakeNow+(elapsed or 1/30)
 return bot.classifier.observe(fakeNow,x or 0,0,speed,heading or 0,obstacle or math.huge,gas or 200,brake or 0)
end

test('abrupt stationary stop under throttle is only a suspected freeze',function()
 equal(observe(20),'moving');equal(observe(0),'suspected_freeze')
 equal(observe(0),'suspected_freeze')
end)

test('nearby obstacle prevents freeze classification',function()
 observe(20,200,0,4);equal(observe(0,200,0,4),'obstructed')
end)

test('recent obstacle survives a temporarily clear scan',function()
 observe(20,200,0,4);equal(observe(0),'obstructed')
end)

test('braking and released throttle are intentional stops',function()
 observe(20);equal(observe(0,200,60),'intentional_stop')
 observe(20);equal(observe(0,0,0),'intentional_stop')
end)

test('a heading jump does not corroborate a motion freeze',function()
 observe(20);equal(observe(0,200,0,nil,150),'stuck')
end)

test('lag gaps discard stale stop evidence',function()
 observe(20);equal(observe(0,200,0,nil,0,0.5),'uncertain')
end)

test('ordinary persistent immobility is not a freeze',function()
 observe(0);for i=1,40 do equal(observe(0),'stuck') end
end)

test('movement clears a pending freeze hypothesis',function()
 observe(20);observe(0);equal(observe(2,200,0,nil,0,nil,0.3),'moving')
 equal(observe(0,200,0,nil,0,nil,0.3),'stuck')
end)

test('actual freeze handler holds before trying reverse for a corroborated abrupt stop',function()
 local route=line(40);bot.setRoute(route)
 bot.setMotion(20,0,0,200,0)
 carSpeed=20;bot.recovery.handleFreeze(1,route,1)
 carSpeed=0
 for i=1,10 do fakeNow=fakeNow+1/30;bot.recovery.handleFreeze(1,route,1) end
 assert(bot.S.freezeTestLatched);equal(bot.S.freezeRecoveryMode,'suspected')
 assert(not bot.S.bumpActive);equal(bot.S.freezeChatToken,nil);neutral()
end)

test('actual intentional stop never starts reverse or refresh recovery',function()
 local route=line(40);bot.setRoute(route)
 bot.setMotion(20,0,0,200,0);carSpeed=20
 bot.recovery.handleFreeze(1,route,1)
 carSpeed=0;bot.setMotion(20,0,0,0,0)
 for i=1,180 do fakeNow=fakeNow+1/30;bot.recovery.handleFreeze(1,route,1) end
 assert(not bot.S.bumpActive);assert(not bot.S.freezeTestLatched);assert(not bot.S.manualPaused)
 equal(#bot.chat.queue,0)
end)

test('actual obstacle stop uses recovery and blocked reverse never schedules chat',function()
 local route=line(40);bot.setRoute(route)
 bot.setMotion(20,0,0,200,0);bot.S.routeObstacleDist=3
 carSpeed=20;bot.recovery.handleFreeze(1,route,1);carSpeed=0
 for i=1,10 do fakeNow=fakeNow+1/30;bot.recovery.handleFreeze(1,route,1) end
 assert(bot.S.bumpActive);assert(not bot.S.freezeTestLatched)
 fakeNow=fakeNow+1.3;bot.updateBump(1,0,0)
 equal(bot.manager.sharedState('PLAYING'),'RECOVERY_BLOCKED');neutral()
 assert(not bot.S.freezeTestLatched);equal(#bot.chat.queue,0)
end)

test('suspected freeze released by movement skips refresh',function()
 bot.freeze('suspected');carX=1
 bot.recovery.updateControlThread()
 assert(not bot.S.freezeTestLatched);assert(not bot.S.refreshSent);equal(#bot.chat.queue,0)
end)

test('suspected refresh cooldown holds then resumes without keyboard injection',function()
 bot.classifier.lastRefreshAt=fakeNow
 bot.freeze('suspected');fakeNow=bot.S.freezeRefreshAt+0.01
 bot.recovery.updateControlThread();assert(bot.S.refreshSent);equal(bot.S.refreshJob,nil)
 fakeNow=bot.S.freezeReleaseUntil+0.01;bot.recovery.updateControlThread()
 assert(not bot.S.freezeTestLatched)
end)

test('inferred freeze and rotation are silent when inference chat is disabled',function()
 bot.freeze('suspected');bot.recovery.resetFreezeRecovery();equal(#bot.chat.queue,0)
 carHeading=180;bot.rotate(1);equal(bot.chat.rotation,nil)
end)

local function bend(spacing)
 local route={}
 for y=0,200,spacing do route[#route+1]={x=0,y=y,z=0,speed=30,heading=0,drive='FWD'} end
 for x=spacing,200,spacing do route[#route+1]={x=x,y=200,z=0,speed=30,heading=270,drive='FWD'} end
 return route
end
local function limits(route)
 local cache=assert(bot.planner.build(route))
 return cache,cache.legs[1]
end

test('straight route keeps recorded speed',function()
 local _,leg=limits(line(100))
 local limit,reason=bot.planner.speedLimit(leg,0,30,30)
 equal(limit,30);equal(reason,'route')
end)

test('corner braking begins before the turn and tightens on approach',function()
 local _,leg=limits(bend(4))
 local far=bot.planner.speedLimit(leg,0,30,30)
 local middle,reason=bot.planner.speedLimit(leg,120,30,30)
 local near=bot.planner.speedLimit(leg,180,30,30)
 equal(far,30);assert(middle<far and near<middle);equal(reason,'corner_braking')
 local past=bot.planner.speedLimit(leg,215,10,30);equal(past,30)
end)

test('recorded low speed remains the upper limit',function()
 local _,leg=limits(bend(4))
 equal(bot.planner.speedLimit(leg,196,10,2),2)
 equal(bot.planner.speedLimit(leg,196,10,0),0)
end)

test('dense and sparse versions of the same path produce matching limits',function()
 local _,dense=limits(bend(1));local _,sparse=limits(bend(4))
 for progress=0,220,10 do
  close(bot.planner.speedLimit(dense,progress,30,30),(bot.planner.speedLimit(sparse,progress,30,30)))
 end
end)

test('duplicate route points do not alter planning or produce invalid values',function()
 local route=bend(4);local dup={}
 for _,point in ipairs(route) do for j=1,10 do dup[#dup+1]=point end end
 local _,a=limits(route);local _,b=limits(dup)
 close(bot.planner.speedLimit(a,180,30,30),(bot.planner.speedLimit(b,180,30,30)))
 local x,y,speed=bot.planner.target(dup,451,0,180,30)
 assert(x==x and y==y and speed==speed)
end)

test('preview and steering target respect a reverse boundary',function()
 local route=line(10)
 for _,point in ipairs(route) do point.speed=30 end
 route[#route+1]={x=0,y=16,z=0,speed=8,drive='BACK'}
 route[#route+1]={x=-10,y=16,z=0,speed=8,drive='BACK'}
 local cache,leg=limits(route)
 equal(bot.planner.speedLimit(leg,10,30,30),30)
 local x,y=bot.planner.target(route,9,0,16,30);equal(x,0);equal(y,18)
 equal(#cache.legs,2)
end)

test('lookahead grows with speed and stays bounded',function()
 local route=line(100)
 local _,slow=bot.planner.target(route,1,0,0,0)
 local _,fast=bot.planner.target(route,1,0,0,20)
 assert(fast>slow);assert(fast<=bot.config.driving.maxLookaheadMeters)
end)

test('projection accounts for accepted waypoints ahead of the car',function()
 local route=line(100);local cache=bot.planner.ensure(route)
 local _,progress=bot.planner.project(cache,5,0,0);equal(progress,0)
 local x,y=bot.planner.target(route,5,0,0,0);equal(x,0);equal(y,3)
end)

test('high speed expands braking preview beyond the base distance',function()
 local _,leg=limits(bend(4))
 local limit=bot.planner.speedLimit(leg,0,50,50)
 assert(limit<50)
end)

test('cache rebuilds for a different route or point count',function()
 local route=line(10);local a=bot.planner.ensure(route)
 equal(bot.planner.ensure(route),a)
 route[#route+1]={x=0,y=20,z=0,speed=10,drive='FWD'}
 assert(bot.planner.ensure(route)~=a)
 local b=bot.planner.ensure(line(10));assert(b.route~=route)
end)

test('invalid or excessive geometry refuses the planning cache',function()
 equal(bot.planner.build({{x=0,y=0},{x=math.huge,y=0}}),nil)
 equal(bot.planner.build({{x=0,y=0},{x=1000000,y=0}}),nil)
end)

test('smooth steering is symmetric bounded and speed sensitive',function()
 local left=bot.planner.steering(-10,10,0,1/30)
 local right=bot.planner.steering(10,10,0,1/30)
 close(left,-right);assert(right>0 and right<128)
 assert(bot.planner.steering(5,40,0,1/30)<bot.planner.steering(5,10,0,1/30))
 local previous=0
 for i=1,90 do local value=bot.planner.steering(170,30,previous,1/30);assert(value<=128 and value-previous<=320/30+0.001);previous=value end
end)

test('smooth steering response is close across 15 30 60 and 120 FPS',function()
 local result={}
 for _,fps in ipairs({15,30,60,120}) do
  local value=0
  for i=1,fps do value=bot.planner.steering(12,20,value,1/fps) end
  result[#result+1]=value
 end
 for i=2,#result do close(result[i],result[1],0.3) end
end)

test('smooth steering recenters and ownership handoff resets the filter',function()
 local value=80
 for i=1,60 do value=bot.planner.steering(0,20,value,1/30) end
 assert(math.abs(value)<0.001)
 bot.S.smoothSteerValue=80;flag('freeze','1\n');bot.manager.sync()
 equal(bot.S.smoothSteerValue,0);neutral()
end)

test('smooth mode does not inject random steering cuts',function()
 bot.steering(53)
 for i=1,100 do bot.noise();equal(pad.steer,53) end
end)

test('actual playback prioritizes planned corner braking over throttle lifts',function()
 local route=bend(4);bot.setRoute(route);bot.setIndex(46)
 carY=180;carSpeed=30;bot.setMotion(30,0,180,200,0)
 bot.S.gasLiftFrames=30;bot.S.rotateIgnoreUntil=fakeNow+100;bot.S.freezeRecoveryGraceUntil=fakeNow+100
 bot.skipScans();bot.telemetry.enabled=true
 bot.route.updatePlayback()
 local gas,brake=bot.getLevels();equal(gas,0);assert(brake>0)
 equal(bot.telemetry.target.branch,'corner_braking');assert(bot.telemetry.target.speed<30)
 equal(bot.applied().gas,0);assert(bot.applied().brake>0)
end)

test('legacy driving switches preserve the recorded speed target',function()
 bot.config.driving.enabled=false;bot.config.controls.steering='bangbang'
 local route=bend(4);bot.setRoute(route);bot.setIndex(46)
 carY=180;carSpeed=30;bot.setMotion(30,0,180,200,0)
 bot.S.rotateIgnoreUntil=fakeNow+100;bot.S.freezeRecoveryGraceUntil=fakeNow+100
 bot.skipScans();bot.telemetry.enabled=true
 bot.route.updatePlayback()
 equal(bot.telemetry.target.speed,30);equal(bot.telemetry.target.branch,'route')
end)

test('corner braking disabled preserves recorded speed around bends',function()
 bot.config.driving.cornerBraking=false
 local route=bend(4);bot.setRoute(route);bot.setIndex(46)
 carY=180;carSpeed=30;bot.setMotion(30,0,180,200,0)
 bot.S.rotateIgnoreUntil=fakeNow+100;bot.S.freezeRecoveryGraceUntil=fakeNow+100
 bot.skipScans();bot.route.updatePlayback()
 equal(bot.telemetry.target.speed,30);equal(bot.telemetry.target.branch,'route')
 local gas,brake=bot.getLevels();equal(brake,0)
end)

test('explicit playback starts at nearest point in memory route',function()
 local route=bend(4);bot.setRoute(route);carX=0;carY=180
 assert(bot.route.startPlayback());equal(bot.getIndex(),46)
end)

test('disk route also starts at nearest point',function()
 local route=bend(4);bot.setRoute({});carX=0;carY=180
 local original=bot.storage.load
 bot.storage.load=function() return route end
 assert(bot.route.startPlayback());equal(bot.getIndex(),46)
 bot.storage.load=original
end)

test('nearest start retains recorded reverse leg',function()
 local route={}
 for i=1,10 do route[i]={x=i*10,y=0,speed=5,reverse=i>=6} end
 carX=80;carY=0
 equal(bot.route.startIndex(route),8)
end)

test('primitive turner outputs only full left right and release',function()
 bot.config.controls.steering='bangbang'
 for _,x in ipairs({-20,0,20}) do
  for i=1,4 do bot.turn(x,20,0,0,1) end
  local value=bot.applied().steer
  assert(value==-128 or value==0 or value==128)
 end
end)

test('primitive route writer quantizes obstacle and reverse steering',function()
 bot.config.controls.steering='bangbang';bot.manager.sync()
 equal(bot.owner(),'ROUTE')
 for _,value in ipairs({-82,-18,-1,0,1,18,82}) do
  bot.steering(value)
  equal(bot.applied().steer,value<0 and -128 or (value>0 and 128 or 0))
 end
end)

test('primitive route output is neutralized by live freeze',function()
 bot.config.controls.steering='bangbang';bot.steering(45);equal(bot.applied().steer,128)
 flag('freeze','test');bot.steering(-45);equal(bot.applied().steer,0)
end)

test('dialog resume can skip far beyond the bounded recovery window',function()
 local route={}
 for i=1,500 do route[i]={x=i*2,y=0,z=0,speed=10,drive='FWD'} end
 bot.setRoute(route);bot.setIndex(322);carX=800;carY=0
 bot.S.dialogRejoinPending=true;bot.route.resumeAfterDialog()
 equal(bot.getIndex(),400);equal(bot.S.dialogRejoinPending,nil)
end)

test('dialog resume never rewinds the route',function()
 local route={}
 for i=1,500 do route[i]={x=i*2,y=0,z=0,speed=10,drive='FWD'} end
 bot.setRoute(route);bot.setIndex(322);carX=600;carY=0
 bot.S.dialogRejoinPending=true;bot.route.resumeAfterDialog()
 equal(bot.getIndex(),322)
end)

local function denseStraight()
 local route={}
 for i=1,200 do route[i]={x=0,y=(i-1)*0.5,z=0,speed=20,drive='FWD'} end
 return route
end

test('10 and 20 FPS advance many dense points in one frame',function()
 for _,fps in ipairs({10,20}) do
  bot.S.playbackDt=1/fps
  local index=bot.route.advanceForward(denseStraight(),1,0,5,20)
  assert(index>20 and index<40)
 end
end)

test('forward advancement does not cross recorded reverse boundary',function()
 local route=denseStraight();route[8].drive='BACK'
 equal(bot.route.advanceForward(route,1,0,0,20),7)
end)

test('forward advancement refuses far off route coordinates',function()
 equal(bot.route.advanceForward(denseStraight(),1,30,5,20),1)
end)

test('10 FPS steering releases small errors instead of chasing them',function()
 bot.config.controls.steering='bangbang';bot.S.playbackDt=0.1
 for i=1,10 do bot.turn((i%2==0 and 1 or -1),20,0,0,1);equal(bot.applied().steer,0) end
end)

test('digital direction change releases first without stale buffer delay',function()
 bot.config.controls.steering='bangbang';bot.S.playbackDt=0.1
 bot.turn(-20,20,0,0,1);local first=bot.applied().steer;assert(math.abs(first)==128)
 bot.turn(20,20,0,0,1);equal(bot.applied().steer,0)
 fakeNow=fakeNow+0.13;bot.turn(20,20,0,0,1);equal(bot.applied().steer,-first)
end)

test('low FPS looks further ahead without changing speed target',function()
 local route=denseStraight();bot.config.driving.cornerBraking=false
 bot.S.playbackDt=1/30;local x,y,speed=bot.planner.target(route,1,0,0,20)
 bot.S.playbackDt=0.1;local slowX,slowY,slowSpeed=bot.planner.target(route,1,0,0,20)
 assert(slowY>y);equal(slowX,x);equal(slowSpeed,speed)
end)

test('tolerance can be disabled for legacy buffered steering',function()
 bot.config.driving.lowFpsTolerance=false;bot.config.controls.steering='bangbang'
 equal(bot.route.advanceForward(denseStraight(),1,0,5,20),1)
 bot.route.clearTransientState();bot.turn(-20,20,0,0,1);equal(bot.applied().steer,0)
end)

test('five-point steering target remains fixed within a group',function()
 bot.config.driving.steeringPointStride=5
 local route=denseStraight()
 local x,y=bot.planner.target(route,1,0,0,20)
 local held=bot.planner.heldTarget
 local a,b=bot.planner.target(route,2,0,0.5,20)
 equal(a,x);equal(b,y);equal(bot.planner.heldTarget,held)
 bot.planner.target(route,6,0,2.5,20);assert(bot.planner.heldTarget~=held)
end)

test('ten-point setting holds longer but never aims behind the car',function()
 bot.config.driving.steeringPointStride=10
 local route=denseStraight();bot.planner.target(route,1,0,0,20)
 local held=bot.planner.heldTarget
 bot.planner.target(route,9,0,4,20);equal(bot.planner.heldTarget,held)
 bot.planner.target(route,9,0,9,20);assert(bot.planner.heldTarget~=held)
 assert(bot.planner.heldTarget.y>9)
end)

test('speed target still updates while steering target is held',function()
 bot.config.driving.steeringPointStride=5;bot.config.driving.cornerBraking=false
 local route=denseStraight();route[2].speed=7
 bot.planner.target(route,1,0,0,20);local held=bot.planner.heldTarget
 local x,y,speed=bot.planner.target(route,2,0,0.5,20)
 equal(speed,7);equal(bot.planner.heldTarget,held)
end)

test('actual route playback uses keyboard backend without writing pad values',function()
 bot.config.controls.input='keyboard'
 local previousRead=bot.Mem.readDword
 bot.Mem.readDword=function(address)
  if address==0x100000+0x21A0E8 then return 0x2000000 end
  if address==0x2000000+0x14E0 then return 0 end
  return previousRead(address)
 end
 bot.Win32.press=function(vk) bot.Win32.held[vk]=true;return true end
 bot.Win32.release=function(vk) bot.Win32.held[vk]=nil;return true end
 bot.Win32.driveHeld={}
 local route=denseStraight();bot.setRoute(route);carSpeed=10;bot.setMotion(10,0,0,0,0)
 bot.skipScans();bot.S.rotateIgnoreUntil=fakeNow+100;bot.S.freezeRecoveryGraceUntil=fakeNow+100
 writes={};bot.route.updatePlayback()
 equal(#writes,0);assert(bot.Win32.driveHeld[0x57])
 flag('freeze','1');bot.manager.sync();equal(next(bot.Win32.driveHeld),nil)
end)

flag('freeze');flag('dialog');flag('rotate')
print(string.format('%d driving/classification regression scenarios passed',total))
