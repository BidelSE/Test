-- Tick once per game frame. Never catch up missed events in a single frame.
local T={};T.__index=T
function T.new(car,now,rapid)
 return setmetatable({car=car,left=5,nextAt=now,rapid=rapid,done=0},T)
end
function T:tick(now,car,cancel)
 if cancel or car~=self.car then self.left=0;return false end
 if self.left==0 or now<self.nextAt then return false end
 self.left=self.left-1;self.done=self.done+1
 self.nextAt=now+(self.rapid and 0 or (self.done%2==1 and 2 or 3))
 return true
end
return T
