-- Execute the actual shipped script with mocked game/Windows surfaces.
-- No copied manager implementation and no GTA/SA-MP installation required.
local sourcePath = arg[1] or 'dangis_vr.lua'
local file = assert(io.open(sourcePath, 'rb'))
local source = file:read('*a'); file:close()
local testRoot = '/tmp/dangis_controls_test'
os.execute('mkdir -p ' .. testRoot)
local fakeNow = 10
os.clock = function() return fakeNow end
package.preload['lib.moonloader'] = function() return {} end
script_name = function() end
script_version = function() end
getWorkingDirectory = function() return testRoot end
PLAYER_PED = 1
local inCar = true
isCharInAnyCar = function() return inCar end
storeCarCharIsInNoSave = function() return 1 end
getCarCoordinates = function() return 0, 0, 0 end
getCarHeading = function() return 0 end
getDistanceBetweenCoords2d = function(x,y,a,b) return math.sqrt((x-a)^2+(y-b)^2) end
printStringNow = function() end
local writes, pad = {}, {}
writeMemory = function(address, size, value)
    assert(size == 2)
    writes[#writes+1] = {address=address, value=value}
    pad[address] = value
end
setGameKeyState = function(key, value)
    assert(key == 0)
    writes[#writes+1] = {steer=value}
    pad.steer = value
end
local appended = [[
return {
    manager=ControlManager, S=S, config=CONFIG, Win32=Win32, Mem=Mem, input=InputHandler,
    route=RouteFollower, recovery=RecoverySystem, loop=MainLoop,
    release=releaseControls, pedals=writeDriveControls, steering=writeSteerControls,
    state=writeSharedState, bump=startBumpRecovery, updateBump=updateBumpRecovery,
    transition=startBackToForwardTransition, freeze=startFreezeRecovery,
    rotate=handleAdminRotate, rotation=pressRotateReaction,
    setPlaying=function(value) playing=value end,
    setSamp=function(value) samp=value end,
    setRoute=function(value) current_route=value; play_index=1 end,
    setSpeed=function(value) lastDriveSpeed=value; S.forwardSpeed=value end,
    applied=function() return ControlManager.applied end,
    owner=function() return ControlManager.owner end,
    clearSharedThrottle=function() lastSharedStateWriteAt=-1 end,
    setLoopStages=function(dialog, recovery, recorder, playback)
        DialogBridge.update=dialog; RecoverySystem.updateControlThread=recovery
        RouteRecorder.recordTick=recorder; RouteFollower.updatePlayback=playback
    end,
}
]]
local bot = assert((loadstring or load)(source .. appended, '@'..sourcePath))()
bot.config.controls.input="gamepad"
local physical, dialog = false, false
isKeyDown = function() return physical end
bot.Win32.isGameForeground = function() return true end
bot.Win32.keyDown = function() return physical end
bot.Mem.readDword = function(address)
    if address == 0x100000 + 0x21A0B8 then return 0x1000000 end
    if address == 0x1000000 + 0x28 then return dialog and 1 or 0 end
end
bot.setSamp(0x100000)
local function flag(name, value)
    local path=testRoot..'/dangis_vr_'..name..'.flag'
    if value then local f=assert(io.open(path,'w')); f:write(value); f:close()
    else os.remove(path) end
end
local function reset()
    flag('freeze'); flag('dialog'); flag('rotate')
    physical, dialog, inCar = false, false, true
    bot.config.controls.brakeMode="foot"
    if bot.config.escape then bot.config.escape.enabled=false end
    bot.setPlaying(false)
    bot.route.clearTransientState()
    bot.manager.neutralize()
    bot.setPlaying(true)
    bot.setRoute({{x=0,y=0,z=0,speed=10,drive='FWD'}, {x=10,y=0,z=0,speed=10,drive='FWD'}})
    bot.setSpeed(20)
    bot.manager.sync()
    writes={}
end
local function equal(value, expected, message)
    assert(value==expected, (message or 'value')..': expected '..tostring(expected)..', got '..tostring(value))
end
local function neutral()
    equal(pad[bot.config.controls.gasAddress],0,'gas')
    equal(pad[bot.config.controls.footBrakeAddress],0,'foot brake')
    equal(pad[bot.config.controls.handbrakeAddress],0,'handbrake')
    equal(pad.steer,0,'steer')
    equal(bot.applied().reverse,false,'reverse')
end
local total=0
local function test(name, fn)
    reset(); fn(); total=total+1; print('PASS '..name)
end

test('route controls and actual brake telemetry', function()
    assert(bot.steering(-72)); assert(bot.pedals(130,40))
    equal(bot.owner(),'ROUTE'); equal(pad.steer,-128)
    equal(pad[bot.config.controls.gasAddress],130)
    equal(pad[bot.config.controls.footBrakeAddress],40)
    bot.setSpeed(0)
    assert(bot.pedals(0,150))
    equal(pad[bot.config.controls.footBrakeAddress],0)
    equal(bot.applied().brake,0)
end)

test('explicit bump ownership rejects stale route producer', function()
    assert(bot.bump(1, {{x=0,y=0,drive='FWD'},{x=10,y=0,drive='FWD'}},1,'test'))
    assert(bot.pedals(0,0,true,'BUMP')); equal(bot.owner(),'BUMP')
    equal(pad[bot.config.controls.footBrakeAddress],255)
    assert(not bot.pedals(255,0)); assert(not bot.steering(128))
    equal(pad[bot.config.controls.footBrakeAddress],255)
    equal(pad.steer,0)
end)

test('freeze preempts bump at the writer before supervisor polling', function()
    bot.S.bumpActive=true; bot.S.bumpPhase='reverse'
    assert(bot.pedals(0,0,true,'BUMP'))
    flag('freeze','1\n')
    assert(not bot.pedals(0,0,true,'BUMP'))
    equal(bot.owner(),'FREEZE'); equal(bot.S.bumpActive,false); neutral()
    assert(not bot.pedals(255,0)); assert(not bot.steering(128)); neutral()
    bot.state('BUMP_BACK')
    local f=assert(io.open(testRoot..'/dangis_vr_state.txt','r'))
    equal(f:read('*l'),'FREEZE_WAIT'); equal(f:read('*l'),'0')
    equal(f:read('*l'),'0'); equal(f:read('*l'),'0')
    f:read('*l'); equal(f:read('*l'),'0'); equal(f:read('*l'),'FREEZE'); f:close()
end)

test('freeze arriving between route steering and pedals drops entire intent', function()
    bot.steering(-128)
    flag('freeze','1\n')
    assert(not bot.pedals(240,0)); neutral()
    flag('freeze')
    assert(bot.pedals(70,0)); equal(pad.steer,0)
end)

test('latched freeze persists after flag removal and rejects rotation', function()
    bot.S.freezeTestLatched=true
    bot.S.rotateFightUntil=fakeNow+2
    assert(not bot.manager.request('ROTATE',{gas=255,steer=128}))
    equal(bot.owner(),'FREEZE'); neutral()
end)

test('live dialog preempts bump and rotation before dialog handler', function()
    bot.S.bumpActive=true
    bot.pedals(0,0,true,'BUMP')
    dialog=true
    assert(not bot.pedals(0,0,true,'BUMP')); equal(bot.owner(),'DIALOG'); neutral()
    bot.S.rotateFightUntil=fakeNow+2
    assert(not bot.manager.request('ROTATE',{gas=255})); neutral()
end)

test('fake dialog flag and dialog cooldown hold neutral', function()
    bot.pedals(255,0)
    flag('dialog','fake_arbotas\n')
    assert(not bot.pedals(255,0)); equal(bot.owner(),'DIALOG'); neutral()
    flag('dialog')
    bot.S.dialogReleaseUntil=fakeNow+1
    assert(not bot.pedals(255,0)); neutral()
end)

test('manual handoff releases once then leaves human controls alone', function()
    bot.pedals(150,0); physical=true
    assert(not bot.pedals(255,0)); equal(bot.owner(),'MANUAL'); neutral()
    local count=#writes
    pad[bot.config.controls.gasAddress]=203; pad.steer=88
    for i=1,3 do bot.manager.neutralize(); bot.steering(-128); bot.pedals(255,0) end
    equal(#writes,count); equal(pad[bot.config.controls.gasAddress],203); equal(pad.steer,88)
    physical=false
    assert(bot.pedals(60,0)); equal(pad.steer,0)
end)

test('pause beats rotation and both route and bump', function()
    bot.S.rotateFightUntil=fakeNow+2; bot.S.bumpActive=true; bot.S.manualPaused=true
    assert(not bot.manager.request('ROTATE',{gas=255})); equal(bot.owner(),'PAUSE'); neutral()
    assert(not bot.pedals(0,0,true,'BUMP')); assert(not bot.pedals(255,0)); neutral()
end)

test('rotation owns complete controls, then waits neutral', function()
    bot.S.rotateFightUntil=fakeNow+1; bot.S.rotateReleaseUntil=fakeNow+2
    -- 5.77.6 repair: pressRotateReaction is a compatibility entry point whose
    -- old forced throttle was intentionally removed (5.78 rotation recovery
    -- submits its own bounded command), so it now holds neutral; the
    -- ownership contract is checked with an explicit ROTATE request.
    bot.rotation(); equal(bot.owner(),'ROTATE'); neutral()
    assert(bot.manager.request('ROTATE',{gas=255})); equal(pad[bot.config.controls.gasAddress],255)
    assert(not bot.pedals(140,0)); equal(pad[bot.config.controls.gasAddress],255)
    fakeNow=fakeNow+1.2
    assert(not bot.manager.request('ROTATE',{gas=255})); equal(bot.owner(),'ROTATE_WAIT'); neutral()
    fakeNow=fakeNow+1
    assert(bot.pedals(80,0)); equal(bot.owner(),'ROUTE'); equal(pad.steer,0)
end)

test('reverse route then transition cannot reapply reverse', function()
    bot.pedals(0,0,true); equal(pad[bot.config.controls.footBrakeAddress],255)
    assert(bot.transition()); equal(bot.owner(),'TRANSITION'); neutral()
    assert(not bot.pedals(0,0,true)); assert(not bot.pedals(0,0,true,'BUMP')); neutral()
    fakeNow=fakeNow+1
    assert(bot.pedals(90,0)); equal(bot.owner(),'ROUTE'); equal(pad.steer,0)
end)

test('stop after playing=false releases pad then never writes while idle', function()
    bot.pedals(0,0,true); bot.steering(128)
    bot.route.stopPlayback(); equal(bot.owner(),'IDLE'); neutral()
    local count=#writes
    pad[bot.config.controls.gasAddress]=195
    bot.release('ALL_STOP'); bot.pedals(255,0); bot.steering(128)
    equal(#writes,count); equal(pad[bot.config.controls.gasAddress],195)
end)

test('F7 stop clears bump ownership and releases reverse', function()
    bot.S.bumpActive=true; bot.pedals(0,0,true,'BUMP')
    bot.route.stopAll(); equal(bot.owner(),'IDLE'); equal(bot.S.bumpActive,false); neutral()
end)

test('unload/reload cleanup releases active controls', function()
    bot.pedals(0,0,true)
    local scr={}; thisScript=function() return scr end
    onScriptTerminate(scr,false); equal(bot.owner(),'IDLE'); neutral()
end)

test('freeze test advances existing refresh states without typing', function()
    flag('freeze','1\n'); bot.config.recovery.typeRefreshInFreezeTest=false
    bot.recovery.updateControlThread(); equal(bot.owner(),'FREEZE'); neutral()
    equal(bot.S.freezeRecoveryMode,'test'); assert(bot.S.freezeTestLatched)
    fakeNow=bot.S.freezeRefreshAt+0.01
    bot.recovery.updateControlThread(); assert(bot.S.refreshSent)
    bot.recovery.updateControlThread()
    bot.state('PLAYING')
    local f=assert(io.open(testRoot..'/dangis_vr_state.txt','r'))
    equal(f:read('*l'),'FREEZE_REFRESH'); f:close()
    fakeNow=bot.S.freezeReleaseUntil+0.01
    bot.recovery.updateControlThread()
    equal(bot.S.freezeTestLatched,false); assert(bot.S.externalFreezeAck)
    assert(not bot.pedals(255,0)); neutral()
    flag('freeze'); bot.recovery.updateControlThread()
    assert(bot.pedals(65,0)); equal(bot.owner(),'ROUTE')
end)

test('leaving vehicle through actual playback path releases controls', function()
    bot.pedals(0,0,true); inCar=false
    bot.route.updatePlayback(); equal(bot.owner(),'IDLE'); neutral()
end)

test('actual playback manual override cancels bump without fighting human', function()
    bot.S.bumpActive=true; bot.S.bumpPhase='reverse'
    bot.pedals(0,0,true,'BUMP'); physical=true
    bot.route.updatePlayback(); equal(bot.owner(),'MANUAL'); equal(bot.S.bumpActive,false); neutral()
    local count=#writes
    pad[bot.config.controls.gasAddress]=201
    bot.route.updatePlayback(); equal(#writes,count); equal(pad[bot.config.controls.gasAddress],201)
end)

test('actual F6 hotkey cancels bump and holds pause neutral', function()
    VK_F2=2; VK_F10=10; VK_F11=11; VK_F6=6; VK_F7=7; VK_F9=9; VK_F3=3
    isKeyJustPressed=function(key) return key==6 end
    bot.S.bumpActive=true; bot.pedals(0,0,true,'BUMP')
    bot.input.handleHotkeys(); equal(bot.owner(),'PAUSE'); equal(bot.S.bumpActive,false); neutral()
    isKeyJustPressed=function() return false end
end)

test('legacy handbrake mode remains available and clears on owner switch', function()
    bot.config.controls.brakeMode='hand'
    assert(bot.pedals(0,110)); equal(pad[bot.config.controls.handbrakeAddress],110)
    flag('freeze','1\n'); assert(not bot.pedals(255,0)); neutral()
end)

test('single frame orders stages and gates flag created during playback', function()
    local stages={}
    bot.setLoopStages(function() stages[#stages+1]='dialog' end,
        function() stages[#stages+1]='recovery' end,
        function() stages[#stages+1]='recorder' end,
        function()
            stages[#stages+1]='playback'; flag('freeze','1\n')
            assert(not bot.pedals(0,0,true,'BUMP'))
        end)
    bot.loop.tick()
    equal(table.concat(stages,','),'dialog,recovery,recorder,playback'); neutral()
end)

flag('freeze'); flag('dialog'); flag('rotate')
print(string.format('%d ownership regression scenarios passed',total))
