-- Obstacle detection audit: a single map object in the middle of the route.
-- The same object as a whitelisted model (1238 cone) and as other models.
-- Simulated (mocked GTA); reports the closest the car's body came to it.
-- Usage: texlua development/audit_object_detection.lua [root]
local root = arg[1] or "."
package.path = "development/?.lua;" .. package.path
local Sim = require("sim_harness")
local function run(model, tag, opts)
    opts = opts or {}
    local pts = {}
    for i = 0, 299 do pts[#pts+1] = {x=0, y=i*2, z=10, speed=opts.speed or 25, heading=0, drive="FWD"} end
    local obstacles = {}
    for i, o in ipairs(opts.objects or {{x=0.3, y=170}}) do
        obstacles[i] = {x=o.x, y=o.y, r=o.r or 0.6, h=o.h or 1.0, model=model}
    end
    local sim = Sim.new({root=root, tag="objdet_" .. tag, files={{"dangis_vr.ini", Sim.read("development/user_v577/dangis_vr.ini")},
        {"dangis_paths/route1.txt", Sim.routeText(pts)}}, x=0, y=0, z=10.6, heading=0, obstacles=obstacles})
    sim.groundZ = 10
    sim.bot.loop.initialize()
    if opts.input then sim.bot.CONFIG.controls.input = opts.input end
    if opts.steering then sim.bot.CONFIG.controls.steering = opts.steering end
    sim:frame(1/30, {[0x79]=true})
    local closest, avoided = math.huge, false
    for i = 1, 30*14 do
        sim:frame(1/30)
        for _, o in ipairs(obstacles) do
            -- distance from the object's centre to the car's body (2.4 x 1.0 half extents)
            local h = math.rad(sim.car.heading)
            local fx, fy = -math.sin(h), math.cos(h)
            local dx, dy = o.x - sim.car.x, o.y - sim.car.y
            local along, side = dx*fx + dy*fy, dx*(-fy) + dy*fx
            local ex = math.max(0, math.abs(along) - 2.4)
            local ey = math.max(0, math.abs(side) - 1.0)
            closest = math.min(closest, math.sqrt(ex*ex + ey*ey) - o.r)
        end
        if sim.bot.S.bypassActive or (sim.bot.S.routeAvoidDir or 0) ~= 0 then avoided = true end
    end
    return closest, avoided
end
local cases = {
    {1238, "cone (on the 5.77 list)"},
    {1459, "road barrier (on the list)"},
    {1228, "road works barrier 1228 (not on the list)"},
    {1237, "bollard/post 1237 (not on the list)"},
    {3578, "concrete block 3578 (not on the list)"},
    {1327, "tyre 1327 (not on the list)"},
}
for _, input in ipairs({{"keyboard"}, {"gamepad", "smooth"}}) do
    print("input: " .. input[1] .. (input[2] and (" / " .. input[2]) or ""))
    for _, c in ipairs(cases) do
        local closest, avoided = run(c[1], tostring(c[1]) .. input[1], {input=input[1], steering=input[2]})
        print(string.format("  %-40s %s, closest %.2f m%s", c[2], avoided and "avoidance active" or "NOT detected     ",
            closest, closest <= 0 and "  <- DROVE INTO IT" or ""))
    end
end
