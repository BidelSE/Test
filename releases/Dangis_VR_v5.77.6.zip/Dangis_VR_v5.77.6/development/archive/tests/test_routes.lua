-- 5.78 named routes, recovery route selection and [rotation] settings.
-- Real dangis_vr.lua through development/sim_harness.lua (simulated).
package.path = "development/?.lua;" .. package.path
local Sim = require("sim_harness")
local L = require("lib.dangis_routes")
local Select = require("lib.dangis_route_select")
local INI = Sim.read("dangis_vr.ini")
local OLD_INI = Sim.read("development/reference_v5_77/dangis_vr.ini")
local DT = 1/30

local total = 0
local function test(name, fn) fn(); total = total + 1; print("PASS " .. name) end
local function equal(a, b, m) if a ~= b then error((m or "value") .. ": expected " .. tostring(b) .. ", got " .. tostring(a), 2) end end
local function line(x, y0, step, n, speed, drive)
    local pts = {}
    for i = 0, n-1 do pts[#pts+1] = {x=x, y=y0+i*step, z=10, speed=speed or 15, heading=step > 0 and 0 or 180, drive=drive or "FWD"} end
    return Sim.routeText(pts)
end
local function boot(tag, files, keep)
    local list = {{"dangis_vr.ini", INI}}
    for _, f in ipairs(files or {}) do list[#list+1] = f end
    local sim = Sim.new({root=".", tag=tag, files=list, keep=keep, x=0, y=0, z=10.6})
    sim.groundZ = 10.0
    sim.bot.loop.initialize()
    return sim
end
local function exists(path) local f = io.open(path, "r"); if f then f:close(); return true end; return false end

test("names are sanitised for safe, predictable files", function()
    equal(L.sanitize("City Loop"), "City_Loop"); equal(L.sanitize("  route-2 "), "route-2")
    assert(not L.sanitize("")); assert(not L.sanitize("../x")); assert(not L.sanitize("a/b"))
    assert(not L.sanitize("CON")); assert(not L.sanitize("routes")); assert(not L.sanitize(string.rep("a", 33)))
    assert(not L.sanitize("Žalia")); equal(L.display("City_Loop"), "City Loop")
end)

test("legacy install: route1.txt alone is found and selected; index is created", function()
    local sim = boot("legacy", {{"dangis_paths/route1.txt", line(0, 0, 2, 100)}})
    local lib = sim.bot.library
    equal(lib.selected, "route1"); equal(#lib:list(), 1); equal(lib:find("route1").points, 100)
    assert(exists(sim.work .. "/dangis_paths/routes.idx"))
    sim:frame(DT, {[0x79]=true})
    assert(sim.bot.isPlaying()); equal(sim.bot.getName(), "route1")
end)

test("legacy 5-field and 3-field route files still load; a stationary stub is never a candidate", function()
    local five, three = {}, {}
    for i = 0, 40 do five[#five+1] = string.format("{%d}:{%d}:{10}:{12}:{0}", 0, i*2) end
    for i = 0, 40 do three[#three+1] = "{1615.8}:{1849.9}:{0}" end
    local sim = boot("formats", {{"dangis_paths/route1.txt", line(0, 0, 2, 100)},
        {"dangis_paths/old5.txt", table.concat(five, "\n")}, {"dangis_paths/temp.txt", table.concat(three, "\n")}})
    local lib = sim.bot.library
    equal(lib:find("old5").points, 41); equal(lib:find("temp").points, 41)
    local names = {}
    for _, e in ipairs(lib:candidates()) do names[e.name] = true end
    assert(names.old5 and names.route1 and not names.temp, "stationary route excluded")
end)

test("independent routes: create, record, save, and all reload after a restart", function()
    local sim = boot("persist", {{"dangis_paths/route1.txt", line(0, 0, 2, 100)}})
    local p = sim.bot.settings.panel
    p.routeAction("new")
    for ch in ("City Loop"):gmatch(".") do p.edit.text = p.edit.text .. ch end
    p.commitEdit()
    equal(sim.bot.library.selected, "City_Loop"); equal(sim.bot.getName(), "City_Loop")
    -- Record it with F2 while driving the car manually.
    sim.car.v = 10
    sim:frame(DT, {[0x71]=true})
    assert(sim.bot.isRecording())
    for i = 1, 150 do sim:frame(DT) end
    sim:frame(DT, {[0x71]=true})
    assert(not sim.bot.isRecording())
    assert(exists(sim.work .. "/dangis_paths/City_Loop.txt"), "saved under its own name")
    assert(sim.bot.library:find("City_Loop").points >= 40)
    equal(sim.bot.library:find("route1").points, 100, "other recording untouched")
    -- Restart the script on the same folder.
    local again = Sim.new({root=".", tag="persist", keep=true, files={}, x=0, y=0, z=10.6})
    again.bot.loop.initialize()
    equal(again.bot.library.selected, "City_Loop", "selected starting route persists")
    assert(again.bot.library:find("route1") and again.bot.library:find("City_Loop"), "both routes available")
    again:frame(DT, {[0x79]=true})
    equal(again.bot.getName(), "City_Loop")
end)

test("selecting the starting route; selection is refused while driving", function()
    local sim = boot("select", {{"dangis_paths/route1.txt", line(0, 0, 2, 100)}, {"dangis_paths/route2.txt", line(5, 0, 2, 100)}})
    local p = sim.bot.settings.panel
    p.routeAction("select", "route2")
    equal(sim.bot.library.selected, "route2")
    sim:frame(DT, {[0x79]=true})
    equal(sim.bot.getName(), "route2")
    p.routeAction("select", "route1")
    equal(sim.bot.library.selected, "route2", "no change while playing")
    assert(p.routeStatus:find("sustabdykite"))
    sim:frame(DT, {[0x76]=true}) -- F7
    p.routeAction("select", "route1"); equal(sim.bot.library.selected, "route1")
end)

test("rename moves the file and its backup, never overwrites another route", function()
    local sim = boot("rename", {{"dangis_paths/route1.txt", line(0, 0, 2, 100)}, {"dangis_paths/route1.txt.bak", line(0, 0, 2, 50)},
        {"dangis_paths/route2.txt", line(5, 0, 2, 100)}})
    local lib = sim.bot.library
    assert(lib:rename("route1", "Main Road"))
    assert(exists(sim.work .. "/dangis_paths/Main_Road.txt") and exists(sim.work .. "/dangis_paths/Main_Road.txt.bak"))
    assert(not exists(sim.work .. "/dangis_paths/route1.txt"))
    equal(lib.selected, "Main_Road")
    local ok, err = lib:rename("Main_Road", "route2"); assert(not ok and err)
    assert(lib:rename("route2", "Route2"), "case-only rename")
    assert(exists(sim.work .. "/dangis_paths/Route2.txt"))
    local again = Sim.new({root=".", tag="rename", keep=true, files={}, x=0, y=0, z=10.6})
    again.bot.loop.initialize()
    assert(again.bot.library:find("Main_Road").points == 100)
end)

test("re-recording an existing route needs a confirmation click; the old copy stays as .bak", function()
    local sim = boot("rerecord", {{"dangis_paths/route1.txt", line(0, 0, 2, 100)}})
    local p = sim.bot.settings.panel
    p.routeAction("record")
    assert(not sim.bot.isRecording()); assert(p.routeStatus:find("dar kart"))
    sim.car.v = 10
    p.routeAction("record")
    assert(sim.bot.isRecording())
    for i = 1, 120 do sim:frame(DT) end
    sim:frame(DT, {[0x71]=true})
    assert(exists(sim.work .. "/dangis_paths/route1.txt.bak"))
end)

test("selector: reachability, unknown probes, hysteresis and leg checks", function()
    local function pts(x, y0, step, n, drive)
        local r = {}
        for i = 0, n-1 do r[#r+1] = {x=x, y=y0+i*step, z=10, drive=drive or "FWD"} end
        return r
    end
    local car = {x=0, y=100, z=10, heading=180}
    local r1, r2 = pts(0, 0, 2, 300), pts(8, 598, -2, 300)
    local entries = {{name="r1", route=r1, current=true, from=40}, {name="r2", route=r2}}
    local plan = Select.choose(entries, car, {reachable=function() return true end})
    equal(plan.name, "r2", "opposite-direction route is more convenient after a 180")
    plan = Select.choose(entries, car, {reachable=function(_, item) return item.entry.name ~= "r2" and true or false, "wall" end})
    equal(plan.name, "r1", "unreachable candidate rejected")
    local report
    plan, report = Select.choose(entries, car, {reachable=function() return nil end})
    equal(plan.name, "r1", "unknown reachability: only the active route (v5.77 behaviour)")
    assert(table.concat(report, ";"):find("r2#%d+.-rejected"))
    -- Nearly equal options: the active route wins (switch penalty).
    car.heading = 0
    plan = Select.choose(entries, car, {reachable=function() return true end})
    equal(plan.name, "r1")
    -- Abandoned-route penalty prevents ping-pong.
    car.heading = 180
    plan = Select.choose(entries, car, {reachable=function() return true end, penalties={r2=40}})
    equal(plan.name, "r1")
    -- Other routes: only forward legs with real road ahead; never a reverse leg or stub end.
    local stub = pts(8, 110, -2, 8)
    local back = pts(8, 598, -2, 300, "BACK")
    plan = Select.choose({{name="stub", route=stub}, {name="back", route=back}}, car, {reachable=function() return true end})
    equal(plan, nil)
    -- Nothing near.
    plan, report = Select.choose(entries, {x=500, y=500, z=10, heading=0}, {reachable=function() return true end})
    equal(plan, nil); assert(report[#report]:find("no recorded point"))
end)

test("selector tracking and aim stay on the chosen leg", function()
    local r = {}
    for i = 0, 99 do r[#r+1] = {x=0, y=i*2, z=10, drive="FWD"} end
    local plan = {route=r, index=10, back=false}
    local idx, cd = Select.track(plan, 3, 40)
    equal(idx, 21); assert(math.abs(cd-3) < 1e-6)
    local err = Select.aim(plan, 3, 40, 0)
    assert(err and err < 0, "target to the left of a north-facing car means turn left")
end)

test("old INI without [rotation] loads with defaults; [rotation] round-trips; bad values rejected", function()
    local sim = Sim.new({root=".", tag="ini_old", files={{"dangis_vr.ini", OLD_INI}}, x=0, y=0, z=10.6})
    sim.bot.loop.initialize()
    equal(sim.bot.settings.status, "loaded"); equal(sim.bot.CONFIG.rotation.firstFight, 0.5)
    local candidate = sim.bot.settings.parse(INI .. "")
    assert(candidate, "shipped INI parses")
    local text = sim.bot.settings.panel.serialize(candidate, sim.bot.settings.parse(INI) and select(2, sim.bot.settings.parse(INI)))
    assert(text:find("%[rotation%]") and text:find("first_fight_seconds = 0.5"))
    assert(text:find("rotation_min_turns"), "legacy keys are preserved when saving")
    local bad = INI:gsub("first_fight_seconds = 0.5", "first_fight_seconds = 9")
    assert(not sim.bot.settings.parse(bad), "out of range rejected")
    local custom = INI:gsub("repeat_fight_seconds = 3", "repeat_fight_seconds = 2")
    local parsed = sim.bot.settings.parse(custom); equal(parsed.rotation.repeatFight, 2)
    sim.bot.settings.panel.section = "rotation"
    local rows = sim.bot.settings.panel.rows()
    equal(#rows, 21, "all rotation settings shown")
    sim.bot.settings.panel.section = "chat"
    for _, key in ipairs(sim.bot.settings.panel.rows()) do assert(not key:find("rotation_"), "legacy rotation-sequence keys hidden: " .. key) end
end)

test("route manager tab renders without errors on every state", function()
    local sim = boot("render", {{"dangis_paths/route1.txt", line(0, 0, 2, 100)}})
    local p = sim.bot.settings.panel
    p.open = true; p.section = "routes"
    p.draw(); assert(p.open, "draw ok")
    p.routeAction("rename", "route1"); p.draw(); assert(p.open, "keyboard draw ok")
    -- Click keys of the on-screen keyboard with the mouse: "1", "Q", then "Gerai".
    local function click(x, y)
        sim.cursorX, sim.cursorY = x, y
        sim.physical = {}; p.draw()
        sim.physical = {[1]=true}; p.draw()
        sim.physical = {}; p.draw()
    end
    p.edit.text = ""
    click(290, 250)                 -- first key of row 1
    click(290, 250 + 32)            -- first key of row 2 (q)
    equal(p.edit.text, "1q")
    click(830, 380)                 -- Gerai
    equal(p.edit, nil)
    assert(sim.bot.library:find("1q"), "renamed through the panel")
    assert(exists(sim.work .. "/dangis_paths/1q.txt"))
    p.section = "rotation"; p.draw(); assert(p.open, "rotation tab draws")
end)
print(total .. " route library / selection / settings scenarios passed")
