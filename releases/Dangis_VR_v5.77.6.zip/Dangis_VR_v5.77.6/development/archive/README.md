# Archive (history only — not used, not run, not shipped to the game)

| Item | Why it is archived |
|---|---|
| `docs/README_5_72.md` (was the top-level `README.md`) | Describes 5.72 and files that are not in this package (`lib/dangis_avoidance.lua`). Superseded by `INSTALL.md`. |
| `docs/README_5_77_4.md`, `docs/README_5_77_5.md` | Release notes of those versions; 5.77.5 said "the update ZIP does not contain an INI" while it did. Superseded by `INSTALL.md` and `CHANGELOG.md`. |
| `docs/SKAITYTI_v5_70.md` | 5.70 install notes (Lithuanian); the file list no longer matches. |
| `docs/validation_5_77_4.txt`, `docs/validation_5_77_5.txt` | Test logs of those versions (texlua + LuaJIT, simulated). |
| `patches/*.patch` | Development diffs of 5.50–5.70, kept for reference. Not applicable to 5.77.6. |
| `run_all_tests_5_77_5.sh` | The old runner: covered 12 of 19 test files, stopped at the first failure, and its `\| tail -1` hid a failing upvalue check. Replaced by `development/run_tests.sh`. |
| `tests/test_routes.lua` | Tests a named-routes library (`lib/dangis_routes.lua`, `routes.idx`, route selection in the panel) and a `development/reference_v5_77/` folder. Neither exists in 5.77.x; it fails at `require "lib.dangis_routes"`. That feature was never part of this line; recovery-route loading that does exist is covered by `test_session_routes.lua` and `test_route_storage.lua`. |
| `tests/audit_object_detection.lua` | A one-off audit of v5.77's object detection (run it with root `development/user_v577` to see v5.77 miss the objects). It decides "detected" from v5.77's bypass state, which 5.77.5+ no longer uses for objects. Against the current script it therefore prints "NOT detected" although the objects are avoided (`test_obstacles.lua`, `test_roadworks.lua` check that). It has no assertions. |
