# Dangis VR 5.72 — minimal interface

This update restyles the settings panel and driving HUD with a charcoal
background, warm white text, thin separators and a muted sage accent. The HUD
is now 260 × 128 pixels rather than 360 × 204. Repeated driving/override banners
are removed; the HUD displays that status. Settings retain Ctrl+I and all prior
controls. F1 hides the HUD. Obstacle path drawings start hidden; F3 toggles them.
Driving, avoidance and recovery algorithms are unchanged from 5.71.

Install the included main script as below. Existing `lib/dangis_ui.lua` remains
required and supplies fonts and translations. The shared theme colours and
card drawing are overridden by the main script; no replacement UI library is
needed. The separately supplied preview renders the Lua layout with approximate
fonts, and shows the HUD and settings together for comparison. In game, opening
settings hides the HUD.

Built from your supplied 5.70 script. This is an experimental client-side
avoidance update for your test server, not a guarantee against collisions.
It has passed 59 automated LuaJIT checks, but has not been run inside GTA,
MoonLoader or VMware here. Real handling, keyboard delivery, raycasts and FPS
cost still require your tests.

## Install

1. Stop the bot and close GTA. Back up your current `dangis_vr.lua` and
   `dangis_vr.ini` outside the MoonLoader root so the backup does not also load.
2. Copy `dangis_vr.lua` from this package into `moonloader`, replacing the old
   script. Copy `lib/dangis_avoidance.lua` into `moonloader/lib`.
3. Keep your existing `lib/dangis_ui.lua`, settings, routes and other dependencies.
   The UI library is not included in this package. The new avoidance module adds
   no `samp.events`, SAMPFUNCS or ImGui dependency; it still needs working native
   MoonLoader entity/raycast APIs. This does not remove dependencies elsewhere
   in your existing setup.
4. Start GTA and check that the startup log says `Dangis VR v5.72` and that only
   one copy of the bot is running.

`tests/` is for offline validation, not a script to copy into the MoonLoader root.

## Enable the new controller

The default is **Stebėjimas** (`shadow`): the new planner shows/logs decisions,
but the previous avoidance system still drives. An existing INI value overrides
this default. Shadow mode is not a collision-protection mode or manual driving.

First inspect the planned corridor at low speed. To let it control avoidance:

1. Pause with **F6**, or stop with **F7**.
2. Open **Ctrl+I → Kliūtys**.
3. Change **Kliūčių sistemos režimas** from **Stebėjimas** to **Valdymas** (`active`).
   This row may be on the next settings page at smaller resolutions.
4. Click **Išsaugoti**. Close the panel with Ctrl+I. Resume with F6, or start with F10.

The panel remains usable during driving, but a mode switch waits for pause/stop.
Other new numeric settings apply live. Start with the defaults. Leave
**Lėto automobilio lenkimas** off for the first tests: ordinary following is
enabled, while overtaking a moving vehicle is opt-in and experimental.

## What changed

- All streamed vehicles are considered automatically, including parked cars;
  no separate list of every vehicle model is needed. Model dimensions determine
  the clearance envelope where available; otherwise a conservative estimate is
  used and reported in diagnostics.
- Configurable object-model rules identify cones, barriers and other objects.
  Collision rays also check other solid geometry and available ground.
- Displacement over elapsed game time estimates nearby vehicle velocity.
  The planner follows slower traffic and yields to detected crossing/oncoming
  conflicts. Newly seen vehicles initially have unknown velocity.
- A chosen passing side is held, checked again, and stopped if it becomes blocked.
  It is not immediately switched to the opposite side. The return corridor is
  checked before rejoining.
- The active forward route uses distance-resampled candidate paths, not every
  recorded point as a steering target. Active-mode rejoin searches do not move
  the route index backwards.
- Scans use elapsed time (default 0.25 seconds). Pauses, ownership changes,
  stale scans and changed settings invalidate the cached plan.
- The existing keyboard steering/output backend is retained. Collision-related
  slowing uses its normal braking path; this update does not turn on corner
  braking. Speed caps also respect recorded speed and visible planning distance.
- Traffic waits do not trigger ordinary stuck/bump recovery. Existing explicit
  control-lock/freeze priority remains above the avoidance controller.
- New Lithuanian settings and a planned-path overlay are included. Technical
  debug codes remain English so they can be matched to logs and tests.

Chat, command typing and rotation behaviour have not been redesigned in this
update. Recorded reverse sections retain the old controller; the new planner
only controls forward driving.

## INI reference

Using the panel and saving adds the new sections automatically. Alternatively,
merge these values into the existing INI; do not replace the whole INI or create
duplicate sections/keys. F12 reloads it while paused/stopped.

```ini
[obstacle]
mode = shadow
overtake = false
scan_seconds = 0.25
scan_radius = 60
margin = 0.5
max_offset = 5
prediction_seconds = 3
headway_seconds = 1.8
pass_speed_mps = 8
commit_seconds = 1.5
clear_seconds = 0.8
braking_deceleration = 4.5

[obstacle_models]
model_1238 = true
model_1459 = true
model_1423 = true
model_19951 = true
model_19952 = true
model_19974 = true
model_19961 = true
model_19960 = true
```

Object entries use **model IDs**, not changing instance handles. Add
`model_YOUR_ID = true` with the numeric ID from your object inspection script.
Setting an entry to false removes its model-specific tracking; it does not
make a physically solid object disappear from collision rays. These rules are
edited in the INI, not through a new model-list editor in the panel.

`pass_speed_mps = 8` means approximately 29 km/h. `max_offset` is a maximum
lateral deviation in metres, not permission to use another lane. Increasing
it can let the planner consider sidewalks or shoulders; there is no road-rule
or lane-recognition system. `braking_deceleration` is an estimate, not measured
handling data for your car. A longer scan interval reduces scan frequency but
also delays responses. Do not increase speed for the first tests.

## Live test checklist

Use a controlled area, start around 20 km/h, and keep F7 available.

| Test | Expected result in active mode |
| --- | --- |
| Clear route | Normal progress, no false traffic stop |
| Parked car; one side open | One checked detour, then forward rejoin |
| Cone/barrier; wall beside it | Blocked side rejected |
| Both sides blocked | Stop and wait, not repeated reversing |
| Slower car | Follow with a gap while overtaking is disabled |
| Crossing/oncoming traffic | Yield when the predicted paths conflict |
| New car enters the chosen passing side | Slow/stop instead of an immediate side flip |
| Obstacle moves away | Fresh scan permits continuing |
| Open chat, coast, then close it | Recheck the corridor before route control resumes |
| Pause/stop during a detour | Controls released; no stale detour on resume |
| Repeat at 60, 20 and 10 FPS | No frame-count-dependent scan rate or side-flip loop |
| Reverse route segment | Previous reverse behaviour, no new forward detour |

After these, optionally enable moving-vehicle overtaking in a wide controlled
area. Test opposing vehicles on both sides. Do not assume that a geometrically
clear side is a legal or physically safe lane.

Send `moonloader.log`, the `[AVOID]` entries from `dangis_vr_debug.log`, your
current INI, vehicle model, FPS and a short clip with the path overlay if anything
goes wrong. Useful log fields include `state`, `reason`, `model`, `entities`,
`cap`, `offset`, `rays` (checked path segments, not individual native calls),
and `estimated` (nearby envelopes using fallback dimensions).

If it stops on a clear road, inspect the reason rather than disabling the stop:
`sensor_incomplete`, `ego_unavailable`, `forward_speed_unavailable`,
`module_missing` and `planner_error` indicate missing or unreliable input.
`both_sides_blocked` can also mean geometry/ground checks could not validate a
route. If signed speed is unavailable, the existing keyboard backend cannot
reliably distinguish braking from reversing; the new mode releases throttle
instead of assuming it can stop the car.

## Limits and rollback

Only streamed/loaded entities are visible. Prediction assumes short-term
constant velocity; teleports, abrupt turns, streaming delay and lag can invalidate
it. Model boxes and sampled rays are approximations, not full collision meshes
or a physics simulation. Pedestrians are checked through rays, not tracked as
moving vehicles. Scan work is bounded; incomplete observations request a stop.
Physical stopping distance, traction and detour tracking must be measured in-game.
Nothing in these tests establishes collision-free driving or VMware performance.

For quick comparison, pause and switch back to **Stebėjimas** to retain the old
avoidance controller (new diagnostic scanning still runs). To remove the update,
close GTA and restore both backed-up `dangis_vr.lua` and `dangis_vr.ini`: older
versions reject the new INI keys. The unused new module can remain in `lib`.

## Automated checks

`tests/test_avoidance.lua` runs 59 planner, adapter, settings and mocked-control
integration tests. It checks 10/20/60 FPS timing, sensor failures, lane commitment,
traffic-stop/recovery interaction, control ownership, and INI round trips.
The maximum reachable function upvalue count checked is 51, below MoonLoader's
reported limit of 60. This is not a live MoonLoader validation.

From this package directory, use a LuaJIT interpreter:

```sh
luajit tests/test_avoidance.lua
```

Or with Python and the `lupa` package installed:

```sh
python3 -c "from lupa.luajit21 import LuaRuntime; LuaRuntime().execute(\"dofile('tests/test_avoidance.lua')\")"
```

Native API signatures were checked against THE-FYP's MoonLoader reference:
https://gist.github.com/THE-FYP/abc6f8bea87f4cb42331fc6dd7a84576/cfa3f0def430ce4cac72d745f1f104f2f2680c36
