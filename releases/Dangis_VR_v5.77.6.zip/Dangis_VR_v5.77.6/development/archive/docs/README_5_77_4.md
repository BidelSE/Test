# Dangis VR 5.77.4: your 5.77 plus apsukimas (rotation) recovery and stronger obstacle avoidance

This build is your own 5.77, exactly as you sent it, with the rotation
(apsukimas) recovery added and, since 5.77.4, the obstacle avoidance fixed.
With nothing in the car's way, everything works exactly as in your 5.77:

* route following, steering, speed and braking
* bump recovery, freeze and /refresh
* dialogs, pause (F6), stop (F7), F2 recording, F10 and F11
* chat replies, your settings and your route files

Only when an object stands in the path does 5.77.4 drive differently: it
now really goes round it. `[driving] avoid_all_objects = false` (or the
Važiavimas tab in Ctrl+I) gives back the exact 5.77 obstacle behaviour.

## Changes in 5.77.4 (your report: objects on the track are driven over)

The simulator reproduced it, with two separate faults in 5.77's obstacle
avoidance:

1. **Only 8 object models counted as obstacles.**
   * Those are the cone (1238), two road barriers (1459, 1423) and five SA-MP
     road sign models.
   * Every other object the scan hit was thrown away: concrete blocks,
     bollards, tyres, other barriers, crates and so on.
   * Objects lower than about 1 m were also missed, because all scan rays
     were above them.
2. **Even a detected cone did not move the car.**
   * The avoidance worked out a side step of about 2.8 m, but applied it to
     the steering point 18–25 m ahead. That is only about 7° of steering
     error.
   * With your `lateral_tolerance = 3`, keyboard steering reacts only from
     10° upwards, so the car went straight on through the object.

What 5.77.4 does:

* **Any map object whose face stands up in the path is an obstacle**,
  whatever its model. Ramps and road pieces face upwards and are still
  driven over.
* **A lower scan band** (about 0.35 m above the road) finds low objects.
* **The side step is steered from a point 5–10 m ahead**, so it really moves
  the car.
* **It aims for an offset that clears every object found ahead**, not only
  the first one, with about a metre to spare. That covers rows, slaloms and
  clusters.
* **After the objects it steers back onto the route line for 5 s.** Then
  your normal 5.77 steering takes over.

Simulator results (keyboard, your INI, objects that 5.77 ignored):

* **Scenarios:** a block in the lane, a low tyre stack, three blocks across
  half the road, a left/right/left slalom 35 m apart, and five bollards in
  a cluster, each at 15, 25 and 35 m/s.
* **Results:** all are passed. The closest was 0.3 m (the bollard
  cluster at 15 m/s); most passes keep 0.8–3 m. The car comes back to the
  route afterwards. A row of bollards along the roadside does not
  make it swerve.
* **Your own route1 with parked cars:** 5.77 drives through them, while
  5.77.4 passes them with 1.5–3 m to spare.
* **How far it moves aside:** at high speed it may move up to about 5 m to
  the side of the route while going round.
* **Normal driving is unchanged:** every identity scenario with nothing in
  the way is still frame-for-frame identical to your 5.77.

Still not seen as obstacles (as in 5.77): people, and buildings or walls,
since the route itself avoids those. If an object on your track is still
driven over, send me its model number and where it is.


## Changes in 5.77.3 (from your second in-game test, 27 Oct 22:29)

* **The reverse spin was still refused in the game.**
  * Your log: at 42 m/s "no room for a reverse spin"; at 24 m/s "reverse
    spin check incomplete". Each time it then braked and turned in moves,
    taking 10–12 s.
  * Cause: before the spin, the bot checked the whole slide (up to 70 m of
    road, 15 m wide). A real roadside always has something in an area that
    size, or the check could not finish before the car had slid on.
  * Now: a fast car slides along the road whether the bot brakes or spins,
    so only the part where the body swings round is checked first (about
    the next 0.3 s of sliding, at full width). The rest is watched while it
    spins.
  * Also fixed: when one side was refused, its check kept restarting and
    starved the check for the other side.
  * Now: a "no room" log line says **what** was in the way and where, for
    example `no room for a reverse spin: object 12 m behind, 6 m right`.
    If it still refuses on your road, send that line and I can tune it to
    what is really there.
* Simulator results:
  * Open road at 10–38 m/s: reverse spin, back on the route in 2.5–4 s.
  * Street with walls 8.5 m from the route on each side: the spin's
    sideways drift does not fit. It brakes and turns round in 7–10 s,
    never closer than 1 m to a wall.
* Driving is still identical to your 5.77 (17 identity checks).

## Changes in 5.77.2 (from your first in-game test, 27 Oct)

* **The reverse spin was cancelled in the first frame.**
  * Cause: 5.77's player-input check briefly reads a key the bot has just
    let go of as your key. That is the OVERRIDE flicker in your log
    (`ROTATE -> MANUAL` 1–2 ms after the turn).
  * Effect: the rotation took that as you taking over, gave up the spin and
    braked instead. Both your tests went `JTURN_CHECK -> HOLD`.
  * Now: a takeover shorter than 0.2 s only pauses the manoeuvre for that
    frame. Turn detection ignores flickers the same way. Holding a key
    longer still hands control to you at once.
  * The simulator reproduced your exact sequence
    (`HOLD > UTURN_CHECK > UTURN > SETTLE`). It now reverse-spins and is back
    on the route in under 6 s.
  * The 5.77 check itself is unchanged.
* **"Kelias užblokuotas" forever after spinning off the road** (your second
  test).
  * Cause: driving back was refused whenever anything was beside the car's
    body, such as the wall next to it. It then retried the same thing every
    2 s.
  * Now: only the path ahead of the car blocks driving back.
  * If that path really is blocked, it heads for the route point whose
    straight line was checked as free, turning first with short
    reverse/forward moves. It no longer repeats the blocked attempt.
* **test_rotate.lua 1.3: Ctrl+9 turns the tool ON/OFF.** It starts OFF, and
  the setting is remembered.
* Driving, chat and everything else are still identical to your 5.77 (the
  same 17 identity checks pass).

## Install

1. Copy everything from the ZIP into your `moonloader` folder and let it
   replace the old files:
   * `dangis_vr.lua`
   * `lib/dangis_rotation.lua`, `lib/dangis_probe.lua`,
     `lib/dangis_route_select.lua`, `lib/dangis_ui.lua`
   * `dangis_rotation_phrases.txt`
   * `test_rotate.lua` (optional test tool; **Ctrl+9 switches it ON/OFF**,
     it starts OFF and remembers the setting in `test_rotate.cfg`)
2. **Keep your own `dangis_vr.ini`.** The ZIP does not contain one.
   * Your 5.77 INI has `[driving] enabled = false`, `lookahead_seconds = 0.75`,
     `lateral_tolerance = 3` and `max_speed_kmh = 250`, and that is the
     driving you know.
   * The 5.78 packages r1 to r4 contained a `dangis_vr.ini` with the driving
     planner switched on (`enabled = true`, 0.35, 2.5, 0). If you unpacked
     one of those over your folder, that INI changed how the car drove. Put
     your own INI back if that happened.
3. `arbotas_auto.lua`, `lib/dangis_accessories.lua`,
   `dangis_admin_phrases.txt` and your `dangis_paths` are not in the ZIP.
   Keep yours; nothing in them changed.
4. Files left over from a 5.78 install, such as `lib/dangis_routes.lua` or
   `dangis_paths/routes.idx`, are not used and can stay or be deleted.

Ctrl+R or a game restart loads the new script.

## What the rotation recovery does

1. When the car is turned around (140 degrees or more within 0.25 s), the bot
   takes over at once.
2. It reverses with full lock (S held at 100%, A or D held) so the nose
   swings round.
3. It then drives forward with W and hands back to your v5.77 driving at the
   right route point.
4. If there is no room to spin, it brakes, steadies the car and turns round
   another way: a one-sweep U-turn, reverse-then-swing, or short moves.
   Walls and cars are checked first, so it never reverses into something it
   can see.
5. A second turn within 10 s counts as the same incident. Three or more turns
   in 10 s: it pulls over, waits for things to calm down, then carries on.
6. One chat reaction per incident level, taken from
   `dangis_rotation_phrases.txt`.
   * It is typed only after the car is back on the route, and only on a
     straight stretch or while (nearly) stopped.
   * It is cancelled with Esc if the car drifts while typing.
   * All other chat replies are typed exactly as in 5.77.

**At your speeds:** route1 is recorded at up to about 150 km/h (41 m/s). Before
5.77.3, a car spun at that speed could never finish the check for the
reverse spin, so it always braked for about 4 s and then turned round in
moves, which took 8 to 10 s. That check now finishes within a few frames.
In the simulation, a car spun at 38–43 m/s on an open road reverse-spins and
is back on the route after 4–5 s. In a narrow street (walls 6 m to each
side) there is no room for the spin: it still brakes and turns in moves,
which takes 9 to 12 s.

The settings panel (Ctrl+I) has a new **Apsukimas** tab. Your INI does not
need a `[rotation]` section; defaults apply until you save from the panel.

## Other routes after a rotation

* When playback starts, the bot reads the other routes in `dangis_paths`, but
  only as places to return to after a rotation. It never writes to that
  folder.
* Files that are skipped:
  * backups (`.bak`)
  * old three-field files without heights, such as `temp.txt`
  * routes shorter than 10 points or 30 m
* After a 180 it may continue on a nearby recorded route that goes the right
  way, if that is clearly the better way back. A route behind a wall is
  rejected.
* The switch lasts only for that playback. When playback ends (F10, F7, end
  of the route, leaving the car), the route you started is restored. F2
  records under that route's name, as in 5.77.
* `route_switching = false` in `[rotation]` turns this off.

## [rotation] settings (all optional)

| key | default | meaning |
|---|---|---|
| `reverse_spin_enabled` | true | turn round by reversing with lock (S, no W first) |
| `uturn_enabled` | true | one-sweep forward U-turn when there is room |
| `reverse_power` / `forward_power` | 100 | % of the time S / W is held during the turn |
| `incident_window_seconds` | 10 | turns within this window form one incident |
| `multi_turns` | 3 | turns in the window that make it pull over |
| `park_enabled` / `park_quiet_seconds` | true / 8 | pull over and wait |
| `search_distance` / `connect_distance` | 28 / 10 | how far it looks for a route / when it hands back |
| `route_switching` / `switch_penalty` | true / 12 | other routes as targets / how much better they must be |
| `chat_enabled` / `chat_cooldown_seconds` / `second_message_chance` | true / 25 / 25 | reactions |
| `first_fight_seconds`, `repeat_fight_seconds`, `multi_resist_seconds` | 0.5, 3, 0.6 | W-reaction mode only (`reverse_spin_enabled = false`) |
| `stabilize_seconds`, `retry_wait_max_seconds`, `probe_rays_per_frame` | 0.3, 8, 100 | advanced |

## How "unchanged" was checked (simulation, not in-game)

The test `development/test_driving_identity.lua` runs **your 5.77**
(`development/user_v577`, with your INI) and 5.77.4 side by side in the same
simulated game. Every scenario runs with `avoid_all_objects = false`, and
every scenario with nothing in the car's way also runs with the default.
In all 31 runs every frame was identical: gas, brake, steering, every key
press and release, control owner, route index and the car's path. The
scenarios were:

* route1 at 30, 60 and a varying 18–45 FPS
* parked cars, and a wall at the roadside
* a second saved route next to route1
* the car stuck (bump recovery)
* an SA-MP dialog, the test-freeze flag, and an /arbotas chat reply
* F6 pause and resume, the route end, and a recorded reverse section
* gamepad input, the planner switched on, and no collision API

At source level, 206 of the 228 functions in your 5.77 are byte-identical.
The other 22 are:

* the rotation functions
* settings and HUD registration for the new tab
* three chat functions, which only gained the rotation reaction path
* the obstacle scan and the playback step: the 5.77.4 obstacle fix, which
  only acts when something is in the way

Your own 5.77 tests give the same results on both versions. Rotation is
covered by 51 integration scenarios, 52 state-machine scenarios, 16 probe
scenarios, 22 audit scenarios and 6 route/session scenarios. They run on
both texlua and LuaJIT. Obstacle avoidance has 17 scenarios of its own
(`development/test_obstacles.lua`).

**None of this was tested in the game.** Please try `test_rotate.lua`
(Ctrl+9 to switch it on, then Ctrl+1 / Ctrl+2 / Ctrl+3) and check `test_rotate.log` and
`dangis_vr_debug.log`.

## Left exactly as in 5.77 (from the audit; tell me if you want any changed)

* **Phantom OVERRIDE:** the bot can read a key it has just released as your
  input for one frame.
* **F6 also opens the SA-MP chat:** after F6 to resume, press Esc.
* **F2:** two quick presses replace the route; the old one stays in `.bak`.
* **/refresh:** it is typed without checking that the chat really opened.
* **`arbotas_auto.lua`** also answers other list dialogs that have exactly
  one blank row.
