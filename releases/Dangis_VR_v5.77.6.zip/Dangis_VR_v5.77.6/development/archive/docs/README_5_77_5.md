# Dangis VR 5.77.5: road works driven like in your first video

This is 5.77.4 with the obstacle avoidance redone after your two videos
("what I want it to do / what it actually does"). Driving with nothing in
the car's way is still exactly your 5.77 (see the end of this file).

## What your second video showed

The bot's own debug box in the video, when the cones come into view:

    KLIUTIS O1238 32m DESINE
    SONAS u0.00 clr 1.4 n5
    APVAZIAVIMAS -3.0m laukti 4.6s

* `O1238` is the cone model. The bot saw the cones 32 m ahead and started
  5.77's **bypass**: a fixed side step of 2.2–3.25 m, held for a few
  seconds, then let go again ("laukti 4.6s").
* 5.77.4 then steered that step from a point 5–10 m ahead. With keyboard
  steering at 130 km/h that is a hard swing to the right, back to the left
  when the hold ran out, and so on. That is the weaving in your video, and
  it brought the car closer to the cones than it would have been without
  any avoidance.
* 5.77's obstacle reaction also lifts the throttle when an object is
  close. Your bot drove through the road works at 125–138 km/h, you drove
  at 151–163 km/h (part of that difference was there before the road
  works, see "About the speed" below).

The simulator gives the same picture. The same place (cones 2.6 m left of
the route, barriers and a sign beyond them) with 5.77.4 and `getAllObjects`
as in your game: at 130 km/h up to 43° of heading swing, 10 m off the
route, speed down from 34 to 19 m/s, and a cone touched; at 72 km/h 16
swings from side to side through the road works.

## What 5.77.5 does instead

Objects (cones, barriers, signs, blocks, any object) and stopped vehicles
are handled by one new part, `ObstacleAvoidance.lane`:

1. **Every object found is remembered at its place along the route**, with
   its width across the road. With `getAllObjects` (your MoonLoader has it)
   cones, barriers and signs are taken at their exact place and size, the
   rays only add what is not in that list.
2. **If the route line is clear, nothing happens.** "Clear" means the car's
   body passes at least 0.9 m from every object. Cones beside your lane, as
   in your video, are not touched: the car drives exactly as 5.77 would
   without any objects, at full speed. That is your first video.
3. **If the line is blocked, it picks the smallest side offset that clears
   everything** from just behind the car to about 2.4 s ahead (≈ 85 m at
   130 km/h), preferring the side it is already on. A row of cones or a
   lane closed by a taper is one move, not one move per cone.
4. **It moves over gradually**, finishing before the first object, at most
   3.5 m/s sideways (a smooth lane change at speed), and **holds the offset
   until the last object has passed the rear of the car**. Then it goes
   back to the route line and hands back to 5.77's steering once the car is
   on the line and straight.
5. **No braking or throttle lift for objects.** It slows down only when it
   cannot get round at that speed: no way through, objects on alternate
   sides too close together to cross between them, or the car not where it
   should be next to an object (seen in bends). Then just as much as
   needed.
6. If the car itself (not the route line) is heading into an object, for
   example after drifting wide in a bend, it is steered back onto the line.
7. Objects that move (attached to your car or another one by the server,
   or being pushed) are not obstacles until they have stood still for 2 s.

While `avoid_all_objects` is on (the default), 5.77's own bypass and
obstacle reaction are no longer used; `avoid_all_objects = false` still
gives the exact 5.77 obstacle behaviour.

The obstacle debug box (the one in your video; F3 until "Kliuciu debug
PILNAS") shows `OBJEKTAI 1.2m -> 2.0m` while it is working: the side offset now and the one it is going to (+ = left).
`dangis_vr_debug.log` gets one `OBSTACLE` line when it starts, one per
change of side, and one when it hands back.

## Simulator results (keyboard, your INI, 72 and 130 km/h, straight and a long bend)

`development/test_roadworks.lua`: 7 kinds of road works at 72 and 130
km/h, straight and in a 250 m radius bend, plus objects attached to the
car (which must change nothing): 29 cases, run with and without
`getAllObjects`. All pass.

At 130 km/h (36 m/s) on the straight, with `getAllObjects`:

| road works | closest to an object | furthest aside | heading swings | lowest speed (none: 34.0 m/s) |
|---|---|---|---|---|
| your place: cones 2.6 m left, barriers, sign | 1.35 m | 0.0 m (identical to no objects) | 0 | 34.0 |
| cones 2.6 m right | 1.35 m | 0.0 m (identical) | 0 | 34.0 |
| taper closing the lane, 90 m closed | 1.51 m | 3.2 m | 1 | 34.0 |
| cones 1.55 m left (would pass 0.3 m from the body) | 1.52 m | 1.2 m | 1 | 34.0 |
| one cone on the route line | 1.05 m | 2.1 m | 1 | 34.0 |
| parked cars 1.6 m left/right/left, 60 m apart | 1.22 m | 2.2 m | 3 | 26.5 |
| cones 1 m left/right/left, 40 m apart | 1.15 m | 3.6 m | 1 | 27.0 |

With 5.77.4, 22 of the 29 cases fail (weaving in almost all of them,
contact in 6). With 5.77's own handling (`avoid_all_objects = false`) the
car drives straight past the cones beside the lane, but it
does not get round anything that is in the lane: on the straight road 8 of
the 14 cases end in contact (the taper, the cone on the line, the parked
cars and the cone slalom, at both speeds).

* **72 km/h, straight:** all the same cases pass at full speed, the
  alternating ones too.
* **In a 250 m bend:** v5.77's keyboard steering itself runs 3–4 m off the
  line there in the simulator, so cones 2.6 m beside the line are in the
  car's way and it goes round them. No contact in any case (closest
  0.6 m). Where the car cannot follow the side offset closely enough it
  slows down: in the alternating cases and the taper at 130 km/h down to
  6–25 m/s, at 72 km/h down to 9 m/s.
* **Without `getAllObjects` (rays only) and without `getModelDimensions`**:
  the same cases pass.

**None of this was tested in the game.** The simulator's keyboard steering
is coarser than GTA's (each tap turns the car about 3.6°), so in the game
the moves should be smoother, not rougher. Please drive the road works
again with the debug box on and, if anything looks wrong, send a video and
the `OBSTACLE` lines from `dangis_vr_debug.log`.

## About the speed in your videos

The bot was also slower before the road works (it accelerated from 0 more
slowly). That part is 5.77's normal speed control and is unchanged: it
follows the speeds recorded in the route, and every 20–60 s it lifts the
throttle for 0.6–1.5 s on purpose (the "gas lift" that makes it look
human; those are also orange exhaust flames). If you want it to go
through faster, record that part of the route again at the speed you want.

## Install

Same as 5.77.4: copy the ZIP into `moonloader` and replace. Keep your own
`dangis_vr.ini` (the update ZIP does not contain one).

## How "unchanged" was checked (simulation, not in-game)

`development/test_driving_identity.lua` runs **your 5.77**
(`development/user_v577`, with your INI) and 5.77.5 side by side in the
same simulated game: route1 at 30, 60 and 18–45 FPS, parked cars, a wall,
a second route, bump recovery, a dialog, the freeze flag, an /arbotas
reply, F6, the route end, a reverse section, gamepad, the planner switched
on and no collision API. Every scenario runs with `avoid_all_objects =
false`, and every one with nothing in the car's way also with the
default. In all 31 runs every frame was identical (gas, brake,
steering, every key, control owner, route index, the car's path).

In the road-works test the cases where nothing is in the car's way are
also compared frame by frame with the same drive without objects, at 72
and 130 km/h: identical.

Only `dangis_vr.lua` changed since 5.77.4 (the `lib` files, `test_rotate.lua`
and the phrases are the same). At source level 202 of the 228 functions in your
5.77 are byte-identical. The 26 changed ones are the rotation, settings,
HUD and chat functions from before, plus, for the object handling: the
obstacle scan, the playback step, the obstacle debug box, and three small
obstacle functions that now leave objects to the new part. The new part
itself is the `ObstacleAvoidance.lane*` functions; it only acts when
something is in the way.

All the other tests (rotation, probes, audit, routes, obstacles,
accessories, rejoin, telemetry) pass on texlua and LuaJIT; the list is in
`development/validation_5_77_5.txt`.
