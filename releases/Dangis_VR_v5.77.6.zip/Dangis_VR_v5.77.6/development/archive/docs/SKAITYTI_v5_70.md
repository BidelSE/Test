# Dangis VR 5.70

Atnaujinta lietuviška sąsaja: tamsus būsenos skydelis, aiškesnis šriftas, maršruto eigos juosta, pranešimų kortelės ir nustatymai su atskiromis skiltimis. Matomos būsenos ir nustatymų pavadinimai išversti į lietuvių kalbą. Techniniai žurnalai, nustatymų failo raktai ir serverio komandos palikti suderinami su ankstesnėmis versijomis.

## Įdiegimas

1. Uždarykite GTA.
2. Pakeiskite moonloader aplanke: dangis_vr.lua, arbotas_auto.lua, hud_aswd.lua, test_freeze.lua, test_rotate.lua, testdialog.lua ir testdialogspy.lua.
3. Nukopijuokite **lib/dangis_ui.lua** į **moonloader/lib/dangis_ui.lua**. Šis naujas failas būtinas; vien pagrindinio failo nepakanka.
4. Išsaugokite savo dangis_vr.ini, frazių failą ir maršrutus. Jų perrašyti nereikia.
5. Paleiskite žaidimą iš naujo.

## Valdymas

- Ctrl + I: atidaryti arba uždaryti nustatymus.
- F1: rodyti arba paslėpti būsenos skydelį.
- F10: pradėti važiuoti; F6: pristabdyti; F7: sustabdyti.
- F2: maršruto įrašymas; F11: kartojimas.
- Nustatymuose spauskite skilčių pavadinimus ir + / - mygtukus. Rodyklės apačioje keičia puslapį.
- „Išsaugoti“ įrašo nustatymus; „Atkurti puslapį“ grąžina tik matomo puslapio numatytąsias reikšmes.

Važiavimo reikšmės taikomos iškart. Žvaigždutė žymi dar laukiančius pakeitimus. Valdymo būdo keitimui reikalinga pauzė arba sustabdymas. Pokalbio ir atkūrimo pakeitimai laukia aktyvių veiksmų pabaigos. Patikrinimo metu nustatymų langas automatiškai uždaromas.

## Patikrinimas žaidime

Patikrinkite, ar taisyklingai matote žodžius „Važiavimas“, „Žinutės“, „Išsaugoti“. Naudojamas Windows šriftas Segoe UI ir Baltijos šalių simbolių rinkinys. Jei VMware rodo netinkamas raides, atsiųskite ekrano nuotrauką. Atsarginis variantas: lib/dangis_ui.lua pirmoje lentelėje pakeiskite ascii=false į ascii=true ir paleiskite žaidimą iš naujo; tekstas liks lietuviškas, tik be diakritinių ženklų.

209 ankstesni automatizuoti scenarijai sėkmingi; papildomai patikrinti visų nustatymų vertimai, 18 lietuviškų raidžių kodavimas ir 18 lango išdėstymų trijose raiškose. Sintaksė ir MoonLoader kintamųjų riba patikrintos. Tikras šriftų ir pelės veikimas VMware dar turi būti patikrintas žaidime. Važiavimo bei užšaldymo algoritmai šiame atnaujinime nekeisti.
