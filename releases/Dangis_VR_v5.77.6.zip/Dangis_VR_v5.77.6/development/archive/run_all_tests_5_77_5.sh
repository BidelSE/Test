#!/bin/sh
# Runs every 5.77.5 test with texlua and (if given) LuaJIT. From the moonloader folder:
#   sh development/run_all_tests.sh [path-to-luajit]
for lua in texlua ${1:-}; do
  for t in test_driving_identity test_rotation test_rotation_modern test_probe test_audit_r4 test_session_routes test_rotate_tool test_obstacles test_roadworks test_accessories test_recovery_rejoin test_telemetry; do
    echo "\$ $lua development/$t.lua"
    out=$($lua development/$t.lua 2>&1) || { echo "$out" | tail -8; echo "FAILED"; exit 1; }
    echo "$out" | tail -1
  done
  # the road works again with the objects also listed by getAllObjects (as in your MoonLoader)
  echo "\$ RW_POOL=1 $lua development/test_roadworks.lua"
  out=$(RW_POOL=1 $lua development/test_roadworks.lua 2>&1) || { echo "$out" | tail -8; echo "FAILED"; exit 1; }
  echo "$out" | tail -1
done
python3 development/check_moonloader_upvalues.py dangis_vr.lua | tail -1
rm -f texluac.out
