-- Module-level tests for lib/dangis_rotation.lua (5.78 incident state machine).
-- Pure state machine: no game, no script; a tiny kinematic model stands in for
-- the car where motion matters. Runs under texlua and LuaJIT.
local R=require 'lib.dangis_rotation'
local Sequence=require 'lib.dangis_rotation_test_sequence'
-- The W-reaction mode (rotation.reverse_spin_enabled = false) is still a
-- setting, and the tests written for it run in that mode. The reverse spin
-- (the default since r4) has its own tests at the end of this file.
local RNew=R.new
R.new=function(o)
 o=o or {}
 local c={};for k,v in pairs(o) do c[k]=v end
 if c.jturnEnabled==nil then c.jturnEnabled=false end
 return RNew(c)
end
local function spinR(o) o=o or {};o.jturnEnabled=true;return R.new(o) end
local total=0
local function test(name,fn) fn();total=total+1;print('PASS '..name) end
local function equal(a,b,m) if a~=b then error((m or 'value')..': expected '..tostring(b)..', got '..tostring(a),2) end end
local function sample(o)
 local s={allowed=true,owner='ROTATE',speed=0,x=0,y=0,heading=0,clear=true,
  reverseClearFor={[128]=true,[-128]=true},forwardSpeed=0,slip=0,chatPending=false}
 for k,v in pairs(o or {}) do s[k]=v end
 if s.reverseClear==nil and s.reverseClearFor then s.reverseClear=true end
 return s
end
local function zero(c) assert(c.gas==0 and c.brake==0 and c.steer==0 and not c.reverse,'command must be neutral') end
local function exclusive(c)
 assert(not (c.gas>0 and (c.reverse or c.brake>0)),'W together with S')
 assert(c.steer==0 or c.steer==128 or c.steer==-128,'digital steering only')
end

-- Drive the machine through FIGHT and HOLD with a stopped car; returns signal.
local function settle(r,t,dt,h)
 for i=1,400 do
  t=t+dt;r:observe(t,1,h,false,true)
  local c,signal=r:step(t,sample({heading=h}),nil)
  exclusive(c)
  if signal=='uturn' then r:setUturn(t,nil) signal=nil end -- no room: normal flow
  if signal then return t,signal,c end
 end
 error('never stabilised')
end

for _,fps in ipairs({10,20,60}) do
 test('first turn: W is bounded to 0.5 s with no steering at '..fps..' FPS',function()
  local r=R.new();local dt=1/fps;local t=0
  r:observe(t,1,0,false,true)
  t=t+dt;assert(r:observe(t,1,180,false,true));equal(r.phase,'FIGHT');equal(r.level,'single')
  local w=0
  for i=1,fps*3 do
   local before=r.phase
   local c,sig=r:step(t,sample({heading=180,forwardSpeed=-1,speed=1}),nil)
   if sig=='uturn' then r:setUturn(t,nil) end
   exclusive(c);assert(not c.reverse)
   if before=='FIGHT' then equal(c.steer,0,'no steering during the reaction') end
   -- W of the reaction itself (later W only brakes the backwards crawl).
   if c.gas>0 and before=='FIGHT' then w=w+dt end
   t=t+dt;r:observe(t,1,180,false,true)
  end
  assert(w<=0.5+dt+1e-9 and w>=0.5-2*dt,'W time '..w)
  assert(r.phase~='FIGHT','reaction ended')
 end)
end

test('two turns: the W budget is 3 s for the whole incident, not per turn',function()
 for _,second in ipairs({0.3,1.0,2.5}) do
  local r=R.new();local dt=1/30;local t=0;local h=0
  r:observe(t,1,h,false,true)
  t=t+dt;h=180;assert(r:observe(t,1,h,false,true))
  local w=0;local turned=false
  for i=1,30*10 do
   local c=r:step(t,sample({heading=h}),nil)
   exclusive(c);equal(c.steer,0)
   if c.gas>0 then w=w+dt end
   t=t+dt
   if not turned and t>=second then h=0;assert(r:observe(t,1,h,false,true));turned=true;equal(r.level,'double')
   else r:observe(t,1,h,false,true) end
  end
  assert(w<=3.0+dt+1e-9 and w>=3.0-2*dt,'second turn at '..second..': W time '..w)
 end
end)

test('a consecutive turn after a resumed recovery stays in the same incident',function()
 local r=R.new();r:observe(0,1,0,false,true);assert(r:observe(0.1,1,180,false,true))
 local id=r.memory.id;r.memory.fightUsed=0.5;r:finish(1)
 assert(r:observe(6,1,180,true,true));equal(r.memory.id,id);equal(r.level,'double')
 equal(r.memory.fightAllowance,3.0);equal(r.phase,'FIGHT')
end)

test('turns separated by more than the window are separate incidents',function()
 local r=R.new();r:observe(0,1,0,false,true);assert(r:observe(0.1,1,180,false,true))
 local id=r.memory.id;r.memory.fightUsed=0.5;r:finish(1)
 assert(r:observe(11.2,1,0,true,true));assert(r.memory.id~=id);equal(r.level,'single')
 equal(r.memory.fightAllowance,0.5)
end)

test('three turns in the window: brief resistance, then a pull-over request',function()
 local r=R.new();local dt=1/30;local t=0;local h=0
 r:observe(t,1,h,false,true)
 local turns={0.05,0.4,0.8};local k=1;local w=0
 for i=1,45 do
  local c=r:step(t,sample({heading=h}),nil)
  exclusive(c);equal(c.steer,0)
  if c.gas>0 then w=w+dt end
  t=t+dt
  if turns[k] and t>=turns[k] then h=(h+180)%360;assert(r:observe(t,1,h,false,true));k=k+1
  else r:observe(t,1,h,false,true) end
 end
 equal(r.level,'multi')
 assert(w<=1.4+dt+1e-9,'resistance must stay brief, got '..w)
 local _,signal=settle(r,t,dt,h)
 equal(signal,'park')
end)

test('further turns of an overwhelming incident never restart W',function()
 local r=R.new();local t=0;local h=0;r:observe(t,1,h,false,true)
 for i=1,3 do t=t+0.05;h=(h+180)%360;r:observe(t,1,h,false,true) end
 r.memory.fightUsed=r.memory.fightAllowance
 for i=1,4 do
  t=t+0.3;r:observe(t,1,h,false,true)
  t=t+0.05;h=(h+180)%360;assert(r:observe(t,1,h,false,true))
  equal(r.phase,'HOLD');zero(r:step(t,sample({heading=h}),nil))
 end
end)

test('W is withheld against an obstacle, at forward speed, airborne or spinning',function()
 local r=R.new();r:observe(0,1,0,false,true);r:observe(0.05,1,180,false,true)
 zero(r:step(0.06,sample({heading=180,fightBlocked=true}),nil));equal(r.phase,'HOLD','obstacle ends the reaction')
 r=R.new();r:observe(0,1,0,false,true);r:observe(0.05,1,180,false,true)
 zero(r:step(0.07,sample({heading=180,forwardSpeed=9,speed=9}),nil))
 zero(r:step(0.09,sample({heading=180,airborne=true}),nil))
 r.rate=400;r.lastEvent=0
 zero(r:step(0.3,sample({heading=180}),nil))
 equal(r.phase,'FIGHT','bounded time still runs out normally')
end)

test('stabilising brakes only against the roll and releases near standstill',function()
 local r=R.new();r:observe(0,1,0,true,true);r.memory.fightUsed=5;r.phase='HOLD';r.uturnTried=true
 local c=r:step(1,sample({forwardSpeed=-9,speed=9}),nil);equal(c.gas,255);equal(c.brake,0);assert(not c.reverse)
 c=r:step(1.1,sample({forwardSpeed=9,speed=9}),nil);equal(c.brake,255);equal(c.gas,0)
 zero(r:step(1.2,sample({forwardSpeed=-2,speed=2}),nil))
 zero(r:step(1.3,sample({forwardSpeed=2,speed=2}),nil))
 zero(r:step(1.4,sample({forwardSpeed=nil,speed=9}),nil))
 zero(r:step(1.5,sample({forwardSpeed=-9,speed=12,slip=80}),nil))
end)

test('sliding sideways keeps the car neutral and prevents planning',function()
 local r=R.new();r:observe(0,1,0,true,true);r.memory.fightUsed=5;r.phase='HOLD'
 for i=1,60 do r:observe(i/10,1,0,false,true);local c,s=r:step(i/10,sample({speed=2,slip=80}),100);zero(c);equal(s,nil) end
 equal(r.phase,'HOLD')
end)

-- Minimal kinematic car for manoeuvre tests.
local function car(h) return {x=0,y=0,h=h,v=0} end
local function move(c,cmd,dt,blockReverseAfter)
 if cmd.reverse then if c.v>0.3 then c.v=c.v-10*dt else c.v=math.max(c.v-4*dt,-6) end
 elseif cmd.gas>0 then if c.v<-0.3 then c.v=math.min(0,c.v+10*dt) else c.v=c.v+7*dt end
 elseif cmd.brake>0 and c.v>0 then c.v=math.max(0,c.v-9*dt)
 else c.v=c.v-(c.v>0 and 1 or -1)*math.min(math.abs(c.v),1.5*dt) end
 local yaw=c.v/2.7*math.tan(cmd.steer/128*math.rad(32))
 c.h=(c.h-math.deg(yaw*dt))%360
 local r=math.rad(c.h);c.x=c.x-math.sin(r)*c.v*dt;c.y=c.y+math.cos(r)*c.v*dt
end
local function err(c,desired) return (c.h-desired+180)%360-180 end

local function runManoeuvre(r,c,t,dt,desired,opts)
 opts=opts or {}
 local legs={};local current,startedAt
 local ready=false
 for i=1,math.floor((opts.seconds or 40)/dt) do
  t=t+dt;r:observe(t,1,c.h,false,true,0,c.x,c.y)
  local s=sample({x=c.x,y=c.y,heading=c.h,speed=math.abs(c.v),forwardSpeed=c.v,connectDistance=opts.connect})
  if opts.reverseBlocked then s.reverseClearFor={[128]=false,[-128]=false};s.reverseClear=false end
  if opts.forwardBlocked then s.clear=false end
  local cmd,signal=r:step(t,s,err(c,desired))
  exclusive(cmd)
  -- Pedal switching: W first brakes a backwards roll and then drives a move
  -- whose path was checked (ALIGN, UTURN, APPROACH); S likewise for REVERSE.
  -- Never the other way round: no W inside a reverse move (except braking a
  -- runaway), no S inside a forward move.
  if cmd.reverse then
   assert(r.phase=='REVERSE' or c.v<=0.31,'S engaged while rolling forwards in '..tostring(r.phase))
   assert(r.phase~='ALIGN' and r.phase~='UTURN' and r.phase~='APPROACH','S inside a forward move')
  end
  if cmd.gas>0 and r.phase=='REVERSE' then assert(c.v<-(r.cfg.reverseMaxSpeed+r.cfg.coastBand)+0.01,'W inside a reverse move') end
  if cmd.gas>0 and r.phase=='SETTLE' then assert(c.v<-0.3,'SETTLE never starts a move with W') end
  if r.phase~=current then
   if current=='REVERSE' or current=='ALIGN' then legs[#legs+1]={kind=current,time=t-startedAt} end
   current,startedAt=r.phase,t
  end
  if signal=='ready' then ready=true;break end
  if signal=='plan' then r:setPlan(t,{name='test'}) end
  if signal=='chat' then r:chatQueued(t,false);r:setPlan(t,{name='test'}) end
  move(c,cmd,dt)
  if opts.connect then opts.connect=math.max(0,opts.connect-math.max(0,c.v)*dt) end
 end
 return ready,legs,t
end

test('single turn: chat, plan, reverse first, bounded K-turn, ready without help',function()
 for _,fps in ipairs({20,60}) do
  local r=R.new();local c=car(180);local dt=1/fps;local t=0
  r:observe(t,1,0,false,true);t=t+dt;r:observe(t,1,180,false,true)
  local signal;t,signal=settle(r,t,dt,180)
  equal(signal,'chat');r:chatQueued(t,true)
  local cmd;cmd,signal=r:step(t+dt,sample({heading=180,chatPending=true}),nil);zero(cmd);equal(signal,nil)
  t=t+2*dt;cmd,signal=r:step(t,sample({heading=180,chatPending=false}),nil);equal(signal,'plan')
  r:setPlan(t,{name='route1'})
  local ready,legs=runManoeuvre(r,c,t,dt,0)
  assert(ready,'must reach ready automatically')
  equal(legs[1].kind,'REVERSE','reverse first after a 180 degree turn')
  for i,leg in ipairs(legs) do
   assert(leg.time<=(leg.kind=='REVERSE' and r.cfg.legReverseSeconds or r.cfg.legForwardSeconds)+2*dt,'leg '..i..' too long '..leg.time)
   if i>1 then assert(leg.kind~=legs[i-1].kind,'legs alternate') end
  end
  assert(#legs<=8)
  assert(math.abs(err(c,0))<=35)
 end
end)

test('U-turn: offered right after W once the backwards slide is braked, full lock and W, then ready',function()
 local r=R.new();r:observe(0,1,0,false,true);r:observe(0.05,1,180,false,true)
 local t=0.05;local signal
 -- Still sliding backwards fast: W keeps braking, no U-turn yet.
 for i=1,30 do t=t+1/30;r:observe(t,1,180,false,true);local c;c,signal=r:step(t,sample({heading=180,forwardSpeed=-6,speed=6}),nil);if signal then break end end
 equal(signal,nil);equal(r.phase,'HOLD')
 local c=r:step(t+0.01,sample({heading=180,forwardSpeed=-2,speed=2}),nil);equal(c.gas,255,'W brakes the crawl')
 t=t+1/30;r:observe(t,1,180,false,true)
 c,signal=r:step(t,sample({heading=180,forwardSpeed=-0.5,speed=0.5}),nil);equal(signal,'uturn')
 r:setUturn(t,{name='route1'},128,sample({heading=180}));equal(r.phase,'UTURN')
 local car={x=0,y=0,h=180,v=-0.5};local ready
 for i=1,30*8 do
  t=t+1/30;r:observe(t,1,car.h,false,true)
  local cmd;cmd,signal=r:step(t,sample({x=car.x,y=car.y,heading=car.h,speed=math.abs(car.v),forwardSpeed=car.v,uturnClear=true,connectDistance=3}),err(car,0))
  exclusive(cmd)
  assert(not cmd.reverse,'no reversing in a U-turn')
  if signal=='ready' then ready=true;break end
  if r.phase=='UTURN' then equal(cmd.steer,128) end
  move(car,cmd,1/30)
 end
 assert(ready,'U-turn completes and hands over')
 assert(math.abs(err(car,0))<=r.cfg.handoffHeading)
end)

-- ---------------------------------------------------------------------------
-- 5.78 review: recovery-to-driving handoff, speed control, pending checks.
local P_=R.PENDING
local function r_cfg() return R.new().cfg end
-- A recovery whose U-turn has just brought the heading round (UTURN state).
local function uturning(opts)
 local r=R.new(opts);r:observe(0,1,0,true,true);r.memory.fightUsed=5;r.rate=0;r.rateAvg=0
 r:setUturn(1,{name='route1'},128,{heading=0})
 return r
end
-- Feed frames of a given motion; returns the first signal and the commands seen.
local function feed(r,t,frames,fn)
 local cmds={}
 for i=1,frames do
  t=t+1/30
  local s,e,rateAvg=fn(i,t)
  r.rate=rateAvg;r.rateAvg=rateAvg
  local cmd,signal=r:step(t,s,e)
  exclusive(cmd);cmds[#cmds+1]=cmd
  if signal then return t,signal,cmds end
 end
 return t,nil,cmds
end

test('U-turn aligned near the route while sliding at 7.8 m/s does not hand over',function()
 local r=uturning()
 local cmd,signal=r:step(1.05,sample({speed=7.8,forwardSpeed=4.0,lateralSpeed=6.7,slip=60,uturnClear=true,connectDistance=3}),10)
 equal(signal,nil,'no handoff while sliding');equal(r.phase,'SETTLE');equal(cmd.steer,0,'wheels straight')
 -- Still sliding for a second: never ready, brakes the slide.
 local t,sig,cmds=feed(r,1.05,30,function() return sample({speed=7.8,forwardSpeed=4.0,lateralSpeed=6.7,slip=60,connectDistance=3}),8,90 end)
 equal(sig,nil)
 local braked=false;for _,c in ipairs(cmds) do if c.brake>0 then braked=true end end
 assert(braked,'the slide is braked')
 equal(r.handoffWhy,'yaw')
end)

test('correct heading but excessive lateral velocity: no handoff until the slide is gone',function()
 local r=uturning();r:step(1.05,sample({speed=6,forwardSpeed=5,lateralSpeed=3,connectDistance=2,uturnClear=true}),5)
 equal(r.phase,'SETTLE')
 local t,sig=feed(r,1.05,30,function() return sample({speed=6,forwardSpeed=5,lateralSpeed=3,connectDistance=2}),5,3 end)
 equal(sig,nil,'sideways 3 m/s is not stable');equal(r.handoffWhy,'sliding')
 -- Slide decays below the limit: handover after the dwell, not before.
 local readyAfter
 t,sig=feed(r,t,30,function(i,tt) readyAfter=i return sample({speed=6,forwardSpeed=6,lateralSpeed=0.4,connectDistance=2}),5,3 end)
 equal(sig,'ready')
 assert(readyAfter*(1/30)>=r.cfg.handoffDwell-1/30,'dwell respected '..readyAfter)
end)

test('stable and aligned while still rolling: rolling handoff, no forced stop',function()
 local r=uturning();r:step(1.05,sample({speed=6,forwardSpeed=6,lateralSpeed=0.2,connectDistance=2,uturnClear=true}),4)
 local t,sig,cmds=feed(r,1.05,30,function() return sample({speed=6,forwardSpeed=6,lateralSpeed=0.2,connectDistance=2}),4,5 end)
 equal(sig,'ready','handed over at 6 m/s')
 for _,c in ipairs(cmds) do equal(c.brake,0,'never braked');equal(c.gas,0);equal(c.steer,0) end
end)

test('handoff dwell restarts if the car becomes unstable halfway',function()
 local r=uturning();r:step(1.05,sample({speed=5,forwardSpeed=5,connectDistance=2,uturnClear=true}),4)
 -- Stable for less than the dwell, then a yaw spike.
 local t,sig=feed(r,1.05,math.max(1,math.floor(r.cfg.handoffDwell*30)-1),function() return sample({speed=5,forwardSpeed=5,lateralSpeed=0.1,connectDistance=2}),4,5 end)
 equal(sig,nil)
 t,sig=feed(r,t,1,function() return sample({speed=5,forwardSpeed=5,lateralSpeed=0.1,connectDistance=2}),4,60 end)
 equal(sig,nil);equal(r.handoffSince,nil,'yaw spike resets the dwell')
 local n=0
 t,sig=feed(r,t,30,function(i) n=i return sample({speed=5,forwardSpeed=5,lateralSpeed=0.1,connectDistance=2}),4,5 end)
 equal(sig,'ready');assert(n*(1/30)>=r.cfg.handoffDwell-1/30)
end)

test('too fast for the handoff: braked down first, then handed over without stopping',function()
 local v=r_cfg().handoffMaxSpeed+2
 local r=uturning();r:step(1.05,sample({speed=v,forwardSpeed=v,connectDistance=2,uturnClear=true}),3)
 local t=1.05;local sig
 local brakes=0
 for i=1,90 do
  t=t+1/30;r.rate=2;r.rateAvg=2
  local cmd;cmd,sig=r:step(t,sample({speed=v,forwardSpeed=v,lateralSpeed=0,connectDistance=2}),3)
  if sig then break end
  if cmd.brake>0 then brakes=brakes+1;v=v-9/30 end
 end
 equal(sig,'ready');assert(brakes>0,'braked');assert(v<=r.cfg.handoffMaxSpeed and v>5,'rolling handoff at '..v)
end)

test('rolling backwards, airborne, wrong route direction or a reverse section block the handoff',function()
 local function blocked(s,e,plan)
  local r=uturning();if plan then r.plan=plan end
  r:startSettle(1)
  local t,sig=feed(r,1,30,function() return s,e or 3,3 end)
  return sig
 end
 equal(blocked(sample({speed=1,forwardSpeed=-1,connectDistance=2})),nil)
 equal(blocked(sample({speed=3,forwardSpeed=3,airborne=true,connectDistance=2})),nil)
 equal(blocked(sample({speed=3,forwardSpeed=3,connectDistance=2,routeHeadingError=120})),nil)
 equal(blocked(sample({speed=3,forwardSpeed=3,connectDistance=2}),3,{back=true}),nil)
 equal(blocked(sample({speed=0.2,forwardSpeed=0,connectDistance=2}),3,{back=true}),'ready','a reverse section is joined from a stop')
end)

test('near the route but not stable: approach keeps the wheels straight, no premature ready',function()
 local r=R.new();r:observe(0,1,0,true,true);r.memory.fightUsed=5;r.plan={}
 r:startApproach(1,4)
 local t,sig,cmds=feed(r,1,20,function() return sample({speed=7,forwardSpeed=6,lateralSpeed=2.5,connectDistance=3}),5,10 end)
 equal(sig,nil,'sliding in the connection zone is not a handoff')
 for _,c in ipairs(cmds) do equal(c.steer,0,'aligned in the zone: no steering pulses') end
end)

test('U-turn: W held, released (never braked) above the ceiling until coastBand below, runaway ends it',function()
 local r=uturning();local cfg=r.cfg
 local function at(t,v) return r:step(t,sample({speed=v,forwardSpeed=v,uturnClear=true}),120) end
 local cmd=at(1.05,3);equal(cmd.gas,255);equal(cmd.steer,128)
 cmd=at(1.10,cfg.uturnMaxSpeed-0.5);equal(cmd.gas,255,'held right up to the ceiling')
 cmd=at(1.15,cfg.uturnMaxSpeed+0.5);equal(cmd.gas,0,'released above');equal(cmd.brake,0,'never braked');equal(cmd.steer,128,'lock kept')
 cmd=at(1.20,cfg.uturnMaxSpeed-0.5);equal(cmd.gas,0,'still released inside the band')
 cmd=at(1.25,cfg.uturnMaxSpeed-cfg.coastBand-0.1);equal(cmd.gas,255,'pressed again below the band')
 at(1.30,cfg.uturnMaxSpeed+cfg.runawayMargin+0.5);equal(r.phase,'STOP')
end)

test('reverse and forward moves hold their pedal for the whole move (no pulsing)',function()
 local r=R.new();r:observe(0,1,180,true,true);r.memory.fightUsed=5;r.rate=0
 r.phase='PLAN';r.plan={};r.legs,r.noProgress,r.manoeuvreStart=0,0,0
 r:step(0.1,sample({heading=180,reverseClearFor={[128]=true,[-128]=true}}),170);equal(r.phase,'REVERSE')
 local c={x=0,y=0,h=180,v=0};local t=0.1
 local held,frames=0,0
 while r.phase=='REVERSE' and t<5 do
  t=t+1/30;r.rate=10
  local cmd=r:step(t,sample({x=c.x,y=c.y,heading=c.h,speed=math.abs(c.v),forwardSpeed=c.v,reverseClear=true,
   reverseClearFor={[128]=true,[-128]=true}}),170)
  if r.phase=='REVERSE' then frames=frames+1;if cmd.reverse then held=held+1 end;assert(cmd.steer~=0,'full lock while reversing') end
  move(c,cmd,1/30)
 end
 assert(frames>10,'a real move');equal(held,frames,'S held on every frame of the reverse move')
end)

test('pending clearance checks: a move stops pushing, a decision waits, both bounded',function()
 -- U-turn: the whole sweep was confirmed before it started. A rolling
 -- re-check still running keeps W for legPendingSeconds, then the car coasts
 -- on full lock; too long -> stop.
 local r=uturning()
 local cmd=r:step(1.05,sample({speed=3,forwardSpeed=3,uturnClear=P_}),120)
 equal(cmd.gas,255);equal(cmd.steer,128);equal(r.phase,'UTURN')
 cmd=r:step(1.05+r.cfg.legPendingSeconds+0.1,sample({speed=3,forwardSpeed=3,uturnClear=P_}),110)
 equal(cmd.gas,0,'no W once the confirmation is stale');equal(cmd.steer,128);equal(r.phase,'UTURN')
 r:step(1.05+r.cfg.probePendingTimeout+0.1,sample({speed=3,forwardSpeed=3,uturnClear=P_}),105)
 equal(r.phase,'STOP','gives up instead of driving into the unknown')
 -- Reverse leg: S inside the space the decision confirmed (2.5 m), none
 -- beyond it while the rolling check is still running.
 r=R.new();r:observe(0,1,180,true,true);r.memory.fightUsed=5;r.rate=0
 r.phase='PLAN';r.plan={};r.legs,r.noProgress,r.manoeuvreStart=0,0,0
 r:step(0.1,sample({heading=180,reverseClearFor={[128]=true,[-128]=true}}),170);equal(r.phase,'REVERSE')
 cmd=r:step(0.2,sample({heading=180,reverseClear=P_}),170);assert(cmd.reverse,'S inside the confirmed space')
 cmd=r:step(0.3,sample({heading=180,y=-2.4,speed=2,forwardSpeed=-2,reverseClear=P_}),170)
 assert(not cmd.reverse,'no S beyond the confirmed space while pending')
 -- Decision: STOP waits (braked, no leg) while the options are still being checked.
 r=R.new();r:observe(0,1,180,true,true);r.memory.fightUsed=5;r.rate=0
 r.phase='STOP';r.stopSince=0;r.afterStop='REVERSE';r.plan={};r.direction=128;r.legs,r.manoeuvreStart=1,0
 local pend=sample({reverseClearFor={[128]=P_,[-128]=P_},shortReverseFor={},clear=P_})
 zero(r:step(1,pend,150));equal(r.phase,'STOP','waits for the checks')
 zero(r:step(2,pend,150));equal(r.phase,'STOP')
 r:step(1+r.cfg.probePendingTimeout+0.1,pend,150);equal(r.phase,'WAIT','unfinished checks count as blocked after the timeout')
 -- FIGHT: unknown space ahead withholds W but keeps the reaction.
 r=R.new();r:observe(0,1,0,false,true);r:observe(0.05,1,180,false,true)
 cmd=r:step(0.1,sample({heading=180,fightBlocked=P_}),nil);equal(cmd.gas,0);equal(r.phase,'FIGHT')
 cmd=r:step(0.15,sample({heading=180,fightBlocked=false}),nil);equal(cmd.gas,255)
end)

test('U-turn check runs over several frames: braked meanwhile, then turns, falls back or times out',function()
 local function checking()
  local r=R.new();r:observe(0,1,0,true,true);r.memory.fightUsed=5;r.rate=0
  r:setUturn(1,{name='route1'},P_,sample());equal(r.phase,'UTURN_CHECK')
  return r
 end
 local r=checking()
 local cmd=r:step(1.1,sample({forwardSpeed=-2,speed=2,uturnSide=P_}),170);equal(cmd.gas,255,'brakes the crawl');equal(cmd.steer,0)
 r:step(1.2,sample({uturnSide=-128}),170);equal(r.phase,'UTURN');equal(r.direction,-128)
 r=checking();r:step(1.2,sample({uturnSide=false}),170);equal(r.phase,'HOLD')
 r=checking();r:step(1+r.cfg.probePendingTimeout+0.1,sample({uturnSide=P_}),170);equal(r.phase,'HOLD','incomplete check: no U-turn')
end)

test('a new rotation during the handoff dwell or the U-turn cancels it immediately',function()
 local r=uturning();r:step(1.05,sample({speed=5,forwardSpeed=5,connectDistance=2,uturnClear=true}),4)
 equal(r.phase,'SETTLE')
 r:observe(1.06,1,0,false,true);assert(r:observe(1.08,1,180,false,true))
 equal(r.phase=='FIGHT' or r.phase=='HOLD',true);equal(r.handoffSince,nil);equal(r.plan,nil)
 r=uturning();r:observe(1.06,1,90,false,true);assert(r:observe(1.08,1,270,false,true))
 assert(r.phase~='UTURN')
end)

test('U-turn: space closing mid-turn stops and falls back to reverse-and-turn; not offered for 3+ rotations',function()
 local r=R.new();r:observe(0,1,0,true,true);r.rate=0;r.memory.fightUsed=5
 r:setUturn(1,{name='route1'},-128,sample({heading=0}))
 zero(r:step(1.1,sample({uturnClear=false}),120));equal(r.phase,'STOP');equal(r.afterStop,'PLAN_REDO')
 r=R.new();local t=0;local h=0;r:observe(t,1,h,false,true)
 for i=1,3 do t=t+0.05;h=(h+180)%360;r:observe(t,1,h,false,true) end
 r.memory.fightUsed=r.memory.fightAllowance
 for i=1,60 do t=t+1/30;r:observe(t,1,h,false,true);local _,s=r:step(t,sample({heading=h}),nil);assert(s~='uturn') end
 -- Disabled in the settings: never offered.
 r=R.new({uturnEnabled=false});r:observe(0,1,0,false,true);r:observe(0.05,1,180,false,true);r.memory.fightUsed=5
 for i=1,60 do local tt=0.05+i/30;r:observe(tt,1,180,false,true);local _,s=r:step(tt,sample({heading=180}),nil);assert(s~='uturn') end
end)

test('turn side follows the shorter way and uses the side with room near 180',function()
 local r=R.new();r:observe(0,1,0,true,true);r.rate=0;r.phase='PLAN';r.plan={}
 r:step(1,sample(),60);equal(r.direction,128)
 r=R.new();r:observe(0,1,0,true,true);r.rate=0;r.phase='PLAN';r.plan={}
 r:step(1,sample(),-60);equal(r.direction,-128)
 r=R.new();r:observe(0,1,0,true,true);r.rate=0;r.phase='PLAN';r.plan={}
 local c=r:step(1,sample({reverseClearFor={[128]=false,[-128]=true}}),170);equal(r.direction,-128);equal(r.phase,'REVERSE')
 c=r:step(1.1,sample({reverseClearFor={[128]=false,[-128]=true},reverseClear=true}),170)
 assert(c.reverse);equal(c.steer,128,'reverse steers opposite to the turn side')
 -- Wall on the side the rear would swing to: back up with the opposite lock.
 r=R.new();r:observe(0,1,0,true,true);r.rate=0;r.phase='PLAN';r.plan={}
 r:step(1,sample({reverseClearFor={[128]=false,[-128]=true}}),120);equal(r.direction,-128);equal(r.phase,'REVERSE')
 -- Same check between legs while the turn side is locked.
 r=R.new();r:observe(0,1,0,true,true);r.rate=0;r.memory.fightUsed=5
 r.phase='STOP';r.stopSince=0;r.afterStop='REVERSE';r.plan={};r.direction=128;r.legs,r.manoeuvreStart=1,0
 r:step(1,sample({reverseClearFor={[128]=false,[-128]=true}}),150);equal(r.phase,'REVERSE');equal(r.direction,-128)
 local cmd=r:step(1.1,sample({reverseClearFor={[128]=false,[-128]=true},reverseClear=true}),150)
 assert(cmd.reverse);equal(cmd.steer,128,'rear swings to the free side')
 -- Little turn left: keep the side and drive forward instead of turning the long way.
 r=R.new();r:observe(0,1,0,true,true);r.rate=0;r.phase='PLAN';r.plan={}
 r:step(1,sample({reverseClearFor={[128]=false,[-128]=true}}),60);equal(r.direction,128);equal(r.phase,'ALIGN')
end)

test('legs: key held on every frame below the ceiling, released (not braked) above it, never a runaway',function()
 local cfg=R.new().cfg
 local r=R.new();local c=car(180);r:observe(0,1,180,true,true);r.memory.fightUsed=5;r.rate=0
 r.phase='PLAN';r.plan={};r.legs,r.noProgress,r.manoeuvreStart=0,0,0
 local t=0;local below={REVERSE={0,0},ALIGN={0,0}};local maxBack,maxFwd=0,0
 for i=1,30*12 do
  t=t+1/30;r.rate=0
  local phase=r.phase
  local cmd=r:step(t,sample({x=c.x,y=c.y,heading=c.h,speed=math.abs(c.v),forwardSpeed=c.v}),err(c,0))
  exclusive(cmd)
  if phase=='REVERSE' and r.phase=='REVERSE' then
   maxBack=math.max(maxBack,-c.v)
   if -c.v<cfg.reverseMaxSpeed-cfg.coastBand then below.REVERSE[1]=below.REVERSE[1]+1;if cmd.reverse then below.REVERSE[2]=below.REVERSE[2]+1 end end
  end
  if phase=='ALIGN' and r.phase=='ALIGN' then
   maxFwd=math.max(maxFwd,c.v)
   if c.v<cfg.forwardMaxSpeed-cfg.coastBand then below.ALIGN[1]=below.ALIGN[1]+1;if cmd.gas>0 then below.ALIGN[2]=below.ALIGN[2]+1 end end
  end
  move(c,cmd,1/30)
  if r.phase=='SETTLE' or r.phase=='WAIT' then break end
 end
 for kind,n in pairs(below) do
  assert(n[1]>0,kind..' leg ran')
  equal(n[2],n[1],kind..' key held on every frame below the ceiling')
 end
 assert(maxBack<=cfg.reverseMaxSpeed+cfg.runawayMargin,'reverse never a runaway: '..maxBack)
 assert(maxFwd<=cfg.forwardMaxSpeed+cfg.runawayMargin,'forward never a runaway: '..maxFwd)
 -- Above the ceiling the key is released, never pressed the other way.
 r=R.new();r:observe(0,1,180,true,true);r.memory.fightUsed=5;r.rate=0
 r.phase='PLAN';r.plan={};r.legs,r.noProgress,r.manoeuvreStart=0,0,0
 r:step(0.1,sample({heading=180}),170);equal(r.phase,'REVERSE')
 local v=cfg.reverseMaxSpeed+0.5
 local cmd=r:step(0.2,sample({heading=180,forwardSpeed=-v,speed=v,reverseClear=true}),170)
 assert(cmd.gas==0 and not cmd.reverse and cmd.brake==0,'released above the ceiling');assert(cmd.steer~=0,'lock kept')
 -- A runaway ends the move.
 v=cfg.reverseMaxSpeed+cfg.runawayMargin+0.5
 r:step(0.3,sample({heading=180,forwardSpeed=-v,speed=v,reverseClear=true}),170);equal(r.phase,'STOP')
 -- Lower power pulses the key instead.
 r=R.new({reversePower=50});r:observe(0,1,180,true,true);r.memory.fightUsed=5;r.rate=0
 r.phase='PLAN';r.plan={};r.legs,r.noProgress,r.manoeuvreStart=0,0,0
 local on,total2=0,0;t=0
 for i=1,40 do t=t+1/30;r.rate=0;local cmd=r:step(t,sample({heading=180}),170)
  if r.phase=='REVERSE' then total2=total2+1;if cmd.reverse then on=on+1 end end end
 assert(on>0 and on<total2,'50 % pulses S')
end)

test('wall appears on the rear-swing side mid-reverse: keeps reversing with the opposite lock',function()
 local r=R.new();r:observe(0,1,0,true,true);r.memory.fightUsed=5;r.rate=0
 r.phase='PLAN';r.plan={};r.legs,r.noProgress,r.manoeuvreStart=0,0,0
 r:step(1,sample(),150);equal(r.phase,'REVERSE');local d=r.direction
 local cmd=r:step(1.1,sample({reverseClear=true}),150);assert(cmd.reverse);equal(cmd.steer,-d)
 local s=sample({reverseClearFor={[d]=false,[-d]=true},reverseClear=false})
 cmd=r:step(1.2,s,150);equal(r.phase,'REVERSE','no stop, no forward leg');equal(r.direction,-d)
 assert(cmd.reverse);equal(cmd.steer,d,'rear now swings to the free side')
 s=sample({reverseClearFor={[d]=false,[-d]=false},reverseClear=false})
 r:step(1.3,s,150);equal(r.phase,'STOP','both sides blocked ends the leg')
end)

test('nose against a wall: backs straight out first, wheels centred',function()
 local r=R.new();r:observe(0,1,0,true,true);r.memory.fightUsed=5;r.rate=0
 r.phase='PLAN';r.plan={};r.legs,r.noProgress,r.manoeuvreStart=0,0,0
 local s=sample({clear=false,reverseClearFor={[128]=false,[-128]=false,[0]=true}})
 r:step(1,s,120);equal(r.phase,'REVERSE');equal(r.reverseKey,0)
 s.reverseClear=true
 local cmd=r:step(1.1,s,120);assert(cmd.reverse);equal(cmd.steer,0)
end)

test('blocked in both directions: neutral wait, automatic bounded retries',function()
 local r=R.new();local c=car(180);r:observe(0,1,180,true,true);r.memory.fightUsed=5;r.rate=0
 local t=0;local waits=0;local last
 for i=1,600 do
  t=t+0.05;r:observe(t,1,c.h,false,true)
  local s=sample({heading=c.h,clear=false,reverseClearFor={[128]=false,[-128]=false},reverseClear=false})
  local cmd,signal=r:step(t,s,180)
  if signal=='chat' then r:chatQueued(t,false);r:setPlan(t,{}) end
  if signal=='plan' then r:setPlan(t,{}) end
  if r.phase=='WAIT' then
   zero(cmd)
   if last~='WAIT' then
    waits=waits+1
    local wait=r.retryAt-t
    if r.attempts%r.cfg.retryLongEvery==0 then assert(wait<=r.cfg.retryLongWait+0.01,'long pause bounded '..wait)
    else assert(wait<=r.cfg.retryMax+0.01,'retry wait is bounded '..wait) end
   end
  end
  assert(cmd.gas==0 and not cmd.reverse,'no pedal while everything is blocked')
  last=r.phase
 end
 assert(waits>=3,'keeps retrying')
end)

test('repeated failures: every 6th attempt pauses longer, then retries again automatically',function()
 local r=R.new();r:observe(0,1,0,true,true);r.memory.fightUsed=5;r.rate=0
 local t=0;local waits={}
 for i=1,13 do
  r:retry(t,'blocked');waits[#waits+1]=r.retryAt-t
  equal(r.phase,'WAIT');zero(r:step(t+0.01,sample(),nil))
  t=r.retryAt+0.01;r:step(t,sample(),nil);equal(r.phase,'HOLD','retries on its own')
 end
 equal(waits[6],r.cfg.retryLongWait);equal(waits[12],r.cfg.retryLongWait)
 assert(waits[5]<=r.cfg.retryMax and waits[7]<=r.cfg.retryMax and waits[13]<=r.cfg.retryMax)
end)

test('reverse without movement never holds S beyond its leg',function()
 local r=R.new();r:observe(0,1,180,true,true);r.memory.fightUsed=5;r.rate=0
 r.phase='PLAN';r.plan={};r.legs,r.noProgress,r.manoeuvreStart=0,0,0
 local t=0;local held,longest,any=0,0,false
 for i=1,400 do
  t=t+0.05
  local cmd,signal=r:step(t,sample({heading=180,clear=false}),170)
  if cmd.reverse then held=held+0.05;any=true;longest=math.max(longest,held) else held=0 end
  if r.phase=='WAIT' then break end
 end
 assert(any and longest<=r.cfg.legReverseSeconds+0.05,'each S hold bounded by its leg: '..longest)
 equal(r.phase,'WAIT','gives up and waits instead of retrying the same stuck legs')
 assert(t<=10,'bounded overall: '..t)
end)

test('a new turn during a reverse leg cancels S in the same frame',function()
 local r=R.new();r:observe(0,1,180,true,true);r.memory.fightUsed=5;r.rate=0
 r.phase='PLAN';r.plan={};r.legs,r.noProgress,r.manoeuvreStart=0,0,0
 r:step(0.1,sample({heading=180}),170)
 assert(r:step(0.15,sample({heading=180}),170).reverse)
 assert(r:observe(0.2,1,0,false,true))
 local cmd=r:step(0.2,sample({heading=0}),-10)
 assert(not cmd.reverse and cmd.steer==0);assert(r.phase=='HOLD' or r.phase=='FIGHT')
 equal(r.plan,nil,'old plan discarded')
end)

test('our own chat keeps waiting phases; any other interruption restarts stabilisation',function()
 local r=R.new();r:observe(0,1,0,true,true);r.memory.fightUsed=5;r.phase='CHAT';r.chatSince=0
 zero(r:step(0.5,sample({allowed=false,owner='CHAT'}),nil));equal(r.phase,'CHAT')
 r.phase='PARKED';r.parkedSince=0
 zero(r:step(0.6,sample({allowed=false,owner='CHAT'}),nil));equal(r.phase,'PARKED')
 r.phase='REVERSE';r.legStart=0;r.legX,r.legY=0,0;r.direction=128
 zero(r:step(0.7,sample({allowed=false,owner='CHAT'}),100));equal(r.phase,'HOLD')
 -- The player taking over: a one-frame flicker (v5.77 reading a key the bot
 -- just released) keeps the phase with no keys; 0.2 s+ restarts stabilisation.
 r.phase='CHAT'
 zero(r:step(0.8,sample({allowed=false,owner='MANUAL'}),nil));equal(r.phase,'CHAT')
 zero(r:step(0.83,sample({allowed=true}),nil))
 r.phase='JTURN';r.jturnStart=0.8;r.progressAt=0.8;r.direction=128
 zero(r:step(0.86,sample({allowed=false,owner='MANUAL'}),nil));equal(r.phase,'JTURN','one-frame flicker')
 zero(r:step(1.0,sample({allowed=false,owner='MANUAL'}),nil));equal(r.phase,'JTURN','still within 0.2 s')
 zero(r:step(1.1,sample({allowed=false,owner='MANUAL'}),nil));equal(r.phase,'HOLD','real takeover')
 r.phase='FIGHT';r.memory.fightUsed=0;r.memory.fightAllowance=3
 zero(r:step(0.9,sample({allowed=false,owner='DIALOG'}),nil));equal(r.phase,'HOLD')
end)

test('no route target: neutral retry, never a manual pause',function()
 local r=R.new();r:observe(0,1,0,true,true);r.memory.fightUsed=5;r.phase='PLAN'
 r:setPlan(1,nil);equal(r.phase,'WAIT');zero(r:step(1.1,sample(),nil))
 r.phase='ALIGN';r.plan={};r.legStart=0;r.legX,r.legY=0,0;r.direction=128
 zero(r:step(2,sample(),nil));equal(r.phase,'WAIT')
end)

test('chat timeout or a pending reply never blocks the recovery for long',function()
 local r=R.new();r:observe(0,1,0,true,true);r.memory.fightUsed=5;r.phase='CHAT';r.chatSince=0
 local _,s=r:step(5,sample({chatPending=true}),nil);equal(s,nil)
 _,s=r:step(9.5,sample({chatPending=true}),nil);equal(s,'plan')
end)

test('approach: W held below the ceiling (lower while turning), released above it, pulsed steering, rolling hand-over',function()
 local cfg=R.new().cfg
 local r=R.new();r:observe(0,1,0,true,true);r.memory.fightUsed=5;r.rate=0;r.rateAvg=0
 r.phase='SETTLE';r.settleSince=0;r.settleStarted=0;r.plan={}
 local t=1
 for i=1,30 do t=t+1/30;r:step(t,sample({connectDistance=15}),5);if r.phase=='APPROACH' then break end end
 equal(r.phase,'APPROACH','stable but far from the line: drive back to it')
 local c=car(0);local maxSpeed=0;local held=0;local maxHeld=0;local ready;local readyAt
 local d=15;local gaps=0
 for i=1,600 do
  t=t+1/30
  r.rate=0;r.rateAvg=0
  local e=err(c,-25)
  local cmd,signal=r:step(t,sample({x=c.x,y=c.y,heading=c.h,speed=math.abs(c.v),forwardSpeed=c.v,connectDistance=d}),e)
  exclusive(cmd)
  if cmd.steer~=0 then held=held+1/30;maxHeld=math.max(maxHeld,held) else held=0 end
  local ceiling=math.abs(e)>25 and cfg.approachTurnSpeed or cfg.approachMaxSpeed
  if not signal and c.v>=-0.3 and c.v<ceiling-cfg.coastBand and cmd.gas==0 then gaps=gaps+1 end
  assert(cmd.brake==0 or signal,'approach never brakes a car going the right way')
  if signal=='ready' then ready=true;readyAt=c.v;break end
  move(c,cmd,1/30);maxSpeed=math.max(maxSpeed,c.v);d=math.max(0,d-math.max(0,c.v)/30)
 end
 assert(ready,'approach hands over')
 equal(gaps,0,'W held on every frame below the ceiling')
 assert(maxSpeed<=cfg.approachMaxSpeed+0.5,'approach speed '..maxSpeed)
 assert(readyAt>1.0,'handed over rolling (no stop required): '..readyAt)
 assert(maxHeld<=0.31+1/30,'steering pulses stay short '..maxHeld)
end)

test('approach without progress stops and retries',function()
 local r=R.new();r:observe(0,1,0,true,true);r.memory.fightUsed=5;r.rate=0
 r.phase='APPROACH';r.plan={};r.approachStart,r.progressAt,r.bestConnect=0,0,15;r.pulseDir,r.pulseUntil,r.pulseRest=0,0,0
 local t=0
 for i=1,200 do t=t+0.05;r:step(t,sample({connectDistance=15}),0);if r.phase=='WAIT' then break end end
 equal(r.phase,'WAIT');assert(t<=3.2+2.6,'no-progress detection is bounded')
end)

test('pull-over manoeuvre is bounded, then parked waits for quiet after the last turn',function()
 local r=R.new();local t=0;local h=0;r:observe(t,1,h,false,true)
 for i=1,3 do t=t+0.05;h=(h+180)%360;r:observe(t,1,h,false,true) end
 r.memory.fightUsed=r.memory.fightAllowance
 local signal;t,signal=settle(r,t,1/30,h);equal(signal,'park')
 r:setPark(t,128,sample({heading=h}))
 equal(r.phase,'PARK')
 local c=car(h);local moved=0;local steps=0
 while r.phase=='PARK' or r.phase=='STOP' do
  t=t+1/30;steps=steps+1
  r:observe(t,1,c.h,false,true)
  local cmd=r:step(t,sample({x=c.x,y=c.y,heading=c.h,speed=math.abs(c.v),forwardSpeed=c.v}),nil)
  exclusive(cmd);move(c,cmd,1/30)
  assert(steps<30*8,'pull-over bounded')
 end
 equal(r.phase,'PARKED')
 assert(math.sqrt(c.x^2+c.y^2)<=7.5)
 local cmd;cmd,signal=r:step(t+0.1,sample({heading=c.h}),nil);equal(signal,'chat');r:chatQueued(t,true)
 -- Another turn while parked: hold, then parked again without a second pull-over.
 t=t+3;h=c.h;r:observe(t-0.05,1,h,false,true);assert(r:observe(t,1,(h+180)%360,false,true))
 local last=t
 local t2,s2=settle(r,t,1/30,(h+180)%360)
 equal(s2,'chat','main decides whether this level already reacted');r:chatQueued(t2,false)
 equal(r.phase,'PARKED')
 local planAt
 for i=1,30*20 do
  t2=t2+1/30;r:observe(t2,1,(h+180)%360,false,true)
  local c2,s=r:step(t2,sample({heading=(h+180)%360}),nil)
  if s=='plan' then planAt=t2;break end
 end
 assert(planAt and planAt-last>=8-0.01,'waits the quiet period after the last turn')
end)

test('no confirmed pull-over space: stays neutrally stopped instead',function()
 local r=R.new();r:observe(0,1,0,true,true);r.level='multi';r.phase='PARK_PLAN'
 r:setPark(1,nil,sample());equal(r.phase,'PARKED');zero(r:step(1.1,sample(),nil))
end)

test('manoeuvre limit ends in a bounded retry',function()
 local r=R.new();r:observe(0,1,0,true,true);r.memory.fightUsed=5;r.rate=0
 r.phase='PLAN';r.plan={};r.legs=16;r.noProgress=0;r.manoeuvreStart=0;r.direction=128
 zero(r:step(1,sample(),120));equal(r.phase,'WAIT')
end)

test('interpolated 180 detected across three samples; curves, stale, teleport do not trigger',function()
 local r=R.new();r:observe(0,1,0,false,true)
 assert(not r:observe(0.05,1,60,false,true));assert(not r:observe(0.10,1,120,false,true))
 assert(r:observe(0.15,1,180,false,true))
 r=R.new()
 for i=0,120 do assert(not r:observe(i/60,1,(350+i)%360,false,true)) end
 assert(not r:observe(10,1,180,false,true),'stale sample')
 assert(not r:observe(10.1,2,0,false,true),'vehicle change')
 r=R.new();r:observe(0,1,0,false,true,0,0,0)
 assert(not r:observe(0.05,1,180,false,true,0,500,500),'teleport is not a rotation')
 assert(not r:observe(0.10,1,180,false,true,0,501,500))
 r=R.new();r:observe(0,1,0,false,false);assert(not r:observe(0.05,1,180,false,false),'disabled while player controls')
end)

test('reset forgets the incident; finish keeps it for the window',function()
 local r=R.new();r:observe(0,1,0,false,true);r:observe(0.05,1,180,false,true)
 r:finish(1);assert(r.memory);equal(r.phase,nil);equal(r:windowCount(5),1);equal(r:windowCount(11),0)
 r:observe(0,1,0,false,true);r:observe(0.05,1,180,false,true);r:reset();equal(r.memory,nil);assert(r.cfg)
end)

test('scheduler cancels on stop or vehicle change and does not catch up',function()
 local s=Sequence.new(1,0,false)
 assert(s:tick(0,1,false));assert(s:tick(20,1,false));assert(not s:tick(20,1,false))
 assert(not s:tick(21,2,false));assert(s.left==0)
 s=Sequence.new(1,0,true);assert(not s:tick(0,1,true));assert(s.left==0)
end)

test('configuration from the INI applies and invalid types are ignored',function()
 local r=R.new({firstFight=0.3,repeatFight='x',window=12})
 equal(r.cfg.firstFight,0.3);equal(r.cfg.repeatFight,3.0);equal(r.cfg.window,12)
 r:configure({parkEnabled=false});equal(r.cfg.parkEnabled,false);equal(r.cfg.firstFight,0.5)
end)
-- ---------------------------------------------------------------------------
-- Reverse spin (J-turn), the default: no W reaction, S with full lock at once.
local P2=R.PENDING
local function spun(opts)
 local r=spinR(opts);r:observe(0,1,0,false,true)
 assert(r:observe(0.05,1,180,false,true))
 return r
end

test('reverse spin: no W reaction; the turn asks for a plan and checks the spin room without any key',function()
 local r=spun();equal(r.phase,'JTURN_CHECK')
 local c,signal=r:step(0.06,sample({heading=180,forwardSpeed=-12,speed=12}),nil)
 zero(c);equal(signal,'jturn')
 r:setJturn(0.06,{name='route1'},P2,sample())
 equal(r.phase,'JTURN_CHECK')
 c,signal=r:step(0.1,sample({heading=180,forwardSpeed=-12,speed=12,jturnSide=P2}),178)
 zero(c);equal(signal,nil)
 c=r:step(0.15,sample({heading=180,forwardSpeed=-12,speed=12,jturnSide=128}),178)
 equal(r.phase,'JTURN');equal(r.direction,128)
end)

test('reverse spin: S with the opposite lock while sliding back, lock only (no S) past the switch angle, then W with the turn-side lock, then wheels straight',function()
 local r=spun();r:step(0.06,sample({heading=180}),nil);r:setJturn(0.06,{name='route1'},P2,sample())
 r:step(0.1,sample({heading=180,forwardSpeed=-30,speed=30,jturnSide=128}),178);equal(r.phase,'JTURN')
 local cfg=r.cfg
 -- Still facing the wrong way and sliding back: S + opposite lock.
 local c=r:step(0.15,sample({heading=180,forwardSpeed=-12,speed=12,reverseClear=true}),170)
 exclusive(c);assert(c.reverse,'S held');equal(c.gas,0);equal(c.steer,-128)
 -- Very fast: S stays held (it just cannot add speed).
 c=r:step(0.2,sample({heading=180,forwardSpeed=-30,speed=30,reverseClear=true}),165)
 assert(c.reverse,'S held at any speed');equal(c.steer,-128)
 -- Round past the switch angle, still sliding back: S would brake the spin.
 c=r:step(0.3,sample({heading=90,forwardSpeed=-6,speed=10,reverseClear=true}),cfg.jturnSwitchAngle-10)
 assert(not c.reverse and c.gas==0,'coasts');equal(c.steer,-128,'lock kept')
 -- Now travelling forwards relative to the car: W with the turn-side lock.
 c=r:step(0.4,sample({heading=60,forwardSpeed=4,speed=9,uturnClear=true}),70)
 exclusive(c);equal(c.gas,255);equal(c.steer,128)
 -- Lined up: SETTLE (wheels straight).
 r.rateAvg=0
 c=r:step(0.5,sample({heading=10,forwardSpeed=8,speed=8}),10)
 equal(r.phase,'SETTLE');zero(c)
end)

test('reverse spin: never W while the car still travels backwards facing the wrong way',function()
 local r=spun();r:step(0.06,sample({heading=180}),nil);r:setJturn(0.06,{name='route1'},P2,sample())
 r:step(0.1,sample({heading=180,forwardSpeed=-8,speed=8,jturnSide=-128}),-178)
 local h,err,t=180,-178,0.1
 for i=1,40 do
  t=t+1/30;err=math.min(-30,err+3)
  local fs=-8+i*0.1
  local c=r:step(t,sample({heading=h,forwardSpeed=fs,speed=math.abs(fs),reverseClear=true,uturnClear=true}),err)
  exclusive(c)
  if r.phase=='JTURN' and c.gas>0 then assert(fs>-1.01,'W only once the car no longer slides back: '..fs) end
 end
end)

test('reverse spin refused, incomplete, blocked or too long: stabilise and plan, reverse-then-swing before the forward U-turn',function()
 -- No room.
 local r=spun();r:step(0.06,sample({heading=180}),nil);r:setJturn(0.06,{name='route1'},P2,sample())
 r:step(0.1,sample({heading=180,jturnSide=false}),178)
 equal(r.phase,'HOLD');equal(r.uturnTried,true,'HOLD does not offer the forward U-turn first');assert(r.plan)
 -- Check never finishes: bounded.
 r=spun();r:step(0.06,sample({heading=180}),nil);r:setJturn(0.06,{name='route1'},P2,sample())
 r:step(0.06+r.cfg.jturnCheckSeconds+0.05,sample({heading=180,jturnSide=P2}),178);equal(r.phase,'HOLD')
 -- No route at all.
 r=spun();r:step(0.06,sample({heading=180}),nil);r:setJturn(0.06,nil,nil,sample());equal(r.phase,'HOLD')
 -- Rear blocked while slow.
 r=spun();r:step(0.06,sample({heading=180}),nil);r:setJturn(0.06,{name='route1'},P2,sample())
 r:step(0.1,sample({heading=180,jturnSide=128,forwardSpeed=-2,speed=2}),178)
 r:step(0.15,sample({heading=180,forwardSpeed=-2,speed=2,reverseClear=false}),175);equal(r.phase,'HOLD')
 -- Too long.
 r=spun();r:step(0.06,sample({heading=180}),nil);r:setJturn(0.06,{name='route1'},P2,sample())
 r:step(0.1,sample({heading=180,jturnSide=128,forwardSpeed=-2,speed=2}),178)
 r:step(0.1+r.cfg.jturnSeconds+0.1,sample({heading=100,forwardSpeed=-2,speed=2,reverseClear=true}),150);equal(r.phase,'HOLD')
 -- PLAN after a refused spin: reverse-then-swing first, then the forward U-turn, then moves.
 r=spun();r:step(0.06,sample({heading=180}),nil);r:setJturn(0.06,{name='route1'},P2,sample())
 r:step(0.1,sample({heading=180,jturnSide=false}),178)
 r.phase='PLAN';r.plan={name='route1'};r.legs,r.noProgress,r.manoeuvreStart=0,0,0.1;r.rate=0
 r:step(0.2,sample({heading=180,threePoint=false,uturnSide=-128}),170)
 equal(r.phase,'UTURN','forward U-turn after reverse-then-swing did not fit')
end)

test('3+ rotations with the reverse spin: no spin and no W push, it brakes and pulls over',function()
 local r=spinR();local t=0;local h=0;r:observe(t,1,h,false,true)
 for i=1,3 do t=t+0.05;h=(h+180)%360;r:observe(t,1,h,false,true) end
 equal(r.level,'multi');equal(r.phase,'HOLD')
 local c=r:step(t+0.05,sample({heading=h,forwardSpeed=-6,speed=6}),nil)
 equal(c.steer,0);assert(not c.reverse)
 -- W here only brakes the backwards roll.
 c=r:step(t+0.1,sample({heading=h,forwardSpeed=0.5,speed=0.5}),nil);equal(c.gas,0)
end)

test('a new turn during the reverse spin restarts it in the same frame, keys released',function()
 local r=spun();r:step(0.06,sample({heading=180}),nil);r:setJturn(0.06,{name='route1'},P2,sample())
 r:step(0.1,sample({heading=180,jturnSide=128,forwardSpeed=-8,speed=8}),178);equal(r.phase,'JTURN')
 r:observe(0.12,1,180,false,true);assert(r:observe(0.14,1,0,false,true))
 equal(r.phase,'JTURN_CHECK');equal(r.level,'double')
 local c,signal=r:step(0.15,sample({heading=0}),nil);zero(c);equal(signal,'jturn')
end)

print(total..' modern rotation scenarios passed')
