-- Execute the actual shipped script with mocked game/Windows surfaces.
-- No copied manager implementation and no GTA/SA-MP installation required.
local sourcePath = arg[1] or 'dangis_vr.lua'
local file = assert(io.open(sourcePath, 'rb'))
local source = file:read('*a'); file:close()
local testRoot = '/tmp/dangis_expansion_test'
os.execute('mkdir -p ' .. testRoot)
local fakeNow = 10
os.clock = function() return fakeNow end
package.preload['lib.moonloader'] = function() return {} end
script_name = function() end
script_version = function() end
getWorkingDirectory = function() return testRoot end
PLAYER_PED = 1
local inCar = true
local carX,carY,carSpeed,carHeading=0,0,20,0
isCharInAnyCar = function() return inCar end
storeCarCharIsInNoSave = function() return 1 end
getCarCoordinates = function() return carX, carY, 0 end
getCarSpeed=function() return carSpeed end
getCharCoordinates=getCarCoordinates
isPointOnScreen=function() return false end
getHeadingFromVector2d=function(x,y) return (math.deg((math.atan2 or math.atan)(-x,y))+360)%360 end
locateCharInCar2d=function() return false end
getCarHeading = function() return carHeading end
getDistanceBetweenCoords2d = function(x,y,a,b) return math.sqrt((x-a)^2+(y-b)^2) end
printStringNow = function() end
local writes, pad = {}, {}
writeMemory = function(address, size, value)
    assert(size == 2)
    writes[#writes+1] = {address=address, value=value}
    pad[address] = value
end
setGameKeyState = function(key, value)
    assert(key == 0)
    writes[#writes+1] = {steer=value}
    pad.steer = value
end
local appended = [[
return {
    settings=Settings,vehicles=VehicleProfiles,escape=EscapePlanner,diag=Diagnostics,api=API,
    classifier=MotionClassifier, planner=DrivingPlanner, chat=AdminChat, telemetry=Telemetry,
    turn=turning_mechanism, noise=applySteerNoise,
    setFrame=function(value) frameScale=value end,
    setMotion=function(speed,x,y,gas,brake)
        lastDriveSpeed=speed; lastX=x; lastY=y; gasLevel=gas; brakeLevel=brake
        ControlManager.apply({gas=gas,brake=brake,steer=0})
    end,
    getLevels=function() return gasLevel,brakeLevel end,
    skipScans=function() ObstacleAvoidance.updateScan=function() end end,
    manager=ControlManager, memory=RecoveryMemory, S=S, config=CONFIG, Win32=Win32, Mem=Mem, input=InputHandler,
    stopBump=stopBumpRecovery, resync=resyncAfterBump, rejoin=handleRouteRejoinRecovery,
    setIndex=function(index) play_index=index end, getIndex=function() return play_index end,
    route=RouteFollower, recovery=RecoverySystem, loop=MainLoop,
    release=releaseControls, pedals=writeDriveControls, steering=writeSteerControls,
    state=writeSharedState, bump=startBumpRecovery, updateBump=updateBumpRecovery,
    transition=startBackToForwardTransition, freeze=startFreezeRecovery,
    rotate=handleAdminRotate, rotation=pressRotateReaction,
    setPlaying=function(value) playing=value end,
    setSamp=function(value) samp=value end,
    setRoute=function(value) current_route=value; play_index=1 end,
    setSpeed=function(value) lastDriveSpeed=value; S.forwardSpeed=value end,
    applied=function() return ControlManager.applied end,
    owner=function() return ControlManager.owner end,
    clearSharedThrottle=function() lastSharedStateWriteAt=-1 end,
    setLoopStages=function(dialog, recovery, recorder, playback)
        DialogBridge.update=dialog; RecoverySystem.updateControlThread=recovery
        RouteRecorder.recordTick=recorder; RouteFollower.updatePlayback=playback
    end,
}
]]
local bot = assert((loadstring or load)(source .. appended, '@'..sourcePath))()
bot.config.controls.input="gamepad"
local physical, dialog = false, false
isKeyDown = function() return physical end
bot.Win32.isGameForeground = function() return true end
bot.Win32.keyDown = function() return physical end
bot.Mem.readDword = function(address)
    if address == 0x100000 + 0x21A0B8 then return 0x1000000 end
    if address == 0x1000000 + 0x28 then return dialog and 1 or 0 end
end
bot.setSamp(0x100000)
local function flag(name, value)
    local path=testRoot..'/dangis_vr_'..name..'.flag'
    if value then local f=assert(io.open(path,'w')); f:write(value); f:close()
    else os.remove(path) end
end
local originalScan=bot.escape.scan
local originalReadWord=bot.Mem.readWord
local function clearScene(ax,ay,az,bx,by,bz)
 if math.abs(ax-bx)<0.0001 and math.abs(ay-by)<0.0001 and az-bz>1 then
  return true,{pos={bx,by,-0.5},normal={0,0,1}}
 end
 return false
end
local function reset()
    for key,value in pairs(bot.settings.defaults) do bot.config[key]=bot.settings.copy(value) end
    flag('freeze'); flag('dialog'); flag('rotate')
    physical, dialog, inCar = false, false, true
    bot.config.controls.brakeMode="foot"
    if bot.config.escape then bot.config.escape.enabled=false end
    bot.setPlaying(false)
    bot.route.clearTransientState()
    bot.manager.neutralize()
    bot.setPlaying(true)
    bot.setRoute({{x=0,y=0,z=0,speed=10,drive='FWD'}, {x=10,y=0,z=0,speed=10,drive='FWD'}})
    bot.setSpeed(20)
    bot.manager.sync()
    bot.S.rejoinCooldownUntil=0; bot.S.rejoinDisableUntil=0
    writes={}
    carX,carY,carSpeed,carHeading=0,0,20,0
    bot.classifier.reset();bot.planner.cache=nil
    bot.config.adminChat.includeInferredTests=false
    bot.config.adminChat.includeLocalTests=false
    bot.config.controls.input='gamepad'
    bot.config.controls.steering='smooth'
    bot.config.driving.enabled=true
    bot.S.showObstacleDots=false;bot.S.nextNudge=fakeNow+100
    bot.S.lapWander=0;bot.S.currentLateral=0
    bot.S.nextGasLift=fakeNow+100;bot.S.gasLiftFrames=0
    bot.telemetry.enabled=false
    bot.config.escape.enabled=true
    bot.escape.scan=originalScan;bot.escape.lastSide=nil
    bot.vehicles.presets=bot.settings.copy(bot.vehicles.defaults)
    bot.vehicles.activeName='standard';bot.vehicles.car=nil;bot.vehicles.model=nil;bot.vehicles.lastUpdate=nil
    bot.api.carPointer=nil;bot.Mem.readWord=originalReadWord
    bot.chat.session={startedAt=fakeNow,checks=0,sent=0,joinedAt=nil}
    bot.chat.phrases={};bot.chat.groups={};bot.chat.bag={};bot.chat.bagKey=nil;bot.chat.lastPhrase=nil
    bot.chat.seen,bot.chat.seenOrder={},{}
    bot.diag.unavailable=nil;bot.diag.font=nil
    processLineOfSight=clearScene
    isKeyJustPressed=function() return false end
    VK_F1=nil;VK_F12=nil
    os.remove(bot.settings.path)
end
local function equal(value, expected, message)
    assert(value==expected, (message or 'value')..': expected '..tostring(expected)..', got '..tostring(value))
end
local function neutral()
    equal(pad[bot.config.controls.gasAddress],0,'gas')
    equal(pad[bot.config.controls.footBrakeAddress],0,'foot brake')
    equal(pad[bot.config.controls.handbrakeAddress],0,'handbrake')
    equal(pad.steer,0,'steer')
    equal(bot.applied().reverse,false,'reverse')
end
local total=0
local function test(name,fn)
 reset(); fn(); total=total+1; print('PASS '..name)
end
local function line(count, mode)
 local result={}
 for i=1,count do result[i]={x=0,y=(i-1)*2,z=0,speed=10,heading=0,drive=mode or 'FWD'} end
 return result
end
local function begin(route)
 bot.setRoute(route); bot.setSpeed(20)
 assert(bot.bump(1,route,1,'test'))
 assert(bot.S.bumpActive)
end
local function finish(route,distance)
 fakeNow=fakeNow+3
 bot.updateBump(1,0,-distance)
 equal(bot.S.bumpPhase,'coast')
 fakeNow=fakeNow+0.4
 bot.updateBump(1,0,-distance)
 equal(bot.S.bumpActive,false)
 fakeNow=fakeNow+4
 bot.setSpeed(20)
end

local function close(a,b,eps) assert(math.abs(a-b)<(eps or 0.001),tostring(a)..' differs from '..tostring(b)) end
local function observe(speed,gas,brake,obstacle,heading,elapsed,x)
 fakeNow=fakeNow+(elapsed or 1/30)
 return bot.classifier.observe(fakeNow,x or 0,0,speed,heading or 0,obstacle or math.huge,gas or 200,brake or 0)
end

local function writeSettings(text)
 local f=assert(io.open(bot.settings.path,'w'));f:write(text);f:close()
end
local function liveBegin()
 local route=line(40);bot.setRoute(route);bot.setSpeed(20)
 assert(bot.bump(1,route,1,'fixture'))
 return route
end

test('shipped settings parse and preserve all four profiles',function()
 local p=sourcePath:gsub('[^/]+$','dangis_vr.ini')
 local f=assert(io.open(p,'rb'));local text=f:read('*a');f:close()
 local cfg,profiles=bot.settings.parse(text);assert(cfg,profiles)
 assert(cfg.escape.enabled and cfg.adminChat.contextual and cfg.adminChat.quitEnabled)
 equal(cfg.vehicle.defaultProfile,'standard');assert(profiles.standard and profiles.cautious and profiles.sport and profiles.heavy)
end)

test('invalid and duplicate settings reject rather than partially apply',function()
 for _,text in ipairs({
  '[chat]\nenabled=maybe','[chat]\nenabled=true\nenabled=false',
  '[driving]\nbraking_deceleration=0','[recovery]\nattempt_limit=2.5',
  '[chat]\ndelay_min_seconds=5\ndelay_max_seconds=1','[vehiclez]\nhello=1',
  '[vehicles]\nmodel_999=sport','[vehicles]\nmodel_411=unknown',
  '[profile.heavy]\nspeed_scale=2','[driving]\nmax_speed_kmh=1e999',
  '[chat]\nunknown_field=true','[controls]\nsteering=xyz',
 }) do local cfg,err=bot.settings.parse(text);equal(cfg,nil);assert(type(err)=='string') end
end)

test('settings load is atomic and retains the previous valid configuration on failure',function()
 writeSettings('[driving]\nbraking_deceleration=3.2\n[vehicles]\ndefault_profile=heavy\n')
 assert(bot.settings.load());equal(bot.config.driving.brakingDeceleration,3.2);equal(bot.vehicles.activeName,'heavy')
 local profiles=bot.vehicles.presets
 writeSettings('[driving]\nbraking_deceleration=6\n[chat]\nenabled=bad\n')
 assert(not bot.settings.load());equal(bot.config.driving.brakingDeceleration,3.2);equal(bot.vehicles.presets,profiles)
end)

test('empty settings restore defaults and oversized files do not mutate them',function()
 writeSettings('');assert(bot.settings.load());equal(bot.config.vehicle.defaultProfile,'standard')
 writeSettings(string.rep('x',65537));assert(not bot.settings.load());equal(bot.config.vehicle.defaultProfile,'standard')
end)

test('reload requires pause or stop and refuses active recovery or typing',function()
 assert(not bot.settings.reloadAllowed())
 bot.S.manualPaused=true;assert(bot.settings.reloadAllowed())
 bot.S.bumpActive=true;assert(not bot.settings.reloadAllowed());bot.S.bumpActive=false
 bot.chat.pendingQuit={};assert(not bot.settings.reloadAllowed());bot.chat.pendingQuit=nil
 dialog=true;assert(not bot.settings.reloadAllowed());dialog=false
 bot.setPlaying(false);assert(bot.settings.reloadAllowed())
end)

test('F12 applies settings only after pause and F1 toggles diagnostics',function()
 writeSettings('[driving]\nmax_speed_kmh=80\n')
 VK_F12=12;isKeyJustPressed=function(key) return key==12 end
 bot.input.handleHotkeys();equal(bot.config.vehicle.maxSpeedKmh,0)
 bot.S.manualPaused=true;bot.input.handleHotkeys();equal(bot.config.vehicle.maxSpeedKmh,80)
 VK_F1=1;isKeyJustPressed=function(key) return key==1 end
 bot.input.handleHotkeys();equal(bot.config.diagnostics.enabled,false)
end)

test('Ctrl F12 explicitly marks a joined session without resetting on route restart',function()
 bot.chat.session.checks=4
 bot.S.manualPaused=true;physical=true
 VK_F12=12;isKeyJustPressed=function(key) return key==12 end
 bot.input.handleHotkeys()
 equal(bot.chat.session.checks,0);equal(bot.chat.session.joinedAt,fakeNow)
 bot.route.clearTransientState();equal(bot.chat.session.joinedAt,fakeNow)
end)

test('model mapping selects a profile and falls back for unknown models',function()
 bot.config.vehicle.modelProfiles[411]='sport'
 bot.config.vehicle.defaultProfile='cautious'
 bot.api.carPointer=function() return 0x3000000 end
 local model=411
 bot.Mem.readWord=function(address) equal(address,0x3000022);return model end
 bot.vehicles.update(true);equal(bot.vehicles.activeName,'sport');equal(bot.vehicles.model,411)
 bot.planner.cache={fixture=true};model=400;bot.vehicles.update(true)
 equal(bot.vehicles.activeName,'cautious');equal(bot.planner.cache,nil)
 bot.api.carPointer=nil;bot.vehicles.update(true);equal(bot.vehicles.activeName,'cautious');equal(bot.vehicles.model,nil)
end)

test('profile and global speed caps never exceed the recorded target',function()
 bot.vehicles.activeName='heavy';close(bot.vehicles.speedLimit(20),15)
 bot.config.vehicle.maxSpeedKmh=36;close(bot.vehicles.speedLimit(20),10)
 equal(bot.vehicles.speedLimit(0),0)
 assert(bot.vehicles.driving('brakingDeceleration')<bot.config.driving.brakingDeceleration)
 local normal=bot.planner.steering(10,20,0,1/30)
 bot.vehicles.activeName='sport'
 assert(bot.planner.steering(10,20,0,1/30)>normal)
end)

test('vehicle or model changes interrupt an active escape',function()
 bot.api.carPointer=function() return 0x3000000 end
 local model=411;bot.Mem.readWord=function() return model end
 bot.vehicles.update(true);liveBegin();assert(bot.S.bumpActive)
 model=400;bot.vehicles.update(true)
 assert(not bot.S.bumpActive);assert(bot.S.manualPaused);neutral()
end)

test('clear scene selects checked straight reverse',function()
 liveBegin();assert(bot.S.bumpActive);equal(bot.S.bumpPlan.side,0);equal(bot.S.bumpSteer,0)
 bot.setSpeed(0);bot.updateBump(1,0,0);equal(bot.applied().reverse,true)
end)

test('blocked straight corridor selects a checked left path and bounded steering',function()
 processLineOfSight=function(ax,ay,az,bx,by,bz,...)
  local hit,point=clearScene(ax,ay,az,bx,by,bz)
  if point then return hit,point end
  if by < -3.01 and by > -6 and math.abs(bx)<0.01 then return true,{pos={bx,by,bz},normal={0,1,0}} end
  return false
 end
 liveBegin();assert(bot.S.bumpActive);equal(bot.S.bumpPlan.side,1);equal(bot.S.bumpSteer,-32)
end)

test('repeat attempts prefer a different clear escape direction',function()
 local seen={}
 bot.escape.scan=function(car,side,distance) seen[#seen+1]=side;return true end
 bot.escape.lastSide=1
 local plan=bot.escape.choose(1,2,4);equal(plan.side,-1);equal(seen[1],-1)
end)

test('right path is selected when other candidates are blocked',function()
 bot.escape.scan=function(car,side) return side==-1,'blocked' end
 liveBegin();assert(bot.S.bumpActive);equal(bot.S.bumpPlan.side,-1);equal(bot.S.bumpSteer,32)
end)

test('missing collision capability holds neutral without consuming an attempt',function()
 processLineOfSight=nil;liveBegin()
 assert(not bot.S.bumpActive);assert(bot.S.manualPaused);equal(bot.memory.attempts,0);neutral()
 equal(bot.manager.sharedState('PLAYING'),'RECOVERY_BLOCKED')
end)

test('failed and malformed queries never count as clear',function()
 processLineOfSight=function() error('query failure') end
 equal(bot.escape.scan(1,0,4),nil)
 processLineOfSight=function() return nil end
 equal(bot.escape.scan(1,0,4),nil)
 processLineOfSight=function() return 0 end
 equal(bot.escape.scan(1,0,4),nil)
end)

test('no ground, steep slopes and incomplete ground data stop escape',function()
 processLineOfSight=function() return false end
 local clear,why=bot.escape.scan(1,0,4);equal(clear,false);assert(why:find('ground'))
 processLineOfSight=function(ax,ay,az,bx,by,bz)
  if az-bz>1 then return true,{pos={bx,by,-0.5},normal={0,0,0.2}} end
  return false
 end
 equal(bot.escape.scan(1,0,4),false)
 processLineOfSight=function(ax,ay,az,bx,by,bz)
  if az-bz>1 then return true,{} end
  return false
 end
 equal(bot.escape.scan(1,0,4),nil)
end)

test('front swing clearance is required for a curved escape',function()
 processLineOfSight=function(ax,ay,az,bx,by,bz,...)
  if ay>0 and by>0 and math.abs(bx-ax)>0.1 then return true,{} end
  return clearScene(ax,ay,az,bx,by,bz)
 end
 assert(bot.escape.scan(1,0,4));equal(bot.escape.scan(1,1,4),false)
end)

test('new obstacle during reverse cancels before another reverse command',function()
 liveBegin();bot.setSpeed(0);bot.updateBump(1,0,0)
 processLineOfSight=function() return true,{} end
 fakeNow=fakeNow+0.16;bot.updateBump(1,0,-0.3)
 assert(not bot.S.bumpActive);assert(bot.S.manualPaused);equal(bot.memory.attempts,1);neutral()
end)

test('reverse speed limit releases reverse throttle until speed drops',function()
 liveBegin();bot.setSpeed(-4);bot.updateBump(1,0,0)
 equal(bot.applied().reverse,false)
 bot.setSpeed(-2);bot.updateBump(1,0,0)
 equal(bot.applied().reverse,true)
end)

test('live freeze still preempts an active curved escape',function()
 bot.escape.scan=function(car,side) return side==1,'blocked' end
 liveBegin();bot.setSpeed(0);bot.updateBump(1,0,0)
 flag('freeze','1\n');bot.pedals(0,0,true,'BUMP')
 equal(bot.owner(),'FREEZE');neutral();equal(bot.memory.attempts,0)
end)

test('disabling escape checks retains straight legacy recovery',function()
 bot.config.escape.enabled=false;processLineOfSight=nil
 liveBegin();assert(bot.S.bumpActive);equal(bot.S.bumpPlan,nil);equal(bot.S.bumpSteer,0)
end)

test('first check excludes repeat, historical, waiting and unknown join claims',function()
 assert(bot.chat.eligible('ka cia darai krw',{checkNumber=1}))
 for _,phrase in ipairs({'bl vel jus','as jau vakar buvau tikrintas','zjbs tik prisijungiau','sakyk greiciau ka spaust'}) do
  assert(not bot.chat.eligible(phrase,{checkNumber=1}))
 end
 assert(bot.chat.eligible('bl vel jus',{checkNumber=2}))
end)

test('third check and frequent claims require their actual session counters',function()
 assert(not bot.chat.eligible('nu jau trecia karta bl',{checkNumber=2}))
 assert(bot.chat.eligible('nu jau trecia karta bl',{checkNumber=3}))
 assert(not bot.chat.eligible('nu jau trecia karta bl',{checkNumber=4}))
 assert(not bot.chat.eligible('as jau zinau sita testa mintinai :DD',{checkNumber=4}))
 assert(bot.chat.eligible('as jau zinau sita testa mintinai :DD',{checkNumber=5}))
 assert(not bot.chat.eligible('as visa diena testuose nx',{checkNumber=5}))
 fakeNow=fakeNow+7200;assert(bot.chat.eligible('as visa diena testuose nx',{checkNumber=5}))
end)

test('explicit session marker enables recent phrases only within its window',function()
 bot.chat.markJoined();assert(bot.chat.eligible('zjbs tik prisijungiau',{checkNumber=1}))
 fakeNow=fakeNow+181;assert(not bot.chat.eligible('zjbs tik prisijungiau',{checkNumber=1}))
end)

test('completion counter is deduplicated and excludes local harnesses',function()
 assert(bot.chat.complete('arbotas','token1',false));equal(bot.chat.session.checks,1)
 assert(not bot.chat.complete('arbotas','token1',false));equal(bot.chat.session.checks,1)
 bot.config.adminChat.includeLocalTests=true
 assert(bot.chat.complete('freeze','local',true));equal(bot.chat.session.checks,1)
 equal(bot.chat.queue[1].checkNumber,1)
end)

test('reply chance can suppress messages without losing observed check count',function()
 bot.config.adminChat.replyChance=0
 assert(not bot.chat.complete('arbotas','skip',false));equal(bot.chat.session.checks,1);equal(#bot.chat.queue,0)
end)

test('context shuffle uses every eligible phrase before repeating',function()
 bot.chat.phrases={'ka cia darai krw','nu ir ka dabar','bl vel jus','as jau vakar buvau tikrintas'}
 local first=bot.chat.pick({checkNumber=1});local second=bot.chat.pick({checkNumber=1})
 assert(first~=second);assert(first~='bl vel jus' and second~='bl vel jus')
 assert(bot.chat.pick({checkNumber=1})~=second)
 local found={}
 for i=1,3 do found[bot.chat.pick({checkNumber=2})]=true end
 assert(found['bl vel jus']);assert(not found['as jau vakar buvau tikrintas'])
end)

test('phrase group tags are metadata and are never typed',function()
 local f=assert(io.open(bot.config.adminChat.phraseFile,'w'))
 f:write('[repeat] custom repeat\n[general] plain text\n[unknown] invalid\n');f:close()
 equal(bot.chat.loadPhrases(),2);equal(bot.chat.phrases[1],'custom repeat')
 assert(not bot.chat.eligible('custom repeat',{checkNumber=1}))
 equal(bot.chat.pick({checkNumber=1}),'plain text')
end)

test('all disabled groups produce no eligible phrase',function()
 bot.chat.phrases={'ka cia darai krw','bl vel jus'}
 bot.config.adminChat.generalPhrases=false;bot.config.adminChat.repeatPhrases=false
 equal(bot.chat.pick({checkNumber=10}),nil)
end)

test('context selection can be disabled to restore the full pool',function()
 bot.config.adminChat.contextual=false
 for _,phrase in ipairs({'bl vel jus','as jau vakar buvau tikrintas','zjbs tik prisijungiau'}) do
  assert(bot.chat.eligible(phrase,{checkNumber=1}))
 end
end)

test('stop and restart clear pending actions but preserve session counters',function()
 bot.chat.complete('arbotas','one',false);bot.route.stopAll()
 equal(bot.chat.session.checks,1);equal(#bot.chat.queue,0)
 bot.chat.markJoined();equal(bot.chat.session.checks,0);assert(bot.chat.session.joinedAt)
end)

test('diagnostics show target, profile, reason and actual chat waiting state',function()
 bot.telemetry.target={speed=12,branch='corner_braking'};bot.manager.sync()
 bot.chat.status='waiting for game focus'
 local text=table.concat(bot.diag.lines(),'\n')
 assert(text:find('43 km/h',1,true));assert(text:find('corner_braking',1,true));assert(text:find('standard',1,true))
 assert(text:find('waiting for game focus',1,true))
 bot.S.manualPaused=true;bot.manager.sync();text=table.concat(bot.diag.lines(),'\n')
 assert(text:find('target --',1,true))
end)

test('diagnostics render failures disable only the overlay',function()
 bot.pedals(100,0);renderCreateFont=function() error('render unavailable') end
 bot.diag.draw();assert(bot.diag.unavailable);equal(bot.applied().gas,100);equal(bot.owner(),'ROUTE')
end)

test('modern dashboard renders Lithuanian text through the existing renderer',function()
 local lines={}
 renderCreateFont=function() return 123 end
 renderDrawBox=function() end
 renderFontDrawText=function(font,text,x,y,color) lines[#lines+1]=text end
 -- 5.77.6 repair: the 5.72 restyle replaced the 9-line dashboard with a
 -- 260x128 card (title, version, state, speed, progress, key hint); the
 -- check now asserts that card's Lithuanian content instead of a line count.
 bot.diag.draw();assert(not bot.diag.unavailable)
 local all=table.concat(lines,'\n')
 assert(all:find('Dangis',1,true));assert(all:find('km/h',1,true))
 assert(all:find('Nustatymai',1,true) and all:find('Sl\235pti',1,true),'Lithuanian key hint (CP1257 \235 = ė)')
end)

flag('freeze');flag('dialog');flag('rotate')
test('old smooth setting without input key uses keyboard and digital steering',function()
 local cfg=assert(bot.settings.parse('[controls]\nsteering=smooth\n'))
 equal(cfg.controls.input,'keyboard');equal(cfg.controls.steering,'bangbang')
end)

print(string.format('%d expansion regression scenarios passed',total))
