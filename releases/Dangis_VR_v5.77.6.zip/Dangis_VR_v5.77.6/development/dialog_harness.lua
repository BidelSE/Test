-- Loads the shipped arbotas_auto.lua with a mocked SA-MP dialog in memory
-- (development only). The dialog text is placed byte by byte at the address
-- the script reads, exactly as SA-MP stores it (rows separated by \n).
local H = {}

function H.load(sourcePath, root)
    local f = assert(io.open(sourcePath, "rb")); local source = f:read("*a"); f:close()
    root = root or ((os.getenv("TMPDIR") or "/tmp") .. "/dangis_dialog_harness")
    os.execute("mkdir -p '" .. root .. "'")
    local state = {now = 10, memory = {}, focused = true, events = {}, tasks = {}, notes = {}}
    local SAMP, DIALOG, TEXT = 0x100000, 0x1000000, 0x3000000
    local env = setmetatable({}, {__index = _G})
    env._G = env
    env.os = setmetatable({clock = function() return state.now end}, {__index = os})
    local seed = 20261028
    env.math = setmetatable({random = function(m, n)
        seed = (1103515245 * seed + 12345) % 2147483648
        local r = seed / 2147483648
        if m == nil then return r end
        if n == nil then n = m; m = 1 end
        return m + math.floor(r * (n - m + 1))
    end}, {__index = math})
    env.getWorkingDirectory = function() return root end
    env.script_name, env.script_version = function() end, function() end
    env.printStringNow = function() end
    env.getModuleHandle = function() return SAMP end
    local u32 = {GetForegroundWindow = function() return state.focused and 1 or nil end,
        GetWindowThreadProcessId = function(_, pid) pid[0] = 42 end,
        keybd_event = function(vk, scan, flags) state.events[#state.events+1] = {vk = vk, flags = flags, t = state.now} end}
    local k32 = {IsBadReadPtr = function(addr) return state.memory[addr] ~= nil and 0 or 1 end,
        GetCurrentProcessId = function() return 42 end}
    local ffi = {cdef = function() end, load = function(name) return name == "user32" and u32 or k32 end,
        new = function() return {[0] = 0} end,
        cast = function(kind, addr) if kind == "void*" then return addr end; return {[0] = state.memory[addr]} end}
    local UI = {notify = function(text) state.notes[#state.notes+1] = text end}
    env.require = function(name)
        if name == "ffi" then return ffi end
        if name == "lib.dangis_ui" then return UI end
        return {}
    end
    env.wait = function(ms) coroutine.yield((ms or 0) / 1000) end
    env.lua_thread = {create = function(fn) state.tasks[#state.tasks+1] = coroutine.create(fn) end}
    local chunk = source .. "\nreturn {scan=function() return scanArbotasDialog() end, navigate=navigateAndClick," ..
        " events=DialogEvents, setSamp=function(v) samp=v end, signature=ArbotasSignature, main=main}\n"
    local fn
    if setfenv then fn = assert(loadstring(chunk, "@" .. sourcePath)); setfenv(fn, env)
    else fn = assert(load(chunk, "@" .. sourcePath, "t", env)) end
    local api = fn()
    api.setSamp(SAMP)
    -- Writes a dialog; style/id are written to the offsets the script reads.
    function state.show(text, opts)
        opts = opts or {}
        local m = {}
        m[SAMP + 0x21A0B8] = DIALOG
        m[DIALOG + 0x28] = opts.active == false and 0 or 1
        m[DIALOG + 0x04] = opts.id or 77
        m[DIALOG + 0x05] = opts.style or 2
        m[DIALOG + 0x34] = TEXT
        for i = 1, #text do m[TEXT + i - 1] = text:byte(i) end
        m[TEXT + #text] = 0
        state.memory = m
    end
    function state.close() state.memory[DIALOG + 0x28] = 0 end
    function state.pump(maxSteps)
        local steps = 0
        while #state.tasks > 0 and steps < (maxSteps or 10000) do
            local co = table.remove(state.tasks, 1)
            local ok, delay = coroutine.resume(co); assert(ok, delay)
            if coroutine.status(co) ~= "dead" then state.now = state.now + (delay or 0); state.tasks[#state.tasks+1] = co end
            steps = steps + 1
            if state.onStep then state.onStep(steps) end
        end
    end
    state.api = api
    -- Runs the script's own main() for `seconds` of game time, one frame per
    -- wait(0); helper threads (key presses) run in between.
    function state.run(seconds, frame, onFrame)
        frame = frame or 1/30
        state.mainCo = state.mainCo or coroutine.create(api.main)
        local stop = state.now + seconds
        local sleepUntil = state.now
        while state.now < stop do
            state.now = state.now + frame
            if onFrame then onFrame(state.now) end
            if state.now >= sleepUntil and coroutine.status(state.mainCo) ~= "dead" then
                local ok, delay = coroutine.resume(state.mainCo); assert(ok, delay)
                sleepUntil = state.now + (delay or 0)
            end
            for i = #state.tasks, 1, -1 do
                local co = state.tasks[i]
                if (state.taskUntil or {})[co] == nil or state.now >= state.taskUntil[co] then
                    local ok, delay = coroutine.resume(co); assert(ok, delay)
                    state.taskUntil = state.taskUntil or {}
                    if coroutine.status(co) == "dead" then table.remove(state.tasks, i)
                    else state.taskUntil[co] = state.now + (delay or 0) end
                end
            end
        end
    end
    function state.keys()
        local out = {}
        for _, e in ipairs(state.events) do
            if e.flags == 0 or e.flags == 1 then out[#out+1] = e.vk == 0x28 and "DOWN" or (e.vk == 0x0D and "ENTER" or tostring(e.vk)) end
        end
        return table.concat(out, " ")
    end
    return state
end

return H
