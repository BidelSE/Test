-- 5.78 rotation recovery integration tests: the real dangis_vr.lua with its
-- real lib/ modules, mocked game APIs and a deterministic simulated car
-- (development/sim_harness.lua). Simulated tests, not in-game tests.
-- Usage: texlua development/test_rotation.lua   (or luajit)
package.path = "development/?.lua;" .. package.path
local Sim = require("sim_harness")
local INI = Sim.read("dangis_vr.ini")
local ADMIN = Sim.read("dangis_admin_phrases.txt")
local ROT = Sim.read("dangis_rotation_phrases.txt")
local DT = 1/30
local W, S, A, D = 0x57, 0x53, 0x41, 0x44

local pools = {}
for group, text in ROT:gmatch("%[(%w+)%]%s+([^\r\n]+)") do pools[text:lower()] = group end

local function line(x, y0, step, n, speed, drive)
    local pts = {}
    for i = 0, n-1 do pts[#pts+1] = {x=x, y=y0+i*step, z=10, speed=speed or 15, heading=step > 0 and 0 or 180, drive=drive or "FWD"} end
    return Sim.routeText(pts)
end

-- An 11 m street between walls: too narrow for a one-sweep U-turn.
local NARROW = {{-5.5, 0, -5.5, 600}, {5.5, 0, 5.5, 600}}

local total = 0
local function test(name, fn)
    fn(); total = total + 1; print("PASS " .. name)
end
local function equal(a, b, m) if a ~= b then error((m or "value") .. ": expected " .. tostring(b) .. ", got " .. tostring(a), 2) end end

-- World with route1 northbound along x=0 plus optional extra routes.
local function world(opts)
    opts = opts or {}
    local files = {{"dangis_vr.ini", opts.ini or INI}, {"dangis_admin_phrases.txt", ADMIN},
        {"dangis_rotation_phrases.txt", ROT}, {"dangis_paths/route1.txt", opts.route1 or line(0, 0, 2, 300, opts.speed)}}
    for _, extra in ipairs(opts.routes or {}) do files[#files+1] = extra end
    local sim = Sim.new({root=".", tag=opts.tag or "rot", files=files, x=0, y=opts.y or 0, z=10.6, heading=opts.heading or 0,
        seed=opts.seed or 7, walls=opts.walls, obstacles=opts.obstacles, terrain=opts.terrain, selfCollision=opts.selfCollision,
        grip=opts.grip == nil and 8 or (opts.grip or nil)})
    sim.groundZ = 10.0
    sim.bot.loop.initialize()
    sim.bot.CONFIG.controls.input = opts.input or "keyboard"
    if opts.legacy then
        -- W-reaction mode (rotation.reverse_spin_enabled = false).
        sim.bot.CONFIG.rotation.jturnEnabled = false
        sim.bot.recovery.rotation:configure(sim.bot.CONFIG.rotation)
    end
    if opts.configure then opts.configure(sim.bot) end
    if opts.keyLag then
        -- MoonLoader's isKeyDown follows the game window's key messages, which
        -- the game reads at the start of a frame: a key the bot releases still
        -- reads as down for the rest of that frame (seen in your own logs as
        -- ROUTE -> MANUAL -> ROUTE flickers of one or two frames).
        local down, seen = {}, {}
        local u32 = sim.bot.Win32.u32
        local send = u32.keybd_event
        u32.keybd_event = function(vk, scan, flags) down[vk] = flags ~= 2; return send(vk, scan, flags) end
        sim.env.isKeyDown = function(vk) return seen[vk] == true or (sim.physical and sim.physical[vk] == true) end
        local frame = sim.frame
        sim.frame = function(self, dt, hot) for k, v in pairs(down) do seen[k] = v end; return frame(self, dt, hot) end
    end
    sim.stats = {maxHold={}, hold={}, wFight=0, frames=0, phases={}, sWithSteer=false}
    sim:frame(DT, {[0x79]=true}) -- F10
    assert(sim.bot.isPlaying(), "playback started")
    return sim
end

-- Signed distance of the car from the active route near the current index.
local function routeOffset(sim)
    local route, index = sim.bot.getRoute(), sim.bot.getIndex()
    local best, offset = math.huge, nil
    for i = math.max(1, index-5), math.min(#route-1, index+15) do
        local a, b = route[i], route[i+1]
        local dx, dy = b.x-a.x, b.y-a.y
        local len2 = dx*dx+dy*dy
        if len2 > 1e-6 then
            local t = math.max(0, math.min(1, ((sim.car.x-a.x)*dx+(sim.car.y-a.y)*dy)/len2))
            local d = (sim.car.x-a.x-dx*t)^2+(sim.car.y-a.y-dy*t)^2
            if d < best then best = d; offset = ((sim.car.x-a.x)*(-dy)+(sim.car.y-a.y)*dx)/math.sqrt(len2) end
        end
    end
    return offset or 0
end

-- One frame plus invariant checks on the synthetic keyboard state.
local function step(sim, dt)
    dt = dt or DT
    sim:frame(dt)
    local held = sim.bot.Win32.driveHeld
    assert(not (held[W] and held[S]), "W and S held together")
    assert(not (held[A] and held[D]), "A and D held together")
    local r = sim.bot.recovery.rotation
    local st = sim.stats
    st.frames = st.frames + 1
    if r.phase then st.phases[r.phase] = true end
    for _, vk in ipairs({W, S, A, D}) do
        if held[vk] then st.hold[vk] = (st.hold[vk] or 0) + dt else st.hold[vk] = 0 end
        if sim.bot.manager.owner == "ROTATE" then st.maxHold[vk] = math.max(st.maxHold[vk] or 0, st.hold[vk]) end
    end
    if r.phase == "FIGHT" or (r.phase == "HOLD" and st.lastPhase == "FIGHT") then
        if held[A] or held[D] then st.steerInFight = true end
    end
    if st.lastPhase == "FIGHT" and held[W] then st.wFight = st.wFight + dt end
    if st.lastPhase == "FIGHT" then st.fightTime = (st.fightTime or 0) + dt end
    if held[S] and (held[A] or held[D]) and sim.bot.manager.owner == "ROTATE" then st.sWithSteer = true end
    -- Outside the deliberate reverse legs, S must never push an already fast backwards roll.
    -- (The reverse spin is a deliberate reverse move as well.)
    if sim.bot.manager.owner == "ROTATE" and held[S] and sim.car.v < -3.2 and r.phase ~= "REVERSE" and r.phase ~= "JTURN" then st.sWhileFastBack = true end
    -- S held for the whole reverse move: in a reverse leg whose clearance is
    -- confirmed, S is never released below the ceiling (minus the coasting
    -- band), and the car never runs away.
    if r.phase == "REVERSE" and st.lastPhase == "REVERSE" then
        local cfg = r.cfg
        -- (car.v is read after this frame's physics, so a margin either side)
        if not held[S] and sim.car.v < -0.05 and -sim.car.v < cfg.reverseMaxSpeed - cfg.coastBand - 0.3 and r.legPendingSince == nil then
            st.reverseGaps = (st.reverseGaps or 0) + 1
        end
        if held[S] then st.reverseS = (st.reverseS or 0) + 1 end
        st.maxReverse = math.max(st.maxReverse or 0, -sim.car.v)
    end
    -- Rotation reactions are typed only once driving has resumed on the route.
    if sim.chatOpen and not st.chatWasOpen then
        st.typingStarts = (st.typingStarts or 0) + 1
        -- (A rotation detected in this very frame may still race the T press; it is cancelled with Esc.)
        local job = sim.bot.chat.job
        if job and job.eventKind == "rotation_incident" then
            assert(st.lastPhase == nil, "rotation reaction typed during recovery (" .. tostring(st.lastPhase) .. ")")
        end
    end
    -- While chat owns the keyboard the car coasts unsteered: that may only
    -- happen when it cannot matter (stopped, or a straight clear stretch).
    if sim.chatOpen then
        if not st.chatWasOpen then st.chatStartOffset = routeOffset(sim); st.chatStartSpeed = math.abs(sim.car.v) end
        if math.abs(sim.car.v) > 2.5 then
            st.maxChatDrift = math.max(st.maxChatDrift or 0, math.abs(routeOffset(sim) - st.chatStartOffset))
            st.movingChat = (st.movingChat or 0) + dt
        end
    end
    st.chatWasOpen = sim.chatOpen
    st.lastPhase = r.phase
    return sim
end

local function log(sim) return Sim.read(sim.work .. "/dangis_vr_debug.log") end

local function handoffLog(sim)
    local speed, side, yaw, heading, dist
    for a, b, c, d, e in log(sim):gmatch("handoff: speed ([%d%.%-]+) m/s, sideways ([%d%.%-]+) m/s, yaw ([%d%.%-]+) deg/s, heading error ([%d%.%-]+), route ([%d%.%-]+) m") do
        speed, side, yaw, heading, dist = tonumber(a), tonumber(b), tonumber(c), tonumber(d), tonumber(e)
    end
    return speed and {speed=speed, sideways=side, yaw=yaw, heading=heading, route=dist}
end
local function assertStableHandoff(sim, cfg)
    local h = handoffLog(sim)
    assert(h, "handoff logged")
    assert(h.sideways <= cfg.handoffLateral, "no sideways slide at handoff: " .. h.sideways)
    assert(h.yaw >= 0 and h.yaw <= cfg.handoffRate, "no yaw at handoff: " .. h.yaw)
    assert(math.abs(h.heading) <= cfg.handoffHeading, "aligned at handoff: " .. h.heading)
    assert(h.route <= cfg.connectDistance, "on the route at handoff: " .. h.route)
    assert(h.speed <= cfg.handoffMaxSpeed, "manageable speed at handoff: " .. h.speed)
    return h
end

local function run(sim, seconds, until_)
    for i = 1, math.floor(seconds/DT + 0.5) do
        step(sim)
        if until_ and until_(sim) then return true end
    end
    return false
end

-- Reactions wait for a safe moment to type (stopped or a straight stretch),
-- so tests wait for them instead of expecting them after a fixed time.
local function awaitMessages(sim, n, seconds)
    run(sim, seconds or 25, function(s) return #s.messages >= n end)
    run(sim, 3) -- and nothing extra right after
end

local function flip(sim)
    sim.car.heading = (sim.car.heading + 180) % 360
    sim.car.v = -sim.car.v
end

local function recovered(sim)
    return sim.bot.recovery.rotation.phase == nil and sim.bot.manager.owner == "ROUTE"
end

local function angleTo(h, target) return math.abs((h - target + 180) % 360 - 180) end


test("W-reaction mode, single rotation, open road: W reaction then one-sweep U-turn at once, no reversing", function()
    local sim = world({tag="uturn", legacy=true})
    run(sim, 8)
    flip(sim)
    local flipAt = sim.now
    local sDuringRecovery = false
    assert(run(sim, 40, function(s)
        if s.bot.manager.owner == "ROTATE" and s.bot.Win32.driveHeld[S] then sDuringRecovery = true end
        return recovered(s)
    end), "recovers")
    assert(sim.stats.phases.UTURN, "turned round in one sweep")
    assert(not sim.stats.phases.REVERSE, "no reverse-and-turn needed")
    assert(not sDuringRecovery, "S never used")
    assert(not sim.stats.steerInFight, "no A/D during the W reaction")
    assert(sim.now - flipAt < 10, "quick recovery: " .. (sim.now - flipAt) .. " s")
    assert(log(sim):find("U-turn to the %a+ fits"))
    awaitMessages(sim, 1)
    equal(#sim.messages, 1, "message after the return")
    assert(angleTo(sim.car.heading, 0) < 25)
end)

test("W-reaction mode, single rotation, narrow road: no room for a U-turn, reverse-and-turn instead", function()
    local sim = world({tag="single", walls=NARROW, legacy=true})
    run(sim, 8)
    local flipIndex = sim.bot.getIndex()
    assert(sim.car.v > 8, "driving before the rotation")
    flip(sim)
    assert(run(sim, 70, recovered), "recovers without manual takeover")
    assert(sim.stats.wFight <= 0.5 + 2*DT and sim.stats.wFight >= 0.5 - 2*DT, "W reaction " .. sim.stats.wFight)
    assert(not sim.stats.steerInFight, "no A/D during the initial reaction")
    assert(sim.stats.sWithSteer, "reverses while steering to regain orientation")
    assert(not sim.stats.sWhileFastBack, "S never accelerates an already fast backwards roll")
    assert((sim.stats.reverseS or 0) > 10 and not sim.stats.reverseGaps, "reverse legs: S held for the whole move")
    local rc = sim.bot.recovery.rotation.cfg
    assert(sim.stats.maxReverse <= rc.reverseMaxSpeed + rc.runawayMargin, "no runaway reversing, max " .. sim.stats.maxReverse)
    for vk, t in pairs(sim.stats.maxHold) do assert(t <= 3.1, string.format("key %x held %.2fs", vk, t)) end
    equal(#sim.messages, 0, "nothing typed before the car is back on the route")
    equal(sim.bot.getName(), "route1")
    assert(sim.bot.S.manualPaused == false)
    awaitMessages(sim, 1)
    equal(#sim.messages, 1, "one frustrated message after returning to the route")
    assert(pools[sim.messages[1].text] == "single", "message from the single-rotation pool: " .. sim.messages[1].text)
    assert(angleTo(sim.car.heading, 0) < 25, "driving along the route again, heading " .. sim.car.heading)
    assert(sim.bot.getIndex() > flipIndex, "route progress continues")
    assert(sim.car.v > 5, "accelerating under the original controller")
    assert(log(sim):find("v5.77 driving resumes", 1, true))
    assert(log(sim):find("no room for a one-sweep U-turn", 1, true))
    assert(not sim.stats.phases.UTURN)
end)

test("clean announcements: each recovery stage is shown once, in order", function()
    local route2 = line(9, 598, -2, 300, 15)
    for _, case in ipairs({{tag="announce", routes={}, expect={"Apsukimas!", "Apsisukama", "Grįžta į maršrutą „route1“"}},
        {tag="announce2", routes={{"dangis_paths/route2.txt", route2}}, expect={"Apsukimas!", "pereinama į maršrutą „route2“", "Grįžta į maršrutą „route2“"}}}) do
        local sim = world({tag=case.tag, routes=case.routes})
        local UI = sim.env.require("lib.dangis_ui")
        local shown = {}
        local original = UI.notify
        UI.notify = function(text, ms)
            if ms and ms > 1000 then shown[#shown+1] = UI.translate(text) end
            return original(text, ms)
        end
        run(sim, 8); local from = #shown; flip(sim)
        assert(run(sim, 70, recovered))
        local list = {}
        for i = from+1, #shown do list[#list+1] = shown[i] end
        local seen = {}
        for _, text in ipairs(list) do assert(not seen[text], "announced twice: " .. text); seen[text] = true end
        local pos = 0
        for _, want in ipairs(case.expect) do
            local found
            for i = pos+1, #list do if list[i]:find(want, 1, true) then found = i; break end end
            assert(found, "missing announcement '" .. want .. "' in: " .. table.concat(list, " | "))
            pos = found
        end
        assert(#list <= 5, "short, clean sequence: " .. table.concat(list, " | "))
        print("    " .. table.concat(list, "  ->  "))
    end
end)

test("W-reaction mode, two rotations: one incident, 3 s TOTAL resistance, 1-2 messages, recovers", function()
    local sim = world({tag="double", legacy=true})
    run(sim, 8)
    flip(sim)
    run(sim, 1.2)
    flip(sim)
    assert(run(sim, 80, recovered), "recovers")
    assert(sim.stats.fightTime <= 3.0 + 3*DT and sim.stats.fightTime >= 2.8, "incident reaction time " .. sim.stats.fightTime)
    assert(sim.stats.wFight <= sim.stats.fightTime + DT, "W only inside the reaction")
    awaitMessages(sim, 1)
    run(sim, 5)
    assert(#sim.messages >= 1 and #sim.messages <= 2, "messages " .. #sim.messages)
    for _, m in ipairs(sim.messages) do assert(pools[m.text] == "double" or pools[m.text] == "followup", m.text) end
    for vk, t in pairs(sim.stats.maxHold) do assert(t <= 3.1, string.format("key %x held %.2fs", vk, t)) end
    run(sim, 6)
    assert(angleTo(sim.car.heading, 0) < 25)
end)

test("three rotations in 10 s: brief resistance, pull over, wait for quiet, react, resume", function()
    local sim = world({tag="multi"})
    run(sim, 8)
    local flips = {}
    for i = 1, 3 do flip(sim); flips[#flips+1] = sim.now; run(sim, 1.0) end
    local lastFlip = flips[3]
    local planAfterQuiet
    assert(run(sim, 90, function(s)
        local r = s.bot.recovery.rotation
        if r.phase == "PLAN" or r.phase == "REVERSE" or r.phase == "ALIGN" or r.phase == "SETTLE" then
            planAfterQuiet = planAfterQuiet or s.now
        end
        return recovered(s)
    end), "recovers after the quiet period")
    assert(sim.stats.phases.PARKED, "waited parked")
    assert(sim.stats.wFight <= 3.0 + 0.6 + 3*DT, "resistance stays bounded " .. sim.stats.wFight)
    assert(planAfterQuiet - lastFlip >= 8 - 0.05, "quiet period respected")
    equal(#sim.messages, 0, "silent while parked and turning")
    awaitMessages(sim, 1)
    run(sim, 5)
    assert(#sim.messages >= 1 and #sim.messages <= 2, "messages " .. #sim.messages)
    assert(pools[sim.messages[1].text] == "multi", sim.messages[1].text)
    assert(log(sim):find("pull over to the", 1, true), "pull-over attempted")
end)

test("no confirmed space: stays neutrally stopped instead of parking", function()
    local walls = {{-3.2, 0, -3.2, 600}, {3.2, 0, 3.2, 600}}
    local sim = world({tag="nopark", walls=walls})
    run(sim, 8)
    for i = 1, 3 do flip(sim); run(sim, 1.0) end
    run(sim, 6, function(s) return s.bot.recovery.rotation.phase == "PARKED" end)
    assert(log(sim):find("no confirmed space to pull over", 1, true))
    equal(sim.bot.recovery.rotation.phase, "PARKED")
end)

test("route switching: a nearby opposite-direction route is preferred after a 180", function()
    local route2 = line(9, 598, -2, 300, 15)
    local sim = world({tag="switch", routes={{"dangis_paths/route2.txt", route2}}})
    run(sim, 8)
    flip(sim)
    assert(run(sim, 80, recovered), "recovers")
    equal(sim.bot.getName(), "route2", "switched to the convenient route")
    -- Handed over only once stable, aligned and within reach of route2
    -- (directly after the U-turn when it ends close enough, else via APPROACH).
    assertStableHandoff(sim, sim.bot.recovery.rotation.cfg)
    local text = log(sim)
    assert(text:find("recovery switch route1 -> route2", 1, true))
    local y0 = sim.car.y
    run(sim, 6)
    assert(sim.car.y < y0 - 10, "driving southbound on route2")
    assert(math.abs(sim.car.x - 9) < 3, "on route2, x=" .. sim.car.x)
    -- The switch lasts for this playback only: F7 ends it and the route the
    -- player started is back for the next F10.
    sim:frame(DT, {[0x76]=true}); sim:frame(DT)
    equal(sim.bot.getName(), "route1", "started route restored when playback ends")
    equal(#sim.bot.getRoute(), 300, "with its own points")
end)

test("route switching: a close route behind a wall is rejected (not reachable)", function()
    local route2 = line(9, 598, -2, 300, 15)
    local sim = world({tag="wall", routes={{"dangis_paths/route2.txt", route2}}, walls={{5, 0, 5, 600}}})
    run(sim, 8)
    flip(sim)
    assert(run(sim, 80, recovered), "recovers")
    equal(sim.bot.getName(), "route1")
    assert(log(sim):find("route2#%d+ [^;]* rejected: building or object in the way"), "rejection logged")
    run(sim, 5)
    assert(angleTo(sim.car.heading, 0) < 25)
end)

test("route switching: the switch setting and old route files are respected", function()
    local route2 = line(9, 598, -2, 300, 15)
    local sim = world({tag="noswitch", routes={{"dangis_paths/route2.txt", route2}},
        configure=function(bot) bot.CONFIG.rotation.routeSwitching = false end})
    run(sim, 8); flip(sim)
    assert(run(sim, 80, recovered)); equal(sim.bot.getName(), "route1")
    -- An old three-field file (no heights) is never a recovery target.
    local legacy = {}
    for i = 0, 299 do legacy[#legacy+1] = string.format("{9}:{%d}:{15}", 598 - i*2) end
    sim = world({tag="legacy", routes={{"dangis_paths/temp.txt", table.concat(legacy, "\n") .. "\n"}}})
    run(sim, 8); flip(sim)
    assert(run(sim, 80, recovered)); equal(sim.bot.getName(), "route1")
end)

test("ordinary driving through an intersection never switches routes", function()
    local cross = {}
    for i = -60, 60 do cross[#cross+1] = {x=i*2, y=200, z=10, speed=15, heading=270, drive="FWD"} end
    local sim = world({tag="cross", routes={{"dangis_paths/cross.txt", Sim.routeText(cross)}}})
    run(sim, 40, function(s) assert(s.bot.getName() == "route1"); return s.car.y > 260 end)
    assert(sim.car.y > 260, "passed the intersection")
    equal(sim.bot.getName(), "route1"); equal(sim.bot.recovery.rotation.phase, nil)
end)

test("no oscillation: after a switch, the abandoned route is not chosen back for a minor gain", function()
    local route2 = line(9, 598, -2, 500, 15)
    local sim = world({tag="osc", routes={{"dangis_paths/route2.txt", route2}}})
    run(sim, 8); flip(sim)
    assert(run(sim, 80, recovered)); equal(sim.bot.getName(), "route2")
    run(sim, 4)
    assert(sim.bot.isPlaying() and sim.car.y > 20, "still driving on route2")
    flip(sim)
    assert(run(sim, 90, recovered))
    equal(sim.bot.getName(), "route2", "stays on route2 instead of flip-flopping")
end)

test("pushed far off the road: the search widens after failed attempts and it drives back by itself", function()
    -- (W-reaction mode: the car is still in its recovery when it is pushed.)
    local sim = world({tag="farroute", legacy=true})
    run(sim, 8); flip(sim)
    run(sim, 2)
    -- Pushed 45 m off the road between samples (not a teleport-sized jump per frame).
    for i = 1, 30 do sim.car.x = sim.car.x + 1.5; step(sim) end
    sim.car.v = 0
    assert(run(sim, 60, recovered), "drives back to the route on its own")
    assert(log(sim):find("no recorded point within search distance", 1, true), "first attempts used the normal search distance")
    equal(sim.bot.S.manualPaused, false, "never a manual pause")
end)

test("no reachable route at all: neutral waiting with bounded retries, then automatic recovery", function()
    local sim = world({tag="noroute"})
    run(sim, 8); flip(sim)
    run(sim, 2)
    -- 120 m away: beyond even the widened search (3 x 28 m).
    for i = 1, 80 do sim.car.x = sim.car.x + 1.5; step(sim) end
    sim.car.v = 0
    local waits = 0
    run(sim, 25, function(s)
        if s.bot.recovery.rotation.phase == "WAIT" then waits = waits + 1 end
        for _, vk in ipairs({W, S, A, D}) do if s.bot.Win32.driveHeld[vk] and s.bot.recovery.rotation.phase == "WAIT" then error("keys held while waiting") end end
    end)
    assert(waits > 0, "waits")
    assert(sim.bot.recovery.rotation.phase ~= nil, "still owns the controls")
    equal(sim.bot.S.manualPaused, false, "never a manual pause")
    assert(log(sim):find("no recorded point within search distance", 1, true))
    -- Conditions improve: back near the road.
    sim.car.x = 3
    assert(run(sim, 80, recovered), "recovers once a route is reachable")
end)

test("a new rotation interrupts typing: obsolete reaction is cancelled before Enter", function()
    local sim = world({tag="chatcancel"})
    run(sim, 8); flip(sim)
    assert(run(sim, 80, function(s) return s.chatOpen end), "reaction typing started after the return")
    run(sim, 0.1)
    flip(sim)
    assert(run(sim, 80, recovered))
    run(sim, 10)
    assert(#sim.cancelled >= 1, "partial reaction closed with Esc")
    for _, m in ipairs(sim.messages) do assert(pools[m.text], "only complete phrases submitted: " .. m.text) end
    assert(#sim.messages <= 2)
    assert(#sim.messages >= 1 and #sim.messages <= 2, "only reactions to the newest state are sent: " .. #sim.messages)
    for _, m in ipairs(sim.messages) do
        for _, c in ipairs(sim.cancelled) do assert(m.text ~= c.text, "obsolete reply never re-sent") end
    end
end)

test("no duplicate reaction for the same incident level; cooldown across incidents", function()
    local sim = world({tag="dupe"})
    run(sim, 8); flip(sim)
    assert(run(sim, 70, recovered)); awaitMessages(sim, 1); equal(#sim.messages, 1)
    run(sim, 2) -- outside the incident window, inside the 25 s chat cooldown
    flip(sim)
    assert(run(sim, 70, recovered))
    run(sim, 6)
    equal(#sim.messages, 1, "second incident within cooldown stays silent")
    assert(log(sim):find("rotation reaction skipped: cooldown", 1, true))
end)

test("no typing while a dialog is open; recovery waits and continues", function()
    local sim = world({tag="dialog"})
    run(sim, 8); flip(sim)
    run(sim, 0.8)
    sim.dialog = true
    run(sim, 6, function(s) assert(not s.chatOpen, "never types into a dialog"); assert(s.bot.manager.owner == "DIALOG") end)
    for _, vk in ipairs({W, S, A, D}) do assert(not sim.bot.Win32.driveHeld[vk]) end
    sim.dialog = false
    assert(run(sim, 80, recovered))
end)

test("stop during a reverse manoeuvre releases every key and ends the incident", function()
    local sim = world({tag="stop", walls=NARROW})
    run(sim, 8); flip(sim)
    assert(run(sim, 30, function(s) return s.bot.recovery.rotation.phase == "REVERSE" and s.bot.Win32.driveHeld[S] end))
    sim:frame(DT, {[0x76]=true}) -- F7
    for _, vk in ipairs({W, S, A, D}) do assert(not sim.bot.Win32.driveHeld[vk], "released") end
    equal(sim.bot.recovery.rotation.phase, nil); equal(sim.bot.isPlaying(), false)
    local before = #sim.keyLog
    run(sim, 3)
    for i = before+1, #sim.keyLog do assert(sim.keyLog[i].up, "no key pressed after stop") end
end)

test("vehicle change during recovery holds neutral; leaving the car ends it", function()
    local sim = world({tag="vehicle", walls=NARROW})
    run(sim, 8); flip(sim)
    assert(run(sim, 30, function(s) return s.bot.recovery.rotation.phase == "REVERSE" end))
    sim.car.handle = 2
    step(sim)
    equal(sim.bot.recovery.rotation.phase, "HOLD")
    for _, vk in ipairs({W, S, A, D}) do assert(not sim.bot.Win32.driveHeld[vk]) end
    assert(run(sim, 80, recovered), "continues safely in the new vehicle")
    run(sim, 2); flip(sim); run(sim, 1)
    sim.car.inCar = false
    step(sim); step(sim)
    equal(sim.bot.recovery.rotation.phase, nil)
    for _, vk in ipairs({W, S, A, D}) do assert(not sim.bot.Win32.driveHeld[vk]) end
end)

test("freeze keeps priority over rotation recovery", function()
    local sim = world({tag="freeze"})
    run(sim, 8); flip(sim)
    run(sim, 3)
    local f = assert(io.open(sim.work .. "/dangis_vr_freeze.flag", "w")); f:write("1"); f:close()
    run(sim, 2, function(s) assert(s.bot.manager.owner == "FREEZE"); for _, vk in ipairs({W, S, A, D}) do assert(not s.bot.Win32.driveHeld[vk]) end end)
    os.remove(sim.work .. "/dangis_vr_freeze.flag")
    assert(run(sim, 90, recovered), "continues after the freeze")
end)

test("manual override keeps working and recovery resumes afterwards", function()
    local sim = world({tag="manual", walls=NARROW})
    run(sim, 8); flip(sim)
    assert(run(sim, 30, function(s) return s.bot.recovery.rotation.phase == "REVERSE" end))
    sim.physical = {[W]=true}
    run(sim, 1, function(s) assert(s.bot.manager.owner == "MANUAL"); assert(not s.bot.Win32.driveHeld[S]) end)
    sim.physical = nil
    assert(run(sim, 80, recovered))
end)

test("high-speed rotation: braking against the slide, never S while rolling back fast", function()
    local sim = world({tag="fast", speed=30})
    run(sim, 14)
    assert(sim.car.v > 18, "fast before the rotation: " .. sim.car.v)
    flip(sim)
    assert(run(sim, 90, recovered))
    assert(not sim.stats.sWhileFastBack)
end)

test("very fast rotation: the car slides far past the old route index and still recovers", function()
    local sim = world({tag="veryfast", speed=40, route1=line(0, 0, 2, 600, 40)})
    run(sim, 20)
    assert(sim.car.v > 30, "very fast before the rotation: " .. sim.car.v)
    local y = sim.car.y
    flip(sim)
    assert(run(sim, 120, recovered), "recovers after a long slide")
    local resumed = log(sim):match("v5.77 driving resumes: route1 (%d+) %-> route1 (%d+)")
    assert(resumed, "resume logged")
    run(sim, 5)
    assert(angleTo(sim.car.heading, 0) < 25)
end)

test("W-reaction mode, wall on the rear-swing side: reverses with the opposite lock, never into the wall", function()
    -- A wall right next to the road on either side; the rear must swing away from it.
    for _, wx in ipairs({2.9, -2.9}) do
        local sim = world({tag="wallside" .. (wx > 0 and "E" or "W"), walls={{wx, 0, wx, 600}}, legacy=true,
            configure=function(bot) bot.CONFIG.rotation.uturnEnabled = false; bot.recovery.rotation:configure(bot.CONFIG.rotation) end})
        run(sim, 8)
        flip(sim)
        local closest = math.huge
        assert(run(sim, 90, function(s) closest = math.min(closest, math.abs(s.car.x - wx)); return recovered(s) end), "recovers")
        assert(closest > 1.0, "body stayed clear of the wall, closest " .. closest)
        assert(sim.stats.sWithSteer, "still reverses while steering")
        run(sim, 5)
        assert(angleTo(sim.car.heading, 0) < 25)
    end
    -- A parked car exactly where the rear would swing on the preferred lock.
    local sim = world({tag="rearcar", legacy=true, configure=function(bot) bot.CONFIG.rotation.uturnEnabled = false; bot.recovery.rotation:configure(bot.CONFIG.rotation) end})
    run(sim, 8)
    flip(sim)
    assert(run(sim, 5, function(s) return s.bot.recovery.rotation.phase == "HOLD" and s.car.v > -3.2 end))
    -- Facing south: rear is north, the car's right is west. Preferred lock here
    -- swings the rear west, so block the north-west.
    local ox, oy = sim.car.x - 2.4, sim.car.y + 5.0
    sim.obstacles[1] = {x=ox, y=oy, r=1.2}
    -- The body (2.4 x 1.0 half extents) never touches the parked car.
    local function gap(s)
        local h = math.rad(s.car.heading)
        local fx, fy = -math.sin(h), math.cos(h)
        local a, l = (ox-s.car.x)*fx+(oy-s.car.y)*fy, (ox-s.car.x)*(-fy)+(oy-s.car.y)*fx
        local dx, dy = math.max(0, math.abs(a)-2.4), math.max(0, math.abs(l)-1.0)
        return math.sqrt(dx*dx+dy*dy) - 1.2
    end
    local closestGap = math.huge
    assert(run(sim, 90, function(s) closestGap = math.min(closestGap, gap(s)); return recovered(s) end), "recovers")
    assert(closestGap > 0.2, "never touched the parked car, gap " .. closestGap)
    assert(log(sim):find("reversing with the opposite lock", 1, true), "steered the other way while reversing")
    assert(log(sim):find("-> REVERSE", 1, true), "still reverse-and-turn")
end)

test("wall on one side, U-turn allowed: it sweeps round towards the free side", function()
    for _, wx in ipairs({2.9, -2.9}) do
        local sim = world({tag="uwall" .. (wx > 0 and "E" or "W"), walls={{wx, 0, wx, 600}}})
        run(sim, 8)
        flip(sim)
        local closest = math.huge
        assert(run(sim, 60, function(s) closest = math.min(closest, math.abs(s.car.x - wx)); return recovered(s) end), "recovers")
        assert(closest > 1.0, "never near the wall, closest " .. closest)
        assert(sim.stats.phases.UTURN, "one-sweep U-turn used")
        local side = log(sim):match("U%-turn to the (%a+) fits")
        -- Facing south after the turn: east (+x) is the car's left.
        equal(side, wx > 0 and "right" or "left", "turned away from the wall")
    end
end)

test("obstacle behind the car: no reverse into it, recovery uses the free direction", function()
    local sim = world({tag="behind"})
    run(sim, 8)
    local x, y = sim.car.x, sim.car.y
    flip(sim)
    sim.car.v = 0
    -- After the turn the car faces south; its rear (north) is blocked.
    sim.obstacles[1] = {x=x, y=y+4.2, r=1.4}
    assert(run(sim, 90, recovered))
    assert(math.sqrt((sim.car.x-x)^2 + (sim.car.y-(y+4.2))^2) > 1.4 + 1.0, "never drove into the obstacle")
end)

test("recorded reverse leg is never driven forwards by recovery", function()
    local sim = world({tag="back", route1=line(0, 0, 2, 300, -3, "BACK"), heading=180})
    run(sim, 3)
    flip(sim); sim.car.v = 0
    run(sim, 40, recovered)
    for vk, t in pairs(sim.stats.maxHold) do assert(t <= 3.1) end
    equal(sim.bot.S.manualPaused, false)
end)

test("gamepad backend: same incident flow without keyboard driving events", function()
    local sim = world({tag="pad", input="gamepad"})
    run(sim, 8); flip(sim)
    assert(run(sim, 80, recovered))
    awaitMessages(sim, 1)
    equal(#sim.messages, 1)
end)
-- ---------------------------------------------------------------------------
-- 5.78 review regressions.

-- A route that is straight for ~120 m and then a long left curve.
local function curvy(n)
    local pts, x, y, h = {}, 0, 0, 0
    for i = 1, n or 400 do
        pts[#pts+1] = {x=x, y=y, z=10, speed=15, heading=h, drive="FWD"}
        if i > 60 then h = h + 1.2 end
        local rad = math.rad(h)
        x, y = x - math.sin(rad)*2, y + math.cos(rad)*2
    end
    return Sim.routeText(pts)
end

test("U-turn finishing while sliding: no handoff until the slide and yaw are gone", function()
    local sim = world({tag="uslide"})
    local cfg = sim.bot.recovery.rotation.cfg
    run(sim, 8)
    flip(sim)
    -- Keep the car sliding sideways for 1 s once the U-turn has brought it round.
    local slideUntil
    local handedOverWhileSliding = false
    assert(run(sim, 40, function(s)
        local r = s.bot.recovery.rotation
        if not slideUntil and r.phase == "SETTLE" then slideUntil = s.now + 1.0 end
        if slideUntil and s.now < slideUntil then
            local h = math.rad(s.car.heading)
            s.car.sx, s.car.sy = math.cos(h)*4, math.sin(h)*4 -- sideways, ~4 m/s
            if not r.phase then handedOverWhileSliding = true end
        end
        return recovered(s)
    end), "recovers")
    assert(slideUntil, "the U-turn ended in SETTLE (not straight in ready)")
    assert(not handedOverWhileSliding, "no handoff during the slide")
    assertStableHandoff(sim, cfg)
end)

test("open road: stable rolling handoff without a complete stop, v5.77 drives on", function()
    local sim = world({tag="roll"})
    local cfg = sim.bot.recovery.rotation.cfg
    run(sim, 8); flip(sim)
    assert(run(sim, 40, recovered))
    local h = assertStableHandoff(sim, cfg)
    assert(h.speed > 1.0, "handed over while still rolling: " .. h.speed)
    run(sim, 3)
    equal(sim.bot.manager.owner, "ROUTE")
    assert(sim.car.v > h.speed - 1, "the original controller keeps driving")
end)

test("handoff releases every recovery input; v5.77 starts from a clean state", function()
    local sim = world({tag="release"})
    local applies = {}
    local apply = sim.bot.manager.apply
    sim.bot.manager.apply = function(command)
        applies[#applies+1] = {owner=sim.bot.manager.owner, gas=command.gas or 0, brake=command.brake or 0,
            steer=command.steer or 0, reverse=command.reverse == true, t=sim.now}
        return apply(command)
    end
    run(sim, 8); flip(sim)
    local handoffAt
    assert(run(sim, 40, function(s)
        if not handoffAt and s.bot.manager.owner == "ROUTE" and s.stats.lastPhase == nil and s.stats.phases.SETTLE then handoffAt = s.now end
        return recovered(s)
    end))
    -- The last command written under ROTATE ownership is fully neutral.
    local lastRotate
    for i = #applies, 1, -1 do if applies[i].owner == "ROTATE" then lastRotate = applies[i]; break end end
    assert(lastRotate, "recovery wrote commands")
    equal(lastRotate.gas, 0); equal(lastRotate.brake, 0); equal(lastRotate.steer, 0); equal(lastRotate.reverse, false)
    -- No recovery-held key survives into ordinary driving, and the
    -- v5.77 steering filter starts from scratch.
    local S_ = sim.bot.S
    assert(S_.keyboardController == nil or S_.keyboardController.at >= lastRotate.t, "fresh keyboard steering state")
    local gas = sim.bot.levels()
    assert(gas <= 18*2+1, "v5.77 throttle ramps up from zero, got " .. gas)
end)

test("chat while driving: a reaction is never typed in a curve; the car keeps its steering", function()
    local sim = world({tag="chatcurve", route1=curvy(400)})
    run(sim, 6); flip(sim)
    assert(run(sim, 40, recovered))
    run(sim, 40)
    local st = sim.stats
    assert((st.maxChatDrift or 0) <= 1.6, "unsteered drift while typing: " .. tostring(st.maxChatDrift))
    local text = log(sim)
    assert(text:find("waiting to type: ", 1, true), "the reply waited for a safe moment")
    -- Either it found a straight/stopped moment or it expired; never typed into the curve.
    for _, m in ipairs(sim.messages) do assert(pools[m.text], m.text) end
end)

test("chat while driving: typing aborts (Esc) when the car drifts, and driving resumes", function()
    local sim = world({tag="chatabort"})
    run(sim, 8); flip(sim)
    assert(run(sim, 40, recovered))
    assert(run(sim, 30, function(s) return s.chatOpen end), "reply starts on the straight")
    assert(math.abs(sim.car.v) > 2.5, "typing started while rolling on a straight")
    -- A gust pushes the car off its line while it coasts.
    sim.car.heading = (sim.car.heading + 15) % 360
    local closedAt
    run(sim, 1.5, function(s) if not s.chatOpen then closedAt = s.now; return true end end)
    assert(closedAt, "chat closed")
    assert(#sim.cancelled >= 1, "the partial reply was cancelled with Esc")
    run(sim, 0.2)
    equal(sim.bot.manager.owner, "ROUTE", "driving owns the keyboard again")
    assert(log(sim):find("driving needs the keyboard", 1, true))
end)

test("chat while driving: other replies stay exactly v5.77 (typed when due, no waiting for a straight)", function()
    -- 5.77.4 keeps every non-rotation message as in v5.77; only the rotation
    -- reaction waits for a safe moment (see the two tests above).
    local sim = world({tag="chatadmin", route1=curvy(400)})
    sim.bot.CONFIG.adminChat.includeInferredTests = true
    run(sim, 11) -- into the curve
    sim.bot.chat.complete("freeze", sim.bot.chat.begin("freeze"), false)
    run(sim, 6)
    equal(#sim.messages, 1, "typed as in v5.77")
    assert(not log(sim):find("waiting to type", 1, true), "no 5.78 waiting for ordinary replies")
end)

test("route switching after a 180: correct direction, stable handoff, no loop", function()
    local route2 = line(9, 598, -2, 300, 15)
    local sim = world({tag="switch2", routes={{"dangis_paths/route2.txt", route2}}})
    local cfg = sim.bot.recovery.rotation.cfg
    run(sim, 8); flip(sim)
    assert(run(sim, 60, recovered))
    equal(sim.bot.getName(), "route2")
    assertStableHandoff(sim, cfg)
    local _, waits = log(sim):gsub("%-> WAIT", "")
    equal(waits, 0, "no failed attempts")
    local y0 = sim.car.y
    run(sim, 5)
    assert(sim.car.y < y0 - 10, "drives route2 in its recorded direction (south)")
end)

test("collision checks that fail never count as clear: the car does not move into the unknown", function()
    local sim = world({tag="losfail"})
    run(sim, 8)
    sim.losFault = function() return "error" end
    flip(sim)
    local moved = {}
    run(sim, 15, function(s)
        local r = s.bot.recovery.rotation
        moved[r.phase or "none"] = true
        assert(r.phase ~= nil, "never hands over without confirmed space")
    end)
    for _, phase in ipairs({"UTURN", "REVERSE", "ALIGN", "APPROACH", "PARK"}) do
        assert(not moved[phase], "no manoeuvre with failing collision checks: " .. phase)
    end
    assert(moved.WAIT, "waits and retries")
    -- Queries work again: automatic recovery.
    sim.losFault = function(n) if n % 7 == 0 then return "nil" end end -- occasional unknown answers still block that check
    run(sim, 2)
    sim.losFault = nil
    assert(run(sim, 60, recovered), "recovers once the checks work")
end)

test("collision checks that cannot finish (no budget) stay pending: no movement, bounded waiting", function()
    local sim = world({tag="nobudget"})
    run(sim, 8)
    sim.bot.CONFIG.rotation.probeBudget = 0
    flip(sim)
    local moved = {}
    run(sim, 12, function(s) moved[s.bot.recovery.rotation.phase or "none"] = true end)
    for _, phase in ipairs({"UTURN", "REVERSE", "ALIGN", "APPROACH"}) do assert(not moved[phase], phase) end
    assert(moved.WAIT, "gives up waiting after the timeout and retries")
    sim.bot.CONFIG.rotation.probeBudget = 100
    assert(run(sim, 60, recovered), "recovers when checks can run again")
end)

test("collision-check cost: at most the frame budget per recovery frame (plus one-off route planning)", function()
    local sim = world({tag="cost", routes={{"dangis_paths/route2.txt", line(9, 598, -2, 300, 15)}}})
    run(sim, 8); flip(sim)
    local over = 0
    local budget = sim.bot.CONFIG.rotation.probeBudget
    assert(run(sim, 60, function(s)
        if s.bot.manager.owner == "ROTATE" and (s.raysLastFrame or 0) > budget then over = over + 1 end
        return recovered(s)
    end))
    assert(over <= 3, "frames above the budget (route planning only): " .. over)
    -- Budget, plus at most one own-car re-cast for the last check, plus route planning.
    assert((sim.maxRotateRays or 0) <= budget + 4 + 5*12 + 16, "worst frame: " .. tostring(sim.maxRotateRays))
end)

test("W-reaction mode, repeated rotations during the U-turn and during the handoff dwell: interrupted, then recovered", function()
    local sim = world({tag="reinterrupt", legacy=true})
    run(sim, 8); flip(sim)
    assert(run(sim, 20, function(s) return s.bot.recovery.rotation.phase == "UTURN" end), "U-turn started")
    run(sim, 0.4)
    flip(sim)
    step(sim)
    local r = sim.bot.recovery.rotation
    assert(r.phase == "FIGHT" or r.phase == "HOLD", "the U-turn is interrupted at once")
    for _, vk in ipairs({A, D}) do assert(not sim.bot.Win32.driveHeld[vk], "lock released") end
    assert(run(sim, 30, function(s) return s.bot.recovery.rotation.phase == "SETTLE" end), "back to settling")
    flip(sim)
    step(sim)
    assert(sim.bot.recovery.rotation.phase ~= "SETTLE" and sim.bot.recovery.rotation.phase ~= nil, "a turn during the dwell cancels the handoff")
    assert(run(sim, 90, recovered), "recovers after repeated interruptions")
    equal(sim.bot.S.manualPaused, false)
end)

-- In-game report (5.78 r3): recovery checks hit the player's own car and the
-- rising road, so every steered path counted as blocked: no U-turn, straight
-- reversing without A/D, "manoeuvre made no progress", WAIT, repeat. The
-- simulator now models both (own car solid, sloping terrain).
test("own car is solid to line checks and the road slopes: still turned round at once, quick, no waiting", function()
    for _, case in ipairs({{tag="slope", terrain=function(x, y) return 10 + 0.04*x + (x > 7 and math.min(0.5, (x-7)*0.25) or 0) end},
        {tag="flatself"}}) do
        local sim = world({tag=case.tag, terrain=case.terrain})
        assert(sim.selfCollision ~= false, "own car is solid in this simulator")
        run(sim, 8)
        flip(sim)
        local flipAt, sNoSteer = sim.now, 0
        assert(run(sim, 30, function(s)
            local held = s.bot.Win32.driveHeld
            if s.bot.manager.owner == "ROTATE" and held[S] and not held[A] and not held[D] then sNoSteer = sNoSteer + 1 end
            return recovered(s)
        end), "recovers")
        assert(sim.stats.phases.JTURN, "turned round with the reverse spin")
        assert(not sim.stats.phases.WAIT, "never waits")
        equal(sNoSteer, 0, "never reverses with the wheels straight on an open road")
        assert(sim.now - flipAt < 7, case.tag .. ": back to normal driving in " .. (sim.now - flipAt) .. " s")
        assertStableHandoff(sim, sim.bot.recovery.rotation.cfg)
        run(sim, 6)
        assert(angleTo(sim.car.heading, 0) < 25 and math.abs(sim.car.x) < 2.5, "back on the line")
    end
end)

test("recovery line checks skip the own car and the road surface, but still see what is behind them", function()
    local sim = world({tag="selfray"})
    run(sim, 2)
    local RS = sim.bot.recovery
    RS.setOwnCar(1)
    local x, y, z = sim.car.x, sim.car.y, sim.car.z
    -- Straight through our own body (inside to outside and right across): clear.
    equal((RS.ray(x, y, z, x, y - 6, z)), true, "from inside the own car")
    equal((RS.ray(x - 4, y, z, x + 4, y, z)), true, "right across the own car")
    -- A wall behind the own car is still found.
    sim.walls[#sim.walls+1] = {-5, y - 5, 5, y - 5}
    equal((RS.ray(x, y + 4, z, x, y - 7, z)), false, "wall beyond the own car")
    table.remove(sim.walls)
    -- A rising road surface is not an obstacle; a car is.
    sim.terrain = function(px, py) return py > y + 4 and 10.8 or 10 end
    equal((RS.ray(x, y + 3, 10.5, x, y + 6, 10.5)), true, "road surface")
    sim.terrain = nil
    sim.obstacles[#sim.obstacles+1] = {x=x, y=y + 6, r=1.0}
    equal((RS.ray(x, y + 3, 10.5, x, y + 9, 10.5)), false, "another car")
end)

test("in-game failure reproduced: without the own-car handling every steered move counts as blocked", function()
    -- Guard for the regression above: the simulator really makes the own car
    -- solid (with the shipped 5.78 r2 checks this scenario never recovered).
    local sim = world({tag="selfsolid"})
    run(sim, 2)
    local x, y, z = sim.car.x, sim.car.y, sim.car.z
    local hit, col = sim.env.processLineOfSight(x, y + 4, z, x, y - 4, z, true, true, true, true, true, false, false, false)
    equal(hit, true, "a plain line check hits the own car")
    equal(col.entity, 0x05000000, "reported as the own car (getCarPointer)")
end)

test("street too narrow for one sweep: S with full lock, then straight into W round the other way (no stop)", function()
    local walls = {{-8.5, 0, -8.5, 600}, {8.5, 0, 8.5, 600}}
    local sim = world({tag="threepoint", walls=walls})
    run(sim, 8)
    flip(sim)
    local flipAt, closest = sim.now, math.huge
    local sStraight, sawSwitch, last = 0, false, nil
    assert(run(sim, 40, function(s)
        local r, held = s.bot.recovery.rotation, s.bot.Win32.driveHeld
        if r.phase == "REVERSE" and held[S] and not held[A] and not held[D] then sStraight = sStraight + 1 end
        if last == "REVERSE" and r.phase == "UTURN" then sawSwitch = true end
        last = r.phase
        -- Body corners stay clear of the walls (half extents 2.4 x 1.0).
        local h = math.rad(s.car.heading)
        local fx, fy, lx, ly = -math.sin(h), math.cos(h), -math.cos(h), -math.sin(h)
        for _, c in ipairs({{2.4, 1}, {2.4, -1}, {-2.4, 1}, {-2.4, -1}}) do
            local cx = s.car.x + fx*c[1] + lx*c[2]
            closest = math.min(closest, 8.5 - math.abs(cx))
        end
        return recovered(s)
    end), "recovers")
    assert(log(sim):find("then swing round forwards", 1, true), "reverse-then-swing planned")
    assert(sawSwitch, "reverse went straight into the forward swing")
    assert(not sim.stats.phases.STOP, "no stop between reversing and swinging round")
    equal(sStraight, 0, "S always with full lock")
    assert(closest > 0.2, "never touched a wall, closest " .. closest)
    assert(sim.now - flipAt < 9, "quick: " .. (sim.now - flipAt) .. " s")
    assertStableHandoff(sim, sim.bot.recovery.rotation.cfg)
    run(sim, 6)
    assert(angleTo(sim.car.heading, 0) < 25 and math.abs(sim.car.x) < 2.5, "back on the line")
end)

-- ---------------------------------------------------------------------------
-- Reverse spin (default): straight after the turn S with full lock, the nose
-- swings round while the car keeps going, then W with the other lock drives
-- on. "Driving forwards" = W while the car moves forwards relative to itself
-- and still faces more than 100 degrees away from the route.
local function spinWatch(sim)
    local w = {forwardWrongWay = 0, sLock = 0, sStraight = 0, wBeforeTurn = 0}
    return w, function(s)
        local held = s.bot.Win32.driveHeld
        if s.bot.manager.owner ~= "ROTATE" then return end
        local wrongWay = angleTo(s.car.heading, 0) > 100
        if held[W] and wrongWay and s.car.v > 0.3 then w.forwardWrongWay = w.forwardWrongWay + 1 end
        if held[S] and (held[A] or held[D]) then w.sLock = w.sLock + 1 end
        if held[S] and not held[A] and not held[D] and s.bot.recovery.rotation.phase == "JTURN" then w.sStraight = w.sStraight + 1 end
    end
end

test("reverse spin, open road: no W first, S with full lock at once, the nose swings round, drives on", function()
    for _, speed in ipairs({15, 25}) do
        local sim = world({tag="spin" .. speed, speed=speed, route1=line(0, 0, 2, 1200, speed)})
        run(sim, 8)
        flip(sim)
        local flipAt = sim.now
        local w, watch = spinWatch(sim)
        local firstKeys
        assert(run(sim, 30, function(s)
            watch(s)
            local held = s.bot.Win32.driveHeld
            if not firstKeys and (held[W] or held[S]) then firstKeys = {w=held[W], s=held[S], at=s.now - flipAt} end
            return recovered(s)
        end), "recovers")
        assert(sim.stats.phases.JTURN, "reverse spin")
        assert(firstKeys and firstKeys.s and not firstKeys.w, "the first pedal after the turn is S, not W")
        assert(firstKeys.at < 0.6, "S within 0.6 s of the turn: " .. firstKeys.at)
        equal(w.forwardWrongWay, 0, "never drives forwards while still facing the wrong way")
        assert(w.sLock >= 5, "S held together with full lock")
        equal(w.sStraight, 0, "never S with straight wheels in the spin")
        assert(sim.now - flipAt < 6, speed .. " m/s: back to normal driving in " .. (sim.now - flipAt) .. " s")
        assertStableHandoff(sim, sim.bot.recovery.rotation.cfg)
        assert(log(sim):find("reverse spin: S with", 1, true))
        if speed <= 15 then
            -- (At 90 km/h the chat gate keeps waiting: ~85 m of unsteered coasting.)
            awaitMessages(sim, 1)
            equal(#sim.messages, 1, "one message after the return")
        end
        run(sim, 4)
        assert(angleTo(sim.car.heading, 0) < 25 and math.abs(sim.car.x) < 3, "back on the line")
    end
end)

test("reverse spin from a slow car: S with lock round, then drives on", function()
    local sim = world({tag="spinslow", speed=5})
    run(sim, 8)
    flip(sim)
    local flipAt = sim.now
    local w, watch = spinWatch(sim)
    assert(run(sim, 30, function(s) watch(s); return recovered(s) end), "recovers")
    assert(sim.stats.phases.JTURN, "reverse spin")
    equal(w.forwardWrongWay, 0, "never drives forwards while still facing the wrong way")
    assert(sim.now - flipAt < 6, "quick: " .. (sim.now - flipAt) .. " s")
    run(sim, 6)
    assert(angleTo(sim.car.heading, 0) < 25, "driving along the route")
end)

test("reverse spin with a wall beside the car: refused, braked, then turned round another way, never into the wall", function()
    for _, wx in ipairs({2.6, -2.6}) do
        local sim = world({tag="spinwall" .. (wx > 0 and "E" or "W"), walls={{wx, 0, wx, 600}}})
        run(sim, 8)
        flip(sim)
        local closest = math.huge
        local w, watch = spinWatch(sim)
        assert(run(sim, 60, function(s)
            watch(s)
            local h = math.rad(s.car.heading)
            local fx, fy, lx, ly = -math.sin(h), math.cos(h), -math.cos(h), -math.sin(h)
            for _, c in ipairs({{2.4, 1}, {2.4, -1}, {-2.4, 1}, {-2.4, -1}}) do
                closest = math.min(closest, math.abs(s.car.x + fx*c[1] + lx*c[2] - wx))
            end
            return recovered(s)
        end), "recovers")
        assert(not sim.stats.phases.JTURN, "no spin next to a wall")
        assert(log(sim):find("no room for a reverse spin", 1, true))
        assert(closest > 0.2, "never touched the wall, closest " .. closest)
        run(sim, 5)
        assert(angleTo(sim.car.heading, 0) < 25)
    end
end)

test("two rotations with the reverse spin: one incident, the second restarts the spin, 1-2 messages", function()
    local sim = world({tag="spindouble"})
    run(sim, 8)
    flip(sim)
    assert(run(sim, 3, function(s) return s.bot.recovery.rotation.phase == "JTURN" end), "spin started")
    run(sim, 0.4)
    flip(sim)
    step(sim)
    local r = sim.bot.recovery.rotation
    assert(r.phase == "JTURN_CHECK" or r.phase == "JTURN", "restarted at once")
    equal(r.level, "double")
    local w, watch = spinWatch(sim)
    assert(run(sim, 60, function(s) watch(s); return recovered(s) end), "recovers")
    awaitMessages(sim, 1)
    run(sim, 5)
    assert(#sim.messages >= 1 and #sim.messages <= 2, "messages " .. #sim.messages)
    for _, m in ipairs(sim.messages) do assert(pools[m.text] == "double" or pools[m.text] == "followup", m.text) end
    run(sim, 4)
    assert(angleTo(sim.car.heading, 0) < 25)
end)

-- 5.77.4: the spin check at your route speeds (route1 is recorded at up to
-- ~43 m/s). Before, the check for a fast slide restarted at every 2 m/s and
-- never finished, so a fast car always braked for ~4 s and turned in moves.
local function fastRun(sim, speed)
    run(sim, 20, function(s) return math.abs(s.car.v) >= speed*0.95 and s.car.y > 150 end)
    flip(sim)
    local t0, seq, last, minX, maxX, sHeld = sim.now, {}, nil, 0, 0, 0
    local ok = run(sim, 40, function(s)
        local p = s.bot.recovery.rotation.phase
        if p ~= last then if p then seq[#seq+1] = p end; last = p end
        minX, maxX = math.min(minX, s.car.x), math.max(maxX, s.car.x)
        if s.bot.Win32.driveHeld[S] then sHeld = sHeld + DT end
        return p == nil and s.bot.manager.owner == "ROUTE" and s.now - t0 > 0.5
    end)
    return ok, sim.now - t0, table.concat(seq, " > "), minX, maxX, sHeld
end

test("fast slide (38 m/s, open road): the reverse spin is checked in time and used; back on the route in under 6 s", function()
    local sim = world({tag="fast38", route1=line(0, 0, 2, 600, 40)})
    local ok, t, seq, _, _, sHeld = fastRun(sim, 38)
    assert(ok, "recovers")
    assert(seq:find("^JTURN_CHECK > JTURN"), "reverse spin used: " .. seq)
    assert(not seq:find("HOLD", 1, true) and not seq:find("PLAN", 1, true), "no braking and turning in moves: " .. seq)
    assert(t < 6, "back on the route after " .. t .. " s")
    assert(sHeld > 0.5, "S held during the spin")
    run(sim, 3); assert(angleTo(sim.car.heading, 0) < 25, "driving on in the route direction")
end)

test("fast slide with a wall along the drift side: the spin never takes the car through the wall", function()
    -- Right lock drifts the car to its right; a wall 5 m to that side.
    local sim = world({tag="fastwall", route1=line(0, 0, 2, 600, 40), walls={{-5, 0, -5, 1200}, {5, 0, 5, 1200}}})
    local ok, t, seq, minX, maxX = fastRun(sim, 38)
    assert(ok, "recovers (" .. seq .. ")")
    assert(minX > -5 and maxX < 5, string.format("stayed between the walls (x %.1f .. %.1f): %s", minX, maxX, seq))
end)

test("your in-game case: one-frame OVERRIDE flickers after the bot releases a key do not cancel the reverse spin", function()
    local sim = world({tag="fastlag", route1=line(0, 0, 2, 600, 40), keyLag=true})
    local ok, t, seq = fastRun(sim, 38)
    assert(ok, "recovers")
    assert(seq:find("^JTURN_CHECK > JTURN"), "reverse spin used despite the flicker: " .. seq)
    assert(t < 6, "back on the route after " .. t .. " s")
end)

test("your in-game case: next to a wall off the road, approach blocked twice -> it manoeuvres instead of retrying forever", function()
    -- The car lands 24 m off the road, nose towards the route, a long wall
    -- 1.4 m along its left side (the beach ledge in your screenshot).
    local H = 312
    local fx, fy = -math.sin(math.rad(H)), math.cos(math.rad(H))
    local lx, ly = -fy, fx
    local cx, cy = -24.3, 200
    local wx, wy = cx + lx*1.4, cy + ly*1.4
    -- The ledge alongside, and where it bends in front of the nose (7 m ahead,
    -- slightly into the car's line) - straight on is really blocked.
    local bx, by = cx + fx*7 - lx*0.6, cy + fy*7 - ly*0.6
    local sim = world({tag="ledge", route1=line(0, 0, 2, 600, 40),
        walls={{wx-fx*20, wy-fy*20, wx+fx*4, wy+fy*4}, {wx+fx*4, wy+fy*4, bx, by}}})
    run(sim, 6)
    sim.car.x, sim.car.y, sim.car.v, sim.car.heading = cx, cy, 0, (H+180) % 360
    run(sim, 0.1)
    flip(sim)
    local ok = run(sim, 40, recovered)
    local _, blocks = log(sim):gsub("approach blocked", "")
    assert(ok, "recovers (approach blocked " .. blocks .. " times)")
    assert(blocks <= 2, "approach retried from the same spot " .. blocks .. " times")
end)

test("17 m street at 15/25/38 m/s: the spin is only used when its sideways drift fits; never within 1 m of a wall", function()
    for _, speed in ipairs({15, 25, 38}) do
        local sim = world({tag="street17_" .. speed, route1=line(0, 0, 2, 600, speed + 2), walls={{-8.5, 0, -8.5, 1200}, {8.5, 0, 8.5, 1200}}})
        run(sim, 20, function(s) return math.abs(s.car.v) >= speed*0.95 and s.car.y > 150 end)
        flip(sim)
        local closest = math.huge
        local ok = run(sim, 40, function(s)
            local h = math.rad(s.car.heading)
            local fx, fy, lx, ly = -math.sin(h), math.cos(h), -math.cos(h), -math.sin(h)
            for _, c in ipairs({{2.4, 1}, {2.4, -1}, {-2.4, 1}, {-2.4, -1}}) do
                closest = math.min(closest, 8.5 - math.abs(s.car.x + fx*c[1] + lx*c[2]))
            end
            return recovered(s) and s.now > 0
        end)
        assert(ok, speed .. " m/s: recovers")
        assert(closest > 1.0, string.format("%d m/s: came within %.1f m of a wall", speed, closest))
        -- A refused spin says what was in the way (for in-game logs).
        local text = log(sim)
        if text:find("no room for a reverse spin", 1, true) then
            assert(text:find("no room for a reverse spin: building/road %d+ m"), "reason logged")
        end
    end
end)

print(total .. " rotation recovery integration scenarios passed (simulated)")
