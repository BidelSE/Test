local sourcePath = arg[1] or 'dangis_vr.lua'
local f=assert(io.open(sourcePath,'rb')); local source=f:read('*a'); f:close()
local testRoot='/tmp/dangis_telemetry_test'
os.execute('mkdir -p '..testRoot)
local now=100
os.clock=function() return now end
package.preload['lib.moonloader']=function() return {} end
script_name=function() end; script_version=function() end
getWorkingDirectory=function() return testRoot end
printStringNow=function() end
PLAYER_PED=1
local gameProbes=0
isCharInAnyCar=function() gameProbes=gameProbes+1; return true end
storeCarCharIsInNoSave=function() return 1 end
getCarCoordinates=function() return 3,4,0 end
getCarSpeed=function() return 10 end
getCarHeading=function() return 350 end
getHeadingFromVector2d=function() return 10 end
getDistanceBetweenCoords2d=function(x,y,a,b) return math.sqrt((x-a)^2+(y-b)^2) end
isKeyDown=function() return false end
local controlWrites=0
writeMemory=function() controlWrites=controlWrites+1 end
setGameKeyState=function() controlWrites=controlWrites+1 end
local api=assert((loadstring or load)(source..[[
return {T=Telemetry, S=S, config=CONFIG, manager=ControlManager, input=InputHandler,
    Win32=Win32, loop=MainLoop, setPlaying=function(value) playing=value end,
    setRoute=function(value) current_route=value; play_index=1 end,
    setName=function(value) current_name=value end,
    setStages=function(dialog,recovery,recorder,playback)
        DialogBridge.update=dialog; RecoverySystem.updateControlThread=recovery
        RouteRecorder.recordTick=recorder; RouteFollower.updatePlayback=playback
    end}
]], '@'..sourcePath))()
api.Win32.isGameForeground=function() return true end
api.Win32.keyDown=function() return false end
local path=api.config.telemetry.file
local function read(path)
 local file=assert(io.open(path,'rb')); local data=file:read('*a'); file:close(); return data
end
local function equal(a,b,msg) assert(a==b,(msg or 'value')..': expected '..tostring(b)..', got '..tostring(a)) end
local function reset()
 api.T.stop(); os.remove(path); os.remove(path..'.previous.csv')
 os.remove(testRoot..'/dangis_vr_freeze.flag'); os.remove(testRoot..'/dangis_vr_dialog.flag')
 api.config.telemetry.file=path; api.config.telemetry.maxBytes=2*1024*1024
 api.T.enabled=false; api.T.handle=nil; api.T.target=nil
 api.manager.owner='ROUTE'; api.manager.applied={gas=120,brake=40,steer=-70,reverse=false}
 api.setPlaying(true); api.setName('route1')
 api.setRoute({{x=0,y=0,z=0,speed=10,heading=0,drive='FWD'}, {x=10,y=0,z=0,speed=10,heading=0,drive='FWD'}})
 api.S.freezeTestLatched=false; api.S.frozenByAdmin=false
 api.S.dialogPaused=false; api.S.manualPaused=false
 api.S.routeObstacleDist=math.huge
 getCarSpeed=function() return 10 end
 now=now+10; gameProbes=0; controlWrites=0
end
local total=0
local function test(name,fn)
 reset(); fn(); total=total+1; equal(controlWrites,0,'telemetry control writes'); print('PASS '..name)
end

test('disabled telemetry performs no file or game probes',function()
 api.T.tick(); equal(gameProbes,0)
 equal(io.open(path,'rb'),nil)
end)

test('F5 starts and stops capture without touching controls',function()
 VK_F5=5; isKeyJustPressed=function(key) return key==5 end
 api.input.handleHotkeys(); assert(api.T.enabled)
 api.input.handleHotkeys(); equal(api.T.enabled,false); equal(api.T.handle,nil)
 assert(read(path):find('target_speed_kmh',1,true))
 isKeyJustPressed=function() return false end
end)

test('CSV contains 29 fields with units, finite values and escaped text',function()
 api.setName('route,"quoted"\nname')
 assert(api.T.start())
 api.T.target={index=1,speed=12,x=3,y=20,reverse=false,branch='route'}
 api.T.tick(); api.T.stop()
 local text=read(path)
 assert(text:find('"route,""quoted"" name"',1,true))
 assert(text:find('36.000,,3.000,4.000,350.000,5.000,1.000,43.200,3.000,20.000,20.000',1,true))
 assert(not text:find('inf',1,true))
 equal(api.T.cell(0/0),''); equal(api.T.cell(-math.huge),'')
 assert(text:find('120.000,40.000,-70.000,0.000',1,true))
end)

test('rate limit skips normal frames but owner change captures immediately',function()
 assert(api.T.start()); api.T.tick(); local bytes=api.T.bytes; local probes=gameProbes
 now=now+0.02; api.T.tick(); equal(api.T.bytes,bytes); equal(gameProbes,probes)
 api.manager.owner='BUMP'; api.T.tick(); assert(api.T.bytes>bytes)
end)

test('capture size limit stops on a complete row',function()
 assert(api.T.start()); local header=api.T.bytes
 api.config.telemetry.maxBytes=header+1
 api.T.tick(); equal(api.T.enabled,false); equal(api.T.handle,nil)
 equal(#read(path),header)
end)

test('starting a new capture preserves the latest completed file',function()
 assert(api.T.start()); api.T.tick(); api.T.stop()
 local previous=read(path)
 assert(api.T.start()); api.T.stop()
 equal(read(path..'.previous.csv'),previous)
 assert(#read(path)<#previous)
end)

test('sample failure disables telemetry and leaves driving active',function()
 assert(api.T.start()); getCarSpeed=function() error('mock game read failure') end
 api.T.tick(); equal(api.T.enabled,false); equal(api.T.handle,nil)
 equal(api.manager.owner,'ROUTE'); equal(api.manager.applied.gas,120)
end)

test('file write failure closes capture without control writes',function()
 assert(api.T.start()); api.T.handle:close()
 local closed=false
 api.T.handle={write=function() return nil,'disk failure' end,
     flush=function() return true end,close=function() closed=true end}
 api.T.tick(); equal(api.T.enabled,false); assert(closed)
end)

test('flush failure disables capture safely',function()
 assert(api.T.start()); api.T.handle:close()
 api.T.handle={write=function(self) return self end,flush=function() return nil,'disk full' end,close=function() end}
 now=now+1.1; api.T.tick(); equal(api.T.enabled,false); equal(api.T.handle,nil)
end)

test('open failure is reported and does not enable capture',function()
 api.config.telemetry.file=testRoot..'/missing_directory/capture.csv'
 assert(not api.T.start()); equal(api.T.enabled,false); equal(api.T.handle,nil)
end)

test('unload closes and flushes capture',function()
 assert(api.T.start()); api.T.tick()
 local scr={}; thisScript=function() return scr end
 onScriptTerminate(scr,true)
 equal(api.T.enabled,false); equal(api.T.handle,nil)
 assert(#read(path)>0)
end)

-- Integrate the real frame loop and manager; its safety writes are expected.
reset()
api.setPlaying(false); api.manager.owner='IDLE'; api.manager.wrote=false
api.setStages(function() end,function() end,function() end,function()
 api.T.target={index=1,speed=20,x=0,y=10,branch='stale_route'}
end)
assert(api.T.start()); api.loop.tick()
equal(api.T.target,nil); api.T.stop(); equal(controlWrites,0)
print('PASS frame loop discards targets outside ROUTE ownership')
total=total+1
print(string.format('%d telemetry regression scenarios passed',total))
