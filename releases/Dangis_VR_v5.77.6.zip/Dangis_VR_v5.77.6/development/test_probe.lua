-- Unit tests for lib/dangis_probe.lua (budgeted collision probes).
-- Usage: texlua development/test_probe.lua   (or luajit)
local P = require("lib.dangis_probe")
local total = 0
local function test(name, fn) fn(); total = total + 1; print("PASS " .. name) end
local function equal(a, b, m) if a ~= b then error((m or "value") .. ": expected " .. tostring(b) .. ", got " .. tostring(a), 2) end end

local function world(opts)
    opts = opts or {}
    local w = {now = 0, calls = 0}
    w.p = P.new({
        budget = opts.budget or 10,
        clock = function() return w.now end,
        ray = function(...)
            w.calls = w.calls + 1
            if opts.ray then return opts.ray(w.calls, ...) end
            return true
        end,
        ground = function(...)
            w.calls = w.calls + 1
            if opts.ground then return opts.ground(w.calls, ...) end
            return true
        end,
    })
    return w
end
local function lines(n) local t = {} for i = 1, n do t[i] = {0, 0, 0, 1, 1, 0} end return t end
local pose = {x=0, y=0, h=0}
local TOL = {dist=0.5, angle=5, age=1.0}

test("an unfinished probe is PENDING, never clear, and finishes over later frames", function()
    local w = world({budget=10})
    w.p:beginFrame()
    equal(w.p:request("a", pose, TOL, function() return lines(25) end, "same"), P.PENDING)
    equal(w.calls, 10, "budget respected")
    w.p:beginFrame(); equal(w.p:request("a", pose, TOL, function() error("not rebuilt") end, "same"), P.PENDING)
    w.p:beginFrame(); equal(w.p:request("a", pose, TOL, function() error("not rebuilt") end, "same"), true)
    equal(w.calls, 25)
end)

test("the frame budget is shared by every probe of that frame", function()
    local w = world({budget=10})
    w.p:beginFrame()
    w.p:request("a", pose, TOL, function() return lines(8) end, "same")
    equal(w.p:request("b", pose, TOL, function() return lines(8) end, "same"), P.PENDING)
    equal(w.calls, 10)
    w.p:beginFrame()
    equal(w.p:request("a", pose, TOL, function() return lines(8) end, "same"), true)
    equal(w.p:request("b", pose, TOL, function() return lines(8) end, "same"), true)
end)

test("an obstacle ends the probe early as blocked", function()
    local w = world({budget=100, ray=function(n) return n ~= 3 end})
    w.p:beginFrame()
    equal(w.p:request("a", pose, TOL, function() return lines(50) end), false)
    equal(w.calls, 3, "stops at the first blocked check")
end)

test("a failed or unknown query is blocked, never clear", function()
    for _, answer in ipairs({nil, "maybe", 1}) do
        local w = world({budget=100, ray=function(n) if n == 2 then return answer end return true end})
        w.p:beginFrame()
        equal(w.p:request("a", pose, TOL, function() return lines(5) end), false)
    end
    local w = world({budget=100, ground=function() return nil end})
    w.p:beginFrame()
    equal(w.p:request("g", pose, TOL, function() return {{0, 0, 0, g=true}} end), false)
end)

test("results expire with distance, heading and age; a moved car is PENDING again", function()
    local w = world({budget=100})
    w.p:beginFrame(); equal(w.p:request("a", pose, TOL, function() return lines(5) end, "same"), true)
    w.p:beginFrame(); equal(w.p:request("a", {x=0.3, y=0, h=2}, TOL, function() return lines(500) end, "same"), true, "within tolerance")
    w.p:beginFrame(); equal(w.p:request("a", {x=2, y=0, h=0}, TOL, function() return lines(500) end, "same"), P.PENDING, "moved away")
    local v = world({budget=100})
    v.p:beginFrame(); v.p:request("a", pose, TOL, function() return lines(5) end, "same")
    v.now = 2
    v.p:beginFrame(); equal(v.p:request("a", pose, TOL, function() return lines(500) end, "same"), P.PENDING, "too old")
end)

test("a job built for a pose the car has left is restarted, not completed with stale geometry", function()
    local built = 0
    local w = world({budget=5})
    local function build() built = built + 1; return lines(20) end
    w.p:beginFrame(); w.p:request("a", pose, TOL, build)
    w.p:beginFrame(); w.p:request("a", {x=3, y=0, h=0}, TOL, build)
    equal(built, 2)
end)

test("rolling refresh starts early so a moving car usually keeps an answer", function()
    local w = world({budget=100})
    local built = 0
    local function build() built = built + 1; return lines(5) end
    w.p:beginFrame(); w.p:request("a", pose, TOL, build)
    w.p:beginFrame(); w.p:request("a", {x=0.2, y=0, h=0}, TOL, build) -- moved more than a quarter of 0.5 m
    equal(built, 2)
end)

test("slots nobody asks for are dropped together with their unfinished work", function()
    local w = world({budget=1})
    w.p:beginFrame(); w.p:request("a", pose, TOL, function() return lines(10) end)
    for i = 1, 40 do w.p:beginFrame() end
    equal(w.p.slots.a, nil)
end)

test("builders: arcs cover the whole body, leading-only covers the front, U-turn uses both radii", function()
    local profile = {half_length=2.7, half_width=1.1}
    local full = P.arc(pose, 0, profile, 128, 3, false, 6.5)
    local lead = P.arc(pose, 0, profile, 128, 3, false, 6.5, true)
    -- Ground under the car, then per 1.5 m step: ground + 12 points x 2 heights.
    equal(#full, 1+2*(12*2+1)); equal(#lead, 1+2*(7*2+1))
    local both = P.arcBoth(pose, 0, profile, 128, 3, false)
    assert(#both > #full, "tight and wide circle")
    local u = P.uturn(pose, 0, profile, -128, 180)
    assert(#u > 200, "full U-turn sweep")
    -- Turning right forwards ends up heading right (GTA heading decreases).
    local last
    for _, c in ipairs(full) do if c.g then last = c end end
    assert(last[1] > 0, "right lock moves the car to the right (+x when facing north)")
    equal(#P.corridor(pose, 0, profile), 13)
    equal(#P.straightBack(pose, 0, profile, 2), 9)
    equal(#P.forwardShort(pose, 0, profile, 1.3), 12)
end)

-- A world with a ground function returning heights (terrain) and a ray
-- that records the heights it was asked for.
local function terrainWorld(height, opts)
    opts = opts or {}
    local w = {now = 0, rays = {}, calls = 0}
    w.p = P.new({budget = opts.budget or 10000, clock = function() return w.now end,
        ray = function(ax, ay, az, bx, by, bz)
            w.calls = w.calls + 1
            w.rays[#w.rays+1] = {ax, ay, az, bx, by, bz}
            if opts.ray then return opts.ray(ax, ay, az, bx, by, bz) end
            return true, opts.cost
        end,
        ground = function(x, y, ref) w.calls = w.calls + 1; return true, height(x, y) end})
    return w
end

test("terrain: rays follow the ground (0.45 m and 1.0 m above it), so a slope is not an obstacle", function()
    local profile = {half_length=2.4, half_width=1.0}
    -- 8 % uphill ahead: the ground under the end of a 3 m move is 0.24 m higher.
    local w = terrainWorld(function(x, y) return 10 + 0.08*y end)
    w.p:beginFrame()
    equal(w.p:request("a", pose, TOL, function() return P.arc(pose, 10.6, profile, 128, 3, false, 6.5) end), true)
    local minAbove, maxAbove = math.huge, -math.huge
    for _, r in ipairs(w.rays) do
        for _, e in ipairs({{r[1], r[2], r[3]}, {r[4], r[5], r[6]}}) do
            -- Heights are relative to the ground sampled at the pose centres.
            minAbove = math.min(minAbove, e[3] - (10 + 0.08*e[2]))
            maxAbove = math.max(maxAbove, e[3] - (10 + 0.08*e[2]))
        end
    end
    assert(minAbove > 0.1 and maxAbove < 1.5, string.format("rays stay at body height above the slope (%.2f..%.2f)", minAbove, maxAbove))
end)

test("terrain: a step or drop between ground samples beyond kerb + grade blocks the path", function()
    local profile = {half_length=2.4, half_width=1.0}
    local kerb = terrainWorld(function(x, y) return y > 2 and 10.15 or 10 end)
    kerb.p:beginFrame()
    equal(kerb.p:request("a", pose, TOL, function() return P.arc(pose, 10.6, profile, 0, 3, false, 6) end), true, "a kerb is drivable")
    local wall = terrainWorld(function(x, y) return y > 2 and 11.2 or 10 end)
    wall.p:beginFrame()
    equal(wall.p:request("a", pose, TOL, function() return P.arc(pose, 10.6, profile, 0, 3, false, 6) end), false, "a 1.2 m step is not")
    equal(wall.p:why("a"), "ground")
    local drop = terrainWorld(function(x, y) return y > 2 and 8.5 or 10 end)
    drop.p:beginFrame()
    equal(drop.p:request("a", pose, TOL, function() return P.arc(pose, 10.6, profile, 0, 3, false, 6) end), false, "a 1.5 m drop is not")
end)

test("cost: extra line-of-sight calls reported by the ray (own-car re-casts) count against the budget", function()
    local w = terrainWorld(function() return 10 end, {budget = 20, cost = 3})
    w.p:beginFrame()
    local profile = {half_length=2.4, half_width=1.0}
    equal(w.p:request("a", pose, TOL, function() return P.arc(pose, 10.6, profile, 128, 3, false, 6.5) end), P.PENDING)
    assert(w.p.stats.frameRays <= 20 + 2, "budget includes re-casts: " .. w.p.stats.frameRays)
end)

test("reverse-then-swing: reverse arc with the opposite lock, then the forward sweep from where it ends", function()
    local profile = {half_length=2.4, half_width=1.0}
    local tight, wide = P.legRadii(profile)
    assert(wide > tight and wide < P.radii(profile)*2, "manoeuvre circles")
    local e = P.arcEnd(pose, -128, 2.5, true, wide)
    -- Reversing with left lock while facing north: the rear swings left
    -- (west) and the nose turns right (heading decreases).
    assert(e.y < 0 and e.h < 0, "reverse end pose " .. e.x .. "," .. e.y .. "," .. e.h)
    local list = P.threePoint(pose, 10.6, profile, 128, 170, 2.5)
    local starts = 0
    for _, c in ipairs(list) do if c.start then starts = starts + 1 end end
    -- Reverse (tight and wide circle) + the forward sweep (tight and wide
    -- circle) from both possible reverse ends.
    equal(starts, 6, "six arcs, each starting with its own ground sample")
end)

test("reverse spin room: fast = slide corridor drifting to the lock side (with lines across it); slow = reverse-then-swing", function()
    local profile = {half_length=2.4, half_width=1.0}
    -- Facing north (h=0), sliding back (south). side=128: lock key -128 (left), drift to the left (-x).
    local fast = P.jturn(pose, 10.6, profile, 128, 180, 15, 0, 100)
    local minX, maxX, across = math.huge, -math.huge, 0
    for _, c in ipairs(fast) do
        if c.rel then
            minX = math.min(minX, c[1], c[4]); maxX = math.max(maxX, c[1], c[4])
            if c.here then across = across + 1 end
        end
    end
    assert(minX < -6 and maxX < 6, string.format("drift to the left: x %.1f..%.1f", minX, maxX))
    assert(across > 0, "lines across the corridor")
    local mirrored = P.jturn(pose, 10.6, profile, -128, 180, 15, 0, 100)
    local mx = -math.huge
    for _, c in ipairs(mirrored) do if c.rel then mx = math.max(mx, c[1], c[4]) end end
    assert(mx > 6, "the other lock drifts the other way")
    local slow = P.jturn(pose, 10.6, profile, 128, 180, 2, 0, 100)
    local starts = 0
    for _, c in ipairs(slow) do if c.start then starts = starts + 1 end end
    equal(starts, 7, "reverse arcs (2) + forward sweeps from both reverse ends (4) + short slide corridor")
end)

test("cache identity: no signature = the builder identifies the check; a signature or a longer reach starts anew", function()
    local w = world({budget=100})
    local builds = 0
    local function b1() builds = builds + 1; return lines(3) end
    w.p:beginFrame(); equal(w.p:request("k", pose, TOL, b1), true)
    w.p:beginFrame(); equal(w.p:request("k", pose, TOL, b1), true); equal(builds, 1, "same builder reused")
    w.p:beginFrame(); w.p:request("k", pose, TOL, function() builds = builds + 1; return lines(3) end); equal(builds, 2, "another builder is another check")
    w.p:beginFrame(); w.p:request("k", pose, TOL, b1, "left", 3); equal(builds, 3)
    w.p:beginFrame(); w.p:request("k", pose, TOL, b1, "right", 3); equal(builds, 4, "other side")
    w.p:beginFrame(); w.p:request("k", pose, TOL, b1, "right", 2); equal(builds, 4, "a shorter reach is covered")
    w.p:beginFrame(); w.p:request("k", pose, TOL, b1, "right", 5); equal(builds, 5, "a longer reach is not")
    -- After a shorter check replaced it, a longer request is not served by it.
    w.now = 10; w.p:beginFrame(); w.p:request("k", pose, TOL, b1, "right", 2); equal(builds, 6)
    w.p:beginFrame(); w.p:request("k", pose, TOL, b1, "right", 5); equal(builds, 7)
end)

test("hard frame budget: a line check that re-casts never pushes a frame over its budget", function()
    for _, cost in ipairs({1, 3, 4, 6}) do
        local calls = 0
        local p = P.new({budget=10, clock=function() return 0 end, ground=function() return true end,
            ray=function() calls = calls + cost; return true, cost end})
        for f = 1, 5 do
            calls = 0
            p:beginFrame()
            p:request("a", pose, TOL, function() return lines(40) end, "s")
            assert(calls <= 10 or (f == 1 and calls <= cost), "cost " .. cost .. " frame " .. f .. ": " .. calls .. " calls")
        end
    end
end)

print(total .. " probe scenarios passed")
