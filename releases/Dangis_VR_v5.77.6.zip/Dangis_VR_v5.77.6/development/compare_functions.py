# Lists every top-level function of the user's v5.77 dangis_vr.lua and whether
# it is byte-identical in the 5.77.4 build. Usage: python3 compare_functions.py OLD NEW
import re, sys
def functions(path):
    lines = open(path, encoding='utf-8').read().split('\n')
    out, name, buf = {}, None, []
    head = re.compile(r'^(?:local\s+)?function\s+([\w\.:]+)\s*\(|^([\w\.]+)\s*=\s*function\s*\(')
    for line in lines:
        if name is None:
            m = head.match(line)
            if m:
                name = m.group(1) or m.group(2); buf = [line]
                if re.search(r'\bend\s*$', line) and line.count('function') == 1 and re.match(r'.*\)\s.*\bend\s*$', line):
                    out.setdefault(name, []).append('\n'.join(buf)); name = None
        else:
            buf.append(line)
            if line == 'end' or line.startswith('end ') or line.startswith('end)'):
                out.setdefault(name, []).append('\n'.join(buf)); name = None
    return out
old, new = functions(sys.argv[1]), functions(sys.argv[2])
same = [n for n in old if n in new and old[n] == new[n]]
changed = [n for n in old if n in new and old[n] != new[n]]
removed = [n for n in old if n not in new]
added = [n for n in new if n not in old]
print(f"v5.77 functions: {len(old)}; identical: {len(same)}; changed: {len(changed)}; removed: {len(removed)}; added: {len(added)}")
print("CHANGED:", ", ".join(changed))
print("REMOVED:", ", ".join(removed))
print("ADDED:", ", ".join(added))
