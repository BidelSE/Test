-- 5.77.6 route files: validation, checked saving, interrupted saves and
-- recovery from .tmp / .bak. Real dangis_vr.lua + lib/dangis_route_io.lua in
-- the simulator; file failures are injected through RouteStorage.io.fs.
-- Usage (from the package root): texlua development/test_route_storage.lua
package.path = "development/?.lua;" .. package.path
local Sim = require("sim_harness")
local INI = Sim.read("dangis_vr.ini")

local total = 0
local function test(name, fn) fn(); total = total + 1; print("PASS " .. name) end
local function equal(a, b, m) if a ~= b then error((m or "value") .. ": expected " .. tostring(b) .. ", got " .. tostring(a), 2) end end

local function lines(n, x)
    local t = {}
    for i = 0, n - 1 do t[#t+1] = string.format("{%s}:{%d}:{10}:{12}:{0}:{FWD}", x or 0, i * 2) end
    return t
end
local GOOD = table.concat(lines(41), "\n") .. "\n"

local function boot(files)
    local list = {{"dangis_vr.ini", INI}}
    for _, f in ipairs(files or {}) do list[#list+1] = f end
    local sim = Sim.new({root=".", tag="routeio", files=list, x=0, y=0, z=10.6})
    sim.groundZ = 10
    sim.bot.loop.initialize()
    return sim
end
local function path(sim, suffix) return sim.work .. "/dangis_paths/route1.txt" .. (suffix or "") end
local function read(p) local f = io.open(p, "rb"); if not f then return nil end; local t = f:read("*a"); f:close(); return t end
local function write(p, t) local f = assert(io.open(p, "wb")); f:write(t); f:close() end
local function route(n, x)
    local r = {}
    for i = 0, n - 1 do r[#r+1] = {x=x or 5, y=i * 2, z=10, speed=12, heading=0, drive="FWD", reverse=false} end
    return r
end

-- Parsing ---------------------------------------------------------------
local function rejected(name, badLine)
    test("rejects " .. name, function()
        local t = lines(41); t[10] = badLine
        local sim = boot({{"dangis_paths/route1.txt", table.concat(t, "\n") .. "\n"}})
        equal(sim.bot.storage.load("route1"), nil, "route")
        local problems = sim.bot.storage.lastLoad.problems
        assert(#problems == 1 and problems[1]:find("line 10", 1, true), "reason names the line: " .. tostring(problems[1]))
        sim:frame(1/30, {[0x79]=true})
        assert(not sim.bot.isPlaying(), "a corrupt route must not start playback")
    end)
end
rejected("nan", "{nan}:{18}:{10}:{12}:{0}:{FWD}")
rejected("-nan(ind) as written by Windows", "{-nan(ind)}:{18}:{10}:{12}:{0}:{FWD}")
rejected("inf", "{0}:{inf}:{10}:{12}:{0}:{FWD}")
rejected("1e999 (overflows to infinity)", "{1e999}:{18}:{10}:{12}:{0}:{FWD}")
rejected("a non-numeric height (was silently 0)", "{0}:{18}:{garbage}:{12}:{0}:{FWD}")
rejected("nan speed (was silently 0)", "{0}:{18}:{10}:{nan}:{0}:{FWD}")
rejected("an unknown drive mode (was silently FWD)", "{0}:{18}:{10}:{12}:{0}:{SIDEWAYS}")
rejected("coordinates outside the map", "{99999999}:{18}:{10}:{12}:{0}:{FWD}")
rejected("a truncated line (was silently dropped)", "{0}:{18}")
rejected("a line of junk", "garbage")

test("legacy 6-, 5- and 3-field files, CRLF and boolean drive modes still load", function()
    local six = lines(20)
    local five, three = {}, {}
    for i = 0, 19 do five[#five+1] = string.format("{%d}:{%d}:{10}:{12}:{0}", 0, i * 2) end
    for i = 0, 19 do three[#three+1] = string.format("{%d}:{%d}:{12}", 0, i * 2) end
    six[3] = "{0}:{4}:{10}:{-3}:{0}:{BACK}"; six[4] = "{0}:{6}:{10}:{-3}:{0}:{true}"; six[5] = "{0}:{8}:{10}:{12}:{0}:{false}"
    local sim = boot({{"dangis_paths/route1.txt", table.concat(six, "\r\n") .. "\r\n"}})
    local r = assert(sim.bot.storage.load("route1"))
    equal(#r, 20); equal(r[3].drive, "BACK"); equal(r[4].drive, "BACK"); equal(r[5].drive, "FWD")
    write(path(sim), table.concat(five, "\n")); r = assert(sim.bot.storage.load("route1")); equal(#r, 20); equal(r[1].z, 10)
    write(path(sim), table.concat(three, "\n")); r = assert(sim.bot.storage.load("route1")); equal(#r, 20); equal(r[1].z, 0)
end)

test("the end marker catches a file cut short on a line boundary", function()
    local sim = boot({{"dangis_paths/route1.txt", GOOD}})
    assert(sim.bot.storage.save("route1", route(30)))
    local text = read(path(sim))
    assert(text:match("#end 30\n$"), "saved file ends with the marker")
    write(path(sim), text:gsub("#end 30", "#end 31"))
    local r = assert(sim.bot.storage.load("route1"))
    equal(#r, 41, "truncated main rejected, previous route from .bak")
    equal(sim.bot.storage.lastLoad.source, "bak")
    assert(sim.bot.storage.lastLoad.problems[1]:find("truncated", 1, true))
end)

-- Saving ----------------------------------------------------------------
test("save writes the new route, keeps the previous one as .bak, leaves no .tmp", function()
    local sim = boot({{"dangis_paths/route1.txt", GOOD}})
    assert(sim.bot.storage.save("route1", route(30)))
    local r = assert(sim.bot.storage.load("route1")); equal(#r, 30); equal(sim.bot.storage.lastLoad.source, "main")
    equal(read(path(sim, ".bak")), GOOD, "backup is the previous file")
    equal(read(path(sim, ".tmp")), nil); equal(read(path(sim, ".bak.tmp")), nil)
    assert(sim.bot.storage.save("route1", route(25, 7)))
    equal(#assert(sim.bot.storage.load("route1")), 25)
    local bak = sim.bot.storage.io.parse(read(path(sim, ".bak"))); equal(#bak, 30, "backup rotated to the previous save")
end)

test("a route with nan/inf in memory is not saved and not played", function()
    local sim = boot({{"dangis_paths/route1.txt", GOOD}})
    local r = route(30); r[7].speed = 0/0
    equal(sim.bot.storage.save("route1", r), false)
    equal(read(path(sim)), GOOD, "file untouched")
    r[7].speed = 12; r[8].x = math.huge
    equal(sim.bot.storage.save("route1", r), false)
    sim.bot.setRoute(r)
    sim:frame(1/30, {[0x79]=true})
    assert(sim.bot.isPlaying(), "the valid file is played instead")
    equal(#sim.bot.getRoute(), 41)
end)

local function faulty(sim, opts)
    local fs = sim.bot.storage.io.fs
    local real = {open=fs.open, remove=fs.remove, rename=fs.rename}
    fs.open = function(p, mode)
        if opts.open and opts.open(p, mode) then return nil, "injected open failure" end
        local f, err = real.open(p, mode)
        if not f or not opts.handle then return f, err end
        return opts.handle(p, mode, f)
    end
    fs.rename = function(a, b) if opts.rename and opts.rename(a, b) then return nil, "injected rename failure" end; return real.rename(a, b) end
    fs.remove = function(p) if opts.remove then opts.remove(p) end; return real.remove(p) end
    return function() fs.open, fs.remove, fs.rename = real.open, real.remove, real.rename end
end
-- A file handle whose write/flush/close report failure (disk full, I/O error).
local function failing(f, what)
    return setmetatable({}, {__index=function(_, k)
        if k == what then return function() return nil, "injected " .. what .. " failure" end end
        return function(_, ...) return f[k](f, ...) end
    end})
end

for _, what in ipairs({"write", "flush", "close"}) do
    test("a " .. what .. " failure on the new file keeps the old route and backup intact", function()
        local sim = boot({{"dangis_paths/route1.txt", GOOD}, {"dangis_paths/route1.txt.bak", GOOD}})
        local restore = faulty(sim, {handle=function(p, mode, f)
            if p:match("route1%.txt%.tmp$") and mode == "w" then return failing(f, what) end
            return f
        end})
        equal(sim.bot.storage.save("route1", route(30)), false)
        restore()
        equal(read(path(sim)), GOOD); equal(read(path(sim, ".bak")), GOOD)
        assert(sim.bot.storage.lastSaveError:find(what, 1, true))
    end)
end

test("the new file cannot be created: nothing changes", function()
    local sim = boot({{"dangis_paths/route1.txt", GOOD}})
    local restore = faulty(sim, {open=function(p, mode) return mode == "w" end})
    equal(sim.bot.storage.save("route1", route(30)), false)
    restore()
    equal(read(path(sim)), GOOD)
end)

test("backup cannot be written: the last valid route is never deleted", function()
    local sim = boot({{"dangis_paths/route1.txt", GOOD}})
    local removed = {}
    local restore = faulty(sim, {open=function(p, mode) return mode == "w" and p:match("%.bak") ~= nil end,
        remove=function(p) removed[#removed+1] = p end})
    equal(sim.bot.storage.save("route1", route(30)), false)
    restore()
    equal(read(path(sim)), GOOD, "route kept")
    for _, p in ipairs(removed) do assert(not p:match("route1%.txt$"), "route file was removed") end
    equal(read(path(sim, ".tmp")), nil, "new file cleaned up")
    assert(sim.bot.storage.lastSaveError:find("backup failed", 1, true))
end)

test("rename refused (file locked): the verified copy fallback still saves", function()
    local sim = boot({{"dangis_paths/route1.txt", GOOD}})
    local restore = faulty(sim, {rename=function() return true end})
    assert(sim.bot.storage.save("route1", route(30)))
    restore()
    equal(#assert(sim.bot.storage.load("route1")), 30)
    equal(read(path(sim, ".bak")), GOOD)
    equal(read(path(sim, ".tmp")), nil)
end)

test("replacing the route fails after the backup: the old route is restored", function()
    local sim = boot({{"dangis_paths/route1.txt", GOOD}})
    -- rename onto route1.txt and the copy of the NEW route onto it both fail;
    -- writing the previous route back is allowed
    local restore = faulty(sim, {rename=function(a, b) return b:match("route1%.txt$") ~= nil end})
    local io_ = sim.bot.storage.io
    local writeVerified = io_.writeVerified
    io_.writeVerified = function(p, t)
        if p:match("route1%.txt$") and t:find("#end 30", 1, true) then return false, "injected copy failure" end
        return writeVerified(p, t)
    end
    equal(sim.bot.storage.save("route1", route(30)), false)
    io_.writeVerified = writeVerified; restore()
    equal(read(path(sim)), GOOD, "previous route written back")
    local r = assert(sim.bot.storage.load("route1")); equal(#r, 41)
    equal(read(path(sim, ".bak")), GOOD, "verified backup also present")
end)

-- Interrupted saves -----------------------------------------------------
test("interrupted after the old file was removed: the complete .tmp is used", function()
    local sim = boot({})
    write(path(sim, ".tmp"), sim.bot.storage.io.serialize(route(30)))
    write(path(sim, ".bak"), GOOD)
    local r = assert(sim.bot.storage.load("route1")); equal(#r, 30); equal(sim.bot.storage.lastLoad.source, "tmp")
    sim:frame(1/30, {[0x79]=true}); assert(sim.bot.isPlaying())
end)

test("interrupted while writing .tmp (partial file): the backup is used", function()
    local sim = boot({})
    local text = sim.bot.storage.io.serialize(route(30))
    write(path(sim, ".tmp"), text:sub(1, math.floor(#text / 2)))
    write(path(sim, ".bak"), GOOD)
    local r = assert(sim.bot.storage.load("route1")); equal(#r, 41); equal(sim.bot.storage.lastLoad.source, "bak")
end)

test("a .tmp left by 5.77.5 (no end marker) is not trusted", function()
    local sim = boot({})
    write(path(sim, ".tmp"), table.concat(lines(30), "\n") .. "\n")
    write(path(sim, ".bak"), GOOD)
    equal(#assert(sim.bot.storage.load("route1")), 41)
end)

test("a corrupt route file falls back to the backup and is not backed up over it", function()
    local t = lines(41); t[5] = "{nan}:{8}:{10}:{12}:{0}:{FWD}"
    local sim = boot({{"dangis_paths/route1.txt", table.concat(t, "\n") .. "\n"}, {"dangis_paths/route1.txt.bak", GOOD}})
    local r = assert(sim.bot.storage.load("route1")); equal(#r, 41); equal(sim.bot.storage.lastLoad.source, "bak")
    assert(sim.bot.storage.save("route1", route(30)))
    equal(read(path(sim, ".bak")), GOOD, "valid backup kept")
end)

test("nothing valid at all: playback refuses with a message, no crash", function()
    local sim = boot({{"dangis_paths/route1.txt", "{nan}:{0}:{0}\n"}})
    sim:frame(1/30, {[0x79]=true})
    assert(not sim.bot.isPlaying())
end)

test("the recorder skips a nan sample instead of saving a corrupt route", function()
    local sim = boot({})
    sim:frame(1/30, {[0x71]=true})          -- F2: start recording
    assert(sim.bot.isRecording())
    local getSpeed = sim.env.getCarSpeed
    for i = 1, 60 do
        sim.car.v = 10
        if i == 30 then sim.env.getCarSpeed = function() return 0/0 end end
        if i == 31 then sim.env.getCarSpeed = getSpeed end
        sim:frame(0.1)
    end
    sim:frame(1/30, {[0x71]=true})          -- F2: stop and save
    local r = assert(sim.bot.storage.load("route1"))
    assert(#r >= 50, "route saved without the bad sample")
    for _, p in ipairs(r) do assert(p.speed == p.speed) end
end)

print(total .. " route storage scenarios passed")
