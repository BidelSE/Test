-- Prints the observable symptom of each 5.77.6 review finding for the script
-- in the current folder (a MoonLoader-style folder: dangis_vr.lua, lib/,
-- arbotas_auto.lua). Run it in the 5.77.5 package and in a staged 5.77.6
-- (development/run_tests.sh stages one) to compare:
--   texlua development/repro_findings.lua
package.path = "development/?.lua;" .. package.path
local Sim = require("sim_harness")
local INI = Sim.read("dangis_vr.ini")
local function straight(speed)
    local pts = {}
    for i = 0, 250 do pts[#pts+1] = {x=0, y=i*4, z=10, speed=speed, heading=0, drive="FWD"} end
    return Sim.routeText(pts)
end
local function boot(tag, o)
    o = o or {}
    local sim = Sim.new({root=".", tag="repro_" .. tag, files={{"dangis_vr.ini", INI}, {"dangis_paths/route1.txt", o.route or straight(25)}},
        x=0, y=0, z=10.6, heading=0, walls=o.walls, collision=o.collision, realKeys=o.realKeys})
    sim.groundZ = 10
    sim.bot.loop.initialize()
    return sim
end

-- 1. wall across the route at y=200
do
    local sim = boot("wall", {walls={{-15, 200, 15, 200}}})
    sim:frame(1/30, {[0x79]=true})
    local entries, crossedGas = 0, nil
    for _ = 1, 900 do
        sim:frame(1/30)
        entries = math.max(entries, #sim.bot.S.obstacleHits)
        if not crossedGas and sim.car.y + 2.4 > 200 then crossedGas = sim.bot.manager.applied.gas end
    end
    print(string.format("1 wall: obstacle entries %d; car front %s the wall (gas when crossing: %s); car y=%.0f",
        entries, crossedGas and "CROSSED" or "stopped before", tostring(crossedGas or "-"), sim.car.y))
end
-- 2. no collision API
do
    local sim = boot("noapi", {collision=false})
    sim:frame(1/30, {[0x79]=true})
    for _ = 1, 60 do sim:frame(1/30) end
    print("2 no collision API: " .. sim:snapshot() .. string.format(", car moved %.1f m", sim.car.y))
end
-- 3. the player presses W while the bot holds W (Windows-like keyboard)
do
    local sim = boot("manual", {realKeys=true})
    sim:frame(1/30, {[0x79]=true})
    for _ = 1, 60 do sim:frame(1/30) end
    local before = sim:snapshot()
    sim.physical = {[0x57]=true}; sim.deliverKey(0x57, true, 0); sim.lastHumanKey = 0x57
    for _ = 1, 5 do sim:frame(1/30) end
    print("3 player W over bot W: before " .. before .. " -> after " .. sim:snapshot())
end
-- 4. line-of-sight calls per frame on a clear road
do
    local sim = boot("rays")
    sim:frame(1/30, {[0x79]=true})
    local maxr, sum = 0, 0
    for _ = 1, 300 do sim:frame(1/30); maxr = math.max(maxr, sim.raysLastFrame or 0); sum = sum + (sim.raysLastFrame or 0) end
    print(string.format("4 clear road: LOS calls max %d per frame, mean %.1f; debug probes stored %d", maxr, sum / 300, #sim.bot.S.obstacleProbes))
end
-- 5. dialog helper
do
    local H = require("dialog_harness")
    local function scan(rows) local d = H.load("arbotas_auto.lua"); d.show(table.concat(rows, "\n")); return table.concat({tostring((d.api.scan()))}, "") , d end
    local shop = {"{FFFFFF}Ginklai", "{FFFFFF}Deagle 500$", "{FFFFFF}M4 1500$", " ", "{FFFFFF}Sarvai 200$", "{FFFFFF}Atgal"}
    local last = {"Pasirinkite tuscia eilute", "{FF4444}Pasirinkus blogai galima gauti Ban", "{99CCFF}1 2 3", "{88CCFF}4 + 5", "{AADDFF}7 8 9", " "}
    local d1 = H.load("arbotas_auto.lua"); d1.show(table.concat(shop, "\n")); local a1, b1 = d1.api.scan()
    local d2 = H.load("arbotas_auto.lua"); d2.show(table.concat(last, "\n")); local a2, b2 = d2.api.scan()
    print(string.format("5 dialog: shop list with a blank row -> %s; real check, blank row last -> %s",
        a1 and ("ANSWERED row " .. tostring(b1)) or "ignored", a2 and ("answered row " .. tostring(b2)) or "MISSED"))
end
-- 6. route file with corrupt values
do
    local lines = {}
    for i = 0, 40 do lines[#lines+1] = string.format("{0}:{%d}:{10}:{12}:{0}:{FWD}", i * 2) end
    local out = {}
    for _, bad in ipairs({"{1e999}:{18}:{10}:{12}:{0}:{FWD}", "{0}:{18}:{10}:{nan}:{0}:{FWD}", "{0}:{18}:{x}:{12}:{0}:{FWD}", "{0}:{18}:{10}:{12}:{0}:{SIDEWAYS}", "{0}:{18}"}) do
        local t = {}; for i, l in ipairs(lines) do t[i] = l end; t[10] = bad
        local sim = boot("route", {route=table.concat(t, "\n") .. "\n"})
        local r = sim.bot.storage.load("route1")
        out[#out+1] = bad:sub(1, 12) .. (r and " ACCEPTED" or " rejected")
    end
    print("6 route values: " .. table.concat(out, "; "))
end
