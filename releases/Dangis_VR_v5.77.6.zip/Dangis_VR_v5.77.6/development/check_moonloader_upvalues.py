"""MoonLoader limits check for every runtime Lua file (Dangis VR 5.77.6).

MoonLoader runs scripts on LuaJIT 2.1, which refuses a function with more
than 60 upvalues or 200 locals. Two independent checks, each must pass:
  1. the Lua 5.3 compiler listing (texluac or luac5.3): every function's
     upvalue count <= 60 (Lua 5.3 also counts _ENV, so this is conservative)
     and the main chunk's locals <= 200;
  2. if LuaJIT is available: `luajit -b` compiles the file (it enforces its
     own limits and syntax).
Exit status 1 on any failure (missing compiler included), so a runner sees it.
Run from the package root: python3 development/check_moonloader_upvalues.py
"""
import glob, os, re, shutil, subprocess, sys, tempfile

files = sorted(glob.glob("moonloader/*.lua") + glob.glob("moonloader/lib/*.lua") + glob.glob("tools/*.lua"))
if len(sys.argv) > 1:
    files = sys.argv[1:]
luac = shutil.which("texluac") or shutil.which("luac5.3") or shutil.which("luac5.4")
luajit = shutil.which("luajit")
failures = []
if not files:
    failures.append("no Lua files found (run from the package root)")
if not luac:
    failures.append("no Lua 5.3/5.4 compiler (texluac or luac5.3) for the listing check")
worst = (0, "")
out = os.path.join(tempfile.gettempdir(), "dangis_luac.out")
for path in files:
    if luac:
        res = subprocess.run([luac, "-o", out, "-l", path], capture_output=True, text=True)
        if res.returncode != 0:
            failures.append(f"{path}: compile error: {res.stderr.strip()}")
        else:
            for name, ups in re.findall(r"^(?:main|function) <([^>]*)>.*\n.*?(\d+) upvalues?", res.stdout, re.M):
                if int(ups) > worst[0]:
                    worst = (int(ups), name)
                if int(ups) > 60:
                    failures.append(f"{name}: {ups} upvalues (limit 60)")
            m = re.search(r"^main <[^>]*>.*\n.*?(\d+) locals", res.stdout, re.M)
            if m and int(m.group(1)) > 200:
                failures.append(f"{path}: main chunk has {m.group(1)} locals (limit 200)")
    if luajit:
        res = subprocess.run([luajit, "-b", path, os.devnull], capture_output=True, text=True)
        if res.returncode != 0:
            failures.append(f"{path}: LuaJIT refuses it: {res.stderr.strip()}")
if os.path.exists(out):
    os.remove(out)
if failures:
    for f in failures:
        print("FAIL " + f)
    sys.exit(1)
print(f"Compile and upvalue ceiling passed for {len(files)} files: maximum {worst[0]} upvalues "
      f"including _ENV ({worst[1]}){'; LuaJIT compiled every file' if luajit else '; LuaJIT not available'}")
