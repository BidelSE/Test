-- 5.77.6 dialog companion (arbotas_auto.lua 1.7): which lists are answered,
-- row boundaries, and re-validation before every key. The shipped script runs
-- with a mocked SA-MP dialog in memory (development/dialog_harness.lua).
-- Usage (from the package root): texlua development/test_dialog_companion.lua
package.path = "development/?.lua;" .. package.path
local H = require("dialog_harness")
local total = 0
local function test(name, fn) fn(H.load("arbotas_auto.lua")); total = total + 1; print("PASS " .. name) end
local function equal(a, b, m) if a ~= b then error((m or "value") .. ": expected " .. tostring(b) .. ", got " .. tostring(a), 2) end end
local function dialog(rows, trailing) return table.concat(rows, "\n") .. (trailing and "\n" or "") end
local HEAD = {"Pasirinkite tuscia eilute", "{FF4444}Pasirinkus blogai galima gauti Ban"}
local function tuscia(blankAt, n)
    local rows = {HEAD[1], HEAD[2]}
    for i = 1, n or 8 do rows[#rows+1] = i == blankAt and " " or string.format("{99CCFF}%d %d %05d", i, i * 7, i * 131) end
    return rows
end
local function downs(n) local t = {} for _ = 1, n do t[#t+1] = "DOWN" end; t[#t+1] = "ENTER"; return table.concat(t, " ") end

test("an unrelated list with one blank row is never acted on (was answered as 'tuscia')", function(d)
    d.show(dialog({"{FFFFFF}Ginklai", "{FFFFFF}Deagle 500$", "{FFFFFF}M4 1500$", " ", "{FFFFFF}Sarvai 200$", "{FFFFFF}Atgal"}))
    d.run(15)
    equal(d.keys(), "", "keys")
    local warned = false
    for _, n in ipairs(d.notes) do if n:find("neatpa", 1, true) then warned = true end end
    assert(warned, "the player is told the list was not recognised")
end)

test("a blank row that is the LAST row is found (was trimmed away)", function(d)
    d.show(dialog(tuscia(8)))
    d.run(15)
    equal(d.keys(), downs(9))
end)

test("a final newline is not mistaken for a blank row", function(d)
    d.show(dialog(tuscia(8), true))
    d.run(15)
    equal(d.keys(), downs(9))
    local d2 = H.load("arbotas_auto.lua")
    d2.show(dialog(tuscia(4), true))
    d2.run(15)
    equal(d2.keys(), downs(5))
end)

test("unchanged: blank row in the middle", function(d)
    d.show(dialog(tuscia(3)))
    d.run(15)
    equal(d.keys(), downs(4))
end)

test("two blank rows: not answered", function(d)
    local rows = tuscia(3); rows[7] = " "
    d.show(dialog(rows))
    d.run(15)
    equal(d.keys(), "")
end)

test("header with Lithuanian letters (read as '?') is recognised", function(d)
    local rows = tuscia(5); rows[1] = "Pasirinkite tu\240\232i\224 eilut\235"
    d.show(dialog(rows))
    d.run(15)
    equal(d.keys(), downs(6))
end)

test("white-numbers check: the 'N N N' row in white is chosen, decoy blank rows ignored", function(d)
    local rows = {"{FFFFFF}Pasirinkite eilut\235 su visais 3 baltais skai\232iais", "{99CCFF}12 {FFFFFF}34 56",
        "{FFFFFF}11 {FFFFFF}22 {FFFFFF}33", " ", "{AADDFF}1 2 3", " "}
    d.show(dialog(rows))
    d.run(15)
    equal(d.keys(), downs(2))
end)

test("white numbers in an unrelated list are not acted on", function(d)
    d.show(dialog({"{FFFFFF}Kainos", "{FFFFFF}100 {FFFFFF}200 {FFFFFF}300", "{FFFFFF}a", "{FFFFFF}b", "{FFFFFF}c"}))
    d.run(15)
    equal(d.keys(), "")
end)

test("the dialog is replaced by another with the same row before the answer: the first answer is dropped", function(d)
    d.show(dialog(tuscia(3)))
    local other = tuscia(3); other[7] = "{99CCFF}different 1 2"   -- row 5 is the blank one
    local swapAt
    d.run(20, nil, function(now)
        -- main() starts scanning 3 s after load (now = 13); swap just after detection
        if now > 13.4 and not swapAt then swapAt = now; d.show(dialog(other)) end
    end)
    local detected, dropped = 0, false
    for _, n in ipairs(d.notes) do
        if n:find("aptiktas", 1, true) then detected = detected + 1 end
        if n:find("praleistas", 1, true) then dropped = true end
    end
    assert(dropped, "the answer prepared for the first dialog is dropped")
    equal(detected, 2, "the replacement dialog is detected afresh (own delay)")
    equal(d.keys(), downs(4))
end)

test("the dialog text changes while moving down the list: navigation stops before Enter", function(d)
    d.show(dialog(tuscia(7)))
    local changed = tuscia(7); changed[1] = "Pasirinkite tuscia eilute!"
    d.run(15, nil, function()
        if not d.swapped then
            for _, e in ipairs(d.events) do
                if e.vk == 0x28 then d.swapped = true; d.show(dialog(changed)); break end
            end
        end
    end)
    assert(not d.keys():find("ENTER", 1, true), "Enter must not be pressed: " .. d.keys())
end)

test("focus lost before the answer: no key is sent to another window", function(d)
    d.show(dialog(tuscia(3)))
    d.focused = false
    d.run(15)
    equal(d.keys(), "")
end)

print(total .. " dialog companion scenarios passed")
