# Tests (development only)

All tests run the shipped scripts unmodified in a simulator: mocked
MoonLoader / GTA / SA-MP / Windows APIs, a simple kinematic car, ideal walls and
objects, and a modelled Windows keyboard. **None of this is a substitute for
the in-game checklist in `INSTALL.md`.**

```
sh development/run_tests.sh              # texlua + LuaJIT, all tests, exit 1 on any failure
sh development/run_tests.sh luajit       # one interpreter
ONLY="test_passage test_panel" sh development/run_tests.sh
texlua development/repro_findings.lua    # in a staged/old package folder: the review findings' symptoms
```

The runner stages `moonloader/`, `defaults/`, `tools/test_rotate.lua` and
`development/` into a temporary MoonLoader-style folder and runs there.

## Inventory

Every Lua test file shipped in 5.77.5 and 5.77.6, with its state.

| File | In 5.77.5 runner | State in 5.77.6 | Covers |
|---|---|---|---|
| test_driving_identity.lua | yes | **updated** | your v5.77 vs 5.77.6 frame by frame: route1 at 30/60/18–45 FPS, dialogs, freeze, chat, F6, route end, reverse, gamepad, planner; source-level list of changed v5.77 functions with reasons. Scenarios where 5.77.6 deliberately differs (parked cars and wall in the path, no collision API) compare v5.77's code paths with `passage_check` off; `test_passage.lua` covers them with it on |
| test_rotation.lua | yes | unchanged | apsukimas recovery integration |
| test_rotation_modern.lua | yes | unchanged | rotation state machine |
| test_probe.lua | yes | unchanged | budgeted rotation probes |
| test_audit_r4.lua | yes | unchanged | audit regressions R4 |
| test_session_routes.lua | yes | unchanged | recovery-route sessions |
| test_rotate_tool.lua | yes | unchanged | `tools/test_rotate.lua` switch |
| test_obstacles.lua | yes | unchanged | objects in the lane, 15/25/35 m/s |
| test_roadworks.lua | yes (+RW_POOL=1) | unchanged; runner also runs RW_POOL=nodims | road works, 20/36 m/s, straight and bend |
| test_accessories.lua | yes | unchanged | nitro/look keys |
| test_recovery_rejoin.lua | yes | unchanged | bump recovery, rejoin |
| test_telemetry.lua | yes | unchanged | F5 capture |
| test_driving.lua | **no** (passed) | **repaired** | planner/steering/classifier units. Fixtures: an empty-world collision function (the passage check holds without collision data) and a two-argument arctangent that also works on LuaJIT (the run silently aborted under LuaJIT, also with 5.77.5) |
| test_expansion.lua | **no** (failed) | **repaired** | settings, chat, diagnostics. Obsolete: expected the pre-5.72 9-line dashboard; now checks the 5.72 card's Lithuanian content. LuaJIT arctangent fixture |
| test_admin_chat.lua | **no** (failed) | **repaired** | chat typing safety. Obsolete: used `rotation` as a generic completion kind, which 5.78 deliberately silenced (`AdminChat.complete`); now `arbotas`. The single-turn rotation reply test now asserts the reply is discarded |
| test_panel.lua | **no** (failed) | **repaired** | settings panel. Obsolete: fixed pre-5.72 click coordinates; the row is now located from the layout. The save-failure test now injects a failure that really prevents saving (a refused rename is recovered by the new verified copy); two save/backup tests added. LuaJIT arctangent fixture |
| test_control_ownership.lua | **no** (failed) | **repaired** | control ownership. Obsolete: expected the forced throttle of `pressRotateReaction`, which 5.78 removed on purpose (code comment); now asserts the ownership contract via an explicit ROTATE request |
| test_dialog_events.lua | **no** (failed) | **repaired** (runner passes the path) | `/arbotas` completion events. Its default path `chat_update/arbotas_auto.lua` did not exist |
| test_routes.lua | **no** (failed) | **archived** | needs `lib/dangis_routes.lua` (named routes), which never existed in 5.77.x — see `archive/README.md` |
| audit_object_detection.lua | no (audit) | **archived** | one-off v5.77 audit without assertions — see `archive/README.md` |
| test_route_storage.lua | — | **new** (finding 6) | strict route parsing, checked save, write/flush/close/backup/rename failures, interrupted saves, .tmp/.bak recovery, recorder nan |
| test_dialog_companion.lua | — | **new** (finding 5) | unrelated lists ignored, blank last row, trailing newline, two blanks, Lithuanian header, white numbers, replaced/changed dialog, focus |
| test_input_ownership.lua | — | **new** (finding 3) | player W/A/S/D over held bot keys, handover without key-up, focus loss, F6, F7, unload, fallback without tagged messages |
| test_passage.lua | — | **new** (findings 1, 2, 4) | walls at 20/36 m/s and low FPS, gamepad, gate, partial wall, object barrier, narrow street, ramps, side step into wall / off road, no API, failing/nil queries, starved budget, stale answers, LOS calls per frame, pending sweeps, teleport, clear-road identity with/without the check |
| test_package.lua | — | **new** (finding 7) | code-only runtime folder (update safety), shipped libraries, versions, defaults load, old INI and route load unchanged |
| tools/test_rotate.lua | — | not a test | in-game tool (moved from the top level) |
| sim_harness.lua | — | updated | `realKeys` Windows keyboard model; stable `thisScript()` (unload was never simulated before) |
| dialog_harness.lua | — | new | loads `arbotas_auto.lua` with a dialog in memory |

## Results

See `validation_5_77_6.txt` (complete output of the last run; texlua 1.18
(Lua 5.3) and LuaJIT 2.1).
