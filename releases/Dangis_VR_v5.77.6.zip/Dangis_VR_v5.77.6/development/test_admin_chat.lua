-- Execute the actual shipped script with mocked game/Windows surfaces.
-- No copied manager implementation and no GTA/SA-MP installation required.
local sourcePath = arg[1] or 'dangis_vr.lua'
local file = assert(io.open(sourcePath, 'rb'))
local source = file:read('*a'); file:close()
local testRoot = '/tmp/dangis_chat_test'
os.execute('mkdir -p ' .. testRoot)
local fakeNow = 10
os.clock = function() return fakeNow end
package.preload['lib.moonloader'] = function() return {} end
script_name = function() end
script_version = function() end
getWorkingDirectory = function() return testRoot end
PLAYER_PED = 1
local inCar = true
isCharInAnyCar = function() return inCar end
storeCarCharIsInNoSave = function() return 1 end
getCarCoordinates = function() return 0, 0, 0 end
getCarHeading = function() return 0 end
getDistanceBetweenCoords2d = function(x,y,a,b) return math.sqrt((x-a)^2+(y-b)^2) end
printStringNow = function() end
local writes, pad = {}, {}
writeMemory = function(address, size, value)
    assert(size == 2)
    writes[#writes+1] = {address=address, value=value}
    pad[address] = value
end
setGameKeyState = function(key, value)
    assert(key == 0)
    writes[#writes+1] = {steer=value}
    pad.steer = value
end
local appended = [[
return {
    api=API, chat=AdminChat, typeText=typeSAMPCommand, chatOpen=isSampChatInputActive, originalForeground=Win32.isGameForeground,
    resetCommand=function() commandJob=nil end, finishDialog=finishDialogPause, dialogUpdate=DialogBridge.update,
    manager=ControlManager, S=S, config=CONFIG, Win32=Win32, Mem=Mem, input=InputHandler,
    route=RouteFollower, recovery=RecoverySystem, loop=MainLoop,
    release=releaseControls, pedals=writeDriveControls, steering=writeSteerControls,
    state=writeSharedState, bump=startBumpRecovery, updateBump=updateBumpRecovery,
    transition=startBackToForwardTransition, freeze=startFreezeRecovery, refreshStep=updateRefreshStep,
    rotate=handleAdminRotate, rotation=pressRotateReaction,
    setPlaying=function(value) playing=value end,
    setSamp=function(value) samp=value end,
    setRoute=function(value) current_route=value; play_index=1 end,
    setSpeed=function(value) lastDriveSpeed=value; S.forwardSpeed=value end,
    applied=function() return ControlManager.applied end,
    owner=function() return ControlManager.owner end,
    clearSharedThrottle=function() lastSharedStateWriteAt=-1 end,
    setLoopStages=function(dialog, recovery, recorder, playback)
        DialogBridge.update=dialog; RecoverySystem.updateControlThread=recovery
        RouteRecorder.recordTick=recorder; RouteFollower.updatePlayback=playback
    end,
}
]]
local bot = assert((loadstring or load)(source .. appended, '@'..sourcePath))()
bot.config.controls.input="gamepad"
local physical, dialog = false, false
isKeyDown = function() return physical end
bot.Win32.isGameForeground = function() return true end
bot.Win32.keyDown = function() return physical end
bot.Mem.readDword = function(address)
    if address == 0x100000 + 0x21A0B8 then return 0x1000000 end
    if address == 0x1000000 + 0x28 then return dialog and 1 or 0 end
end
bot.setSamp(0x100000)
local function flag(name, value)
    local path=testRoot..'/dangis_vr_'..name..'.flag'
    if value then local f=assert(io.open(path,'w')); f:write(value); f:close()
    else os.remove(path) end
end
local function reset()
    flag('freeze'); flag('dialog'); flag('rotate')
    physical, dialog, inCar = false, false, true
    bot.config.controls.brakeMode="foot"
    if bot.config.escape then bot.config.escape.enabled=false end
    bot.setPlaying(false)
    bot.route.clearTransientState()
    bot.manager.neutralize()
    bot.setPlaying(true)
    bot.setRoute({{x=0,y=0,z=0,speed=10,drive='FWD'}, {x=10,y=0,z=0,speed=10,drive='FWD'}})
    bot.setSpeed(20)
    bot.manager.sync()
    writes={}
end
local function equal(value, expected, message)
    assert(value==expected, (message or 'value')..': expected '..tostring(expected)..', got '..tostring(value))
end
local function neutral()
    equal(pad[bot.config.controls.gasAddress],0,'gas')
    equal(pad[bot.config.controls.footBrakeAddress],0,'foot brake')
    equal(pad[bot.config.controls.handbrakeAddress],0,'handbrake')
    equal(pad.steer,0,'steer')
    equal(bot.applied().reverse,false,'reverse')
end
local originalForeground=bot.originalForeground
local chatOpen, unknown, focus, dontOpen = false,false,true,false
local keyboard, keyEvents, threads = {},{},{}
local callback=nil
wait=function(ms) coroutine.yield((ms or 0)/1000) end
lua_thread={create=function(fn)
 local task={co=coroutine.create(fn),at=fakeNow}; threads[#threads+1]=task; return task
end}
local function pump()
 local steps=0
 while #threads>0 do
  local task=table.remove(threads,1)
  fakeNow=math.max(fakeNow,task.at)
  if callback then callback(steps) end
  local ok,delay=coroutine.resume(task.co); assert(ok,delay)
  if coroutine.status(task.co)~='dead' then
   task.at=fakeNow+(delay or 0); threads[#threads+1]=task
  end
  steps=steps+1; assert(steps<2000,'typing loop did not terminate')
 end
end
bot.Win32.init=function() return true end
bot.Win32.isGameForeground=function() return focus end
bot.Win32.keyDown=function(vk) return keyboard[vk]==true or bot.Win32.held[vk]==true end
isKeyDown=function(vk) return bot.Win32.keyDown(vk) end
bot.Win32.press=function(vk)
 bot.Win32.held[vk]=true; keyEvents[#keyEvents+1]={vk=vk,down=true}
 if vk==0x54 and not chatOpen and not dontOpen then chatOpen=true end
 if (vk==0x0D or vk==0x1B) and chatOpen then chatOpen=false end
 return true
end
bot.Win32.release=function(vk) bot.Win32.held[vk]=nil; keyEvents[#keyEvents+1]={vk=vk,down=false}; return true end
bot.Win32.u32={VkKeyScanA=function(byte)
 if byte==63 then return 0xBF+256 end
 if byte==32 then return 32 end
 return byte
end}
bot.Mem.readDword=function(address)
 if address==0x100000+0x21A0B8 then return 0x1000000 end
 if address==0x1000000+0x28 then return dialog and 1 or 0 end
 if address==0x100000+0x21A0E8 then if unknown then return nil end; return 0x2000000 end
 if address==0x2000000+0x14E0 then return chatOpen and 1 or 0 end
end
local function pressed(vk)
 for _,event in ipairs(keyEvents) do if event.down and event.vk==vk then return true end end
 return false
end
local total=0
local function prepare()
 bot.api.playerControlOn=nil;PLAYER_HANDLE=nil
 reset(); bot.resetCommand(); bot.chat.clear()
 bot.config.recovery.refreshAfterArbotas=true
 bot.chat.seen,bot.chat.seenOrder={},{}
 bot.chat.phrases={'kas cia buvo?','lagas?','wtf'}; bot.chat.bag={}; bot.chat.lastPhrase=nil
 bot.chat.lastEventPoll=-1
 bot.chat.lastSent=-100; bot.config.adminChat.includeLocalTests=false
 bot.config.adminChat.quitEnabled=true; bot.config.adminChat.includeInferredTests=false; bot.config.adminChat.enabled=true; bot.config.adminChat.delayMinSeconds=0.8; bot.config.adminChat.delayMaxSeconds=1.8
 chatOpen,unknown,focus,dontOpen=false,false,true,false
 keyboard,keyEvents,threads={},{},{}; callback=nil
 bot.Win32.held={};bot.Win32.driveHeld={};bot.config.controls.input="gamepad"
 bot.S.adminChatTyping=false; bot.S.freezeChatToken=nil
 os.remove(bot.config.adminChat.eventFile)
end
local function test(name,fn)
 prepare(); fn(); total=total+1; print('PASS '..name)
end
local function queued(token)
 assert(bot.chat.complete('arbotas',token or bot.chat.begin('arbotas'),false))
 fakeNow=fakeNow+2
end

test('each completion token queues at most once',function()
 local token=bot.chat.begin('freeze')
 assert(bot.chat.complete('freeze',token,false)); assert(not bot.chat.complete('freeze',token,false))
 equal(#bot.chat.queue,1)
end)

test('local tests are opt-in and stop/idle never queues chat',function()
 assert(not bot.chat.complete('freeze','local1',true))
 bot.config.adminChat.includeLocalTests=true
 assert(bot.chat.complete('freeze','local2',true))
 bot.setPlaying(false); assert(not bot.chat.complete('rotation','idle',false))
end)

test('30 phrase shuffle uses each once per cycle and avoids immediate repeats',function()
 bot.chat.phrases={}; for i=1,30 do bot.chat.phrases[i]='phrase '..i end
 local seen={}; local last=nil
 for i=1,30 do local text=bot.chat.pick(); assert(not seen[text]); seen[text]=true; last=text end
 assert(bot.chat.pick()~=last)
end)

test('text file normalizes Lithuanian and rejects commands/control text',function()
 local file=assert(io.open(bot.config.adminChat.phraseFile,'w'))
 file:write('# comment\n ką čia darai? \nwtf\nwtf\n/refresh\ninvalid\1text\n');file:close()
 equal(bot.chat.loadPhrases(),2)
 equal(bot.chat.phrases[1],'ka cia darai?'); equal(bot.chat.phrases[2],'wtf')
 equal(bot.chat.normalize('a\nb'),nil)
 os.remove(bot.config.adminChat.phraseFile)
end)

test('T then characters then Enter sends one message while holding neutral',function()
 queued('send1');bot.chat.tick()
 assert(bot.S.adminChatTyping); equal(bot.owner(),'CHAT'); neutral()
 assert(not bot.pedals(255,0))
 pump(); assert(bot.chat.job.done); assert(bot.chat.job.ok); assert(bot.chat.job.submitted)
 assert(pressed(0x54)); assert(pressed(0x0D)); equal(chatOpen,false)
 bot.chat.tick(); equal(bot.S.adminChatTyping,false); equal(#bot.chat.queue,0)
 equal(bot.chat.job,nil)
end)

test('open or unknown chat defers without injecting keys',function()
 queued('chat_busy'); chatOpen=true; bot.chat.tick(); equal(#keyEvents,0); equal(#bot.chat.queue,1)
 chatOpen=false; unknown=true;bot.chat.tick(); equal(#keyEvents,0); equal(#bot.chat.queue,1)
end)

test('focus, dialog, physical typing and recovery defer sending',function()
 queued('blocked')
 focus=false;bot.chat.tick();equal(#keyEvents,0)
 focus=true;dialog=true;bot.chat.tick();equal(#keyEvents,0)
 dialog=false;keyboard[0x4B]=true;bot.chat.tick();equal(#keyEvents,0)
 keyboard={};bot.S.bumpActive=true;bot.chat.tick();equal(#keyEvents,0)
 bot.S.bumpActive=false;flag('freeze','1\n');bot.chat.tick();equal(#keyEvents,0)
end)

test('losing focus during typing never presses Enter or Escape elsewhere',function()
 queued('focus_loss');bot.chat.tick()
 callback=function(step) if step>=1 then focus=false end end
 pump(); assert(not bot.chat.job.ok); assert(not pressed(0x0D)); assert(not pressed(0x1B))
 equal(next(bot.Win32.held),nil)
end)

test('human takeover leaves chat buffer open and does not submit',function()
 queued('human_takeover');bot.chat.tick()
 callback=function(step) if step>=1 then keyboard[0x4B]=true end end
 pump(); equal(bot.chat.job.reason,'user input')
 assert(not pressed(0x0D)); assert(not pressed(0x1B)); assert(chatOpen)
 bot.chat.tick(); bot.manager.sync(); equal(bot.owner(),'CHAT')
end)

test('freeze during typing aborts, closes owned chat, and holds neutral',function()
 queued('freeze_interrupt');bot.chat.tick()
 callback=function(step) if step>=1 then flag('freeze','1\n') end end
 pump(); assert(not bot.chat.job.ok); assert(not pressed(0x0D)); assert(pressed(0x1B))
 bot.chat.tick(); bot.manager.sync(); equal(bot.owner(),'FREEZE'); neutral()
end)

test('failure to open chat never types a phrase or submits',function()
 queued('no_open');dontOpen=true;bot.chat.tick();pump()
 equal(bot.chat.job.reason,'chat did not open');assert(not pressed(0x0D))
 for _,event in ipairs(keyEvents) do if event.down then equal(event.vk,0x54) end end
end)

test('expired completions are discarded and repeated completions are spaced',function()
 queued('old');fakeNow=fakeNow+31;bot.chat.tick();equal(#bot.chat.queue,0);equal(#keyEvents,0)
 queued('new1');bot.chat.tick();pump();bot.chat.tick()
 local count=#keyEvents
 assert(bot.chat.complete('arbotas','new2',false));fakeNow=fakeNow+2;bot.chat.tick();equal(#keyEvents,count)
 fakeNow=fakeNow+5;bot.chat.tick();assert(bot.chat.job)
end)

test('only fresh recognized-dialog completion events are accepted',function()
 local file=assert(io.open(bot.config.adminChat.eventFile,'w'));file:write('dialogtoken\n'..fakeNow..'\n');file:close()
 bot.chat.pollDialogEvent();equal(#bot.chat.queue,1)
 fakeNow=fakeNow+0.06
 file=assert(io.open(bot.config.adminChat.eventFile,'w'));file:write('dialogtoken\n'..fakeNow..'\n');file:close()
 bot.chat.pollDialogEvent();equal(#bot.chat.queue,1)
 fakeNow=fakeNow+0.06
 file=assert(io.open(bot.config.adminChat.eventFile,'w'));file:write('stale\n'..(fakeNow-31)..'\n');file:close()
 bot.chat.pollDialogEvent();equal(#bot.chat.queue,1)
end)

-- 5.77.6 repair: the pre-5.78 single-turn rotation reply (AdminChat.rotation)
-- was intentionally replaced by completed-sequence replies (covered in
-- test_rotation.lua). A leftover single-turn reply must now be discarded.
test('obsolete single-turn rotation reply is discarded, never queued',function()
 bot.chat.rotation={token='rotate_done',untilTime=fakeNow+2,localTest=false}
 bot.chat.tick();equal(#bot.chat.queue,0);equal(bot.chat.rotation,nil)
 fakeNow=fakeNow+2;bot.chat.tick();equal(#bot.chat.queue,0)
 assert(not bot.chat.complete('rotation','rotate_done2',false))
end)

test('opted-in inferred freeze completion queues only once',function()
 bot.config.adminChat.includeInferredTests=true
 bot.freeze('real');assert(bot.S.freezeChatToken)
 bot.recovery.resetFreezeRecovery();equal(#bot.chat.queue,1)
 bot.recovery.resetFreezeRecovery();equal(#bot.chat.queue,1)
end)

test('ordinary dialog close never queues an admin reaction',function()
 bot.S.dialogPaused=true
 bot.finishDialog();equal(#bot.chat.queue,0)
end)

test('fake arbotas completion is optional and emitted only once',function()
 bot.config.adminChat.includeLocalTests=true
 flag('dialog','fake_arbotas\n');bot.dialogUpdate()
 flag('dialog');bot.dialogUpdate();equal(#bot.chat.queue,1)
 bot.dialogUpdate();equal(#bot.chat.queue,1)
end)

test('an empty phrase file emits no public message',function()
 bot.chat.phrases={};os.remove(bot.config.adminChat.phraseFile)
 queued('no_phrases');bot.chat.tick()
 equal(#bot.chat.queue,0);equal(#keyEvents,0)
end)

test('strict foreground checks do not indefinitely stale the ordinary focus cache',function()
 bot.Win32.ffi={new=function() return {[0]=0} end}
 bot.Win32.k32={GetCurrentProcessId=function() return 42 end}
 bot.Win32.u32.GetForegroundWindow=function() return 1 end
 bot.Win32.u32.GetWindowThreadProcessId=function(hwnd,pid) pid[0]=focus and 42 or 99 end
 bot.Win32.focusCheckedAt=-1;focus=true
 assert(originalForeground(false))
 focus=false;fakeNow=fakeNow+0.01;equal(originalForeground(true),false)
 fakeNow=fakeNow+0.04;equal(originalForeground(true),false)
 fakeNow=fakeNow+0.01;equal(originalForeground(false),false)
end)

test('stop cancels typing and clears pending messages',function()
 queued('stop_now');bot.chat.tick();local job=bot.chat.job
 bot.route.stopAll();assert(job.cancelled);equal(#bot.chat.queue,0);equal(bot.S.adminChatTyping,false)
 pump();assert(not pressed(0x0D));equal(next(bot.Win32.held),nil)
end)

test('shipped pool contains all 99 phrases without markup or action annotation',function()
 local old=bot.config.adminChat.phraseFile
 bot.config.adminChat.phraseFile=sourcePath:gsub('[^/]+$','dangis_admin_phrases.txt')
 equal(bot.chat.loadPhrases(),99)
 equal(bot.chat.phrases[1],'ka cia darai krw')
 equal(bot.chat.phrases[3],'ai nx as taip nezaisiu')
 equal(bot.chat.phrases[31],'vel testas bl')
 equal(bot.chat.phrases[99],'po sito jau paleisi?')
 local seen={}
 for i=1,99 do
  local phrase=bot.chat.pick();assert(not seen[phrase]);seen[phrase]=true
  assert(not phrase:find('&#') and not phrase:find('disconnect'))
 end
 bot.config.adminChat.phraseFile=old
end)

local function startQuitPhrase()
 bot.chat.phrases={'ai nx as taip nezaisiu'};bot.chat.bag={}
 queued('quit_phrase');bot.chat.tick()
 equal(bot.chat.job.cmd,'ai nx as taip nezaisiu')
end

test('quit phrase submits first, then separately types /q and stops playback',function()
 startQuitPhrase();pump();assert(bot.chat.job.submitted)
 bot.chat.tick();assert(bot.chat.pendingQuit);assert(bot.S.adminChatTyping)
 bot.manager.sync();equal(bot.owner(),'CHAT');neutral()
 assert(not bot.chat.job)
 fakeNow=fakeNow+0.6;bot.chat.tick()
 equal(bot.chat.job.cmd,'/q');assert(bot.chat.job.isQuit)
 pump();assert(bot.chat.job.ok and bot.chat.job.submitted)
 local enters=0
 for _,event in ipairs(keyEvents) do if event.down and event.vk==0x0D then enters=enters+1 end end
 equal(enters,2)
 bot.chat.tick();equal(bot.chat.pendingQuit,nil);equal(#bot.chat.queue,0)
 assert(not bot.chat.complete('rotation','afterquit',false))
end)

test('failed phrase never schedules /q',function()
 startQuitPhrase();dontOpen=true;pump();assert(not bot.chat.job.ok)
 bot.chat.tick();equal(bot.chat.pendingQuit,nil);equal(bot.chat.job,nil)
 fakeNow=fakeNow+2;bot.chat.tick();equal(bot.chat.job,nil)
end)

for _,interruption in ipairs({'physical','focus','dialog','freeze','unknown','manual','expiry','stop'}) do
 test('pending /q cancels on '..interruption,function()
  startQuitPhrase();pump();bot.chat.tick();assert(bot.chat.pendingQuit)
  if interruption=='physical' then keyboard[0x4B]=true
  elseif interruption=='focus' then focus=false
  elseif interruption=='dialog' then dialog=true
  elseif interruption=='freeze' then flag('freeze','1\n')
  elseif interruption=='unknown' then unknown=true
  elseif interruption=='manual' then bot.S.manualPaused=true
  elseif interruption=='expiry' then fakeNow=fakeNow+4
  elseif interruption=='stop' then bot.route.stopAll() end
  bot.chat.tick();equal(bot.chat.pendingQuit,nil);equal(bot.chat.job,nil)
  keyboard={};focus=true;dialog=false;unknown=false;bot.S.manualPaused=false;flag('freeze')
  fakeNow=fakeNow+5;bot.chat.tick();equal(bot.chat.job,nil)
 end)
end

test('interrupted /q is not retried or submitted',function()
 startQuitPhrase();pump();bot.chat.tick();fakeNow=fakeNow+0.6;bot.chat.tick()
 equal(bot.chat.job.cmd,'/q')
 callback=function(step) if step>=1 then keyboard[0x4B]=true end end
 pump();assert(not bot.chat.job.ok);assert(not bot.chat.job.submitted)
 bot.chat.tick();equal(bot.chat.pendingQuit,nil);equal(bot.chat.job,nil)
end)

test('quit can be disabled without suppressing its public phrase',function()
 bot.config.adminChat.quitEnabled=false
 startQuitPhrase();pump();assert(bot.chat.job.ok and bot.chat.job.submitted)
 bot.chat.tick();equal(bot.chat.pendingQuit,nil);equal(bot.chat.job,nil)
 fakeNow=fakeNow+2;bot.chat.tick();equal(bot.chat.job,nil)
 local enters=0
 for _,event in ipairs(keyEvents) do if event.down and event.vk==0x0D then enters=enters+1 end end
 equal(enters,1)
end)

test('local freeze sends refresh through T text Enter when enabled',function()
 bot.config.recovery.typeRefreshInFreezeTest=true
 bot.freeze('test');fakeNow=bot.S.freezeRefreshAt+0.01
 bot.refreshStep(fakeNow);assert(bot.S.refreshJob)
 local job=bot.S.refreshJob;pump()
 assert(job.ok and job.submitted);assert(pressed(0x54));assert(pressed(0x0D))
 bot.refreshStep(fakeNow);fakeNow=bot.S.freezeReleaseUntil+0.01;bot.refreshStep(fakeNow)
 equal(bot.S.freezeTestLatched,false)
end)

local function recognized(token)
 fakeNow=fakeNow+0.06
 local f=assert(io.open(bot.config.adminChat.eventFile,'w'))
 f:write(token..'\n'..string.format('%.17g',fakeNow)..'\n');f:close();bot.chat.pollDialogEvent()
end

test('arbotas completion schedules refresh even when phrases are disabled and recovery paused',function()
 bot.config.adminChat.enabled=false;bot.S.manualPaused=true
 bot.S.recoveryBlockedCode='RECOVERY_BLOCKED'
 recognized('sequence_disabled_chat')
 equal(bot.S.freezeRecoveryMode,'arbotas');equal(#bot.chat.queue,0)
 fakeNow=bot.S.freezeRefreshAt+0.01;bot.refreshStep(fakeNow)
 local job=assert(bot.S.refreshJob);pump();assert(job.ok and job.submitted)
 assert(pressed(0x54));assert(pressed(0x0D));equal(bot.S.manualPaused,true)
end)

test('arbotas completion preserves an existing freeze and waits until dialog closes',function()
 bot.config.recovery.refreshAfterArbotas=false
 bot.freeze('test');local due=bot.S.freezeRefreshAt
 dialog=true;recognized('sequence_existing_freeze')
 equal(bot.S.freezeRecoveryMode,'test');equal(bot.S.freezeRefreshAt,due)
 fakeNow=due+0.01;bot.refreshStep(fakeNow)
 equal(bot.S.refreshJob,nil);assert(not pressed(0x54))
 dialog=false;fakeNow=bot.S.freezeRefreshAt+0.01;bot.refreshStep(fakeNow)
 local job=assert(bot.S.refreshJob);pump();assert(job.ok and job.submitted)
end)

test('recognized completion retry does not restart completed refresh',function()
 recognized('sequence_duplicate');fakeNow=bot.S.freezeRefreshAt+0.01
 bot.refreshStep(fakeNow);local job=assert(bot.S.refreshJob);pump();assert(job.ok)
 bot.refreshStep(fakeNow);fakeNow=bot.S.freezeReleaseUntil+0.01;bot.refreshStep(fakeNow)
 equal(bot.S.freezeTestLatched,false)
 recognized('sequence_duplicate');equal(bot.S.freezeTestLatched,false)
end)

test('normal arbotas does not refresh when standalone trigger is disabled',function()
 bot.config.recovery.refreshAfterArbotas=false
 recognized('normal_arbotas_no_refresh')
 equal(bot.S.freezeTestLatched,false);equal(bot.S.refreshJob,nil);equal(#bot.chat.queue,1)
 assert(not pressed(0x54))
end)

local function controlProbe(fn)
 PLAYER_HANDLE=0
 bot.api.playerControlOn=function(handle) equal(handle,0);return fn() end
end

test('disabled controls preempt route writes before freeze confirmation',function()
 controlProbe(function() return true end)
 bot.steering(128);bot.pedals(255,0)
 controlProbe(function() return false end)
 assert(not bot.pedals(255,0));equal(bot.owner(),'FREEZE');neutral()
 bot.recovery.pollControlLock(fakeNow);assert(not bot.S.freezeTestLatched)
 fakeNow=fakeNow+0.21;bot.recovery.pollControlLock(fakeNow)
 equal(bot.S.freezeRecoveryMode,'control_lock');assert(not bot.S.bumpActive)
end)

test('control lock types refresh once then waits for enabled controls before phrase',function()
 local enabled=false;controlProbe(function() return enabled end)
 bot.recovery.pollControlLock(fakeNow);fakeNow=fakeNow+0.21;bot.recovery.pollControlLock(fakeNow)
 assert(bot.S.freezeChatToken)
 fakeNow=bot.S.freezeRefreshAt+0.01;bot.refreshStep(fakeNow)
 local job=assert(bot.S.refreshJob);pump();assert(job.ok and job.submitted)
 bot.refreshStep(fakeNow);fakeNow=bot.S.freezeReleaseUntil+0.01;bot.refreshStep(fakeNow)
 assert(bot.S.freezeTestLatched);equal(#bot.chat.queue,0)
 local eventCount=#keyEvents;fakeNow=fakeNow+3;bot.refreshStep(fakeNow);equal(#keyEvents,eventCount)
 enabled=true;bot.refreshStep(fakeNow)
 equal(bot.S.freezeTestLatched,false);equal(#bot.chat.queue,1)
 assert(bot.chat.holdsRecoveryReply());equal(bot.manager.sync(),"CHAT");neutral()
 fakeNow=fakeNow+2;bot.chat.tick();pump();assert(bot.chat.job.ok and bot.chat.job.submitted)
end)

test('dialog-only disabled controls never schedule refresh',function()
 local enabled=false;controlProbe(function() return enabled end)
 dialog=true;bot.recovery.pollControlLock(fakeNow);fakeNow=fakeNow+2;bot.recovery.pollControlLock(fakeNow)
 equal(bot.S.freezeTestLatched,false)
 enabled=true;dialog=false;bot.recovery.pollControlLock(fakeNow)
 equal(bot.S.freezeTestLatched,false)
end)

test('freeze still disabled after dialog closes is detected before reverse',function()
 controlProbe(function() return false end);dialog=true
 bot.recovery.pollControlLock(fakeNow);fakeNow=fakeNow+2
 dialog=false;bot.recovery.pollControlLock(fakeNow)
 assert(not bot.pedals(255,0));neutral()
 fakeNow=fakeNow+0.21;bot.recovery.pollControlLock(fakeNow)
 equal(bot.S.freezeRecoveryMode,'control_lock')
end)

test('missing error and malformed control probes do not fabricate freezes',function()
 for _,fn in ipairs({function() error('unsupported') end,function() return 0 end,function() return nil end}) do
  controlProbe(fn);equal(bot.recovery.controlLockState(),nil)
  bot.recovery.pollControlLock(fakeNow);fakeNow=fakeNow+1;bot.recovery.pollControlLock(fakeNow)
  equal(bot.S.freezeTestLatched,false)
 end
end)

test('short control lock releases without sending refresh',function()
 local enabled=false;controlProbe(function() return enabled end)
 bot.recovery.pollControlLock(fakeNow);fakeNow=fakeNow+0.1
 enabled=true;bot.recovery.pollControlLock(fakeNow)
 equal(bot.S.freezeTestLatched,false);equal(bot.S.controlLockSince,nil)
end)

test('keyboard driving sends only WASD transitions with no pad writes',function()
 bot.config.controls.input='keyboard';writes={}
 assert(bot.pedals(90,0));assert(bot.steering(-32))
 assert(bot.Win32.driveHeld[0x57]);assert(bot.Win32.driveHeld[0x41]);equal(#writes,0)
 equal(bot.applied().gas,255);equal(bot.applied().steer,-128)
 local count=#keyEvents;bot.pedals(90,0);bot.steering(-32);equal(#keyEvents,count)
 for _,event in ipairs(keyEvents) do assert(event.vk==0x57 or event.vk==0x41) end
end)

test('keyboard releases opposite directions and pedals before pressing replacements',function()
 bot.config.controls.input='keyboard';bot.pedals(200,0);bot.steering(-128)
 keyEvents={};bot.steering(128)
 equal(keyEvents[1].vk,0x41);equal(keyEvents[1].down,false)
 equal(keyEvents[2].vk,0x44);equal(keyEvents[2].down,true)
 keyEvents={};bot.pedals(200,100)
 equal(keyEvents[1].vk,0x57);equal(keyEvents[1].down,false)
 equal(keyEvents[2].vk,0x53);equal(keyEvents[2].down,true)
 assert(not bot.Win32.driveHeld[0x57]);assert(bot.Win32.driveHeld[0x53])
end)

for _,reason in ipairs({'freeze','dialog','focus','stop'}) do
 test('keyboard held driving keys release on '..reason,function()
  bot.config.controls.input='keyboard';bot.pedals(255,0);bot.steering(128)
  if reason=='freeze' then flag('freeze','1')
  elseif reason=='dialog' then dialog=true
  elseif reason=='focus' then focus=false
  else bot.setPlaying(false) end
  bot.manager.sync();bot.pedals(255,0)
  equal(next(bot.Win32.driveHeld),nil)
  assert(not bot.Win32.held[0x57] and not bot.Win32.held[0x44])
 end)
end

test('keyboard refuses driving into existing or unknown chat',function()
 bot.config.controls.input='keyboard';chatOpen=true;bot.pedals(255,0)
 equal(next(bot.Win32.driveHeld),nil)
 chatOpen=false;unknown=true;bot.pedals(255,0);equal(next(bot.Win32.driveHeld),nil)
end)

test('keyboard synthetic movement does not trigger manual takeover',function()
 bot.config.controls.input='keyboard';bot.pedals(255,0);bot.steering(-128)
 equal(bot.manager.sync(),'ROUTE')
 keyboard[0x53]=true;equal(bot.manager.sync(),'MANUAL')
 equal(next(bot.Win32.driveHeld),nil)
end)

prepare();flag('freeze');flag('dialog');flag('rotate')
print(string.format('%d admin-chat regression scenarios passed',total))
