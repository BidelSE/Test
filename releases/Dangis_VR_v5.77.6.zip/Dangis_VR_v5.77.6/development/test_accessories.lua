local A=require 'lib.dangis_accessories'
local n=0
local function test(name,fn) fn();n=n+1;print('PASS '..name) end
local function setup(random)
 local held,events={},{}
 local a=A.new({random=function() return random or .5 end,down=function() return false end,
 press=function(k) held[k]=true;events[#events+1]={'down',k};return true end,
 release=function(k) held[k]=nil;events[#events+1]={'up',k} end})
 local c={nitroEnabled=true,nitroInterval=60,nitroVariation=15,lookEnabled=true,lookInterval=25}
 local s={running=true,allowed=true,car=1,nitroSafe=true}
 return a,c,s,held,events
end
test('nitro range 45 to 75 seconds; no immediate startup press',function()
 for _,r in ipairs({0,.5,.999999}) do
  local a,c,s,h=setup(r);a:tick(0,c,s);assert(not next(h));assert(a.nextNitro>=45 and a.nextNitro<=75)
 end
end)
test('one Ctrl pulse, release at low FPS, no repeated activation',function()
 local a,c,s,h,e=setup();c.lookEnabled=false;a:tick(0,c,s);a:tick(60,c,s)
 assert(h[0x11]);a:tick(60.1,c,s);assert(#e==1);a:tick(60.2,c,s);assert(not next(h));assert(#e==2)
end)
test('nitro waits until permitted and does not catch up missed attempts',function()
 local a,c,s,h=setup();c.lookEnabled=false;a:tick(0,c,s);s.nitroSafe=false
 a:tick(180,c,s);assert(not next(h));s.nitroSafe=true;a:tick(181,c,s);assert(h[0x11]);assert(a.nextNitro==241)
end)
test('all three camera combinations and bounded hold',function()
 for _,r in ipairs({0,.3,.9}) do
  local a,c,s,h=setup(r);c.nitroEnabled=false;a:tick(0,c,s);a:tick(40,c,s)
  if r==0 then assert(h[0x51] and not h[0x45])
  elseif r==.3 then assert(h[0x45] and not h[0x51])
  else assert(h[0x51] and h[0x45]) end
  a:tick(41,c,s);assert(not next(h))
 end
end)
test('UI focus freeze recovery interruption releases active keys',function()
 local a,c,s,h=setup(.9);c.nitroEnabled=false;a:tick(0,c,s);a:tick(40,c,s)
 assert(next(h));s.allowed=false;a:tick(40.1,c,s);assert(not next(h))
 s.allowed=true;a:tick(40.2,c,s);assert(not next(h))
end)
test('disable and stop release keys; vehicle change resets timers',function()
 local a,c,s,h=setup();c.lookEnabled=false;a:tick(0,c,s);a:tick(60,c,s);c.nitroEnabled=false
 a:tick(60.01,c,s);assert(not next(h));s.car=2;a:tick(61,c,s);assert(a.nextNitro==121)
 s.running=false;a:tick(62,c,s);assert(a.nextNitro==nil and not next(h))
end)
test('physical Q E Ctrl are never acquired or released',function()
 for _,key in ipairs({0x11,0x51,0x45}) do
  local a,c,s,h,e=setup();a.io.down=function(k) return k==key end
  a:tick(0,c,s);a:tick(60,c,s);a:reset();assert(#e==0)
 end
end)
test('partial Q+E failure releases the first key',function()
 local a,c,s,h=setup(.9);c.nitroEnabled=false
 a.io.press=function(k) if k==0x45 then return false end;h[k]=true;return true end
 a:tick(0,c,s);a:tick(40,c,s);assert(not next(h) and not a.kind)
end)
print(n..' accessory scenarios passed')
