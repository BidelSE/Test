local sourcePath=arg[1] or 'chat_update/arbotas_auto.lua'
local f=assert(io.open(sourcePath,'rb'));local source=f:read('*a');f:close()
local root='/tmp/dangis_dialog_events_test';os.execute('mkdir -p '..root)
getWorkingDirectory=function() return root end
script_name=function() end;script_version=function() end;printStringNow=function() end
package.preload['lib.moonloader']=function() return {} end
local now=10;os.clock=function() return now end
local memory={[0x100000+0x21A0B8]=0x1000000,[0x1000000+0x28]=1}
local focused=true
local events={}
local u32={GetForegroundWindow=function() return focused and 1 or nil end,
 GetWindowThreadProcessId=function(hwnd,pid) pid[0]=42 end,
 keybd_event=function(vk,scan,flags) events[#events+1]={vk=vk,flags=flags} end}
local kernel32={IsBadReadPtr=function(addr) return memory[addr]~=nil and 0 or 1 end,
 GetCurrentProcessId=function() return 42 end}
local ffi={cdef=function() end,load=function(name) return name=='user32' and u32 or kernel32 end,
 new=function() return {[0]=0} end,
 cast=function(kind,addr) if kind=='void*' then return addr end;return {[0]=memory[addr]} end}
package.preload['ffi']=function() return ffi end
package.loaded['ffi']=ffi
local tasks={}
wait=function(ms) coroutine.yield((ms or 0)/1000) end
lua_thread={create=function(fn) tasks[#tasks+1]=coroutine.create(fn) end}
local api=assert((loadstring or load)(source..[[
return {events=DialogEvents,navigate=navigateAndClick,setSamp=function(value) samp=value end,
 setScan=function(fn) scanArbotasDialog=fn end}
]],'@'..sourcePath))()
api.setSamp(0x100000)
local function pump()
 while #tasks>0 do
  local co=table.remove(tasks,1);local ok,delay=coroutine.resume(co);assert(ok,delay)
  if coroutine.status(co)~='dead' then now=now+delay;tasks[#tasks+1]=co end
 end
end
local function eq(a,b) assert(a==b,'expected '..tostring(b)..', got '..tostring(a)) end
local total=0
local function test(name,fn)
 memory[0x1000000+0x28]=1;focused=true;events={};tasks={};os.remove(api.events.file)
 api.setScan(function() return 123,2,'baltai' end)
 fn();total=total+1;print('PASS '..name)
end

test('recognized submitted dialog emits once only after actual close',function()
 local job=api.navigate(2,123,'baltai');pump();assert(job.done);assert(job.submitted)
 eq(api.events.poll(job,now),job);eq(io.open(api.events.file,'r'),nil)
 memory[0x1000000+0x28]=0
 eq(api.events.poll(job,now),nil)
 local file=assert(io.open(api.events.file,'r'));local token=file:read('*l');local stamp=file:read('*l');file:close()
 assert(token:match('^123:'));assert(tonumber(stamp))
 eq(api.events.poll(job,now),nil)
 file=assert(io.open(api.events.file,'r'));eq(file:read('*l'),token);file:close()
end)

test('unsubmitted close does not emit a completion',function()
 memory[0x1000000+0x28]=0
 eq(api.events.poll({done=true,submitted=false,startedAt=now},now),nil)
 eq(io.open(api.events.file,'r'),nil)
end)

test('unknown dialog state does not emit',function()
 memory[0x1000000+0x28]=nil
 local job={done=true,submitted=true,dialogId=123,startedAt=now}
 eq(api.events.poll(job,now),job);eq(io.open(api.events.file,'r'),nil)
end)

test('expired response does not emit',function()
 memory[0x1000000+0x28]=0
 eq(api.events.poll({done=true,submitted=true,startedAt=now-21,dialogId=123},now),nil)
 eq(io.open(api.events.file,'r'),nil)
end)

test('navigation aborts before injecting keys when focus is lost',function()
 focused=false;local job=api.navigate(2,123,'baltai');pump()
 assert(job.done);eq(job.submitted,false);eq(#events,0)
end)

test('navigation aborts if recognized dialog changes',function()
 api.setScan(function() return 124,2,'baltai' end)
 local job=api.navigate(2,123,'baltai');pump();assert(job.done);eq(job.submitted,false);eq(#events,0)
end)

os.remove(api.events.file)
print(string.format('%d dialog-event regression scenarios passed',total))
