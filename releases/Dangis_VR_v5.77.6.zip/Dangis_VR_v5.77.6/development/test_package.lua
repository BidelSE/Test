-- 5.77.6 release package: layout, update safety, versions, defaults.
-- Run by development/run_tests.sh (PACKAGE_ROOT = the unpacked package).
package.path = "development/?.lua;" .. package.path
local Sim = require("sim_harness")
local ROOT = os.getenv("PACKAGE_ROOT") or ".."
local total = 0
local function test(name, fn) fn(); total = total + 1; print("PASS " .. name) end
local function equal(a, b, m) if a ~= b then error((m or "value") .. ": expected " .. tostring(b) .. ", got " .. tostring(a), 2) end end
local function list(dir)
    local p = io.popen("cd '" .. ROOT .. "' && find " .. dir .. " -type f 2>/dev/null | sort")
    local out = {}
    for line in p:lines() do out[#out+1] = line end
    p:close()
    return out
end
local function read(path) local f = io.open(ROOT .. "/" .. path, "rb"); if not f then return nil end; local t = f:read("*a"); f:close(); return t end

test("moonloader/ holds code only: copying it over an install never replaces INI, routes or phrases", function()
    local files = list("moonloader")
    assert(#files >= 9, "runtime files present")
    for _, f in ipairs(files) do
        assert(f:match("%.lua$"), "not a code file in moonloader/: " .. f)
        assert(not f:match("dangis_paths"), "route file in moonloader/: " .. f)
    end
    for _, f in ipairs({"moonloader/dangis_vr.lua", "moonloader/arbotas_auto.lua"}) do assert(read(f), f) end
end)

test("every library the runtime requires is shipped, and nothing development-only is", function()
    local shipped = {}
    for _, f in ipairs(list("moonloader/lib")) do shipped[f:match("lib/(.+)%.lua$")] = true end
    local needed = {}
    for _, f in ipairs(list("moonloader")) do
        for name in read(f):gmatch("require%s*%(?%s*['\"]lib%.([%w_]+)['\"]") do needed[name] = f end
    end
    needed.moonloader = nil                 -- MoonLoader's own lib.moonloader
    for name, from in pairs(needed) do assert(shipped[name], from .. " requires lib." .. name .. " which is not shipped") end
    for name in pairs(shipped) do assert(needed[name], "lib/" .. name .. ".lua is shipped but not used at runtime") end
end)

test("defaults/ holds the first-install files only", function()
    local files = list("defaults")
    local want = {["defaults/dangis_vr.ini"]=true, ["defaults/dangis_admin_phrases.txt"]=true, ["defaults/dangis_rotation_phrases.txt"]=true}
    equal(#files, 3)
    for _, f in ipairs(files) do assert(want[f], f) end
end)

test("one version everywhere: 5.77.6 (arbotas_auto 1.7)", function()
    local main = read("moonloader/dangis_vr.lua")
    equal(main:match("script_version%('([^']+)'%)"), "5.77.6")
    equal(main:match('local VR_VERSION = "([^"]+)"'), "5.77.6")
    equal(read("moonloader/arbotas_auto.lua"):match("script_version%('([^']+)'%)"), "1.7")
    assert(read("INSTALL.md"):find("5.77.6", 1, true), "INSTALL.md")
    assert(read("CHANGELOG.md"):find("5.77.6", 1, true), "CHANGELOG.md")
    equal(read("README.md"), nil, "the old 5.72 README is not at the top level any more")
end)

test("default INI and phrase files load without errors", function()
    local sim = Sim.new({root=".", tag="pkg_defaults", files={{"dangis_vr.ini", read("defaults/dangis_vr.ini")},
        {"dangis_admin_phrases.txt", read("defaults/dangis_admin_phrases.txt")},
        {"dangis_rotation_phrases.txt", read("defaults/dangis_rotation_phrases.txt")}}})
    sim.bot.loop.initialize()
    equal(sim.bot.settings.status, "loaded")
    assert(#sim.bot.chat.phrases > 50, "admin phrases loaded: " .. #sim.bot.chat.phrases)
    equal(sim.bot.CONFIG.driving.passageCheck, true)
    equal(sim.bot.CONFIG.obstacle.scanRaysPerFrame, 100)
end)

test("an existing 5.77 INI (no new keys) loads unchanged; new keys take their defaults", function()
    local old = Sim.read("development/user_v577/dangis_vr.ini")
    assert(not old:find("passage_check", 1, true))
    local sim = Sim.new({root=".", tag="pkg_oldini", files={{"dangis_vr.ini", old}}})
    sim.bot.loop.initialize()
    equal(sim.bot.settings.status, "loaded")
    equal(sim.bot.CONFIG.driving.lateralTolerance, 3, "your value kept")
    equal(sim.bot.CONFIG.driving.lookaheadSeconds, 0.75, "your value kept")
    equal(sim.bot.CONFIG.driving.passageCheck, true, "new key default")
    -- and the file itself is not rewritten by loading it
    assert(Sim.read(sim.work .. "/dangis_vr.ini") == old:gsub("\r\n", "\n"), "loading never rewrites the INI")
end)

test("existing routes and phrase files are read as they are (no migration step)", function()
    local route = Sim.read("development/fixtures/route1.txt")
    local sim = Sim.new({root=".", tag="pkg_route", files={{"dangis_vr.ini", read("defaults/dangis_vr.ini")},
        {"dangis_paths/route1.txt", route}}})
    sim.bot.loop.initialize()
    local r = assert(sim.bot.storage.load("route1"), "your 5.77 route loads")
    equal(#r, 1682)
    -- (the simulator stores files as Windows text mode reads them: LF)
    assert(Sim.read(sim.work .. "/dangis_paths/route1.txt") == route:gsub("\r\n", "\n"), "loading never rewrites the file")
end)

print(total .. " package scenarios passed")
