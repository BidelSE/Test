-- 5.77.6 passage check and scan budget (simulated; keyboard input, your INI).
-- Walls (world geometry) across or beside the path, a side step into a wall
-- or off the road, slopes, missing/failing/starved collision data, braking
-- that must never turn into reversing, and the number of line-of-sight
-- calls per frame (printed as measurements).
-- Usage (from the package root): texlua development/test_passage.lua
package.path = "development/?.lua;" .. package.path
local Sim = require("sim_harness")
local INI = Sim.read("development/user_v577/dangis_vr.ini")
local DT = 1/30

local total = 0
local function test(name, fn) fn(); total = total + 1; print("PASS " .. name) end
local function equal(a, b, m) if a ~= b then error((m or "value") .. ": expected " .. tostring(b) .. ", got " .. tostring(a), 2) end end

-- Straight route north along x=0 (left of the route = -x).
local function straight(speed, length, zAt)
    local pts = {}
    for i = 0, math.floor((length or 1000) / 4) do
        local y = i * 4
        pts[#pts+1] = {x=0, y=y, z=zAt and zAt(y) or 10, speed=speed, heading=0, drive="FWD"}
    end
    return Sim.routeText(pts)
end

local function boot(opts)
    local sim = Sim.new({root=".", tag="passage_" .. (opts.tag or "x"), files={{"dangis_vr.ini", INI},
        {"dangis_paths/route1.txt", opts.route or straight(opts.speed or 25)}}, x=0, y=opts.y or 0, z=10.6, heading=0,
        walls=opts.walls, obstacles=opts.obstacles, collision=opts.collision, terrain=opts.terrain, grip=opts.grip})
    sim.groundZ = 10
    sim.holes = opts.holes
    sim.bot.loop.initialize()
    sim.bot.CONFIG.controls.input = opts.input or "keyboard"
    if opts.configure then opts.configure(sim.bot) end
    sim:frame(DT, {[0x79]=true})
    return sim
end

-- Runs frames; returns stats. each(sim, i) may change the world.
local function drive(sim, frames, opts)
    opts = opts or {}
    local st = {maxY=-math.huge, minV=math.huge, maxV=0, backward=false, sBelowMin=false, maxRays=0, rays=0, frames=0, owners={}}
    for i = 1, frames do
        if opts.each then opts.each(sim, i) end
        sim:frame(opts.dt and opts.dt(i) or DT)
        local front = sim.car.y + 2.4
        st.maxFront = math.max(st.maxFront or -math.huge, front)
        st.minV, st.maxV = math.min(st.minV, sim.car.v), math.max(st.maxV, sim.car.v)
        if sim.car.v < -0.05 then st.backward = true end
        local fs = sim.bot.S.forwardSpeed
        if sim.bot.Win32.driveHeld[0x53] and fs and fs <= sim.bot.CONFIG.controls.footBrakeMinSpeed then st.sBelowMin = true end
        st.maxRays = math.max(st.maxRays, sim.raysLastFrame or 0)
        st.rays, st.frames = st.rays + (sim.raysLastFrame or 0), st.frames + 1
        st.owners[sim.bot.manager.owner] = true
        if opts.stop and opts.stop(sim, i) then break end
    end
    return st
end

local WALL = {{-15, 300, 15, 300}}             -- building wall across the road at y=300

for _, speed in ipairs({20, 36}) do
    test(speed .. " m/s: a wall across the route: controlled stop before it, no reversing (5.77.5: full throttle into it)", function()
        local sim = boot({tag="wall" .. speed, speed=speed, walls=WALL})
        local st = drive(sim, 30 * 40)
        assert(st.maxFront < 300 - 0.5, string.format("front reached y=%.2f (wall at 300)", st.maxFront))
        assert(st.maxV > speed - 3, "drove at route speed before the wall")
        assert(sim.car.v < 0.5, "stopped")
        equal(st.backward, false, "rolled backwards"); equal(st.sBelowMin, false, "S held while (almost) stopped: would reverse")
        equal(sim.bot.manager.owner, "ROUTE")
        local L = assert(sim.bot.S.passageLimit, "limit active")
        equal(L.kind, "wall"); equal(L.state, "blocked")
        equal(sim.bot.manager.applied.gas, 0, "no throttle while held")
        assert(sim.bot.recovery.rotation.phase == nil and not sim.bot.S.bumpActive, "no recovery started for an intentional stop")
    end)
end

test("the wall opens (gate): driving resumes on its own", function()
    local sim = boot({tag="gate", speed=20, walls={{-15, 300, 15, 300}}})
    drive(sim, 30 * 25)
    assert(sim.car.v < 0.5 and sim.car.y < 300)
    sim.walls = {}
    drive(sim, 30 * 15)
    assert(sim.car.y > 330, string.format("drove on (y=%.0f)", sim.car.y))
    equal(sim.bot.S.passageLimit, nil)
end)

test("15 FPS and 18-45 FPS: still stops before the wall", function()
    for _, dt in ipairs({function() return 1/15 end, function(i) return i % 3 == 0 and 1/18 or 1/45 end}) do
        local sim = boot({tag="wallfps", speed=36, walls=WALL})
        local st = drive(sim, 30 * 40, {dt=dt})
        assert(st.maxFront < 300 - 0.3, string.format("front reached y=%.2f", st.maxFront))
        equal(st.backward, false)
    end
end)

test("gamepad input: braking uses the foot brake while rolling forward, never reverse", function()
    local sim = boot({tag="wallpad", speed=30, walls=WALL, input="gamepad"})
    local reversed = false
    local st = drive(sim, 30 * 40, {each=function(s) if s.bot.manager.applied.reverse then reversed = true end end})
    assert(st.maxFront < 300 - 0.5); equal(reversed, false); equal(st.backward, false)
end)

test("a wall reaching 0.6 m into the car's path from the side: stop (walls are not steered round)", function()
    local sim = boot({tag="partial", speed=25, walls={{0.5, 300, 6, 300}}})
    local st = drive(sim, 30 * 30)
    assert(st.maxFront < 300 - 0.3, string.format("front reached y=%.2f", st.maxFront))
end)

test("server objects (concrete blocks) across the whole road at 20/36 m/s: stops before them", function()
    for _, speed in ipairs({20, 36}) do
        local blocks = {}
        for x = -7, 7, 0.9 do blocks[#blocks+1] = {x=x, y=300, r=0.5, h=1.0, model=3578} end
        local sim = boot({tag="blocks" .. speed, speed=speed, obstacles=blocks})
        local st = drive(sim, 30 * 40)
        assert(st.maxFront < 300 - 0.5 - 0.3, string.format("%d m/s: front reached y=%.2f (blocks from 299.5)", speed, st.maxFront))
        equal(st.backward, false)
    end
end)

test("walls beside the road (narrow street, 2.0 m from the line): no intervention", function()
    local a = boot({tag="street", speed=20, walls={{-2.0, 100, -2.0, 600}, {2.0, 100, 2.0, 600}}})
    local b = boot({tag="street_ref", speed=20})
    for i = 1, 30 * 25 do
        a:frame(DT); b:frame(DT)
        if a:snapshot() ~= b:snapshot() then error("frame " .. i .. " differs: " .. a:snapshot() .. " vs " .. b:snapshot()) end
    end
    equal(a.bot.S.passageLimit, nil)
end)

test("a sloping road (8% and 25% ramp) is road, not a wall", function()
    for _, grade in ipairs({0.08, 0.25}) do
        local function terrain(_, y) return 10 + math.max(0, math.min(y - 200, 60)) * grade end
        local sim = boot({tag="ramp" .. grade, speed=25, terrain=terrain, route=straight(25, 1000, function(y) return terrain(0, y) end)})
        local limited = false
        drive(sim, 30 * 20, {each=function(s) if s.bot.S.passageLimit and s.car.y > 120 then limited = true end end})
        equal(limited, false, "limited on a " .. grade * 100 .. "% ramp")
        assert(sim.car.y > 300, "drove over the ramp")
    end
end)

-- Cone on the line, the left side step blocked by a wall: the passage check
-- vetoes that offset and the lane steps right instead.
test("side step into a wall: that side is refused, the car passes on the other side", function()
    -- the cone is 0.6 m right of the line, so the lane would step left
    local cone = {{x=0.6, y=300, r=0.3, h=0.8, model=1238}}
    local leftWall = {{-2.4, 230, -2.4, 380}}
    local right = boot({tag="sideR", speed=20, obstacles=cone, walls=leftWall})
    local minWall, passedX = math.huge, nil
    drive(right, 30 * 30, {each=function(s)
        if s.car.y > 230 and s.car.y < 380 then minWall = math.min(minWall, (s.car.x + 2.4) - 1.0) end
        if not passedX and s.car.y > 300 then passedX = s.car.x end
    end})
    assert(passedX and passedX > 1.5, "passed the cone on the right (x=" .. tostring(passedX) .. ")")
    assert(minWall > 0.3, string.format("came %.2f m from the wall", minWall))
end)

test("side step off the road (no ground there): refused, other side used", function()
    local holes = {}
    for y = 240, 360, 2 do for x = -5, -1.4, 0.6 do holes[#holes+1] = {x=x, y=y, r=0.5} end end
    local sim = boot({tag="hole", speed=20, obstacles={{x=0.6, y=300, r=0.3, h=0.8, model=1238}}})
    sim.holes = holes
    local passedX
    drive(sim, 30 * 30, {each=function(s) if not passedX and s.car.y > 300 then passedX = s.car.x end end})
    assert(passedX and passedX > 1.5, "passed on the side with ground (x=" .. tostring(passedX) .. ")")
end)

-- Missing, failing and starved sensing ------------------------------------
test("no collision API: holds still and says why (5.77.5: ROUTE gas 255)", function()
    local sim = boot({tag="noapi", collision=false})
    local st = drive(sim, 30 * 5)
    assert(math.abs(sim.car.y) < 1.0, "did not drive blind")
    equal(sim.bot.manager.applied.gas, 0)
    local P = assert(sim.bot.S.passage); equal(P.state, "unknown"); equal(P.reason, "collision API unavailable")
    local lines = table.concat(sim.bot.loop and {} or {}, "")
    equal(sim.bot.S.scanState and sim.bot.S.scanState.status, "unknown", "the object scan also reports unknown")
end)

test("collision queries failing for 1.5 s at 25 m/s: slows down, never full throttle blind; resumes after", function()
    local sim = boot({tag="fail", speed=25})
    drive(sim, 30 * 12)
    local v0 = sim.car.v
    assert(v0 > 22)
    local gasDuring, vEnd = 0, nil
    local st = drive(sim, 45, {each=function(s) s.losFault = function() return "error" end end})
    sim.losFault = nil
    vEnd = sim.car.v
    assert(vEnd < v0 - 3, string.format("slowed down (%.1f -> %.1f m/s)", v0, vEnd))
    equal(sim.bot.S.passage.reason, "collision query failed")
    drive(sim, 30 * 10)
    assert(sim.car.v > 22, "back to route speed once the checks work")
end)

test("a query returning nil is unknown, not clear", function()
    local sim = boot({tag="nilq", speed=25})
    drive(sim, 30 * 3, {each=function(s) s.losFault = function() return "nil" end end})
    assert(sim.car.y < 1.0)
end)

test("scan budget starved (passage budget 3 calls): never treated as clear; speed limited to what is verified", function()
    local sim = boot({tag="starve", speed=36, configure=function(bot) bot.CONFIG.obstacle.passageRaysPerFrame = 3 end})
    local pending = 0
    local st = drive(sim, 30 * 20, {each=function(s) if s.bot.S.passageLimit and s.bot.S.passageLimit.pending then pending = pending + 1 end end})
    assert(st.maxV < 30, string.format("speed %.1f m/s with almost no verification", st.maxV))
    assert(pending > 0, "limited for 'not checked yet'")
end)

test("stale answers expire: a wall that appears is seen within the refresh time", function()
    local sim = boot({tag="appear", speed=20})
    drive(sim, 30 * 8)
    local y = sim.car.y
    sim.walls = {{-15, y + 45, 15, y + 45}}
    local st = drive(sim, 30 * 10)
    assert(st.maxFront < y + 45 - 0.3, "stopped for a wall that appeared 45 m ahead")
end)

-- Scan workload --------------------------------------------------------------
local function measure(label, sim, frames, dt)
    local st = drive(sim, frames, {dt=dt})
    print(string.format("  measured %-44s LOS calls/frame: max %3d, mean %5.1f", label, st.maxRays, st.rays / st.frames))
    return st
end

test("line-of-sight calls per frame are bounded (5.77.5: 568-622 in one frame)", function()
    local cfg = boot({tag="cfg"}).bot.CONFIG.obstacle
    local bound = cfg.scanRaysPerFrame + 3 * 2 * cfg.passageRaysPerFrame + 12
    local cases = {
        {"clear road, 30 FPS, 36 m/s", boot({tag="m1", speed=36}), 900},
        {"clear road, 60 FPS, 36 m/s", boot({tag="m2", speed=36}), 1800, function() return 1/60 end},
        {"clear road, 15 FPS, 36 m/s", boot({tag="m3", speed=36}), 450, function() return 1/15 end},
        {"clear road, 18-45 FPS, 36 m/s", boot({tag="m4", speed=36}), 900, function(i) return i % 3 == 0 and 1/18 or 1/45 end},
    }
    local dense = {}
    for y = 60, 900, 6 do dense[#dense+1] = {x=-3.2, y=y, r=0.3, h=0.8, model=1238}; dense[#dense+1] = {x=3.2, y=y + 3, r=0.3, h=0.8, model=1238} end
    for y = 150, 900, 40 do dense[#dense+1] = {x=y % 80 == 0 and 1.6 or -1.6, y=y, r=1.3} end
    cases[#cases+1] = {"dense: 290 cones beside + parked cars, 25 m/s", boot({tag="m5", speed=25, obstacles=dense}), 900}
    for _, c in ipairs(cases) do
        local st = measure(c[1], c[2], c[3], c[4])
        assert(st.maxRays <= bound, c[1] .. ": " .. st.maxRays .. " > " .. bound)
    end
end)

test("a sweep in progress is 'pending', its hits are published only when it is complete", function()
    local sim = boot({tag="pending", speed=20})
    local sawPending, sawComplete = false, false
    drive(sim, 120, {each=function(s)
        local st = s.bot.S.scanState
        if st and st.status == "pending" then
            sawPending = true
            assert(st.done < st.total)
        elseif st and st.status == "complete" then sawComplete = true end
    end})
    assert(sawPending and sawComplete)
end)

test("a sweep is dropped when the car is moved far (respawn/teleport)", function()
    local sim = boot({tag="teleport", speed=20})
    local dropped = false
    drive(sim, 200, {each=function(s, i)
        if i == 100 then
            local job = s.bot.S.scanJob
            s.car.y = s.car.y + 120
            s:frame(DT)
            dropped = job ~= nil and s.bot.S.scanJob ~= job
        end
    end})
    assert(dropped, "the half-done sweep was not reused after a 120 m jump")
end)

-- Unaffected driving -----------------------------------------------------------
test("clear road: identical with and without the passage check (36 m/s, 30 FPS and 18-45 FPS)", function()
    for _, dt in ipairs({function() return DT end, function(i) return i % 3 == 0 and 1/18 or 1/45 end}) do
        local a = boot({tag="ida", speed=36})
        local b = boot({tag="idb", speed=36, configure=function(bot) bot.CONFIG.driving.passageCheck = false end})
        for i = 1, 30 * 25 do
            local d = dt(i)
            a:frame(d); b:frame(d)
            if a:snapshot() ~= b:snapshot() then error("frame " .. i .. ": " .. a:snapshot() .. " vs " .. b:snapshot()) end
        end
    end
end)

print(total .. " passage/scan scenarios passed")
