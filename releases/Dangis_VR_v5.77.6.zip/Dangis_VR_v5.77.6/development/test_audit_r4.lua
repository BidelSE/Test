-- Regression tests for the r4 code audit (Dangis_VR_r4_audit.md). Each of
-- the audit's 20 reproductions is turned into an assertion of the desired
-- behaviour (the audit script asserted the defects), plus the extra cases the
-- audit asked for. Usage (from the moonloader folder):
--   texlua development/test_audit_r4.lua      (or luajit)
package.path = 'development/?.lua;' .. package.path
local R = require('lib.dangis_rotation')
local P = require('lib.dangis_probe')
local Select = require('lib.dangis_route_select')
local Sim = require('sim_harness')
local total = 0
local function test(name, fn) fn(); total = total + 1; print('PASS ' .. name) end
local function equal(a, b, m) if a ~= b then error((m or 'value') .. ': expected ' .. tostring(b) .. ', got ' .. tostring(a), 2) end end
local function sample(extra)
    local s = {allowed=true, owner='ROTATE', x=0, y=0, heading=180, speed=10, forwardSpeed=-10, lateralSpeed=0, slip=0,
        airborne=false, reverseClear=true, uturnClear=true, clear=true, connectDistance=0, routeHeadingError=0}
    for k, v in pairs(extra or {}) do s[k] = v end
    return s
end
-- A reverse spin that has just started at `speed` (sliding back).
local function spin(speed)
    speed = speed or 10
    local r = R.new(); r:noteTurn(0, false); r.plan = {back=false}
    r:startJturn(0, 128, sample({speed=speed, forwardSpeed=-speed})); r.rate = 0; r.rateAvg = 0
    return r
end
local function noPower(c) return c.gas == 0 and not c.reverse and c.brake == 0 end

-- D01 -----------------------------------------------------------------------
test('D01: blocked rear during the spin: no reverse power at any speed (4.9, 5, 10, 25 m/s), the spin ends', function()
    for _, v in ipairs({4.9, 5, 10, 25}) do
        local r = spin(v)
        local c = r:step(0.1, sample({speed=v, forwardSpeed=-v, reverseClear=false}), 180)
        assert(not c.reverse, v .. ' m/s: no S into the blocked space')
        equal(r.phase, 'HOLD', v .. ' m/s: spin ended')
        -- The fallback brakes the backwards slide (W only while rolling back).
        c = r:step(0.2, sample({speed=v, forwardSpeed=-v}), 180)
        assert(not c.reverse and c.steer == 0, 'no S, wheels straight')
    end
end)
test('D01: an unknown or failed rear check counts as blocked too', function()
    for _, value in ipairs({'nil', 'error', 7}) do
        local r = spin(10)
        local s = sample(); if value == 'nil' then s.reverseClear = nil else s.reverseClear = value end
        local c = r:step(0.1, s, 180)
        assert(not c.reverse, tostring(value) .. ': no S'); equal(r.phase, 'HOLD')
    end
end)
-- D02 -----------------------------------------------------------------------
test('D02: airborne in the spin: keys released at once, the spin ends if it lasts', function()
    local r = spin(10)
    local c = r:step(0.1, sample({airborne=true}), 180)
    assert(noPower(c) and c.steer == 0, 'neutral while airborne'); equal(r.phase, 'JTURN')
    r:step(0.1 + r.cfg.airborneSeconds + 0.05, sample({airborne=true}), 180)
    equal(r.phase, 'HOLD', 'ends when it stays airborne')
end)
test('D02: runaway and displacement bounds end the spin', function()
    local r = spin(10)
    r:step(0.1, sample({speed=50, forwardSpeed=-50}), 180); equal(r.phase, 'HOLD', 'faster than it came in')
    r = spin(10)
    r:step(0.1, sample({x=200}), 180); equal(r.phase, 'HOLD', '200 m from where it started')
    r = spin(25)
    r:step(0.1, sample({speed=25, forwardSpeed=-25, x=R.jturnLength(25)+5}), 180); equal(r.phase, 'HOLD', 'beyond the checked slide')
    r = spin(25)
    local c = r:step(0.1, sample({speed=25, forwardSpeed=-25, x=R.jturnLength(25)-5}), 180)
    equal(r.phase, 'JTURN', 'inside the checked slide it continues'); assert(c.reverse)
    -- The common route-distance guard applies too.
    r = spin(10)
    r:step(0.1, sample({connectDistance=r:reach()+10}), 180); equal(r.phase, 'HOLD')
end)
-- D03 -----------------------------------------------------------------------
test('D03: an early straighten (fast yaw) is not undone by SETTLE while the heading converges', function()
    local r = spin(10); r.rateAvg = 220
    r:step(0.1, sample(), 44); equal(r.phase, 'SETTLE')
    r:step(0.12, sample(), 44); equal(r.phase, 'SETTLE', 'still converging: no STOP')
    r:step(0.5, sample(), 30); equal(r.phase, 'SETTLE')
    -- Not converging for longer than settleConvergeSeconds: replanned.
    local r2 = spin(10); r2.rateAvg = 220
    r2:step(0.1, sample(), 44)
    r2:step(0.1 + r2.cfg.settleConvergeSeconds + 0.1, sample(), 44)
    equal(r2.phase, 'STOP'); equal(r2.afterStop, 'PLAN_REDO')
    -- And SETTLE entered normally still replans a real drift beyond 35.
    local r3 = R.new(); r3.plan = {back=false}; r3.rate = 0; r3.rateAvg = 0; r3:startSettle(0)
    r3:step(0.1, sample(), 40); equal(r3.phase, 'STOP')
end)
-- D04 -----------------------------------------------------------------------
test('D04: APPROACH steers towards the route direction when that is what blocks the handoff', function()
    for _, routeErr in ipairs({90, -90}) do
        local r = R.new(); r.plan = {back=false}; r.rate = 0; r.rateAvg = 0; r:startApproach(0, 1)
        local c = r:step(0.1, sample({speed=2, forwardSpeed=2, connectDistance=1, routeHeadingError=routeErr}), 10)
        equal(r.handoffWhy, 'route direction')
        equal(c.steer, routeErr > 0 and 128 or -128, 'steers to line up with the route')
    end
end)
-- D05 / D06 -----------------------------------------------------------------
local sim = Sim.new({root='.', tag='audit_r4', x=0, y=-20, z=10.6, heading=180})
sim.groundZ = 10
test('D05: a reverse-section plan keeps its real distance; no handoff 20 m away', function()
    local route = {}; for i = 1, 50 do route[i] = {x=0, y=(i-1)*2, z=10, drive='BACK'} end
    local p = {route=route, index=1, back=true}
    local err, cd = sim.bot.recovery.planTarget(1, 0, -20, p)
    assert(cd > 19, 'real distance: ' .. tostring(cd))
    local r = R.new(); r.plan = p; r.rate = 0; r.rateAvg = 0; r:startSettle(0)
    local s = sample({speed=0, forwardSpeed=0, connectDistance=cd})
    local _, signal = r:step(0.2, s, err)
    assert(signal ~= 'ready', 'never handed over from 20 m')
    equal(r.phase, 'STOP', 'a reverse section too far away is not approached forwards')
end)
test('D06: joining a reverse section brakes down to the handoff speed, then hands over', function()
    local r = R.new(); r.plan = {back=true}; r.rate = 0; r.rateAvg = 0; r:startSettle(0)
    local c = r:step(0.1, sample({speed=2.0, forwardSpeed=2.0, connectDistance=1}), 0)
    equal(c.brake, 255, 'braked'); equal(r.handoffWhy, 'reverse section needs a stop')
    assert(r.cfg.reverseHandoffSpeed > 1.0, 'handoff speed above the control writer foot-brake minimum (1 m/s)')
    local t, signal = 0.1, nil
    for i = 1, 10 do t = t + 0.05; _, signal = r:step(t, sample({speed=1.1, forwardSpeed=1.1, connectDistance=1}), 0); if signal then break end end
    equal(signal, 'ready', 'handed over at 1.1 m/s')
end)
-- L01 -----------------------------------------------------------------------
test('L01: its own fast turn is not a new rotation; an instant flip during the spin still is', function()
    local r = R.new(); r:observe(0, 1, 0, false, true, 128, 0, 0); r:noteTurn(0, true); r:startJturn(0, 128, sample())
    for i = 1, 4 do r:observe(i*0.05, 1, i*35, false, true, 128, 0, 0) end
    equal(r.count, 1, 'own 140 degrees in 0.2 s is not a disturbance'); equal(r.phase, 'JTURN')
    assert(r:observe(0.233, 1, (140+180)%360, false, true, 128, 0, 0), 'a 180 degree flip in one frame is')
    equal(r.count, 2)
    -- Without our own steering the original rule is unchanged.
    local q = R.new(); q:observe(0, 1, 0, false, true, 0, 0, 0)
    local hit = false
    for i = 1, 4 do if q:observe(i*0.05, 1, i*35, false, true, 0, 0, 0) then hit = true end end
    assert(hit, '140 degrees in 0.2 s while not steering counts as before')
end)
-- D07 -----------------------------------------------------------------------
test('D07: tracking stays on the contiguous drive-mode leg (never across a reverse section)', function()
    local route = {}
    for i = 1, 5 do route[#route+1] = {x=0, y=i*2, drive='FWD'} end
    for i = 1, 3 do route[#route+1] = {x=10, y=10-i*2, drive='BACK'} end
    for i = 1, 5 do route[#route+1] = {x=1, y=i*2, drive='FWD'} end
    local plan = {route=route, index=1, back=false}; Select.track(plan, 1, 10)
    assert(plan.index >= 1 and plan.index <= 5, 'stays on the first forward leg: ' .. plan.index)
end)
-- D09 -----------------------------------------------------------------------
test('D09: a cached answer is reused only for the same shape reaching no further', function()
    local p = P.new({clock=function() return 0 end, ray=function(ax) return ax == 0 end, ground=function() return true end, budget=100})
    local pose, tol, builds = {x=0, y=0, h=0}, {dist=1, angle=15, age=.4}, 0
    local clearBuild = function() builds = builds + 1; return {{0,0,0,1,1,1}} end
    local blockedBuild = function() builds = builds + 1; return {{9,0,0,1,1,1}} end
    p:beginFrame(); equal(p:request('roll:uturn', pose, tol, clearBuild, 'left', 30), true)
    p:beginFrame(); equal(p:request('roll:uturn', pose, tol, blockedBuild, 'right', 30), false, 'other side: rebuilt')
    p:beginFrame(); equal(p:request('roll:uturn', pose, tol, clearBuild, 'right', 30), false, 'same shape: reused')
    p:beginFrame(); equal(p:request('roll:uturn', pose, tol, clearBuild, 'right', 20), false, 'reaching less: reused')
    p:beginFrame(); equal(p:request('roll:uturn', pose, tol, clearBuild, 'right', 45), true, 'reaching further: rebuilt')
    equal(builds, 3)
end)
-- D10 -----------------------------------------------------------------------
test('D10: a road surface rising into a line does not hide an obstacle behind it', function()
    local calls = 0
    local saved = sim.env.processLineOfSight
    sim.env.processLineOfSight = function(ax, ay, az, bx, by, bz)
        calls = calls + 1
        if calls == 1 then return true, {pos={0, 1, 10.4}, normal={0, 0, 1}, entityType=1, entity=0x07000000} end
        return true, {pos={0, 6, az}, normal={0, 1, 0}, entityType=1, entity=0x07000000}
    end
    local ok = sim.bot.recovery.ray(0, 0, 10.45, 0, 10, 10.45)
    equal(ok, false, 'obstacle further along is found'); equal(calls, 2, 're-cast once above the road')
    -- An upward-facing object top is not road.
    calls = 0
    sim.env.processLineOfSight = function() calls = calls + 1; return true, {pos={0, 1, 10.4}, normal={0, 0, 1}, entityType=4, entity=0x08000000} end
    equal((sim.bot.recovery.ray(0, 0, 10.45, 0, 10, 10.45)), false, 'object top blocks')
    sim.env.processLineOfSight = saved
end)
-- D11 -----------------------------------------------------------------------
test('D11: the planned arc end is exactly where the checked arc ends', function()
    local pose, radius, d = {x=0, y=0, h=0}, 5.46, 7
    local endOne = P.arcEnd(pose, -128, d, true, radius)
    local steps = P.arcSteps(pose, -128, d, true, radius)
    local last = steps[#steps]
    assert(math.abs(last.x-endOne.x) < 1e-9 and math.abs(last.y-endOne.y) < 1e-9, 'same construction')
    -- And the audit's piecewise construction agrees now.
    local cur, done, step = pose, 0, math.min(1.5, radius*math.rad(15))
    while done < d-0.001 do local ds = math.min(step, d-done); cur = P.arcEnd(cur, -128, ds, true, radius); done = done + ds end
    assert(math.sqrt((cur.x-endOne.x)^2+(cur.y-endOne.y)^2) < 1e-6, 'piecewise = whole')
end)
-- D14 / D15 (route library index and rename) do not apply to 5.77.4: it has
-- no route library and never writes route files or an index.
test('L02: HOLD that never becomes stable retries instead of waiting forever', function()
    local r = R.new({jturnEnabled=false, uturnEnabled=false}); r:noteTurn(0, false); r:hold(0); r.rate = 0; r.rateAvg = 0
    local retried = false
    for i = 1, 300 do
        r:step(i*0.1, sample({speed=4, forwardSpeed=0, lateralSpeed=4, slip=90}), nil)
        if r.phase == 'WAIT' then retried = true; break end
    end
    assert(retried, 'retries'); assert(r.attempts and r.attempts >= 1)
end)
-- D08 -----------------------------------------------------------------------
test('D08: at the route end the aim follows the last direction; no retry for a missing target', function()
    local route = {}; for i = 1, 50 do route[i] = {x=0, y=(i-1)*2, drive='FWD'} end
    local plan = {route=route, index=50, back=false}; Select.track(plan, 0, 98)
    local err = Select.aim(plan, 0, 98, 0)
    assert(err and math.abs(err) < 1, 'aims along the route at its end: ' .. tostring(err))
    local r = R.new(); r:setPlan(0, plan)
    r:step(.1, sample({x=0, y=98, speed=0, forwardSpeed=0}), err)
    assert(r.phase ~= 'WAIT', 'no retry: ' .. tostring(r.phase))
end)
-- L03 -----------------------------------------------------------------------
test('L03: an incident stays at its highest level while it is active (documented policy)', function()
    local r = R.new(); r:noteTurn(0, false); r:noteTurn(1, false); r:noteTurn(2, false); r:noteTurn(20, false)
    equal(r:windowCount(20), 1); equal(r.level, 'multi')
end)
-- D13 -----------------------------------------------------------------------
test('D13: re-casts never take a frame beyond its budget; a check that cannot fit waits for the next frame', function()
    local p = P.new({clock=function() return 0 end, ray=function(_, _, _, _, _, _, allowance)
        if (allowance or 99) < 4 then return 'more', allowance end
        return true, 4 end, ground=function() return true end, budget=10})
    local function build() local a = {}; for i = 1, 20 do a[i] = {0,0,0,1,1,1} end; return a end
    p:beginFrame(); equal(p:request('a', {x=0, y=0, h=0}, {dist=1, angle=1, age=1}, build), P.PENDING)
    assert(p.used <= 10, 'used ' .. p.used)
    for i = 1, 12 do p:beginFrame(); p:request('a', {x=0, y=0, h=0}, {dist=1, angle=1, age=1}, build); assert(p.used <= 10, 'used ' .. p.used) end
    equal(p:request('a', {x=0, y=0, h=0}, {dist=1, angle=1, age=1}, build), true, 'finished over several frames')
end)
test('D13: route planning line checks are counted in the frame total', function()
    sim.car.y = -25; sim.car.heading = 0
    local route = {}; for i = 1, 50 do route[i] = {x=0, y=(i-1)*2, z=10, speed=15, heading=0, drive='FWD'} end
    sim.bot.setRoute(route, 'route1'); sim.bot.setIndex(1)
    local calls = 0
    local saved = sim.env.processLineOfSight
    sim.env.processLineOfSight = function(ax, ay, az, bx, by, bz)
        calls = calls + 1
        if ax == bx and ay == by then return true, {pos={ax, ay, 10}, normal={0, 0, 1}} end
        return false, nil
    end
    sim.bot.recovery.probes:beginFrame(10)
    assert(sim.bot.recovery.planRecovery(1, sim.now))
    equal(sim.bot.recovery.probes.used, calls, 'every planning call counted')
    sim.env.processLineOfSight = saved
end)
-- D17 -----------------------------------------------------------------------
test('D17: recovery targets with infinite or NaN numbers are rejected (v5.77 route loading unchanged)', function()
    local function route(x)
        local r = {}
        for i = 1, 20 do r[i] = {x=(i == 5 and x or i*2), y=0, z=10, speed=10, heading=0} end
        return r
    end
    local usable = sim.bot.recovery.usableRoute
    equal(usable(route(math.huge)), false)
    equal(usable(route(-math.huge)), false)
    equal(usable(route(0/0)), false)
    equal(usable(route(1e300)), false)
    equal(usable(route(10)), true, 'ordinary coordinates still accepted')
    assert(not Select.finite(math.huge) and Select.finite(12.5))
end)
-- L04 / D12 / L05 -----------------------------------------------------------
test('L04: the slow sweep on the tight circle has the lower speed ceiling', function()
    local cfg = R.new().cfg
    assert(cfg.uturnTightMaxSpeed <= cfg.uturnMaxSpeed)
    local r = R.new(); r:observe(0, 1, 0, true, true); r.memory.fightUsed = 5; r.rate = 0
    r:setUturn(1, {name='route1'}, 64, {heading=0}); assert(r.uturnTight)
    local c = r:step(1.05, sample({speed=cfg.uturnTightMaxSpeed+0.5, forwardSpeed=cfg.uturnTightMaxSpeed+0.5, heading=0}), 120)
    equal(c.gas, 0, 'released above the tight ceiling')
    r:step(1.1, sample({speed=cfg.uturnTightMaxSpeed+cfg.runawayMargin+0.5, forwardSpeed=cfg.uturnTightMaxSpeed+cfg.runawayMargin+0.5, heading=0}), 110)
    equal(r.phase, 'STOP', 'runaway judged against the tight ceiling')
end)
test('D12: a short forward move with the lock is judged by the turning body, not a straight corridor', function()
    -- The script's check for the short locked forward move is the swept arc
    -- of the turning body (with the rear swing), keyed by the lock side.
    local RS = sim.bot.recovery
    RS.probes:reset(); RS.probes:beginFrame(1000)
    RS.setOwnCar(1)
    local r = R.new(); r.phase = 'PLAN'; r.direction = 128; r.planGen = 1
    local view = RS.probeView(1, sim.now, r, 120, 0)
    local _ = view.shortClear
    local slot = RS.probes.slots['decide:sfwd:128']
    assert(slot, 'lock-specific short forward check')
    local straight = P.forwardShort({x=0, y=0, h=0}, 10, {half_length=2.7, half_width=1.1}, 1.3)
    local arc = P.arcBoth({x=0, y=0, h=0}, 10, {half_length=2.7, half_width=1.1}, 128, 1.3, false, false, 5.46)
    assert(#arc > #straight, 'the arc check covers the whole turning body')
end)

test('L05: driving back to the line checks its stopping distance ahead; braking scales with the vehicle', function()
    local r = R.new(); r.plan = {back=false}; r.rate = 0; r.rateAvg = 0; r:startApproach(0, 20)
    r:step(0.1, sample({speed=10, forwardSpeed=10, connectDistance=20, aheadClear=false}), 40)
    equal(r.phase, 'STOP', 'blocked stopping distance ends the approach')
    local heavy = R.stopping({speed=10, brakeDecel=8*0.65})
    local normal = R.stopping({speed=10, brakeDecel=8})
    assert(heavy > normal + 1, 'a heavy car needs more room')
end)

print(total .. ' audit regression scenarios passed')
