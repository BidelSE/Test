-- Execute the actual shipped script with mocked game/Windows surfaces.
-- No copied manager implementation and no GTA/SA-MP installation required.
local sourcePath = arg[1] or 'dangis_vr.lua'
local file = assert(io.open(sourcePath, 'rb'))
local source = file:read('*a'); file:close()
local testRoot = '/tmp/dangis_panel_test'
os.execute('mkdir -p ' .. testRoot)
local fakeNow = 10
os.clock = function() return fakeNow end
package.preload['lib.moonloader'] = function() return {} end
script_name = function() end
script_version = function() end
getWorkingDirectory = function() return testRoot end
PLAYER_PED = 1
local inCar = true
local carX,carY,carSpeed,carHeading=0,0,20,0
isCharInAnyCar = function() return inCar end
storeCarCharIsInNoSave = function() return 1 end
getCarCoordinates = function() return carX, carY, 0 end
getCarSpeed=function() return carSpeed end
getCharCoordinates=getCarCoordinates
isPointOnScreen=function() return false end
getHeadingFromVector2d=function(x,y) return (math.deg((math.atan2 or math.atan)(-x,y))+360)%360 end
locateCharInCar2d=function() return false end
getCarHeading = function() return carHeading end
getDistanceBetweenCoords2d = function(x,y,a,b) return math.sqrt((x-a)^2+(y-b)^2) end
printStringNow = function() end
local writes, pad = {}, {}
writeMemory = function(address, size, value)
    assert(size == 2)
    writes[#writes+1] = {address=address, value=value}
    pad[address] = value
end
setGameKeyState = function(key, value)
    assert(key == 0)
    writes[#writes+1] = {steer=value}
    pad.steer = value
end
local appended = [[
return {
    settings=Settings,vehicles=VehicleProfiles,escape=EscapePlanner,diag=Diagnostics,api=API,
    classifier=MotionClassifier, planner=DrivingPlanner, chat=AdminChat, telemetry=Telemetry,
    turn=turning_mechanism, noise=applySteerNoise,
    setFrame=function(value) frameScale=value end,
    setMotion=function(speed,x,y,gas,brake)
        lastDriveSpeed=speed; lastX=x; lastY=y; gasLevel=gas; brakeLevel=brake
        ControlManager.apply({gas=gas,brake=brake,steer=0})
    end,
    getLevels=function() return gasLevel,brakeLevel end,
    skipScans=function() ObstacleAvoidance.updateScan=function() end end,
    manager=ControlManager, memory=RecoveryMemory, S=S, config=CONFIG, Win32=Win32, Mem=Mem, input=InputHandler,
    stopBump=stopBumpRecovery, resync=resyncAfterBump, rejoin=handleRouteRejoinRecovery,
    setIndex=function(index) play_index=index end, getIndex=function() return play_index end,
    route=RouteFollower, recovery=RecoverySystem, loop=MainLoop,
    release=releaseControls, pedals=writeDriveControls, steering=writeSteerControls,
    state=writeSharedState, bump=startBumpRecovery, updateBump=updateBumpRecovery,
    transition=startBackToForwardTransition, freeze=startFreezeRecovery,
    rotate=handleAdminRotate, rotation=pressRotateReaction,
    setPlaying=function(value) playing=value end,
    setSamp=function(value) samp=value end,
    setRoute=function(value) current_route=value; play_index=1 end,
    setSpeed=function(value) lastDriveSpeed=value; S.forwardSpeed=value end,
    applied=function() return ControlManager.applied end,
    owner=function() return ControlManager.owner end,
    clearSharedThrottle=function() lastSharedStateWriteAt=-1 end,
    setLoopStages=function(dialog, recovery, recorder, playback)
        DialogBridge.update=dialog; RecoverySystem.updateControlThread=recovery
        RouteRecorder.recordTick=recorder; RouteFollower.updatePlayback=playback
    end,
}
]]
local bot = assert((loadstring or load)(source .. appended, '@'..sourcePath))()
bot.config.controls.input="gamepad"
local physical, dialog = false, false
isKeyDown = function() return physical end
bot.Win32.isGameForeground = function() return true end
bot.Win32.keyDown = function() return physical end
bot.Mem.readDword = function(address)
    if address == 0x100000 + 0x21A0B8 then return 0x1000000 end
    if address == 0x1000000 + 0x28 then return dialog and 1 or 0 end
end
bot.setSamp(0x100000)
local function flag(name, value)
    local path=testRoot..'/dangis_vr_'..name..'.flag'
    if value then local f=assert(io.open(path,'w')); f:write(value); f:close()
    else os.remove(path) end
end
local originalScan=bot.escape.scan
local originalReadWord=bot.Mem.readWord
local function clearScene(ax,ay,az,bx,by,bz)
 if math.abs(ax-bx)<0.0001 and math.abs(ay-by)<0.0001 and az-bz>1 then
  return true,{pos={bx,by,-0.5},normal={0,0,1}}
 end
 return false
end
local function reset()
    for key,value in pairs(bot.settings.defaults) do bot.config[key]=bot.settings.copy(value) end
    flag('freeze'); flag('dialog'); flag('rotate')
    physical, dialog, inCar = false, false, true
    bot.config.controls.brakeMode="foot"
    if bot.config.escape then bot.config.escape.enabled=false end
    bot.setPlaying(false)
    bot.route.clearTransientState()
    bot.manager.neutralize()
    bot.setPlaying(true)
    bot.setRoute({{x=0,y=0,z=0,speed=10,drive='FWD'}, {x=10,y=0,z=0,speed=10,drive='FWD'}})
    bot.setSpeed(20)
    bot.manager.sync()
    bot.S.rejoinCooldownUntil=0; bot.S.rejoinDisableUntil=0
    writes={}
    carX,carY,carSpeed,carHeading=0,0,20,0
    bot.classifier.reset();bot.planner.cache=nil
    bot.config.adminChat.includeInferredTests=false
    bot.config.adminChat.includeLocalTests=false
    bot.config.controls.input='gamepad'
    bot.config.controls.steering='smooth'
    bot.config.driving.enabled=true
    bot.S.showObstacleDots=false;bot.S.nextNudge=fakeNow+100
    bot.S.lapWander=0;bot.S.currentLateral=0
    bot.S.nextGasLift=fakeNow+100;bot.S.gasLiftFrames=0
    bot.telemetry.enabled=false
    bot.config.escape.enabled=true
    bot.escape.scan=originalScan;bot.escape.lastSide=nil
    bot.vehicles.presets=bot.settings.copy(bot.vehicles.defaults)
    bot.vehicles.activeName='standard';bot.vehicles.car=nil;bot.vehicles.model=nil;bot.vehicles.lastUpdate=nil
    bot.api.carPointer=nil;bot.Mem.readWord=originalReadWord
    bot.chat.session={startedAt=fakeNow,checks=0,sent=0,joinedAt=nil}
    bot.chat.phrases={};bot.chat.groups={};bot.chat.bag={};bot.chat.bagKey=nil;bot.chat.lastPhrase=nil
    bot.chat.seen,bot.chat.seenOrder={},{}
    bot.diag.unavailable=nil;bot.diag.font=nil
    processLineOfSight=clearScene
    isKeyJustPressed=function() return false end
    VK_F1=nil;VK_F12=nil
    os.remove(bot.settings.path)
end
local function equal(value, expected, message)
    assert(value==expected, (message or 'value')..': expected '..tostring(expected)..', got '..tostring(value))
end
local function neutral()
    equal(pad[bot.config.controls.gasAddress],0,'gas')
    equal(pad[bot.config.controls.footBrakeAddress],0,'foot brake')
    equal(pad[bot.config.controls.handbrakeAddress],0,'handbrake')
    equal(pad.steer,0,'steer')
    equal(bot.applied().reverse,false,'reverse')
end
local total=0
local function test(name,fn)
 reset(); bot.settings.panel.pending={};bot.settings.panel.close();
 bot.chat.queue={};bot.chat.job=nil;bot.chat.pendingQuit=nil;
 bot.Mem.readDword=function(address)
  if address==0x100000+bot.config.adminChat.chatInputPointerOffset then return 0x2000000 end
  if address==0x2000000+bot.config.adminChat.chatEnabledOffset then return 0 end
 end
 fn(); total=total+1; print('PASS '..name)
end
local p=bot.settings.panel
local cursorCalls={}
showCursor=function(show,lock) cursorCalls[#cursorCalls+1]={show,lock};equal(lock,false,'never lock driving') end
getCursorPos=function() return 0,0 end
getScreenResolution=function() return 800,600 end
isGamePaused=function() return false end
renderCreateFont=function() return 1 end
renderDrawBox=function() end
renderFontDrawText=function() end

test('live driving edits update configuration and invalidate held target',function()
 bot.planner.heldTarget={index=12}
 assert(p.set('driving.waypoint_radius',18));equal(bot.config.route.radius,18)
 equal(bot.planner.heldTarget,nil);equal(next(p.pending),nil)
 assert(p.set('driving.steering_point_stride',10));equal(bot.config.driving.steeringPointStride,10)
end)
test('invalid values and crossed delay range do not change active or pending state',function()
 local before=bot.config.route.radius
 equal(p.set('driving.waypoint_radius',100),false);equal(bot.config.route.radius,before)
 equal(p.set('chat.delay_min_seconds',9),false);equal(next(p.pending),nil)
end)
test('input backend defers while driving and releases old backend when paused',function()
 assert(p.set('controls.input','keyboard'));equal(bot.config.controls.input,'gamepad')
 equal(p.pending['controls.input'],'keyboard')
 bot.S.manualPaused=true;p.flush()
 equal(bot.config.controls.input,'keyboard');equal(bot.config.controls.steering,'bangbang')
 bot.S.manualPaused=false
end)
test('chat and recovery edits defer through an active sequence',function()
 bot.chat.queue={{readyAt=20,expiresAt=40}}
 local previous=bot.config.adminChat.replyChance
 assert(p.set('chat.reply_chance',40));equal(bot.config.adminChat.replyChance,previous)
 assert(p.set('recovery.attempt_limit',4));equal(bot.config.recovery.repeatedAttemptLimit,2)
 bot.chat.queue={};p.flush()
 equal(bot.config.adminChat.replyChance,40);equal(bot.config.recovery.repeatedAttemptLimit,4)
end)
test('save roundtrip preserves custom profiles mappings and backs up old file',function()
 bot.config.vehicle.modelProfiles[411]='sport'
 bot.vehicles.presets.sport.half_width=1.3
 local f=assert(io.open(bot.settings.path,'w'));f:write('# previous');f:close()
 assert(p.set('driving.waypoint_radius',17));assert(p.save())
 f=assert(io.open(bot.settings.path));local config,profiles=bot.settings.parse(f:read('*a'));f:close()
 assert(config,profiles);equal(config.route.radius,17);equal(config.vehicle.modelProfiles[411],'sport')
 equal(profiles.sport.half_width,1.3)
 f=assert(io.open(bot.settings.path..'.bak'));equal(f:read('*a'),'# previous');f:close()
end)
test('save failure preserves original INI and reports failure',function()
 local f=assert(io.open(bot.settings.path,'w'));f:write('# retained');f:close()
 -- 5.77.6: a refused rename alone is now recovered by a verified copy, so
 -- the injected failure also refuses writing the INI itself.
 local rename,open=os.rename,io.open
 os.rename=function(from,to) if to==bot.settings.path then return nil,'simulated' end return rename(from,to) end
 io.open=function(path,mode) if path==bot.settings.path and mode=='w' then return nil,'simulated' end return open(path,mode) end
 equal(p.save(),false)
 os.rename,io.open=rename,open
 assert(p.status:find('Save failed',1,true),p.status)
 -- The deliberate failure blocks rollback too: intact backup is retained.
 f=assert(io.open(bot.settings.path..'.bak'));equal(f:read('*a'),'# retained');f:close()
end)
test('rename refused but copy works: INI saved, previous one backed up',function()
 local f=assert(io.open(bot.settings.path,'w'));f:write('# previous\n');f:close()
 local rename=os.rename
 os.rename=function(from,to) if to==bot.settings.path then return nil,'simulated' end return rename(from,to) end
 assert(p.save())
 os.rename=rename
 f=assert(io.open(bot.settings.path));assert(f:read('*a'):find('[driving]',1,true));f:close()
 f=assert(io.open(bot.settings.path..'.bak'));equal(f:read('*a'),'# previous\n');f:close()
 equal(io.open(bot.settings.path..'.tmp'),nil)
end)
test('INI missing after an interrupted save: the backup is loaded and reported',function()
 assert(p.save())
 local f=assert(io.open(bot.settings.path));local text=f:read('*a');f:close()
 f=assert(io.open(bot.settings.path..'.bak','w'));f:write((text:gsub('waypoint_radius = %d+','waypoint_radius = 17')));f:close()
 os.remove(bot.settings.path)
 assert(bot.settings.load());equal(bot.config.route.radius,17)
 assert(bot.settings.status:find('bak',1,true))
end)
test('opening and closing panel never change route owner or lock player controls',function()
 local owner=bot.owner();p.toggle();equal(p.open,true);equal(bot.owner(),owner)
 p.draw();equal(p.open,true);p.toggle();equal(p.open,false)
 equal(cursorCalls[#cursorCalls][1],false)
end)
test('panel closes and releases cursor when dialog or chat interrupts',function()
 p.toggle();equal(p.open,true)
 bot.chat.queue={{readyAt=20,expiresAt=40}};p.draw();equal(p.open,false)
 equal(cursorCalls[#cursorCalls][1],false)
end)
test('mouse messages consumed but driving keyboard messages preserved',function()
 p.toggle();local count=0
 consumeWindowMessage=function(game,scripts) equal(game,true);equal(scripts,false);count=count+1 end
 onWindowMessage(0x201,0,0);equal(count,1)
 onWindowMessage(0x100,0x57,0);equal(count,1)
 p.close();onWindowMessage(0x201,0,0);equal(count,1)
end)
test('render failure closes panel without touching driving state',function()
 p.toggle();local owner=bot.owner();local draw=renderDrawBox
 renderDrawBox=function() error('device lost') end
 p.draw();equal(p.open,false);equal(bot.owner(),owner)
 renderDrawBox=draw
end)
test('mouse adjustment fires once per press, including low frame rates',function()
 p.page=1;p.toggle()
 -- 5.77.6 repair: the 5.72 restyle moved the panel (700 px wide, section
 -- tabs) and 5.77.4 added avoid_all_objects as the first driving row, so the
 -- '+' of the braking row is located from the shipped layout formula
 -- (Settings.panel.draw) instead of the pre-5.72 fixed (726,122).
 local width,rowCount=math.min(700,800-24),math.max(1,math.min(8,math.floor((600-220)/34)))
 local px,py=(800-width)/2,math.max(6,(600-(210+rowCount*34))/2)
 local row;for i,key in ipairs(p.rows()) do if key=='driving.braking_deceleration' then row=i end end
 assert(row and row<=rowCount,'braking row on the first page')
 getCursorPos=function() return px+width-54+10,py+112+(row-1)*34+2+10 end
 local keys=bot.Win32.keyDown;bot.Win32.keyDown=function(vk) return vk==1 end
 local before=bot.config.driving.brakingDeceleration
 p.draw();equal(bot.config.driving.brakingDeceleration,before+0.1)
 p.draw();equal(bot.config.driving.brakingDeceleration,before+0.1)
 bot.Win32.keyDown=keys;getCursorPos=function() return 0,0 end
end)
test('page defaults reset only displayed settings',function()
 -- 5.77.6: two new driving rows moved waypoint_radius to row 14, so the
 -- page that shows it is reset (was hard-coded page 1).
 p.section='driving'
 local row;for i,key in ipairs(p.rows()) do if key=='driving.waypoint_radius' then row=i end end
 p.page=math.ceil(row/12);assert(p.set('driving.waypoint_radius',20));assert(p.set('chat.reply_chance',45))
 assert(p.resetPage(12));equal(bot.config.route.radius,bot.settings.defaults.route.radius)
 equal(bot.config.adminChat.replyChance,45)
end)
print(total..' panel scenarios passed')
