-- Execute the actual shipped script with mocked game/Windows surfaces.
-- No copied manager implementation and no GTA/SA-MP installation required.
local sourcePath = arg[1] or 'dangis_vr.lua'
local file = assert(io.open(sourcePath, 'rb'))
local source = file:read('*a'); file:close()
local testRoot = '/tmp/dangis_recovery_test'
os.execute('mkdir -p ' .. testRoot)
local fakeNow = 10
os.clock = function() return fakeNow end
package.preload['lib.moonloader'] = function() return {} end
script_name = function() end
script_version = function() end
getWorkingDirectory = function() return testRoot end
PLAYER_PED = 1
local inCar = true
isCharInAnyCar = function() return inCar end
storeCarCharIsInNoSave = function() return 1 end
getCarCoordinates = function() return 0, 0, 0 end
getCarHeading = function() return 0 end
getDistanceBetweenCoords2d = function(x,y,a,b) return math.sqrt((x-a)^2+(y-b)^2) end
printStringNow = function() end
local writes, pad = {}, {}
writeMemory = function(address, size, value)
    assert(size == 2)
    writes[#writes+1] = {address=address, value=value}
    pad[address] = value
end
setGameKeyState = function(key, value)
    assert(key == 0)
    writes[#writes+1] = {steer=value}
    pad.steer = value
end
local appended = [[
return {
    manager=ControlManager, memory=RecoveryMemory, S=S, config=CONFIG, Win32=Win32, Mem=Mem, input=InputHandler,
    stopBump=stopBumpRecovery, resync=resyncAfterBump, rejoin=handleRouteRejoinRecovery,
    setIndex=function(index) play_index=index end, getIndex=function() return play_index end,
    route=RouteFollower, recovery=RecoverySystem, loop=MainLoop,
    release=releaseControls, pedals=writeDriveControls, steering=writeSteerControls,
    state=writeSharedState, bump=startBumpRecovery, updateBump=updateBumpRecovery,
    transition=startBackToForwardTransition, freeze=startFreezeRecovery,
    rotate=handleAdminRotate, rotation=pressRotateReaction,
    setPlaying=function(value) playing=value end,
    setSamp=function(value) samp=value end,
    setRoute=function(value) current_route=value; play_index=1 end,
    setSpeed=function(value) lastDriveSpeed=value; S.forwardSpeed=value end,
    applied=function() return ControlManager.applied end,
    owner=function() return ControlManager.owner end,
    clearSharedThrottle=function() lastSharedStateWriteAt=-1 end,
    setLoopStages=function(dialog, recovery, recorder, playback)
        DialogBridge.update=dialog; RecoverySystem.updateControlThread=recovery
        RouteRecorder.recordTick=recorder; RouteFollower.updatePlayback=playback
    end,
}
]]
local bot = assert((loadstring or load)(source .. appended, '@'..sourcePath))()
bot.config.controls.input="gamepad"
local physical, dialog = false, false
isKeyDown = function() return physical end
bot.Win32.isGameForeground = function() return true end
bot.Win32.keyDown = function() return physical end
bot.Mem.readDword = function(address)
    if address == 0x100000 + 0x21A0B8 then return 0x1000000 end
    if address == 0x1000000 + 0x28 then return dialog and 1 or 0 end
end
bot.setSamp(0x100000)
local function flag(name, value)
    local path=testRoot..'/dangis_vr_'..name..'.flag'
    if value then local f=assert(io.open(path,'w')); f:write(value); f:close()
    else os.remove(path) end
end
local function reset()
    flag('freeze'); flag('dialog'); flag('rotate')
    physical, dialog, inCar = false, false, true
    bot.config.controls.brakeMode="foot"
    if bot.config.escape then bot.config.escape.enabled=false end
    bot.setPlaying(false)
    bot.route.clearTransientState()
    bot.manager.neutralize()
    bot.setPlaying(true)
    bot.setRoute({{x=0,y=0,z=0,speed=10,drive='FWD'}, {x=10,y=0,z=0,speed=10,drive='FWD'}})
    bot.setSpeed(20)
    bot.manager.sync()
    bot.S.rejoinCooldownUntil=0; bot.S.rejoinDisableUntil=0
    writes={}
end
local function equal(value, expected, message)
    assert(value==expected, (message or 'value')..': expected '..tostring(expected)..', got '..tostring(value))
end
local function neutral()
    equal(pad[bot.config.controls.gasAddress],0,'gas')
    equal(pad[bot.config.controls.footBrakeAddress],0,'foot brake')
    equal(pad[bot.config.controls.handbrakeAddress],0,'handbrake')
    equal(pad.steer,0,'steer')
    equal(bot.applied().reverse,false,'reverse')
end
local total=0
local function test(name,fn)
 reset(); fn(); total=total+1; print('PASS '..name)
end
local function line(count, mode)
 local result={}
 for i=1,count do result[i]={x=0,y=(i-1)*2,z=0,speed=10,heading=0,drive=mode or 'FWD'} end
 return result
end
local function begin(route)
 bot.setRoute(route); bot.setSpeed(20)
 assert(bot.bump(1,route,1,'test'))
 assert(bot.S.bumpActive)
end
local function finish(route,distance)
 fakeNow=fakeNow+3
 bot.updateBump(1,0,-distance)
 equal(bot.S.bumpPhase,'coast')
 fakeNow=fakeNow+0.4
 bot.updateBump(1,0,-distance)
 equal(bot.S.bumpActive,false)
 fakeNow=fakeNow+4
 bot.setSpeed(20)
end

test('first reverse stays normal; second completed attempt extends distance and duration',function()
 local route=line(30); begin(route)
 local min, max, duration=bot.S.bumpMinDistance,bot.S.bumpMaxDistance,bot.S.bumpUntil-bot.S.bumpStartedAt
 finish(route,4); equal(bot.memory.attempts,1)
 assert(bot.bump(1,route,1,'repeat'))
 equal(bot.S.bumpMinDistance,min+2); equal(bot.S.bumpMaxDistance,max+2)
 assert(bot.S.bumpUntil-bot.S.bumpStartedAt>duration)
 equal(bot.S.bumpSteer,0)
end)

test('two completed attempts without escape cause a neutral manual pause',function()
 local route=line(30); begin(route); finish(route,4)
 assert(bot.bump(1,route,1,'repeat')); finish(route,6)
 equal(bot.memory.attempts,2)
 assert(bot.bump(1,route,1,'third'))
 equal(bot.S.bumpActive,false); assert(bot.S.manualPaused); assert(bot.memory.blocked)
 equal(bot.owner(),'PAUSE'); neutral()
 equal(bot.manager.sharedState('PLAYING'),'RECOVERY_LIMIT')
end)

test('F6 clears blocked history and allows a fresh recovery',function()
 local route=line(30); begin(route); finish(route,4)
 assert(bot.bump(1,route,1,'repeat')); finish(route,6)
 bot.bump(1,route,1,'third')
 VK_F6=6; isKeyJustPressed=function(key) return key==6 end
 bot.input.handleHotkeys(); equal(bot.memory.attempts,0); equal(bot.S.manualPaused,false)
 equal(bot.S.recoveryBlockedReason,nil)
 assert(bot.bump(1,route,1,'fresh')); assert(bot.S.bumpActive)
 isKeyJustPressed=function() return false end
end)

test('manual interruption does not consume an attempt',function()
 local route=line(30); begin(route)
 physical=true; bot.updateBump(1,0,0)
 equal(bot.memory.attempts,0); equal(bot.memory.active,false); equal(bot.S.bumpActive,false)
end)

test('dialog interruption does not consume an attempt',function()
 local route=line(30); begin(route)
 bot.S.dialogPaused=true; bot.updateBump(1,0,0)
 equal(bot.memory.attempts,0); equal(bot.memory.active,false)
end)

test('explicit freeze cancels active attempt without penalizing it',function()
 local route=line(30); begin(route)
 flag('freeze','1\n'); bot.pedals(0,0,true,'BUMP')
 equal(bot.memory.attempts,0); equal(bot.memory.active,false); neutral()
end)

test('unflagged reverse immobility pauses without freeze escalation',function()
 local route=line(30); begin(route)
 fakeNow=fakeNow+1.3; bot.updateBump(1,0,0)
 equal(bot.memory.attempts,1); equal(bot.memory.active,false)
 assert(not bot.S.freezeTestLatched); assert(bot.S.manualPaused); equal(bot.S.recoveryBlockedCode,'RECOVERY_BLOCKED'); neutral()
end)

test('reverse displacement alone does not clear memory; forward progress does',function()
 local route=line(30); begin(route); finish(route,4)
 bot.memory.observe(route,6,0,-9,-3); equal(bot.memory.attempts,1)
 bot.memory.observe(route,1,0,9,3); equal(bot.memory.attempts,1)
 bot.memory.observe(route,6,0,10,3); equal(bot.memory.attempts,0); equal(bot.memory.route,nil)
end)

test('unknown signed speed can confirm escape with applied forward throttle',function()
 local route=line(30); begin(route); finish(route,4)
 bot.manager.applied.gas=80
 bot.memory.observe(route,6,0,10,nil); equal(bot.memory.attempts,0)
end)

test('history expires or resets for a different area or route',function()
 local route=line(30)
 equal(bot.memory.plan(route,1,0,0,fakeNow),1); bot.memory.finish('test')
 equal(bot.memory.plan(route,1,0,0,fakeNow+61),1); bot.memory.finish('test')
 equal(bot.memory.plan(route,1,20,0,fakeNow),1); bot.memory.finish('test')
 equal(bot.memory.plan(line(30),1,0,0,fakeNow),1)
end)

test('local rejoin rejects a physically close point far along recorded path',function()
 local route=line(60); route[#route+1]={x=0,y=0,drive='FWD'}
 local index, accepted=bot.route.findRejoin(route,0,0,2,0,100,30,0)
 assert(accepted); equal(index,2)
end)

test('no valid local candidate keeps current index instead of global nearest',function()
 local route=line(60); route[#route+1]={x=100,y=0,drive='FWD'}
 local index, accepted=bot.route.findRejoin(route,100,0,1,0,100,20,0)
 equal(index,1); equal(accepted,false)
end)

test('rejoin cannot cross BACK boundary into another forward leg',function()
 local route={{x=0,y=0,drive='FWD'}, {x=0,y=5,drive='BACK'}, {x=0,y=8,drive='FWD'}}
 local index, accepted=bot.route.findRejoin(route,0,8,1,0,20,20,0)
 equal(index,1); assert(accepted)
end)

test('nearby returning leg with opposite travel direction is rejected',function()
 local route={{x=0,y=0,drive='FWD'},{x=0,y=5,drive='FWD'},{x=0,y=10,drive='FWD'},
  {x=5,y=10,drive='FWD'},{x=0,y=5,drive='FWD'},{x=0,y=1,drive='FWD'}}
 local index=bot.route.findRejoin(route,0,1,2,0,20,20,0)
 equal(index,2)
end)

test('BACK leg alignment uses backward travel direction',function()
 local route={{x=0,y=0,drive='BACK'},{x=0,y=-2,drive='BACK'},{x=0,y=-4,drive='BACK'}}
 local index, accepted=bot.route.findRejoin(route,0,-2,1,0,10,20,0)
 equal(index,2); assert(accepted)
end)

test('candidate predicate rejection never falls back to distance scoring',function()
 local route=line(10)
 local index,accepted=bot.route.findRejoin(route,0,4,2,0,10,20,0,function() return nil end)
 equal(index,2); equal(accepted,false)
end)

test('bump resync uses bounded path and respects reverse boundaries',function()
 local route={{x=0,y=0,drive='FWD'},{x=0,y=5,drive='BACK'},{x=0,y=8,drive='FWD'}}
 bot.setRoute(route); bot.resync(0,8,0); equal(bot.getIndex(),1)
end)

test('actual forward rejoin returns immediately after neutralizing old controls',function()
 local route=line(30)
 route[21]={x=-3,y=-3,drive='FWD'}
 for i=22,30 do route[i]={x=0,y=10+(i-22)*2,drive='FWD'} end
 bot.setRoute(route); bot.setIndex(21)
 bot.pedals(150,0)
 assert(bot.rejoin(1,0,0,-3,-3,10))
 assert(bot.getIndex()>21); neutral()
end)

test('actual forward rejoin refuses to skip across a reverse section',function()
 local route=line(30)
 route[21]={x=-3,y=-3,drive='FWD'}; route[22]={x=0,y=10,drive='BACK'}
 bot.setRoute(route); bot.setIndex(21)
 equal(bot.rejoin(1,0,0,-3,-3,10),false); equal(bot.getIndex(),21)
end)

test('stop clears recovery history and blocked status',function()
 local route=line(30); bot.memory.plan(route,1,0,0,fakeNow); bot.memory.finish('test')
 bot.route.stopAll(); equal(bot.memory.attempts,0); equal(bot.memory.blocked,false)
end)

flag('freeze'); flag('dialog'); flag('rotate')
print(string.format('%d recovery/rejoin regression scenarios passed',total))
