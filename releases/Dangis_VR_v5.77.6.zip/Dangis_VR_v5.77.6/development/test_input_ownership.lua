-- 5.77.6 manual takeover with overlapping player and bot keys (W/A/S/D).
-- Simulated Windows keyboard (Sim realKeys): one shared state per key, the
-- bot's key events carry its dwExtraInfo marker, the player's do not and
-- auto-repeat while held. Real dangis_vr.lua, keyboard input, user INI.
-- Usage (from the package root): texlua development/test_input_ownership.lua
package.path = "development/?.lua;" .. package.path
local Sim = require("sim_harness")
local INI = Sim.read("dangis_vr.ini")
local W, A, S, D, SPACE = 0x57, 0x41, 0x53, 0x44, 0x20
local DT = 1/30

local total = 0
local function test(name, fn) fn(); total = total + 1; print("PASS " .. name) end
local function equal(a, b, m) if a ~= b then error((m or "value") .. ": expected " .. tostring(b) .. ", got " .. tostring(a), 2) end end

-- A long left-hand arc so the bot holds A (or D) regularly, then a straight.
local function route()
    local pts = {}
    for i = 0, 120 do
        local a = math.rad(i * 1.5)
        pts[#pts+1] = {x=80 - 80 * math.cos(a), y=80 * math.sin(a), z=10, speed=14, heading=0, drive="FWD"}
    end
    return Sim.routeText(pts)
end

local function boot(opts)
    opts = opts or {}
    local sim = Sim.new({root=".", tag="input_" .. (opts.tag or "x"), realKeys=true,
        files={{"dangis_vr.ini", INI}, {"dangis_paths/route1.txt", route()}}, x=0, y=0, z=10.6, heading=270})
    sim.groundZ = 10
    sim.noKeyMessages = opts.noMessages
    sim.bot.loop.initialize()
    sim:frame(DT, {[0x79]=true})            -- F10
    for _ = 1, opts.warmup or 45 do sim:frame(DT) end
    return sim
end
local function run(sim, frames, each) for i = 1, frames do sim:frame(DT); if each then each(i) end end end
local function owner(sim) return sim.bot.manager.owner end
local function botHolds(sim, vk) return sim.bot.Win32.held[vk] == true end
-- key events the bot sent for vk since index `from`
local function botEvents(sim, vk, from)
    local out = {}
    for i = from or 1, #sim.keyLog do local e = sim.keyLog[i]; if e.vk == vk then out[#out+1] = e.up and "up" or "down" end end
    return table.concat(out, ",")
end
local function untilHolding(sim, vk, limit)
    for _ = 1, limit or 600 do if botHolds(sim, vk) then return true end; sim:frame(DT) end
    return false
end

test("bot keys alone never look like the player (40 s of W/A/D on a bend)", function()
    local sim = boot({tag="selfonly"})
    local manual = 0
    run(sim, 1200, function() if owner(sim) == "MANUAL" then manual = manual + 1 end end)
    equal(manual, 0, "frames owned by MANUAL")
    equal(sim.bot.Win32.inputMode(), "verified")
end)

test("player presses W while the bot holds W: takeover, W is not cut", function()
    local sim = boot({tag="overW"})
    assert(untilHolding(sim, W), "bot holds W"); equal(owner(sim), "ROUTE")
    local mark = #sim.keyLog + 1
    sim:humanKey(W, true); sim:frame(DT)
    equal(owner(sim), "MANUAL", "owner (5.77.5: stayed ROUTE)")
    equal(botEvents(sim, W, mark), "", "no key-up for the player's W")
    equal(sim.sysKey[W], true, "W still down for the game")
    equal(sim.bot.Win32.input.transferred[W], true)
    run(sim, 30)
    equal(owner(sim), "MANUAL")
    sim:humanKey(W, false); sim:frame(DT); sim:frame(DT)
    equal(owner(sim), "ROUTE", "back to the route after the player lets go")
    assert(untilHolding(sim, W, 60), "bot presses W again")
    equal(next(sim.bot.Win32.input.transferred), nil)
end)

test("player presses the steering key the bot is holding: takeover", function()
    local sim = boot({tag="overA"})
    local key = untilHolding(sim, A, 900) and A or (untilHolding(sim, D, 900) and D)
    assert(key, "bot steers at some point")
    local mark = #sim.keyLog + 1
    sim:humanKey(key, true); sim:frame(DT)
    equal(owner(sim), "MANUAL")
    equal(botEvents(sim, key, mark), "", "steering key not cut")
    equal(botEvents(sim, W, mark):match("up") ~= nil or not botHolds(sim, W), true, "bot's own W released")
    sim:humanKey(key, false); run(sim, 3)
    equal(owner(sim), "ROUTE")
end)

test("player presses S (not held by the bot): bot's W released once, S untouched", function()
    local sim = boot({tag="S"})
    assert(untilHolding(sim, W))
    local mark = #sim.keyLog + 1
    sim:humanKey(S, true); sim:frame(DT)
    equal(owner(sim), "MANUAL")
    equal(botEvents(sim, W, mark), "up", "the bot's W")
    equal(botEvents(sim, S, mark), "", "the player's S")
    run(sim, 20)
    equal(botEvents(sim, W, mark), "up", "nothing more while the player drives")
    sim:humanKey(S, false); run(sim, 3)
    equal(owner(sim), "ROUTE")
end)

test("focus lost while the player holds a handed-over W: released, nothing stuck", function()
    local sim = boot({tag="focus"})
    assert(untilHolding(sim, W))
    sim:humanKey(W, true); sim:frame(DT)
    equal(sim.bot.Win32.input.transferred[W], true)
    local mark = #sim.keyLog + 1
    sim:setFocus(false); sim:frame(DT)
    equal(botEvents(sim, W, mark), "up", "handed-over W released on focus loss")
    equal(next(sim.bot.Win32.input.transferred), nil)
    sim.physical[W] = nil                     -- player lets go in the other window
    sim:setFocus(true); run(sim, 5)
    equal(next(sim.bot.Win32.input.physical), nil, "no stale player key")
    equal(owner(sim), "ROUTE")
    for vk in pairs(sim.sysKey) do assert(sim.bot.Win32.held[vk], "key " .. vk .. " down but not held by anyone") end
end)

test("F6 pause: bot keys released; the player's keys during the pause are left alone", function()
    local sim = boot({tag="pause"})
    assert(untilHolding(sim, W))
    sim:press(0x75)                           -- F6
    equal(owner(sim), "PAUSE")
    equal(next(sim.bot.Win32.held), nil, "bot holds nothing while paused")
    local mark = #sim.keyLog + 1
    sim:humanKey(W, true); run(sim, 10); sim:humanKey(W, false); run(sim, 2)
    equal(#sim.keyLog, mark - 1, "no bot key events while paused")
    sim:press(0x75)                           -- F6 resume
    run(sim, 3)
    equal(owner(sim), "ROUTE")
end)

test("F7 stop while the player holds a handed-over W: W stays the player's", function()
    local sim = boot({tag="stop"})
    assert(untilHolding(sim, W))
    sim:humanKey(W, true); sim:frame(DT)
    local mark = #sim.keyLog + 1
    sim:press(0x76)                           -- F7
    assert(not sim.bot.isPlaying())
    equal(botEvents(sim, W, mark), "", "no key-up while the player holds W")
    sim:humanKey(W, false); run(sim, 2)
    equal(next(sim.sysKey), nil, "no key left down")
    equal(next(sim.bot.Win32.input.transferred), nil)
end)

test("script termination releases every key it pressed or handed over", function()
    local sim = boot({tag="term"})
    assert(untilHolding(sim, W))
    sim.env.onScriptTerminate(sim.env.thisScript(), false)
    equal(next(sim.bot.Win32.held), nil)
    equal(next(sim.sysKey), nil, "no synthetic key left down")
    local sim2 = boot({tag="term2"})
    assert(untilHolding(sim2, W)); sim2:humanKey(W, true); sim2:frame(DT)
    sim2.env.onScriptTerminate(sim2.env.thisScript(), false)
    equal(sim2.sysKey[W], nil, "handed-over W released (nobody tracks it after unload)")
end)

test("when tagged key messages are not observed: documented fallback, F6 still takes over", function()
    local sim = boot({tag="polling", noMessages=true, warmup=120})
    equal(sim.bot.Win32.inputMode(), "polling only")
    assert(untilHolding(sim, W))
    sim:humanKey(W, true); sim:frame(DT)
    equal(owner(sim), "ROUTE", "limitation: a key the bot holds cannot be told apart by polling")
    sim:press(0x75)                           -- F6: explicit takeover
    equal(owner(sim), "PAUSE")
    equal(sim.bot.Win32.held[W], nil, "bot let go of W (its key-up also cuts the player's W ...)")
    sim:frame(DT)                             -- (... until the keyboard's next auto-repeat)
    equal(owner(sim), "MANUAL", "the player's W is visible once the bot let go of it")
    sim:humanKey(W, false); run(sim, 2)
    equal(owner(sim), "PAUSE")
    sim:humanKey(D, true); sim:frame(DT)      -- a key the bot is not holding is always seen
    equal(owner(sim), "MANUAL")
end)

print(total .. " input ownership scenarios passed")
