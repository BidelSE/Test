-- Driving identity: YOUR v5.77 (development/user_v577, exactly as sent, with
-- your dangis_vr.ini) against 5.77.4 (this folder), side by side.
-- Both scripts are loaded from disk into isolated environments with the same
-- mocked game, the same deterministic random numbers and the same simulated
-- car. Every frame the applied gas/brake/steer/reverse, the control owner, the
-- route index and every synthetic key event must be identical, and the two
-- cars must stay on exactly the same path. No rotation happens in these runs:
-- they cover everything else (driving, obstacles, bump recovery, dialogs,
-- freeze, chat replies, pause, route end and repeat).
-- Usage (from the moonloader folder): texlua development/test_driving_identity.lua
package.path = "development/?.lua;" .. package.path
local Sim = require("sim_harness")
local ROOT_NEW = "."
local ROOT_OLD = "development/user_v577"
local INI = Sim.read(ROOT_OLD .. "/dangis_vr.ini")          -- your INI: planner off, lookahead 0.75 ...
local ROUTE1 = Sim.read("development/fixtures/route1.txt")   -- your route1.txt
local PHRASES = Sim.read("dangis_admin_phrases.txt")

local function parse(text)
    local route = {}
    for x, y, z, speed, heading, drive in text:gmatch("{([^}]*)}:{([^}]*)}:{([^}]*)}:{([^}]*)}:{([^}]*)}:{([^}]*)}") do
        route[#route+1] = {x=tonumber(x), y=tonumber(y), z=tonumber(z), speed=tonumber(speed), heading=tonumber(heading), drive=drive}
    end
    return route
end

local total = 0
local function pair(opts)
    local files = {{"dangis_vr.ini", opts.ini or INI}, {"dangis_admin_phrases.txt", PHRASES}, {"dangis_paths/route1.txt", opts.route or ROUTE1}}
    for _, extra in ipairs(opts.extra or {}) do files[#files+1] = extra end
    local start = parse(opts.route or ROUTE1)[1]
    local function make(root, tag)
        return Sim.new({root=root, tag=tag, files=files, x=start.x, y=start.y, z=start.z, heading=start.heading,
            seed=opts.seed or 99, obstacles=opts.obstacles, walls=opts.walls, collision=opts.collision})
    end
    local old = make(ROOT_OLD, "old_" .. opts.name:gsub("%W", "_"))
    local new = make(ROOT_NEW, "new_" .. opts.name:gsub("%W", "_"))
    for _, sim in ipairs({old, new}) do
        sim.bot.loop.initialize()
        if opts.input then sim.bot.CONFIG.controls.input = opts.input end
        if opts.steering then sim.bot.CONFIG.controls.steering = opts.steering end
        if opts.configure then opts.configure(sim.bot) end
    end
    return old, new
end

local function writeFile(path, text) local f = assert(io.open(path, "w")); f:write(text); f:close() end

local function runOnce(opts)
    local old, new = pair(opts)
    local frames = opts.frames or 3000
    local events = 0
    for frame = 1, frames do
        local dt = opts.dt and opts.dt(frame) or 1/30
        local hot = nil
        if frame == 2 and opts.repeating ~= false then hot = {[0x7A]=true} end   -- F11 repeat
        if frame == 4 then hot = {[0x79]=true} end                                 -- F10 start
        if opts.hotkeys and opts.hotkeys[frame] then hot = {[opts.hotkeys[frame]]=true} end
        if opts.event then
            for _, sim in ipairs({old, new}) do opts.event(sim, frame) end
        end
        old:frame(dt, hot); new:frame(dt, hot)
        local a, b = old:snapshot(), new:snapshot()
        if a ~= b then
            error(string.format("%s: frame %d differs\n  v5.77  : %s\n  5.77.4 : %s", opts.name, frame, a, b))
        end
        if #old.keyLog ~= #new.keyLog then
            error(string.format("%s: frame %d keyboard events differ (%d vs %d)", opts.name, frame, #old.keyLog, #new.keyLog))
        end
        if math.abs(old.car.x - new.car.x) > 1e-9 or math.abs(old.car.y - new.car.y) > 1e-9 then
            error(string.format("%s: frame %d the cars are no longer in the same place", opts.name, frame))
        end
    end
    for i = 1, #old.keyLog do
        local x, y = old.keyLog[i], new.keyLog[i]
        assert(x.vk == y.vk and x.up == y.up, opts.name .. ": keyboard event " .. i .. " differs")
    end
    assert(#old.messages == #new.messages, opts.name .. ": different number of chat messages")
    for i = 1, #old.messages do assert(old.messages[i].text == new.messages[i].text, opts.name .. ": chat message differs") end
    if opts.check then opts.check(old, new) end
    assert(old.bot.getIndex() > 20 or opts.noProgressOk, opts.name .. ": simulated car did not make progress")
    assert(new.bot.recovery.rotation.phase == nil, opts.name .. ": rotation recovery must stay inactive")
    total = total + 1
    print(string.format("PASS %s: %d frames identical, %d key events, %d chat messages, index %d/%d, owner %s",
        opts.name, frames, #new.keyLog, #new.messages, new.bot.getIndex(), #new.bot.getRoute(), new.bot.manager.owner))
end

-- Every scenario runs with [driving] avoid_all_objects = false (exactly
-- v5.77), and - when nothing stands in the car's way - also with the 5.77.4
-- default (true): the obstacle fix may only change driving around obstacles.
-- 5.77.6: the passage check (driving.passage_check, on by default) runs in
-- every scenario. It deliberately changes driving where something solid is
-- in the car's path or the path cannot be verified (v5.77 drives into the
-- parked cars and the wall below, and on without collision data): those
-- scenarios (passageChanges) compare v5.77's code paths with the check off;
-- development/test_passage.lua covers them with it on.
local function run(opts)
    if opts.passageChanges then
        local inner = opts.configure
        opts.configure = function(bot) bot.CONFIG.driving.passageCheck = false; if inner then inner(bot) end end
    end
    local configure = opts.configure
    local off = {}
    for k, v in pairs(opts) do off[k] = v end
    off.name = opts.name .. " [avoid_all_objects=false]"
    off.configure = function(bot) bot.CONFIG.driving.avoidAllObjects = false; if configure then configure(bot) end end
    runOnce(off)
    if not opts.objectsInWay then
        local on = {}
        for k, v in pairs(opts) do on[k] = v end
        on.name = opts.name .. " [default]"
        runOnce(on)
    end
end

-- Synthetic route with a recorded reverse section (FWD -> BACK -> FWD).
local function reverseRoute()
    local pts = {}
    local function add(x, y, speed, drive) pts[#pts+1] = {x=x, y=y, z=10, speed=speed, heading=0, drive=drive} end
    for i = 0, 60 do add(0, i*2, 12, "FWD") end
    for i = 1, 12 do add(0, 120 - i*1.5, -3, "BACK") end
    for i = 1, 60 do add(i*2, 102, 12, "FWD") end
    return Sim.routeText(pts)
end
local r1 = parse(ROUTE1)
local parked = {}
for _, i in ipairs({120, 260, 420, 640}) do
    local p, q = r1[i], r1[i+3]
    local dx, dy = q.x-p.x, q.y-p.y
    local l = math.sqrt(dx*dx+dy*dy)
    parked[#parked+1] = {x=p.x - dy/l*1.6, y=p.y + dx/l*1.6, r=1.3}
end
-- A second recorded route next to route1 (5.77.4 loads it as a recovery target).
local function offsetRoute(route, offset)
    local pts = {}
    for i = 1, #route-1 do
        local p, q = route[i], route[i+1]
        local dx, dy = q.x-p.x, q.y-p.y
        local l = math.max(0.001, math.sqrt(dx*dx+dy*dy))
        pts[#pts+1] = {x=p.x - dy/l*offset, y=p.y + dx/l*offset, z=p.z, speed=p.speed, heading=p.heading, drive="FWD"}
    end
    return Sim.routeText(pts)
end
-- A wall across the road at route point 330: the car gets stuck, bump recovery runs.
local wall = {}
do
    local p, q = r1[330], r1[333]
    local dx, dy = q.x-p.x, q.y-p.y
    local l = math.sqrt(dx*dx+dy*dy)
    local nx, ny = -dy/l, dx/l
    wall[1] = {p.x - nx*12, p.y - ny*12, p.x + nx*12, p.y + ny*12}
end
-- A short route (no repeat) to cover the route end.
local function shortRoute()
    local t = {}
    for i = 1, 120 do t[i] = r1[i] end
    return Sim.routeText(t)
end

run({name="your INI, keyboard 30 FPS, route1", input=nil, frames=5400})
run({name="your INI, keyboard 60 FPS", frames=6000, dt=function() return 1/60 end})
run({name="your INI, keyboard variable 18-45 FPS", frames=3600, dt=function(f) return f%3 == 0 and 1/18 or 1/45 end})
run({name="your INI, parked cars beside the route", frames=4200, obstacles=parked, objectsInWay=true, passageChanges=true})
run({name="your INI, a second saved route next to route1", frames=4200, extra={{"dangis_paths/route2.txt", offsetRoute(r1, 6)}}})
run({name="your INI, wall across the road (obstacle checks)", frames=2400, walls=wall, passageChanges=true})
run({name="your INI, car stuck for 3 s (sudden stop, bump recovery)", frames=2400,
    event=function(sim, f)
        if f == 700 then sim.stuckAt = {sim.car.x, sim.car.y} end
        if f >= 700 and f < 790 then sim.car.x, sim.car.y, sim.car.v = sim.stuckAt[1], sim.stuckAt[2], 0 end
    end,
    check=function(old, new)
        local function bumped(sim)
            local f = io.open(sim.work .. "/dangis_vr_debug.log", "rb"); local t = f and f:read("*a") or ""; if f then f:close() end
            return t:find("BUMP", 1, true) ~= nil or t:find("RECOVERY", 1, true) ~= nil
        end
        assert(bumped(old) and bumped(new), "the stop should have started recovery")
    end})
run({name="your INI, SA-MP dialog while driving", frames=2400,
    event=function(sim, f) if f == 700 then sim.dialog = true elseif f == 820 then sim.dialog = false end end})
run({name="your INI, test-freeze flag while driving", frames=2400,
    event=function(sim, f)
        local path = sim.work .. "/dangis_vr_freeze.flag"
        if f == 700 then writeFile(path, "1\n") elseif f == 900 then os.remove(path) end
    end})
run({name="your INI, /arbotas completion -> chat reply typed while driving", frames=2400,
    event=function(sim, f)
        if f == 600 then writeFile(sim.bot.CONFIG.adminChat.eventFile, "77:1.000:1\n" .. string.format("%.3f", sim.now) .. "\n") end
    end,
    check=function(old) assert(#old.messages >= 1, "the reply should have been typed") end})
run({name="your INI, F6 pause and resume", frames=2400, hotkeys={[700]=0x75, [790]=0x75}})
run({name="your INI, route end without repeat", frames=1500, repeating=false, route=shortRoute(), noProgressOk=true,
    check=function(old, new) assert(not old.bot.isPlaying() and not new.bot.isPlaying(), "route should have ended") end})
run({name="your INI, recorded reverse section", frames=1500, route=reverseRoute()})
run({name="gamepad input, smooth steering, parked cars", input="gamepad", steering="smooth", frames=3000, obstacles=parked, objectsInWay=true, passageChanges=true})
run({name="driving planner switched on (other INI)", frames=3000, configure=function(bot) bot.CONFIG.driving.enabled = true end})
run({name="without collision API", frames=2400, collision=false, passageChanges=true})

-- Source-level guard: every v5.77 function is byte-identical except the
-- listed rotation, rotation-chat and settings-registration functions.
do
    local allowed = {
        ["ControlManager.sync"]="keeps W through a FIGHT handoff; only when the new owner is ROTATE",
        ["Settings.parse"]="accepts the [rotation] section", ["Settings.load"]="applies [rotation]",
        ["hasPauseSource"]="optional third argument (rotation reply only)",
        ["typeSAMPCommand"]="rotation reply flag",
        ["handleAdminRotate"]="rotation", ["RecoverySystem.finishRotation"]="rotation",
        ["RecoverySystem.updateRotation"]="rotation", ["RecoverySystem.updateControlThread"]="rotation session tick",
        ["Settings.panel.serialize"]="[rotation] section", ["Settings.panel.busy"]="rotation keys",
        ["Settings.panel.flush"]="rotation keys", ["Settings.panel.rows"]="rotation tab",
        ["Settings.panel.draw"]="rotation tab", ["Diagnostics.lines"]="rotation line; 5.77.6: passage and sensor lines", ["Diagnostics.draw"]="rotation headline; 5.77.6: passage warning in the card",
        ["AdminChat.eligible"]="rotation reply", ["AdminChat.blockReason"]="rotation reply",
        ["AdminChat.loadPhrases"]="also loads rotation phrases", ["AdminChat.tick"]="rotation reply",
        ["scanRouteAhead"]="5.77.4/5.77.5 obstacle fix: any upright object + low ray bands (off: avoid_all_objects=false)",
        ["RouteFollower.updatePlayback"]="5.77.5 obstacle lane: steering/speed only while objects are in the way; 5.77.6 passage check (no change while the path is verified)",
        ["computeObstacleClusterPlan"]="5.77.5: skips hits the obstacle lane handles (avoid_all_objects)",
        ["getObstacleAhead"]="5.77.5: skips hits the obstacle lane handles (avoid_all_objects)",
        ["draw_line"]="5.77.5: obstacle lane line in the debug box",
        ["ObstacleAvoidance.updateScan"]="5.77.5: feeds the obstacle lane memory (avoid_all_objects); 5.77.6: budgeted sweep",
        -- 5.77.6 (review fixes; driving with nothing in the way is checked
        -- frame by frame above)
        ["Win32.init"]="5.77.6: GetMessageExtraInfo for telling player keys from bot keys",
        ["Win32.press"]="5.77.6: key events carry the bot's dwExtraInfo marker",
        ["Win32.release"]="5.77.6: key events carry the bot's dwExtraInfo marker",
        ["isPhysicalKeyDown"]="5.77.6: a player key the bot also holds is seen (tagged key messages)",
        ["Win32.drive"]="5.77.6: a key the player holds too is handed over, not cut",
        ["onWindowMessage"]="5.77.6: key messages feed the player/bot key distinction",
        ["onScriptTerminate"]="5.77.6: also releases keys handed to the player",
        ["AdminChat.userInputActive"]="5.77.6: a player key the bot holds counts as user input",
        ["MainLoop.tick"]="5.77.6: line-of-sight count per frame, focus-loss key release, passage check kept warm",
        ["saveRoute"]="5.77.6: checked save (lib/dangis_route_io.lua), last valid route never deleted",
        ["loadRoute"]="5.77.6: strict parsing, .tmp/.bak recovery with reasons",
        ["RouteStorage.validateRoute"]="5.77.6: finite numbers, map ranges, known drive modes",
        ["RouteRecorder.recordTick"]="5.77.6: a nan/inf sample is not recorded; failed loop save is reported",
        ["RouteFollower.startPlayback"]="5.77.6: a route in memory is validated; corrupt file message",
        ["Settings.panel.save"]="5.77.6: every step checked and read back; previous INI written back on failure",
        ["Settings.load"]="5.77.6 (and rotation): falls back to dangis_vr.ini.bak after an interrupted save",
        ["resetFreezeRecovery"]="5.77.6: also clears the scan sweep and passage-check state",
        ["RouteFollower.resetPlaybackStartState"]="5.77.6: also clears the scan sweep and passage-check state",
        ["RouteFollower.stopAll"]="5.77.6: also clears the scan sweep and passage-check state",
    }
    -- v5.77 functions 5.77.6 removed, with the reason.
    local removedOk = {
        storageFileExists="replaced by lib/dangis_route_io.lua (checked file operations)",
        copyStorageFile="replaced by lib/dangis_route_io.lua (unchecked copy could delete the last valid route)",
    }
    local p = io.popen("python3 development/compare_functions.py " .. ROOT_OLD .. "/dangis_vr.lua " .. ROOT_NEW .. "/dangis_vr.lua")
    local out = p:read("*a"); p:close()
    local identical = tonumber(out:match("identical: (%d+)"))
    local changed = out:match("CHANGED: ([^\n]*)") or ""
    local removed = out:match("REMOVED: ([^\n]*)") or ""
    for name in removed:gmatch("[^,%s]+") do assert(removedOk[name], "v5.77 function removed: " .. name) end
    local n = 0
    for name in changed:gmatch("[^,%s]+") do
        assert(allowed[name], "v5.77 function changed outside the rotation system: " .. name)
        n = n + 1
    end
    total = total + 1
    print(string.format("PASS source: %d v5.77 functions byte-identical; %d changed, each listed with its reason (%s)",
        identical, n, changed))
end
print(total .. " identity checks passed (your v5.77 vs 5.77.6)")
