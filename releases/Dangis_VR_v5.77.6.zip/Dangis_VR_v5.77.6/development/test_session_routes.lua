-- 5.77.4 recovery route targets and the per-playback switch (simulated).
-- Usage: texlua development/test_session_routes.lua
package.path = "development/?.lua;" .. package.path
local Sim = require("sim_harness")
local INI = Sim.read("dangis_vr.ini")
local DT = 1/30
local total = 0
local function test(name, fn) fn(); total = total + 1; print("PASS " .. name) end
local function equal(a, b, m) if a ~= b then error((m or "value") .. ": expected " .. tostring(b) .. ", got " .. tostring(a), 2) end end
local function line(x, y0, step, n)
    local pts = {}
    for i = 0, n-1 do pts[#pts+1] = {x=x, y=y0+i*step, z=10, speed=15, heading=step > 0 and 0 or 180, drive="FWD"} end
    return Sim.routeText(pts)
end
local function listing(dir)
    local p = io.popen("ls -1 '" .. dir .. "' | sort"); local t = p:read("*a"); p:close(); return t
end
local function log(sim) local f = io.open(sim.work .. "/dangis_vr_debug.log", "rb"); local t = f and f:read("*a") or ""; if f then f:close() end; return t end
local function world(extra, tag)
    local files = {{"dangis_vr.ini", INI}, {"dangis_paths/route1.txt", line(0, 0, 2, 300)},
        {"dangis_paths/route1.txt.bak", line(50, 0, 2, 300)}}
    for _, f in ipairs(extra or {}) do files[#files+1] = f end
    local sim = Sim.new({root=".", tag=tag, files=files, x=0, y=0, z=10.6, heading=0, seed=7, grip=8})
    sim.groundZ = 10
    sim.bot.loop.initialize()
    sim.bot.CONFIG.controls.input = "keyboard"
    return sim
end
local function legacy()
    local t = {}
    for i = 0, 299 do t[#t+1] = string.format("{9}:{%d}:{15}", 598 - i*2) end
    return table.concat(t, "\n") .. "\n"
end

test("playback start reads the other recordings once; backups, old 3-field files and the active route are not targets", function()
    local sim = world({{"dangis_paths/route2.txt", line(9, 598, -2, 300)}, {"dangis_paths/temp.txt", legacy()},
        {"dangis_paths/stub.txt", line(20, 0, 2, 5)}}, "sess_list")
    sim:frame(DT, {[0x79]=true}); sim:frame(DT)
    local names = {}
    for _, e in ipairs(sim.bot.recovery.candidates) do names[#names+1] = e.name end
    equal(table.concat(names, ","), "route2")
    assert(log(sim):find("recovery routes: route2", 1, true))
end)

test("5.77.4 never writes into dangis_paths (no index, no rewritten routes)", function()
    local sim = world({{"dangis_paths/route2.txt", line(9, 598, -2, 300)}}, "sess_nowrite")
    local before = listing(sim.work .. "/dangis_paths")
    local f = io.open(sim.work .. "/dangis_paths/route2.txt", "rb"); local content = f:read("*a"); f:close()
    sim:frame(DT, {[0x79]=true})
    for i = 1, 240 do sim:frame(DT) end
    sim.car.heading = (sim.car.heading + 180) % 360; sim.car.v = -sim.car.v
    for i = 1, 30*20 do sim:frame(DT); if sim.bot.getName() == "route2" then break end end
    equal(sim.bot.getName(), "route2", "switched during recovery")
    sim:frame(DT, {[0x76]=true}); sim:frame(DT)
    equal(listing(sim.work .. "/dangis_paths"), before, "same files")
    f = io.open(sim.work .. "/dangis_paths/route2.txt", "rb"); equal(f:read("*a"), content, "route2 untouched"); f:close()
end)

local function switched(tag)
    local sim = world({{"dangis_paths/route2.txt", line(9, 598, -2, 300)}}, tag)
    sim:frame(DT, {[0x79]=true})
    for i = 1, 240 do sim:frame(DT) end
    sim.car.heading = (sim.car.heading + 180) % 360; sim.car.v = -sim.car.v
    for i = 1, 30*20 do sim:frame(DT); if sim.bot.getName() == "route2" then break end end
    equal(sim.bot.getName(), "route2", "switched during recovery")
    for i = 1, 30 do sim:frame(DT) end
    equal(sim.bot.isPlaying(), true, "driving on route2")
    return sim
end

test("after a switch: F10 (stop) restores the started route for the next F10", function()
    local sim = switched("sess_f10")
    sim:frame(DT, {[0x79]=true}); sim:frame(DT)
    equal(sim.bot.isPlaying(), false)
    equal(sim.bot.getName(), "route1"); equal(#sim.bot.getRoute(), 300)
    sim:frame(DT, {[0x79]=true}); sim:frame(DT)
    equal(sim.bot.isPlaying(), true); equal(sim.bot.getName(), "route1", "next playback drives the started route")
end)

test("after a switch: F2 records under the started route's name, as in v5.77; the recording is kept", function()
    local sim = switched("sess_f2")
    sim:frame(DT, {[0x71]=true})                 -- F2: playback stops, recording starts
    for i = 1, 90 do sim:frame(DT) end
    equal(sim.bot.isRecording(), true)
    equal(sim.bot.getName(), "route1", "recording goes to the started route")
    assert(#sim.bot.getRoute() > 10, "points being recorded are kept: " .. #sim.bot.getRoute())
end)

test("after a switch: leaving the car ends the playback and restores the started route", function()
    local sim = switched("sess_exit")
    sim.car.inCar = false
    sim:frame(DT); sim:frame(DT)
    equal(sim.bot.isPlaying(), false); equal(sim.bot.getName(), "route1")
end)

test("route switching off: nothing is read at playback start", function()
    local sim = world({{"dangis_paths/route2.txt", line(9, 598, -2, 300)}}, "sess_off")
    sim.bot.CONFIG.rotation.routeSwitching = false
    sim:frame(DT, {[0x79]=true}); sim:frame(DT)
    equal(#sim.bot.recovery.candidates, 0)
end)

print(total .. " recovery-route session scenarios passed (simulated)")
