# Dangis VR 5.77.6 — installation and use

This is the only installation guide for this package. Older READMEs (5.70,
5.72, 5.77.4, 5.77.5) are kept for history in `development/archive/docs/`
and do not apply any more.

**Status:** every change in 5.77.6 was tested in a simulator (mocked
MoonLoader / GTA / SA-MP / Windows, see `development/TESTS.md`). Nothing in
this release has been run inside GTA yet. Please go through the in-game
checklist at the end before relying on it.

## 1. Requirements

| | |
|---|---|
| Game | GTA San Andreas **1.0 US** executable (the gamepad input mode and the route recorder read the 1.0 US CPad addresses `0xB73458+…`). |
| Multiplayer client | SA-MP **0.3.7-R1**. Dialog and chat-input detection read R1 memory offsets (`0x21A0B8`, `0x21A0E8`). With another SA-MP version the chat state reads as *unknown*: keyboard driving and automatic chat replies then refuse to act (fail closed), and the dialog helper stays idle. |
| Script loader | MoonLoader (LuaJIT 2.1 with FFI). The script uses only standard MoonLoader functions; `processLineOfSight` is required for driving (see §6). Optional, used when present: `getAllObjects`, `getModelDimensions`, `getObjectHeading`, `getClosestObject`, `getClosestCar`, `isPlayerControlOn`. |
| Not needed | SAMPFUNCS, `samp.events`, ImGui, any other library. |
| OS | Windows (user32/kernel32 via FFI). Works in VMware as before. |

## 2. What is in the package

```
moonloader/   code only — copy its CONTENTS into GTA's moonloader folder
  dangis_vr.lua            the bot
  arbotas_auto.lua         /arbotas check helper (optional, see §7)
  lib/*.lua                7 libraries the bot needs (all required)
defaults/     first install only — never copy over your own files
  dangis_vr.ini            settings (your 5.77 values + the new keys)
  dangis_admin_phrases.txt chat replies, one per line
  dangis_rotation_phrases.txt
tools/        optional in-game test tool
  test_rotate.lua          spins the car to test apsukimas recovery (Ctrl+9 on/off)
development/  simulator tests and history — not for the game folder
INSTALL.md, CHANGELOG.md
```

`moonloader/` contains no settings, routes or phrase files, so copying it
over an existing installation cannot overwrite your data.

## 3. Fresh install

1. Close GTA.
2. Copy everything inside `moonloader/` into `GTA San Andreas/moonloader/`
   (so you get `moonloader/dangis_vr.lua` and `moonloader/lib/dangis_passage.lua` …).
3. Copy the three files from `defaults/` into the same `moonloader/` folder.
4. Start the game. After ~8 s the bot shows *Sistema paruošta* and writes
   `==== … Dangis VR v5.77.6 loading ====` to `moonloader/dangis_vr_debug.log`.

## 4. Updating from 5.77.x (keeps your settings, routes and phrases)

1. Close GTA. Optionally back up `moonloader/dangis_vr.ini`,
   `moonloader/dangis_paths/` and the two phrase files **outside** the
   moonloader folder.
2. Copy everything inside `moonloader/` over your `moonloader/` folder and
   allow replacing. Do **not** copy `defaults/`.
3. Make sure only one copy of the bot exists (no `dangis_vr_old.lua` or similar
   next to it; the bot warns *Veikia kelios boto kopijos* if it finds two).
4. Start the game; the log line must say `v5.77.6`.

Your existing `dangis_vr.ini` loads unchanged. The two new keys
(`passage_check`, `scan_rays_per_frame`) take their defaults until you save
from the settings panel, which then writes them. Route files from every
earlier version load as before; files saved by 5.77.6 end with a line
`#end <points>` that older versions ignore.

Companion scripts from older packages (`hud_aswd.lua`, `test_freeze.lua`,
`testdialog.lua`, `test_dialog_spy.lua`) are not part of this package; they
keep working unchanged.

## 5. Controls

| Key | Action |
|---|---|
| **F10** | start / stop driving the route (`dangis_paths/route1.txt`) |
| **F6** | pause / resume. While paused the bot holds no key — the dependable way to take over (§6) |
| **F7** | stop everything (driving, recording, recovery) |
| **F2** | start / stop recording the route |
| **F11** | repeat the route on / off |
| **W A S D Space** | take over while driving (the bot lets go while you hold them) |
| **Ctrl+I** | settings panel (Lithuanian) |
| **F12** | reload `dangis_vr.ini` and the phrases (when paused or stopped); **Ctrl+F12** marks a new server session |
| **F1** | status card on / off |
| **F3** | obstacle debug view: cycles off / dots / full |
| **F9** | trail on / off |
| **F5** | telemetry capture on / off (`dangis_vr_telemetry.csv`) |

## 6. How it drives (what changed in 5.77.6)

Driving with nothing in the way is unchanged from your 5.77: same route
following, keyboard steering, recorded speeds, reverse sections, gas lifts,
recovery, chat replies and Lithuanian interface. (Simulator: frame-for-frame
identical on route1 at 30/60/18–45 FPS, see `development/TESTS.md`.)

**Passage check** (`[driving] passage_check = true`). Every frame, the path
the car is about to drive is checked with body-height lines along its centre
and both sides. This includes a side step around cones, with the way into it
and back. Where the side step leaves the recorded line by more than 1 m, the
ground is checked too. The path must be verified clear for the distance the
car needs to stop (about 110 m at 130 km/h):
* nothing found → no change at all;
* a **wall / building / gate across the path** → controlled braking and a stop
  before it; the car waits and drives on by itself when it is gone. It never
  reverses for it (the brake key is used only while rolling forward);
* a **cone, object, parked car or person** on the line → left to the obstacle
  lane (5.77.5), which steers round it; the passage check slows the car only
  if no way round has been found and verified by the time it is close;
* a side step that runs into a wall or **off the road** (no ground) → that
  side is refused for 3 s and the other side is used, or the car slows down;
* **slopes and ramps** (upward-facing surfaces) are road, not walls;
* **unknown** — no collision API, a failed query, a check not finished yet,
  or an answer too old — is never treated as clear: the car slows to what is
  verified, or holds still if nothing is (no collision data at all).

The reason is shown on the status card (*Kliūtis kelyje: 18 m*,
*Kelias nepatikrintas: …*), in the Ctrl+I diagnostics lines (`Passage: …`,
`Sensors: …`) and in `dangis_vr_debug.log` (`[OBSTACLE] passage …`).

**Scan workload.** The object scan (~570 line checks per sweep) now runs at
most `scan_rays_per_frame` (100) checks per frame instead of all in one frame.
The passage check uses at most 48 per frame (up to 96 below 15 FPS), plus one
extra round of up to twice that in a frame where the planned path changes.
Simulator: at most 130–136 line checks in any frame, previously 568–622 every
6th frame. The average per frame is about the same as before. The FPS effect
in the game has not been measured.

**Taking over.** Every key the bot presses is marked. In the game window's
messages the bot can therefore tell your W from its own W even while it is
holding W itself. You take over at once, and keys you are holding are left
to you (not released under your finger). This needs the bot to see its own
marked key messages. The log then says `own key events recognised` and the
diagnostics show `keys verified`. If that never happens (`keys polling only`),
a key the bot is holding cannot be told apart from yours: press **F6** first,
then drive. Keys you are not holding are always seen.

**Routes.** Route files are checked strictly before playback (finite numbers,
map-sized coordinates, known drive modes, no malformed lines). Saving writes
a new file, reads it back, keeps the previous valid route as
`route1.txt.bak`, and never deletes it before that backup exists. If a
save is interrupted, the next start uses the complete `.tmp` or the `.bak`
and says so (*atsargine kopija*). A corrupt file is reported
(*Kelio failas sugadintas*) instead of being played or silently patched.

## 7. The /arbotas helper (`arbotas_auto.lua` 1.7)

It answers the server's check dialog (pick the blank row, or the row of three
white numbers) after a 2–5.5 s human-like delay. It only acts on a list whose
**first row is the check's instruction** ("Pasirinkite …" with "tuščią" or
"baltais"), so other lists (shops, menus) with a blank row are never
touched. If a list looks like a check but its first row is different, it
says *Patikrinimas neatpažintas … atsakykite patys* and does nothing. The
exact dialog text is re-read before every key press; if it changes, or the
game loses focus, it stops. If the server changes the wording, adjust
`ArbotasSignature` at the top of the file.

## 8. Settings (`moonloader/dangis_vr.ini`, or Ctrl+I)

Unchanged keys keep your values; all ranges are checked and an invalid file is
refused as a whole (the previous settings stay). New in 5.77.6:

| Key | Default | Meaning |
|---|---|---|
| `[driving] passage_check` | `true` | the passage check above; `false` = 5.77.5 behaviour (drives on without verifying the path) |
| `[driving] scan_rays_per_frame` | `100` | line checks per frame for the object scan (40–600). Higher = each sweep finishes in fewer frames; lower = less work per frame |

Defaults that matter for driving (your 5.77 values): keyboard input with
digital steering, `corner_braking = false`, `avoid_all_objects = true`,
`lateral_tolerance = 3`, `lookahead_seconds = 0.75`, `max_speed_kmh = 250`.
5.77.6 changes none of them.

A settings save checks every step, reads the file back, keeps the previous
file as `dangis_vr.ini.bak`, and puts it back if replacing fails. If only the
`.bak` exists after an interruption, it is loaded and the status says so.

## 9. Files the bot writes (in `moonloader/`)

`dangis_vr_debug.log` (events, trimmed at 64 KB), `dangis_vr_state.txt`
(state for HUD scripts), `dangis_paths/<name>.txt(.bak/.tmp)`,
`dangis_vr.ini(.bak/.tmp)`, `dangis_vr_telemetry.csv` (only with F5),
flag files `dangis_vr_*.flag` used by the test scripts.

## 10. Known limitations

* None of 5.77.6 has been run in GTA. The simulator's physics, collision and
  keyboard are simplified (each keyboard tap turns the car more than in GTA;
  walls and objects are ideal shapes; Windows messages are modelled).
* The passage check assumes the car can brake at about 7 m/s² (scaled by the
  vehicle profile). A vehicle that brakes worse needs a profile with a lower
  `braking_scale` to stop in time before a wall.
* Walls are not steered round, only stopped for. A route recorded through a
  place that is now closed (gate, barrier object across the whole road) stops
  the car there; take over or re-record.
* Ray heights follow the recorded route's height. Very steep stunt surfaces
  or stairs (vertical faces) can read as walls and stop the car.
* Lines start just ahead of the front bumper. Anything within 0.6 m of the
  car's own outline is treated as part of the car (attached objects).
* Telling your key from the bot's key relies on Windows' `GetMessageExtraInfo`
  for the game window's key messages; until those are seen the old rule
  applies (F6 to take over a key the bot holds). When F6 releases a key you
  are also holding, the game sees it up until your keyboard repeats it.
* On focus loss and on script unload, keys handed over to you are released
  (nobody tracks them then).
* The dialog helper's dialog-type/ID offsets (`+0x04/+0x05`) are taken over
  unchanged from earlier versions and could not be verified here; recognition
  no longer depends on them (first-row wording and full-text re-checks).
* SA-MP versions other than 0.3.7-R1 are not supported (see §1).

## 11. In-game validation checklist

Do these on your test server, with the status card on (F1) and the log open
afterwards.

1. **Version and keys:** start the game; the log has `Dangis VR v5.77.6` and,
   after the first few seconds of driving, `own key events recognised`. If it
   says `own key events not seen …` instead, report it (and use F6 to take over).
2. **Clear road:** drive route1 for a few laps at your usual speed. The car
   must drive as with 5.77.5: same speeds, no slow-downs, card never shows
   *Kliūtis kelyje* / *Kelias nepatikrintas*.
3. **Take over while it holds W:** while it accelerates, press and hold W
   yourself → the card shows the override state at once and W stays pressed;
   release → it continues. Repeat with A or D while it steers.
4. **Wall / closed gate:** drive towards a wall or a closed gate on the route
   at 60 and 130 km/h → it brakes and stops before it without reversing;
   the card shows *Kliūtis kelyje*; log `[OBSTACLE] passage blocked: wall …`.
5. **Road works:** the cones from your videos → driven past as in 5.77.5,
   no braking where the lane is free.
6. **Side step next to a wall or off the road:** an object on the line with a
   wall or a drop on one side → it goes round on the other side.
7. **Ramps / hills on the route:** no slow-down at the foot or crest.
8. **Dialogs:** open a shop/menu list with a blank row → the helper does
   nothing. A real /arbotas check → answered as before.
9. **Route save:** F2, drive, F2 → *Kelias issaugotas!*; `route1.txt.bak`
   holds the previous route; F10 plays the new one.
10. **FPS:** compare FPS on a busy street with 5.77.5 (the scan's per-frame
    peak is lower; please report what you see).

Send `dangis_vr_debug.log` and a short video for anything that differs.
