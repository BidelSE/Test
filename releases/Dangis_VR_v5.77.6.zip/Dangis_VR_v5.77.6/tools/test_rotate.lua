script_name("Dangis rotate test")
script_author("Dangis VR tools")
script_version("1.3")
script_description("Spins your car 180 degrees on a hotkey so you can test Dangis VR apsukimas recovery in-game.")

-- Standalone test tool for Dangis VR 5.78. No SAMPFUNCS, no samp.events.
-- Put it in the moonloader folder next to dangis_vr.lua. It does not change
-- dangis_vr.lua or its settings; it only turns your car around and watches
-- what the bot does (dangis_vr_state.txt and dangis_vr_debug.log).
--
-- Hotkeys (hold Ctrl, you must be the driver):
--   Ctrl+9  tool ON/OFF (starts OFF; remembered in test_rotate.cfg). While
--           OFF nothing is spun, auto test is off and only Ctrl+9 / Ctrl+0 work.
--   Ctrl+1  one spin                  (first-rotation behaviour)
--   Ctrl+2  two spins, 2 s apart      (double behaviour)
--   Ctrl+3  three spins, 2 s apart    (3+ in 10 s: pull over / park)
--   Ctrl+4  spin style: quick turn (0.15 s sweep) / instant flip
--   Ctrl+5  speed after spin: keep momentum / stop the car
--   Ctrl+6  auto test on/off (random spins every 30-60 s while the bot drives)
--   Ctrl+0  show/hide the panel
-- Every test is written to moonloader/test_rotate.log.
-- Don't press W/A/S/D/Space around a spin: the bot ignores rotations while
-- you drive (the panel tells you when that happened).

require 'lib.moonloader'

----------------------------------------------------------------- settings
local SPIN_TIME = 0.15        -- seconds for a quick spin (the bot detects 140+ degrees inside 0.25 s)
local SPIN_GAP = 2.0          -- seconds between the spins of a double/triple test
local AUTO_MIN, AUTO_MAX = 30, 60
local AUTO_MIN_SPEED = 5.0    -- m/s; auto mode only spins a car that is really driving
local DETECT_TIMEOUT = 1.5    -- the bot must take over within this time after the first spin
local RECOVER_TIMEOUT = 120.0 -- give up watching after this long
local ROUTE_CONFIRM = 1.0     -- normal driving must last this long to count as recovered
local HUD_X, HUD_Y = 20, 260
local BOT_LOG_LINES = 7

local dir = getWorkingDirectory()
local STATE_FILE = dir .. "/dangis_vr_state.txt"
local BOT_LOG = dir .. "/dangis_vr_debug.log"
local TEST_LOG = dir .. "/test_rotate.log"
local CFG_FILE = dir .. "/test_rotate.cfg"

local VK_CTRL = 0x11
-- The bot ignores a spin while you press any of these (manual driving).
local DRIVE_KEYS = {0x57, 0x41, 0x53, 0x44, 0x20}
local KEY = {one=0x31, two=0x32, three=0x33, style=0x34, momentum=0x35, auto=0x36, hud=0x30, power=0x39}

------------------------------------------------------------------- state
local enabled = false          -- master switch (Ctrl+9)
local style = "quick"         -- "quick" or "instant"
local momentum = "keep"       -- "keep" or "stop"
local autoOn, autoNext = false, nil
local hudOn = true
local font
local busy = false            -- a spin sequence is running
local current = nil           -- the test being watched
local lastResult = "no test yet"
local testId = 0
local nextSide = 1            -- quick spins alternate left/right
local bot = nil               -- last read of dangis_vr_state.txt
local botReadAt = -1
local botLines = {}
local logPos = nil
local logReadAt = -1

local okMem, memory = pcall(require, "memory")
if not okMem then memory = nil end

----------------------------------------------------------------- helpers
local function writeLog(text)
    local f = io.open(TEST_LOG, "a")
    if not f then return end
    f:write(os.date("%Y-%m-%d %H:%M:%S") .. string.format(" [%.3f] ", os.clock()) .. text .. "\n")
    f:close()
end

local function notify(text)
    printStringNow(text, 2500)
end

-- The ON/OFF state survives reloads and game restarts.
local function loadEnabled()
    local f = io.open(CFG_FILE, "r")
    if not f then return false end
    local value = f:read("*l")
    f:close()
    return value == "on"
end

local function saveEnabled()
    local f = io.open(CFG_FILE, "w")
    if not f then return end
    f:write(enabled and "on\n" or "off\n")
    f:close()
end

local function driverCar()
    if not isCharInAnyCar(PLAYER_PED) then return nil end
    local car = storeCarCharIsInNoSave(PLAYER_PED)
    if not car or not doesVehicleExist(car) then return nil end
    if getDriverOfCar(car) ~= PLAYER_PED then return nil end
    return car
end

-- World velocity (CPhysical::m_vecMoveSpeed). Keeping it through the spin
-- makes the car keep sliding the way it was going, like a real apsukimas.
local function readVelocity(car)
    if not memory then return nil end
    local p = getCarPointer(car)
    if not p or p == 0 then return nil end
    return memory.getfloat(p + 0x44), memory.getfloat(p + 0x48), memory.getfloat(p + 0x4C)
end

local function writeVelocity(car, x, y, z)
    if not memory or not x then return end
    local p = getCarPointer(car)
    if not p or p == 0 then return end
    memory.setfloat(p + 0x44, x)
    memory.setfloat(p + 0x48, y)
    memory.setfloat(p + 0x4C, z)
end

local function readBot(now)
    if now - botReadAt < 0.05 then return bot end
    botReadAt = now
    local f = io.open(STATE_FILE, "r")
    if not f then bot = nil; return nil end
    local l = {}
    for line in f:lines() do l[#l + 1] = line end
    f:close()
    local stamp = tonumber(l[5] or "")
    bot = {
        state = l[1] or "?", gas = tonumber(l[2] or "") or 0, brake = tonumber(l[3] or "") or 0,
        steer = tonumber(l[4] or "") or 0, reversing = l[6] == "1", owner = l[7] or "?",
        fresh = stamp ~= nil and math.abs(now - stamp) < 1.0,
    }
    return bot
end

-- The player's own driving input. isKeyDown() may also see the keys the bot
-- itself injects, so a key only counts when the bot is not holding it (from
-- its state file: gas -> W, brake/reverse -> S, steer -> A/D), or when the
-- bot itself reports manual control (owner MANUAL).
local function botHolds(vk, b)
    if not b or not b.fresh then return false end
    if vk == 0x57 then return (b.gas or 0) > 0 end
    if vk == 0x53 then return (b.brake or 0) > 0 or b.reversing end
    if vk == 0x41 then return (b.steer or 0) < 0 end
    if vk == 0x44 then return (b.steer or 0) > 0 end
    return false
end

local function driverKeyDown()
    local b = readBot(os.clock())
    if b and b.fresh and b.owner == "MANUAL" then return true end
    for _, vk in ipairs(DRIVE_KEYS) do
        if isKeyDown(vk) and not botHolds(vk, b) then return true end
    end
    return false
end

local function botDriving(b)
    return b and b.fresh and b.owner == "ROUTE"
end

-- Follow dangis_vr_debug.log and keep the rotation-related lines.
local function pollBotLog(now)
    if now - logReadAt < 0.25 then return end
    logReadAt = now
    local f = io.open(BOT_LOG, "rb")
    if not f then return end
    local size = f:seek("end")
    if not logPos or size < logPos then logPos = size end -- start at the end; skip a trimmed file
    if size > logPos then
        f:seek("set", logPos)
        local data = f:read(size - logPos) or ""
        local last = data:match(".*()\n")
        if last then
            logPos = logPos + last
            for line in data:sub(1, last):gmatch("([^\r\n]+)") do
                if line:find("[ROTATION]", 1, true) or line:find("[ADMIN_CHAT]", 1, true) then
                    local short = line:gsub("^%[[%d%.]+%] ", "")
                    botLines[#botLines + 1] = short
                    while #botLines > BOT_LOG_LINES do table.remove(botLines, 1) end
                    if current and not current.result then current.botLog[#current.botLog + 1] = short end
                end
            end
        end
    end
    f:close()
end

------------------------------------------------------------------ spins
local function spinOnce(car, side)
    if driverKeyDown() and current then current.keysPressed = true end
    local h0 = getCarHeading(car)
    local vx, vy, vz = readVelocity(car)
    local function hold()
        if momentum == "stop" then
            if vx then writeVelocity(car, 0, 0, vz) else setCarForwardSpeed(car, 0) end
        else
            writeVelocity(car, vx, vy, vz)
        end
    end
    if style == "instant" then
        setCarHeading(car, (h0 + 180) % 360)
        hold()
        return true
    end
    local t0 = os.clock()
    while true do
        if not doesVehicleExist(car) or driverCar() ~= car or not enabled then return false end
        local t = math.min(1, (os.clock() - t0) / SPIN_TIME)
        setCarHeading(car, (h0 + side * 180 * t) % 360)
        hold()
        if driverKeyDown() and current then current.keysPressed = true end
        if t >= 1 then return true end
        wait(0)
    end
end

local function runTest(count, reason)
    if not enabled then notify("Rotate test is OFF - Ctrl+9 turns it on"); return end
    if busy then notify("Rotate test: spins already running"); return end
    local car = driverCar()
    if not car then notify("Rotate test: get in a car as the driver"); return end
    busy = true
    testId = testId + 1
    local test = {id = testId, count = count, reason = reason, spins = {}, phases = {}, botLog = {}}
    current = test
    lua_thread.create(function()
        for i = 1, count do
            car = driverCar()
            if not enabled then test.result = "aborted: tool switched off"; break end
            if not car then test.result = "aborted: you left the car"; break end
            local b = readBot(os.clock())
            local speed, heading = getCarSpeed(car), getCarHeading(car)
            local side = nextSide
            nextSide = -nextSide
            if not spinOnce(car, side) then
                test.result = enabled and "aborted: car changed during the spin" or "aborted: tool switched off"
                break
            end
            local at = os.clock()
            test.firstSpin = test.firstSpin or at
            test.lastSpin = at
            test.spins[i] = at
            writeLog(string.format("test #%d spin %d/%d (%s, %s %s, momentum %s): speed %.1f m/s, heading %.0f -> %.0f, bot %s/%s",
                test.id, i, count, reason, style, style == "quick" and (side > 0 and "left" or "right") or "",
                momentum, speed, heading, getCarHeading(car), b and b.state or "no data", b and b.owner or "-"))
            if i < count then wait(math.floor(SPIN_GAP * 1000)) end
        end
        if test.result then writeLog(string.format("test #%d %s", test.id, test.result)) end
        busy = false
    end)
    notify(string.format("Rotate test #%d: %d spin%s", test.id, count, count > 1 and "s" or ""))
end

-- Watch the bot's control owner and phase until it is driving normally again.
local function finish(test, text)
    test.result = text
    local phases = table.concat(test.phases, " > ")
    lastResult = string.format("#%d x%d: %s", test.id, test.count, text)
    writeLog(string.format("test #%d result: %s | phases: %s", test.id, text, phases ~= "" and phases or "-"))
    for _, line in ipairs(test.botLog) do writeLog("    bot: " .. line) end
end

local function watch(now, b)
    local test = current
    if not test or test.result or not test.firstSpin then return end
    if b and b.fresh then
        local label = b.state:gsub("^ROTATE_", "")
        if b.owner == "ROTATE" or b.state:find("^ROTATE_") then test.detected = test.detected or now end
        if test.detected and test.phases[#test.phases] ~= label then test.phases[#test.phases + 1] = label end
    end
    if not test.detected then
        if now - test.firstSpin <= 0.5 and driverKeyDown() then test.keysPressed = true end
        if now - test.firstSpin > DETECT_TIMEOUT then
            finish(test, string.format("NOT DETECTED (bot %s/%s)%s", b and b.state or "no data", b and b.owner or "-",
                test.keysPressed and " - you were pressing W/A/S/D/Space: the bot ignores spins while you drive" or ""))
        end
        return
    end
    if busy then return end
    if botDriving(b) then
        test.routeSince = test.routeSince or now
        if now - test.routeSince >= ROUTE_CONFIRM then
            finish(test, string.format("recovered %.1f s after the last spin", test.routeSince - test.lastSpin))
        end
    else
        test.routeSince = nil
    end
    if not test.result and now - test.lastSpin > RECOVER_TIMEOUT then
        finish(test, string.format("still not driving after %.0f s (bot %s)", RECOVER_TIMEOUT, b and b.state or "no data"))
    end
end

local function scheduleAuto(now)
    autoNext = now + AUTO_MIN + math.random() * (AUTO_MAX - AUTO_MIN)
end

local function autoTick(now, b)
    if not enabled or not autoOn or busy or (current and not current.result) then return end
    if now < autoNext then return end
    local car = driverCar()
    if not car or not botDriving(b) or getCarSpeed(car) < AUTO_MIN_SPEED then return end -- try again next frame
    local roll = math.random()
    runTest(roll < 0.6 and 1 or (roll < 0.85 and 2 or 3), "auto")
    scheduleAuto(now)
end

------------------------------------------------------------------- panel
local function drawHud(now, b)
    if not hudOn or not font then return end
    if not enabled then
        renderFontDrawText(font, "{FFD54F}ROTATE TEST {EF5350}OFF{FFFFFF}  Ctrl+9 on   Ctrl+0 hide", HUD_X, HUD_Y, 0xFFFFFFFF)
        return
    end
    local car = driverCar()
    local lines = {
        "{FFD54F}ROTATE TEST {66BB6A}ON{FFFFFF}  Ctrl+1/2/3 spin x1/x2/x3   Ctrl+4 style   Ctrl+5 speed   Ctrl+6 auto   Ctrl+9 off   Ctrl+0 hide",
        string.format("style: %s   after spin: %s   auto: %s",
            style == "quick" and string.format("quick turn %.2fs", SPIN_TIME) or "instant flip",
            momentum == "keep" and "keep momentum" or "stop",
            autoOn and string.format("on, next in %.0fs", math.max(0, (autoNext or now) - now)) or "off"),
        car and string.format("car: %.1f m/s  heading %.0f", getCarSpeed(car), getCarHeading(car)) or "car: not driving",
        b and string.format("bot: %s / %s   gas %d brake %d steer %d%s%s", b.state, b.owner, b.gas, b.brake, b.steer,
            b.reversing and "  R" or "", b.fresh and "" or "  (stale: bot paused or stopped?)")
            or "bot: no data (is dangis_vr.lua running?)",
    }
    local test = current
    if test and not test.result then
        local status
        if busy then status = "spinning"
        elseif not test.detected then status = "waiting for the bot to react"
        else status = string.format("recovering %.1fs", now - (test.lastSpin or now)) end
        lines[#lines + 1] = string.format("{80DEEA}test #%d x%d: %s   %s", test.id, test.count, status, table.concat(test.phases, " > "))
    end
    lines[#lines + 1] = "last: " .. lastResult
    for _, line in ipairs(botLines) do lines[#lines + 1] = "{B0BEC5}" .. line end
    local h = renderGetFontDrawHeight(font)
    for i, line in ipairs(lines) do
        renderFontDrawText(font, line, HUD_X, HUD_Y + (i - 1) * h, 0xFFFFFFFF)
    end
end

-------------------------------------------------------------------- main
function main()
    while not isPlayerPlaying(PLAYER_HANDLE) do wait(100) end
    math.randomseed(os.time())
    font = renderCreateFont("Arial", 9, 5) -- bold + border
    enabled = loadEnabled()
    writeLog("---- rotate test loaded, " .. (enabled and "ON" or "OFF") .. " (memory module " .. (memory and "ok" or "missing: momentum uses the game default") .. ")")
    while true do
        wait(0)
        local now = os.clock()
        local b = readBot(now)
        if enabled then pollBotLog(now) else logPos = nil end
        if not isGamePaused() and isKeyDown(VK_CTRL) and isKeyJustPressed(KEY.power) then
            enabled = not enabled
            saveEnabled()
            if not enabled then
                autoOn = false
                if current and not current.result and not busy then finish(current, "stopped: tool switched off") end
            end
            notify("Rotate test " .. (enabled and "~g~ON" or "~r~OFF"))
            writeLog("tool switched " .. (enabled and "on" or "off"))
        elseif not isGamePaused() and isKeyDown(VK_CTRL) and enabled then
            if isKeyJustPressed(KEY.one) then runTest(1, "manual")
            elseif isKeyJustPressed(KEY.two) then runTest(2, "manual")
            elseif isKeyJustPressed(KEY.three) then runTest(3, "manual")
            elseif isKeyJustPressed(KEY.style) then
                style = style == "quick" and "instant" or "quick"
                notify("Spin style: " .. (style == "quick" and "quick turn" or "instant flip"))
            elseif isKeyJustPressed(KEY.momentum) then
                momentum = momentum == "keep" and "stop" or "keep"
                notify("After spin: " .. (momentum == "keep" and "keep momentum" or "stop"))
            elseif isKeyJustPressed(KEY.auto) then
                autoOn = not autoOn
                if autoOn then scheduleAuto(now) end
                notify("Auto test " .. (autoOn and "ON" or "OFF"))
                writeLog("auto test " .. (autoOn and "on" or "off"))
            elseif isKeyJustPressed(KEY.hud) then
                hudOn = not hudOn
            end
        elseif not isGamePaused() and isKeyDown(VK_CTRL) and isKeyJustPressed(KEY.hud) then
            hudOn = not hudOn
        end
        watch(now, b)
        autoTick(now, b)
        drawHud(now, b)
    end
end
