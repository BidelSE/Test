# Changelog

## 5.77.6 — review fixes (simulated; not yet run in GTA)

Every finding was first reproduced against the unchanged 5.77.5 in the
simulator (`development/repro_findings.lua` prints the symptom for any
version; output for 5.77.5 and 5.77.6 in `development/TESTS.md`). The
regression tests named below cover the fixed behaviour.
Driving with nothing in the way is frame-for-frame identical to your v5.77
(`test_driving_identity.lua`, 31 checks, passage check on).

| # | Finding (verified) | Fix | Tests |
|---|---|---|---|
| 1 | **Walls were invisible to normal driving.** The scan discarded building hits (`kind ~= "car" → return`, `dangis_vr.lua` 5.77.5 l. 2606). A wall across the route gave 0 obstacle entries and the car crossed its plane at full throttle. Side-step offsets were only checked against remembered cones. | New **passage check** (`lib/dangis_passage.lua`, `ObstacleAvoidance.passagePath/passageLimit`). It verifies the body corridor of the path the car will actually drive: route line, the lane's side step, the way into it and back. It reuses the rotation-recovery line test (own car skipped, road surfaces re-cast) and its ground test off the recorded line. Walls/world geometry → controlled brake and stop (foot brake only while rolling forward, never reverse). Objects/vehicles → told to the obstacle lane, which steers round them; speed is limited only if no way round is verified in time. A side step into a wall or off the road vetoes that side for 3 s. Upward surfaces (ramps, slopes) are road. Not done: registering walls in the scan, since roadside buildings would then trigger the lane in every street. | `test_passage.lua` (wall at 20/36 m/s, 15 FPS and 18–45 FPS, gamepad, gate opening, partial wall, narrow street = no change, 8 %/25 % ramps, side step into wall / off road) |
| 2 | **Missing sensing read as clear.** With no collision API: `ROUTE g=255`. Failed queries in the scan were dropped silently. | Three states per checked piece: clear / blocked / unknown. Unknown covers no API, failed or nil query, not finished (budget), and stale (older than 0.4 s near / 1.0 s far). It is never clear: the car slows to what is verified, or holds if nothing is. The scan reports `pending` / `complete` / `unknown` with a reason. The reason is shown on the card, the diagnostics and the log. A brief carry-over (≤ 0.5 s, same path) bridges only "not checked yet", never a failure. | `test_passage.lua` (no API → holds, reason; failing queries 1.5 s → slows, recovers; nil answers; starved budget; stale answers expire) |
| 3 | **Player W ignored while the bot held W.** `isPhysicalKeyDown` returned false for any key in `Win32.held`. Polling cannot tell them apart (one Windows key state). | Every synthetic key event carries a `dwExtraInfo` marker. `onWindowMessage` reads `GetMessageExtraInfo()` per key message and records untagged keys as the player's. This is trusted only after the bot has seen its own tagged messages; otherwise the old rule applies and F6 remains the takeover. A key the player also holds is handed over instead of released (no key-up under their finger). Handed-over keys are released on focus loss and unload. Diagnostics: `keys verified / polling only`. | `test_input_ownership.lua` (W and steering overlap, S, focus loss, F6, F7, unload, fallback; simulator now models one shared key state + messages) |
| 4 | **568–622 line checks in one frame;** the 280 limit only capped debug probes. | `processLineOfSight` is wrapped and counted. The object scan is a queued sweep run under `scan_rays_per_frame = 100` per frame. Rays laid out around the car follow it, distances are measured from where the car is when a ray is cast, hits reach the lane as they are found, and results are published only when the sweep is complete. A sweep is restarted after a route change, a jump > 20 m, or 1.5 s. `avoid_all_objects = false` keeps v5.77's one-frame sweep. Measured (simulator): max **130–136** calls in any frame at 15/30/60/18–45 FPS and in a dense scene (290 cones + parked cars); mean 54–110 per frame. | `test_passage.lua` (bounded calls, pending vs complete, teleport invalidation) |
| 5 | **Dialog helper:** an unrelated list with one blank row was answered as `tuscia`; a real check with the blank row LAST was missed (trimming removed it). | `arbotas_auto.lua` 1.7: only a truly empty trailing line is trimmed. A list must start with the check's own instruction (`ArbotasSignature`) and the target row must be below it. Otherwise nothing is pressed and the player is told. The full dialog text is re-read before every key; foreground and revalidation guards kept. | `test_dialog_companion.lua` (6 of 11 fail on 1.6), `test_dialog_events.lua` |
| 6 | **Routes:** `1e999`, NaN speed, junk heights, unknown drive modes and huge coordinates were accepted or silently defaulted; malformed lines were dropped. `saveRoute` deleted the old `.bak` first and, if a rename failed, deleted the live route after an unchecked copy. | `lib/dangis_route_io.lua`: strict parser (6/5/3-field formats kept, finite and in-range values, known drive modes, `#end N` marker against truncation). Checked save: write, flush and close checked, read-back; verified `.bak` before the old file is replaced; restore on failure. Load falls back to a complete `.tmp`, then `.bak`, with reasons. The recorder skips nan samples; playback validates a route in memory. Settings save: the same checked steps; a failed replace now writes the previous INI back (it could leave no INI before); load falls back to `.bak`. | `test_route_storage.lua` (27), `test_panel.lua` (save failure, rename refused, `.bak` fallback) |
| 7 | **Tests and package:** the runner covered 12 of 19 test files and hid upvalue-check failures (`… \| tail -1`). 6 of 7 omitted tests failed. READMEs contradicted each other (5.72 README; "no INI included" next to an INI). | New `development/run_tests.sh`: every test on texlua and LuaJIT, no stop at first failure, exit 1 on any failure, compile and limits check, missing interpreter. Omitted tests repaired where obsolete (details in `development/TESTS.md`); `test_routes.lua` and `audit_object_detection.lua` archived with reasons. Package split into `moonloader/` (code only), `defaults/`, `tools/`, `development/`. One guide: `INSTALL.md`. | `test_package.lua`; runner verified to fail on an injected test failure, a 70-upvalue function and a missing interpreter |

Also fixed while testing:
* LuaJIT: three tests used two-argument `math.atan` (LuaJIT ignores the
  second argument); `test_driving.lua` silently aborted under LuaJIT, also with
  5.77.5.
* Simulator `thisScript()` returned a new table each call, so
  `onScriptTerminate` never ran in simulated unload tests.

The complete code change (runtime files only) is
`development/changes_5_77_5_to_5_77_6.patch` (`git apply`-able against 5.77.5;
four libraries are unchanged, `dangis_ui.lua` gains two panel labels).

Unchanged on purpose: steering and its tuning, recorded and cruising speeds,
corner braking (still off), reverse sections, bump/freeze/rotation recovery,
chat replies, Lithuanian interface, your INI values.

Earlier versions: see `development/archive/docs/` (5.70–5.77.5 READMEs and
validation logs).
