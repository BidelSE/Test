script_name('arbotas_auto')
script_version('1.7')
require 'lib.moonloader'
local UI = require 'lib.dangis_ui'

-- Handles two /arbotas dialog types detected via direct SAMP memory reads:
--
--   "baltai"  – one row has all 3 numbers in a white-ish color ({fXfXfX}).
--               Multiple empty rows may appear as decoys – ignored.
--               The header line ("Pasirinkite eilutę su visais 3 baltais
--               skaičiais") also uses white-ish codes, so the white check
--               REQUIRES the row text to match "N N N" before accepting it.
--
--   "tuscia"  – exactly one row is blank (space that stripColor trims to "").
--               Only reached when no white-numbers row exists.
--
-- No samp.* API used anywhere.
--
-- 1.7 (Dangis VR 5.77.6): a list is only answered when its first row is the
-- check's own instruction (ArbotasSignature below), so an unrelated list that
-- happens to contain one blank row (a shop, a menu) is never acted on; only a
-- true trailing newline is trimmed, so a blank row that is the LAST row is
-- still found; and the exact dialog text is re-read before every key press.
-- If the server changes its wording the helper stays idle and says so.

-- Lower-case Lua patterns matched against the first row with colour codes
-- removed. Letters with diacritics are read as "?" (e.g. "tu??i?").
ArbotasSignature = {
    header = "pasirink",
    baltai = {"balt"},
    tuscia = {"tu[s%?]+[c%?]*i"},
}

local samp = 0
local DialogEvents = {serial = 0, file = getWorkingDirectory() .. "/dangis_admin_dialog.event"}

local ffi = require("ffi")
pcall(ffi.cdef, "int IsBadReadPtr(const void* lp, unsigned int ucb);")
local _k32 = ffi.load("kernel32")

local function _ok(addr, n)
    if not addr or addr < 0x10000 or addr > 0x7FFFFFFF then return false end
    return _k32.IsBadReadPtr(ffi.cast("void*", addr), n or 1) == 0
end

local function rByte(addr)
    if not _ok(addr, 1) then return nil end
    return tonumber(ffi.cast("uint8_t*", addr)[0])
end

local function rWord(addr)
    if not _ok(addr, 2) then return nil end
    return tonumber(ffi.cast("uint16_t*", addr)[0])
end

local function rDword(addr)
    if not _ok(addr, 4) then return nil end
    return tonumber(ffi.cast("uint32_t*", addr)[0])
end

local function rStr(addr, maxLen)
    if not _ok(addr, 1) then return nil end
    local s      = ""
    local limit  = (maxLen or 128) - 1
    local okPage = math.floor(addr / 4096)
    for i = 0, limit do
        local cur  = addr + i
        local page = math.floor(cur / 4096)
        if page ~= okPage then
            if not _ok(cur, 1) then break end
            okPage = page
        end
        local b = ffi.cast("uint8_t*", cur)[0]
        if b == 0 then break end
        if b == 0x0A then
            s = s .. "\n"
        elseif b >= 32 and b <= 126 then
            s = s .. string.char(b)
        elseif b > 126 then
            s = s .. "?"
        end
    end
    return #s >= 1 and s or nil
end

local function stripColor(s)
    return (s:gsub("{%x%x%x%x%x%x}", ""):match("^%s*(.-)%s*$"))
end

-- True when rawLine has 3+ color codes where R1, G1, B1 are all 'f'/'F'.
-- Catches white/near-white shades: {FFFFFF}, {F5F5F5}, {FAFAFA}, etc.
local function whiteCodeCount(rawLine)
    local count = 0
    for code in rawLine:gmatch("{(%x%x%x%x%x%x)}") do
        if code:sub(1,1):lower() == 'f'
        and code:sub(3,3):lower() == 'f'
        and code:sub(5,5):lower() == 'f' then
            count = count + 1
        end
    end
    return count
end

-- Strict guard: the row must read as exactly three whitespace-separated
-- numbers, otherwise the header line ("...3 baltais skaičiais") would match
-- because it also uses white color codes.
local function looksLikeThreeNumbers(s)
    return s:match("^%s*%d+%s+%d+%s+%d+%s*$") ~= nil
end

-- Returns dialogId, targetIdx (0-based), kind ("baltai"|"tuscia"); or nil.
local function scanArbotasDialog()
    if samp == 0 then return nil end
    local dPtr = rDword(samp + 0x21A0B8)
    if not dPtr or dPtr < 0x01000000 or dPtr > 0x7FFFFFFF then return nil end
    if rDword(dPtr + 0x28) ~= 1 then return nil end
    if rByte(dPtr + 0x05) ~= 2 then return nil end

    local dialogId = rWord(dPtr + 0x04)
    local p34      = rDword(dPtr + 0x34)
    if not p34 or p34 < 0x01000000 or p34 > 0x7FFFFFFF then return nil end

    local blob = rStr(p34, 4096)
    if not blob then return nil end

    local rawLines = {}
    local stripped = {}
    for line in (blob .. "\n"):gmatch("([^\n]*)\n") do
        table.insert(rawLines, line)
        table.insert(stripped, stripColor(line))
    end
    -- Only a truly empty last line is the artifact of a final newline. A row
    -- holding a space or a colour code is a real (blank-looking) row.
    while #rawLines > 0 and rawLines[#rawLines] == "" do
        table.remove(rawLines)
        table.remove(stripped)
    end

    if #rawLines < 5 or #rawLines > 20 then return nil end

    local header = stripped[1]:lower()
    local function headerSays(patterns)
        for _, pattern in ipairs(patterns) do
            if header:find(pattern) then return true end
        end
        return false
    end
    local isCheck = header:find(ArbotasSignature.header, 1, true) ~= nil

    -- "baltai" check first. The row must (a) carry 3+ white-ish color codes
    -- AND (b) read as "N N N" – this skips the header row that also uses
    -- white codes around its non-numeric text.
    for i, rawLine in ipairs(rawLines) do
        if i > 1 and whiteCodeCount(rawLine) >= 3 and looksLikeThreeNumbers(stripped[i]) then
            if isCheck and headerSays(ArbotasSignature.baltai) then return dialogId, i - 1, "baltai", blob end
            return nil, "unrecognized", "baltai"
        end
    end

    -- "tuscia" check: exactly one blank row, no white-numbers row present.
    local emptyIdx, emptyCount = nil, 0
    for i, s in ipairs(stripped) do
        if s == "" then
            emptyCount = emptyCount + 1
            emptyIdx   = i - 1
        end
    end
    if emptyCount == 1 and emptyIdx > 0 then
        if isCheck and headerSays(ArbotasSignature.tuscia) then return dialogId, emptyIdx, "tuscia", blob end
        return nil, "unrecognized", "tuscia"
    end

    return nil
end

-- A completion event is emitted only after our submitted recognized dialog
-- closes. An ordinary dialog close or an interrupted navigation emits nothing.
function DialogEvents.isDialogClosed()
    local pointer = rDword(samp + 0x21A0B8)
    if not pointer or pointer < 0x01000000 or pointer > 0x7FFFFFFF then return false end
    return rDword(pointer + 0x28) == 0
end

function DialogEvents.poll(job, now)
    if not job or not job.done then return job end
    if job.emitted or not job.submitted or now - job.startedAt > 20 then return nil end
    if not DialogEvents.isDialogClosed() then return job end
    job.emitted = true
    DialogEvents.serial = DialogEvents.serial + 1
    local file = io.open(DialogEvents.file, "w")
    if file then
        file:write(string.format("%d:%.3f:%d\n%.3f\n", job.dialogId, now, DialogEvents.serial, now))
        file:close()
    end
    return nil
end

local function navigateAndClick(targetIdx, dialogId, kind, fingerprint)
    pcall(ffi.cdef, "void keybd_event(unsigned char, unsigned char, unsigned long, unsigned long*);")
    pcall(ffi.cdef, "void* GetForegroundWindow(void);")
    pcall(ffi.cdef, "unsigned long GetWindowThreadProcessId(void*, unsigned long*);")
    pcall(ffi.cdef, "unsigned long GetCurrentProcessId(void);")
    local u32ok, u32 = pcall(ffi.load, "user32")
    if not u32ok then UI.notify("~r~Patikrinimas: nepavyko pasiekti klaviatūros.", 3000); return nil end
    local job={done=false, submitted=false, dialogId=dialogId, startedAt=os.clock()}
    local function safeToNavigate()
        local hwnd=u32.GetForegroundWindow()
        if hwnd==nil then return false end
        local pid=ffi.new("unsigned long[1]")
        u32.GetWindowThreadProcessId(hwnd,pid)
        if tonumber(pid[0])~=tonumber(_k32.GetCurrentProcessId()) then return false end
        local id, index, currentKind, text=scanArbotasDialog()
        return id==dialogId and index==targetIdx and currentKind==kind and text==fingerprint
    end
    lua_thread.create(function()
        wait(math.random(300, 600))
        for i = 1, targetIdx do
            if not safeToNavigate() then job.done=true; return end
            u32.keybd_event(0x28, 0x50, 0x01, nil)
            u32.keybd_event(0x28, 0x50, 0x03, nil)
            wait(math.random(65, 130))
        end
        wait(math.random(200, 450))
        if not safeToNavigate() then job.done=true; return end
        u32.keybd_event(0x0D, 0, 0, nil)
        u32.keybd_event(0x0D, 0, 2, nil)
        job.submitted,job.done=true,true
    end)
    return job
end

function main()
    wait(3000)
    samp = getModuleHandle("samp.dll")
    if samp == 0 then
        UI.notify("~r~Patikrinimas: nerastas samp.dll.", 3000)
        return
    end
    UI.notify("~g~Patikrinimų pagalbininkas paruoštas.", 2000)

    local lastAnsweredId = -1
    local dialogWasOpen  = false
    local pending        = false
    local pendingId      = -1
    local pendingIdx     = -1
    local pendingKind    = ""
    local pendingAt      = 0
    local pendingText    = nil
    local warnedText     = nil
    local responseJob = nil

    while true do
        wait(0)
        local now = os.clock()
        responseJob = DialogEvents.poll(responseJob, now)

        local dialogId, targetIdx, kind, text = scanArbotasDialog()
        local dialogOpen = dialogId ~= nil
        if dialogId == nil and targetIdx == "unrecognized" then
            -- Looks like a check but the first row is not the known wording.
            if warnedText ~= kind then
                warnedText = kind
                UI.notify("~y~Patikrinimas neatpažintas (kitokia antraštė) - atsakykite patys.", 5000)
            end
        else
            warnedText = nil
        end

        if not dialogOpen and dialogWasOpen then
            lastAnsweredId = -1
            if pending then
                pending = false
                UI.notify("~y~Patikrinimo langas uždarytas. Veiksmas praleistas.", 2000)
            end
        end
        dialogWasOpen = dialogOpen

        if pending and now >= pendingAt then
            pending = false
            if dialogId == pendingId and targetIdx == pendingIdx and text == pendingText then
                lastAnsweredId = pendingId
                responseJob = navigateAndClick(pendingIdx, pendingId, pendingKind, pendingText)
                UI.notify(string.format(
                    "~g~Patikrinimas: pasirenkama eilutė [%d]...", pendingIdx, pendingKind), 4000)
            else
                UI.notify("~y~Patikrinimo langas uždarytas. Veiksmas praleistas.", 2000)
            end
        end

        if not pending and dialogOpen and dialogId ~= lastAnsweredId then
            pending     = true
            pendingId   = dialogId
            pendingIdx  = targetIdx
            pendingKind = kind
            pendingText = text
            local delay = math.random(2000, 5500) / 1000.0
            pendingAt   = now + delay
            UI.notify(string.format(
                "~y~Patikrinimas aptiktas. Atsakymas po %.1f s. Eilutė [%d].",
                delay, targetIdx), 6000)
        end
    end
end
