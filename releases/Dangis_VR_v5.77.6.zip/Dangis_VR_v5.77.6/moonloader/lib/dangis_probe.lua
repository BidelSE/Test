-- Dangis VR 5.78 budgeted collision probes for rotation recovery. No game APIs:
-- the main script injects the line-of-sight and ground tests.
--
-- A probe is an ordered list of checks built from the car's pose: a line
-- {ax,ay,az,bx,by,bz} or a ground test {x,y,z,g=true}. Its result is
--   true          every check ran and reported clear
--   false         a check reported an obstacle, or the query failed/was unknown
--   P.PENDING     not finished yet (the frame budget ran out)
-- PENDING is never "clear". Checks resume next frame, so an expensive probe is
-- spread over several frames instead of stalling one.
--
-- Results are kept per slot and reused while the car stays within the slot's
-- tolerance of the pose the probe was built from and the result is young
-- enough; a refresh starts in the background at half the allowed age.
--
--   P.new{ray=fn, ground=fn, clock=fn, budget=n}
--   p:beginFrame(budget)                   once per game frame
--   p:request(key, pose, tol, build[, sig[, cover]]) -> true | false | P.PENDING
--       (no sig: the build function itself identifies the check)
--       pose = {x=,y=,h=}, tol = {dist=, angle=, age=}, build() -> checks
--       sig: the geometry the checks stand for (side, circle, plan
--       generation...); a slot built for another sig is discarded, never
--       reused for a different shape. cover: how far the checks reach
--       (distance or angle); an answer (or a running check) reaching at
--       least as far is reused, a request reaching further starts anew.
--   p:reset()                              forget everything (new incident)
--   p.stats = {rays=, frameRays=, maxFrameRays=, jobs=}
--   p:why(key)                             "obstacle" | "ground" | nil for the last blocked result
local P = {}
P.__index = P
P.PENDING = "pending"

local function angleDiff(a, b) return math.abs((a-b+180)%360-180) end

-- opts.maxCalls: the most line-of-sight calls one check may use (re-casts).
-- A check is only started when that many are left in the frame (or the frame
-- has not used any yet), so the frame budget is a hard cap. A callback that
-- reports more than that raises it for every later check.
function P.new(opts)
    return setmetatable({ray=opts.ray, ground=opts.ground, clock=opts.clock, budget=opts.budget or 40, hit=opts.hit,
        maxCost=opts.maxCalls or 1,
        used=0, frame=0, slots={}, stats={rays=0, frameRays=0, maxFrameRays=0, jobs=0}}, P)
end

function P:beginFrame(budget)
    if budget then self.budget = budget end
    self.stats.maxFrameRays = math.max(self.stats.maxFrameRays, self.used)
    self.stats.frameRays = 0
    self.used = 0
    self.frame = self.frame + 1
    -- Slots nobody asked for during the last ~30 frames are dropped together
    -- with any unfinished work, so stale checks never consume budget.
    for key, slot in pairs(self.slots) do
        if self.frame-(slot.asked or 0) > 30 then self.slots[key] = nil end
    end
end

function P:reset()
    self.slots = {}
end

function P:why(key)
    local slot = self.slots[key]
    return slot and slot.result == false and slot.why or nil
end

local function fits(slot, pose, tol, now)
    if slot.result == nil or not slot.pose then return false end
    local dx, dy = slot.pose.x-pose.x, slot.pose.y-pose.y
    return dx*dx+dy*dy <= tol.dist*tol.dist and angleDiff(slot.pose.h, pose.h) <= tol.angle
        and now-slot.at <= tol.age
end

-- Ground samples carry the terrain along a probe: the first ({start=true})
-- is taken under the car, every later one must stay within a drivable step of
-- the previous sample (kerb + slope over the distance between them), and
-- terrain-relative rays ({rel=true}) run at a height above the ground sampled
-- at both of their ends. The ground callback returns ok[, height[, cost]];
-- without a height (ground checks disabled) rel rays use their fallback
-- absolute heights fa/fb. ray(ax,ay,az,bx,by,bz,allowance) returns ok[, cost]:
-- cost = line-of-sight calls used (re-casts past the player's own car or a
-- road surface count too); ok "more" = the allowance ran out (the check is
-- repeated next frame). A check never uses more than the frame has left.
P.MAX_STEP, P.MAX_GRADE = 0.2, 0.25
function P:run(slot)
    local job = slot.job
    local checks = job.checks
    while job.i <= #checks do
        local remaining = self.budget-self.used
        if remaining <= 0 or (self.used > 0 and remaining < self.maxCost) then return end
        local c = checks[job.i]
        local ok, cost
        if c.g then
            local height
            ok, height, cost = self.ground(c[1], c[2], (not c.start and job.gz) or c[3])
            if ok == true and type(height) == "number" then
                if not c.start and job.gz then
                    local d = math.sqrt((c[1]-job.gx)^2+(c[2]-job.gy)^2)
                    if math.abs(height-job.gz) > P.MAX_STEP+P.MAX_GRADE*d then ok = false end
                end
                job.gPrev = c.start and height or (job.gz or height)
                job.gz, job.gx, job.gy = height, c[1], c[2]
            end
        elseif c.rel then
            local base = c.here and job.gz or job.gPrev
            local za = base and base+c[3] or c.fa
            local zb = job.gz and job.gz+c[6] or c.fb
            ok, cost = self.ray(c[1], c[2], za, c[4], c[5], zb, remaining)
        else
            ok, cost = self.ray(c[1], c[2], c[3], c[4], c[5], c[6], remaining)
        end
        -- Every line-of-sight call counts, including re-casts inside a check.
        cost = (type(cost) == "number" and cost >= 1) and cost or 1
        if cost > self.maxCost then self.maxCost = cost end
        self.used = self.used+cost
        self.stats.rays = self.stats.rays+cost
        self.stats.frameRays = self.stats.frameRays+cost
        if ok == "more" then
            -- This check needs more calls than the frame has left: it is
            -- repeated from its start next frame. If even a whole frame's
            -- budget is not enough, its answer is unknown (blocked).
            if remaining < self.budget then return end
            ok = nil
        end
        if ok ~= true then
            -- Obstacle, failed query or unknown answer: blocked, never clear.
            slot.result, slot.at, slot.pose, slot.job = false, self.clock(), job.pose, nil
            slot.resultCover = job.cover
            slot.why = c.g and "ground" or "obstacle"
            -- Where it failed (for the log): the check's points and, for a
            -- line, what the game reported it hit.
            slot.whyCheck = {kind=c.g and (ok == false and "step or slope" or "no ground") or "line",
                ax=c[1], ay=c[2], bx=c[4], by=c[5], hit=(not c.g and self.hit) and self.hit() or nil}
            return
        end
        job.i = job.i+1
    end
    slot.result, slot.at, slot.pose, slot.job, slot.why = true, self.clock(), job.pose, nil, nil
    slot.resultCover = job.cover
end

function P:request(key, pose, tol, build, sig, cover)
    local now = self.clock()
    -- Without a signature the builder itself is the identity: a different
    -- check is never answered from another one's result.
    if sig == nil then sig = build end
    local slot = self.slots[key]
    if not slot or slot.sig ~= sig then
        slot = {sig=sig}
        self.slots[key] = slot
    end
    -- An answer (or a running check) is used only if it reaches at least as
    -- far as this request needs.
    local function covers(c) return cover == nil or (c ~= nil and c >= cover-1e-6) end
    if slot.result ~= nil and not covers(slot.resultCover) then slot.result, slot.pose = nil, nil end
    if slot.job and not covers(slot.job.cover) then slot.job = nil end
    slot.asked = self.frame
    local fresh = fits(slot, pose, tol, now)
    -- Refresh early (a quarter of the distance, half the age), so a rolling
    -- car normally has a valid answer while the next one is computed.
    local moved = slot.pose and math.sqrt((slot.pose.x-pose.x)^2+(slot.pose.y-pose.y)^2) or math.huge
    local refresh = not fresh or now-slot.at > tol.age*0.5 or moved > tol.dist*0.25
    if slot.job and not fresh then
        -- The running job was built for a pose the car has left: restart it.
        local jp = slot.job.pose
        local dx, dy = jp.x-pose.x, jp.y-pose.y
        if dx*dx+dy*dy > tol.dist*tol.dist or angleDiff(jp.h, pose.h) > tol.angle then slot.job = nil end
    end
    if not slot.job and refresh then
        slot.job = {checks=build(), i=1, pose={x=pose.x, y=pose.y, h=pose.h}, cover=cover}
        self.stats.jobs = self.stats.jobs+1
    end
    if slot.job then self:run(slot) end
    if fits(slot, pose, tol, now) then return slot.result end
    return P.PENDING
end

-- ---------------------------------------------------------------------------
-- Check builders (pure geometry). Headings follow GTA: 0 = north, growing to
-- the left; the nose points along (-sin h, cos h).
local function axes(h)
    local r = math.rad(h)
    local fx, fy = -math.sin(r), math.cos(r)
    return fx, fy, -fy, fx
end
P.axes = axes

-- Swept body along a full-lock (or straight) arc, forwards or backwards:
-- corners, bumper centres and side points every half length, traced from
-- pose to pose at two heights above the ground (0.45 m and 1.0 m, so kerbs
-- and road camber are not obstacles but bumpers, barriers and cars are),
-- with the ground sampled under every pose first. Steps are at most 1.5 m
-- (15 degrees of the circle).
-- leading=true (rolling re-checks inside a move whose whole body sweep was
-- already checked when it started): only the leading half of the body, which
-- is where anything new is met; the trailing half follows inside that path.
local LEAD_FORWARD, LEAD_BACKWARD = {1, 3, 4, 5, 6, 7, 8}, {2, 11, 12, 9, 10, 7, 8}
local ALL_FORWARD, ALL_BACKWARD = {1, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 2}, {2, 11, 12, 9, 10, 7, 8, 5, 6, 3, 4, 1}
P.HEIGHTS = {0.45, 1.0}
P.CENTRE = 0.6 -- fallback: car centre height above the ground
function P.arc(pose, z, profile, steer, distance, backwards, radius, leading)
    local checks = {{pose.x, pose.y, z, g=true, start=true}}
    local hl, hw = profile.half_length+0.3, profile.half_width+0.4
    local function points(cx, cy, hh)
        local fx, fy, lx, ly = axes(hh)
        local list = {{cx+fx*hl, cy+fy*hl}, {cx-fx*hl, cy-fy*hl}}
        for _, along in ipairs({hl, hl*0.5, 0, -hl*0.5, -hl}) do
            list[#list+1] = {cx+fx*along+lx*hw, cy+fy*along+ly*hw}
            list[#list+1] = {cx+fx*along-lx*hw, cy+fy*along-ly*hw}
        end
        return list
    end
    local px, py, ph = pose.x, pose.y, pose.h
    local previous = points(px, py, ph)
    for _, step in ipairs(P.arcSteps(pose, steer, distance, backwards, radius)) do
        px, py, ph = step.x, step.y, step.h
        local current = points(px, py, ph)
        checks[#checks+1] = {px, py, z, g=true}
        -- Leading points first: an obstacle is usually met by the front (or
        -- the rear when reversing), so a blocked arc is rejected early.
        local order = leading and (backwards and LEAD_BACKWARD or LEAD_FORWARD) or (backwards and ALL_BACKWARD or ALL_FORWARD)
        for _, i in ipairs(order) do
            for _, height in ipairs(P.HEIGHTS) do
                local fallback = z-P.CENTRE+height
                checks[#checks+1] = {previous[i][1], previous[i][2], height, current[i][1], current[i][2], height,
                    rel=true, fa=fallback, fb=fallback}
            end
        end
        previous = current
    end
    return checks
end

-- Poses along a full-lock (or straight) arc in steps of at most 1.5 m
-- (15 degrees of the circle). P.arc checks the body between consecutive
-- poses and P.arcEnd is the last one, so a planned endpoint is exactly where
-- the checked path ends.
function P.arcSteps(pose, steer, distance, backwards, radius)
    local turnSign = (steer > 0 and -1 or (steer < 0 and 1 or 0))*(backwards and -1 or 1)
    local stepLength = math.min(1.5, radius*math.rad(15))
    local px, py, ph = pose.x, pose.y, pose.h
    local travelled = 0
    local sign = backwards and -1 or 1
    local steps = {}
    while travelled < distance-0.001 do
        local d = math.min(stepLength, distance-travelled)
        local dh = turnSign*math.deg(d/radius)
        local mid = math.rad(ph+dh/2)
        px, py = px-math.sin(mid)*d*sign, py+math.cos(mid)*d*sign
        ph = ph+dh
        travelled = travelled+d
        steps[#steps+1] = {x=px, y=py, h=ph}
    end
    return steps
end

function P.arcEnd(pose, steer, distance, backwards, radius)
    local steps = P.arcSteps(pose, steer, distance, backwards, radius)
    local last = steps[#steps]
    if not last then return {x=pose.x, y=pose.y, h=pose.h} end
    return {x=last.x, y=last.y, h=last.h}
end

-- Reverse-then-swing (three-point turn): reverse `meters` with the lock
-- opposite to `side` (both circles), then the forward sweep with `side` from
-- where the reverse ends, covering what is left of `degrees`. The reverse
-- is assumed to turn along the wide circle (the least turning), so the
-- forward sweep is checked for the larger remainder.
-- Both parts are slow manoeuvres, so they use the manoeuvre circles.
function P.threePoint(pose, z, profile, side, degrees, meters)
    local tight, wide = P.legRadii(profile)
    local list = P.arcBoth(pose, z, profile, -side, meters+0.5, true, nil, wide)
    -- The reverse ends somewhere between its tight and its wide circle: the
    -- forward sweep is checked from both ends (for what is left of the turn
    -- from each), so it covers the whole envelope.
    for _, radius in ipairs({wide, tight}) do
        local stop = P.arcEnd(pose, -side, meters, true, radius)
        local remaining = math.max(30, degrees-math.deg(meters/radius))
        for _, c in ipairs(P.uturn(stop, z, profile, side, remaining, false, true)) do list[#list+1] = c end
    end
    return list
end

-- Corridor behind the car where a car sliding backwards spins round: from
-- the half diagonal (+0.3 m) on one side to that plus `drift` on the other
-- (drift > 0: towards the car's left, < 0: right), `distance` metres back
-- plus the half diagonal. Lines along it and across it (walls running
-- alongside would slip between lines along it), terrain-relative.
function P.spinCorridor(pose, z, profile, distance, drift, step)
    drift = drift or 0
    local checks = {{pose.x, pose.y, z, g=true, start=true}}
    local fx, fy, lx, ly = axes(pose.h)
    local rd = math.sqrt(profile.half_length^2+profile.half_width^2)+0.3
    local lo, hi = -rd+math.min(0, drift), rd+math.max(0, drift)
    local total = distance+rd
    -- Cross lines every `step` metres (default 1.5). Lines along the
    -- corridor stay continuous whatever the step.
    local n = math.max(1, math.ceil(total/(step or 1.5)))
    local offsets = {}
    local m = math.max(2, math.ceil((hi-lo)/1.5))
    for i = 0, m do offsets[#offsets+1] = lo+(hi-lo)*i/m end
    local prev = 0
    for i = 1, n do
        local back = total*i/n
        local cx, cy = pose.x-fx*back, pose.y-fy*back
        checks[#checks+1] = {cx, cy, z, g=true}
        for _, height in ipairs(P.HEIGHTS) do
            local fallback = z-P.CENTRE+height
            checks[#checks+1] = {cx+lx*lo, cy+ly*lo, height, cx+lx*hi, cy+ly*hi, height, rel=true, fa=fallback, fb=fallback, here=true}
        end
        for _, o in ipairs(offsets) do
            local ax, ay = pose.x-fx*prev+lx*o, pose.y-fy*prev+ly*o
            local bx, by = cx+lx*o, cy+ly*o
            for _, height in ipairs(P.HEIGHTS) do
                local fallback = z-P.CENTRE+height
                checks[#checks+1] = {ax, ay, height, bx, by, height, rel=true, fa=fallback, fb=fallback}
            end
        end
        prev = back
    end
    return checks
end

-- Reverse spin (J-turn) to `side` (+-128, the way the nose should turn):
-- S with the opposite lock until the car is `switch` degrees from the
-- route direction, then W with the `side` lock for the rest.
-- Slow (backSpeed < 8 m/s): the car follows its circles, so this is the
-- reverse-then-swing path (reverse arc, then the forward sweep from where
-- it ends). Fast: the car slides on along the road while it spins, drifting
-- towards the lock side, so the slide corridor (length ~ v^2/12, drift a
-- quarter of it, at most 8 m) is checked, plus the first 3 m of the reverse
-- arc.
function P.jturn(pose, z, profile, side, degrees, backSpeed, extra, switch, length, driftLength)
    switch = switch or 100
    local list = {}
    local function add(t) for _, c in ipairs(t) do list[#list+1] = c end end
    if backSpeed < 8 then
        local _, wide = P.legRadii(profile)
        local meters = math.max(1.0, wide*math.rad(math.max(0, degrees-switch)))
        add(P.threePoint(pose, z, profile, side, degrees, meters))
        add(P.spinCorridor(pose, z, profile, math.max(2, backSpeed*backSpeed/12)+(extra or 0), 0))
        return list
    end
    local _, wide = P.legRadii(profile)
    add(P.arcBoth(pose, z, profile, -side, 3.0, true, nil, wide))
    local d = (length or math.min(70, backSpeed*backSpeed/12+3))+(extra or 0)
    -- The lock key is -side; the car drifts towards the lock side
    -- (right lock -> right, which is -l in P.axes).
    local driftSide = (-side > 0) and -1 or 1
    -- A fast slide covers a long corridor; its cross lines are spaced with
    -- the speed (0.1 s of sliding, 1.5 to 4 m: shorter than a car), so the
    -- check finishes in a few frames while the car is still inside it.
    local step = math.max(1.5, math.min(4.0, backSpeed*0.1))
    -- Sideways drift while it spins: a quarter of the whole slide (which may
    -- be longer than the part checked here), at most 8 m.
    add(P.spinCorridor(pose, z, profile, d, driftSide*math.min(8, (driftLength or d)/4), step))
    return list
end

-- The turning circle varies by car and speed: check a tight and a wide one.
function P.radii(profile)
    return math.max(4.2, profile.half_length*1.6), math.max(6.5, profile.half_length*2.4)
end

-- Short manoeuvre moves are slow, so the car stays close to its tightest
-- circle; they are checked on the tight circle and 1.3 times it. The
-- one-sweep U-turn (faster, more tyre slip) keeps the wide circle.
function P.legRadii(profile)
    local tight = P.radii(profile)
    return tight, tight*1.3
end

function P.arcBoth(pose, z, profile, steer, distance, backwards, leading, wideRadius)
    if steer == 0 then return P.arc(pose, z, profile, 0, distance, backwards, 6.0, leading) end
    local tight, wide = P.radii(profile)
    wide = wideRadius or wide
    local list = P.arc(pose, z, profile, steer, distance, backwards, tight, leading)
    for _, c in ipairs(P.arc(pose, z, profile, steer, distance, backwards, wide, leading)) do list[#list+1] = c end
    return list
end

-- One-sweep U-turn over `degrees` (+15 margin, at most 200).
-- tightOnly: the slow version for tight spots, on the manoeuvre circles
-- (P.legRadii) instead of the faster sweep's wide circle.
function P.uturn(pose, z, profile, side, degrees, leading, tightOnly)
    local tight, wide = P.radii(profile)
    if tightOnly then tight, wide = P.legRadii(profile) end
    local a = math.rad(math.min(200, degrees+15))
    local list = P.arc(pose, z, profile, side, wide*a, false, wide, leading)
    for _, c in ipairs(P.arc(pose, z, profile, side, tight*a, false, tight, leading)) do list[#list+1] = c end
    return list
end

-- Forward corridor of 5.77's RecoverySystem.rotationCorridor, as checks.
function P.corridor(pose, z, profile)
    local checks = {{pose.x, pose.y, z, g=true, start=true}}
    local x, y = pose.x, pose.y
    local fx, fy, lx, ly = axes(pose.h)
    local halfLength, halfWidth = profile.half_length, profile.half_width+0.4
    for _, side in ipairs({-1, 0, 1}) do
        local ax, ay = x+fx*(halfLength+0.3)+lx*side*halfWidth, y+fy*(halfLength+0.3)+ly*side*halfWidth
        checks[#checks+1] = {ax, ay, z+0.4, ax+fx*3, ay+fy*3, z+0.4}
    end
    for _, side in ipairs({-1, 1}) do
        local ax, ay = x+lx*side*halfWidth, y+ly*side*halfWidth
        checks[#checks+1] = {ax-fx*halfLength, ay-fy*halfLength, z+0.4, ax+fx*(halfLength+2), ay+fy*(halfLength+2), z+0.4}
    end
    for _, side in ipairs({-1, 1}) do
        for _, height in ipairs({0.25, 0.85}) do
            local ax, ay = x+fx*halfLength+lx*side*halfWidth, y+fy*halfLength+ly*side*halfWidth
            checks[#checks+1] = {ax, ay, z+height, ax+fx*2+lx*side*2, ay+fy*2+ly*side*2, z+height}
        end
        checks[#checks+1] = {x+fx*(halfLength+2)+lx*side*2, y+fy*(halfLength+2)+ly*side*2, z, g=true}
    end
    checks[#checks+1] = {x+fx*(halfLength+3), y+fy*(halfLength+3), z, g=true}
    return checks
end

-- Short forward move (tight streets).
function P.forwardShort(pose, z, profile, distance)
    local checks = {{pose.x, pose.y, z, g=true, start=true}}
    local fx, fy, lx, ly = axes(pose.h)
    local hl, hw = profile.half_length, profile.half_width+0.3
    for _, height in ipairs({0.25, 0.85}) do
        for _, offset in ipairs({-hw, 0, hw}) do
            local ax, ay = pose.x+fx*(hl-0.3)+lx*offset, pose.y+fy*(hl-0.3)+ly*offset
            checks[#checks+1] = {ax, ay, z+height, ax+fx*(distance+0.6), ay+fy*(distance+0.6), z+height}
        end
        for _, side in ipairs({-1, 1}) do
            local ax, ay = pose.x+fx*(hl-0.3)+lx*side*hw, pose.y+fy*(hl-0.3)+ly*side*hw
            checks[#checks+1] = {ax, ay, z+height, ax+fx*distance+lx*side*0.8, ay+fy*distance+ly*side*0.8, z+height}
        end
    end
    checks[#checks+1] = {pose.x+fx*(hl+distance), pose.y+fy*(hl+distance), z, g=true}
    return checks
end

-- Straight reverse: only the space behind the rear bumper and the ground.
function P.straightBack(pose, z, profile, distance)
    local checks = {{pose.x, pose.y, z, g=true, start=true}}
    local fx, fy, lx, ly = axes(pose.h)
    local hl, hw = profile.half_length, profile.half_width+0.3
    for _, height in ipairs({0.25, 0.85}) do
        for _, offset in ipairs({-hw, 0, hw}) do
            local ax, ay = pose.x-fx*(hl-0.3)+lx*offset, pose.y-fy*(hl-0.3)+ly*offset
            checks[#checks+1] = {ax, ay, z+height, ax-fx*(distance+0.6), ay-fy*(distance+0.6), z+height}
        end
    end
    for _, fraction in ipairs({0.5, 1}) do
        checks[#checks+1] = {pose.x-fx*(hl+distance*fraction), pose.y-fy*(hl+distance*fraction), z, g=true}
    end
    return checks
end

return P
