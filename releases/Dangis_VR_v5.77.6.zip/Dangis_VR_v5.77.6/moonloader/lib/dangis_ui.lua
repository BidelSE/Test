-- Shared Lithuanian presentation layer. No driving state or input writes.
local UI={fonts={},notices={},colors={bg=0xF2181918,panel=0xF2181918,muted=0xFFA5A59F,text=0xFFE9E8E3,accent=0xFFC1CBB4,edge=0xFF363834,hover=0xFF2C2E2A},ascii=false}
UI.labels={
 ["controls.nitro_enabled"]="Periodinis nitro",
 ["controls.nitro_interval_seconds"]="Nitro intervalas (s)",
 ["controls.nitro_variation_seconds"]="Nitro intervalo nuokrypis (±s)",
 ["controls.look_enabled"]="Žvalgymasis Q / E",
 ["controls.look_interval_seconds"]="Žvalgymosi intervalas (s)",
 ["driving.steering_point_stride"]="Vairavimo taškų žingsnis",
 ["driving.low_fps_tolerance"]="Prisitaikymas prie mažo FPS",
 ["driving.avoid_all_objects"]="Apvažiuoti visus objektus kelyje",
 ["driving.passage_check"]="Tikrinti kelią (sienos, užtvaros)",
 ["driving.scan_rays_per_frame"]="Kliūčių spindulių per kadrą",
 ["driving.waypoint_radius"]="Taško pasiekimo spindulys",
 ["driving.lateral_tolerance"]="Šoninio nuokrypio tolerancija",
 ["driving.corner_braking"]="Stabdymas posūkiuose",
 ["driving.enabled"]="Greičio planavimas",
 ["driving.lateral_acceleration"]="Šoninis pagreitis",
 ["driving.braking_deceleration"]="Stabdymo pagreitis",
 ["driving.reaction_seconds"]="Reakcijos laikas",
 ["driving.lookahead_seconds"]="Žvilgsnis į priekį",
 ["driving.max_speed_kmh"]="Didžiausias greitis",
 ["controls.input"]="Valdymo būdas",
 ["controls.steering"]="Vairavimo režimas",
 ["chat.enabled"]="Automatinės žinutės",
 ["chat.contextual"]="Frazės pagal situaciją",
 ["chat.rotation_sequence_replies"]="Žinutė po apsukimų serijos",
 ["chat.rotation_min_turns"]="Mažiausiai apsukimų žinutei",
 ["chat.rotation_quiet_seconds"]="Laukimas baigus apsukimus",
 ["chat.rotation_reply_cooldown_seconds"]="Tarpas tarp apsukimų žinučių",
 ["chat.reply_chance"]="Atsakymo tikimybė",
 ["chat.between_messages_seconds"]="Tarpas tarp žinučių",
 ["chat.delay_min_seconds"]="Trumpiausia atsakymo delsa",
 ["chat.delay_max_seconds"]="Ilgiausia atsakymo delsa",
 ["chat.quit_enabled"]="Leisti atsijungimą (/q)",
 ["chat.include_local_tests"]="Reaguoti į vietinius testus",
 ["chat.include_inferred_tests"]="Reaguoti į numanomus testus",
 ["chat.general_phrases"]="Bendros frazės",
 ["chat.repeat_phrases"]="Pakartotinių patikrinimų frazės",
 ["chat.recent_join_phrases"]="Neseniai prisijungusio frazės",
 ["chat.frequent_phrases"]="Dažnų patikrinimų frazės",
 ["chat.historical_phrases"]="Ankstesnių patikrinimų frazės",
 ["chat.waiting_phrases"]="Laukimo frazės",
 ["chat.recent_join_seconds"]="Naujo prisijungimo laikotarpis",
 ["recovery.escape_checks"]="Laisvo kelio tikrinimas",
 ["recovery.probe_distance"]="Tikrinimo atstumas",
 ["recovery.reverse_max_speed"]="Didžiausias atbulinis greitis",
 ["recovery.refresh_after_arbotas"]="/refresh po kiekvieno /arbotas",
 ["recovery.refresh_in_freeze_test"]="/refresh vietiniame teste",
 ["recovery.require_ground"]="Tikrinti kelio dangą",
 ["recovery.attempt_limit"]="Bandymų skaičius",
 ["diagnostics.enabled"]="Rodyti būsenos skydelį",
 ["diagnostics.x"]="Skydelio vieta horizontaliai",
 ["diagnostics.y"]="Skydelio vieta vertikaliai",
 ["vehicles.default_profile"]="Numatytasis automobilio profilis",
 ["rotation.first_fight_seconds"]="Pirmo apsukimo W reakcija",
 ["rotation.repeat_fight_seconds"]="Pakartotinio apsukimo W iš viso",
 ["rotation.multi_resist_seconds"]="Trumpas pasipriešinimas (3+)",
 ["rotation.incident_window_seconds"]="Apsukimų grupavimo langas",
 ["rotation.multi_turns"]="Apsukimai sustojimui",
 ["rotation.stabilize_seconds"]="Stabilizavimo laikas",
 ["rotation.park_enabled"]="Sustoti kelkraštyje (3+)",
 ["rotation.park_quiet_seconds"]="Ramybės laukimas sustojus",
 ["rotation.retry_wait_max_seconds"]="Ilgiausias laukimas prieš kartojant",
 ["rotation.connect_distance"]="Maršruto pasiekimo atstumas",
 ["rotation.search_distance"]="Maršrutų paieškos atstumas",
 ["rotation.route_switching"]="Leisti pereiti į kitą maršrutą",
 ["rotation.switch_penalty"]="Perėjimo į kitą maršrutą kaina",
 ["rotation.chat_enabled"]="Žinutės po apsukimo",
 ["rotation.chat_cooldown_seconds"]="Tarpas tarp apsukimų žinučių",
 ["rotation.second_message_chance"]="Antros žinutės tikimybė",
 ["rotation.reverse_power"]="Atbulinės galia apsisukant",
 ["rotation.forward_power"]="Grįžimo į maršrutą galia",
 ["rotation.uturn_enabled"]="Apsisukti vienu posūkiu, jei telpa",
 ["rotation.reverse_spin_enabled"]="Apsisukti atbuline eiga (be W)",
 ["rotation.probe_rays_per_frame"]="Kliūčių patikrų per kadrą",
}
UI.states={
 ["IDLE"]="Laukiama",
 ["ROUTE"]="Važiuojama",
 ["PLAYING"]="Važiuojama",
 ["STOPPED"]="Sustabdyta",
 ["MANUAL"]="Valdote jūs",
 ["OVERRIDE"]="Valdote jūs",
 ["PAUSE"]="Pristabdyta",
 ["PAUSED"]="Pristabdyta",
 ["CHAT"]="Rašoma žinutė",
 ["CHAT_WAIT"]="Pokalbio pauzė",
 ["DIALOG"]="Patikrinimo langas",
 ["DIALOG_WAIT"]="Laukiama lango uždarymo",
 ["FREEZE"]="Užšaldyta",
 ["FREEZE_WAIT"]="Laukiama atkūrimo",
 ["FREEZE_REFRESH"]="Siunčiama /refresh",
 ["FREEZE_RESUME"]="Tęsiamas važiavimas",
 ["BUMP"]="Išvažiavimas iš kliūties",
 ["BUMP_BACK"]="Važiuojama atbulomis",
 ["BUMP_WAIT"]="Laukiama po atsitraukimo",
 ["BUMP_DONE"]="Atsitraukimas baigtas",
 ["RECOVERY_BLOCKED"]="Reikia jūsų pagalbos",
 ["ROTATE"]="Posūkio reakcija",
 ["ROTATE_REACT"]="Išlaikoma ankstesnė vairo kryptis",
 ["ROTATE_REVERSE"]="Atsargiai važiuojama atgal",
 ["ROTATE_HOLD"]="Stabilizuojama po apsukimo",
 ["ROTATE_ALIGN"]="Lėtai grįžtama į kryptį",
 ["ROTATE_SETTLE"]="Tikrinamas stabilumas",
 ["ROTATE_BLOCKED"]="Po apsukimo reikia pagalbos",
 ["ROTATE_WAIT"]="Laukiama saugaus kelio",
 ["ROTATE_FIGHT"]="Bandoma išlaikyti kryptį",
 ["ROTATE_UTURN"]="Apsisukama vienu posūkiu",
 ["ROTATE_UTURN_CHECK"]="Tikrinama, ar telpa apsisukti",
 ["ROTATE_JTURN_CHECK"]="Tikrinama, ar telpa apsisukti atbuline eiga",
 ["ROTATE_JTURN"]="Apsisukama atbuline eiga",
 ["ROTATE_CHAT"]="Reaguojama į apsukimą",
 ["ROTATE_PLAN"]="Ieškomas pasiekiamas maršrutas",
 ["ROTATE_STOP"]="Sustojama prieš kitą manevrą",
 ["ROTATE_APPROACH"]="Grįžtama į maršrutą",
 ["ROTATE_PARK_PLAN"]="Ieškoma vietos sustoti",
 ["ROTATE_PARK"]="Sustojama kelkraštyje",
 ["ROTATE_PARKED"]="Laukiama, kol baigsis sukinėjimas",
 ["TRANSITION"]="Keičiama kryptis",
 ["R_TO_FWD"]="Jungiama priekinė eiga",
 ["REJOIN_SKIP"]="Grįžtama į maršrutą",
 ["DONE"]="Maršrutas baigtas",
 ["standard"]="Įprastas",
 ["cautious"]="Atsargus",
 ["sport"]="Sportinis",
 ["heavy"]="Sunkus",
 ["keyboard"]="Klaviatūra",
 ["gamepad"]="Žaidimo valdiklis",
 ["bangbang"]="A / D",
 ["smooth"]="Tolygus",
 ["idle"]="Laukiama",
 ["ready"]="Pasiruošta",
 ["off"]="Išjungta",
 ["defaults"]="Numatytieji",
 ["loaded"]="Įkelta",
 ["panel changes applied"]="Pritaikyta",
 ["normal_reverse"]="Trumpas atsitraukimas",
 ["extended_reverse"]="Ilgesnis atsitraukimas",
 ["reverse_blocked"]="Atbulinis kelias užblokuotas",
 ["stuck"]="Automobilis nejuda",
 ["reaction delay"]="Laukiama prieš atsakymą",
 ["typing reaction"]="Rašoma frazė",
 ["typing /q"]="Rašoma /q",
 ["quit follow-up pending"]="Laukiama atsijungimo",
 ["user input"]="Valdote jūs",
 ["player input active"]="Valdote jūs",
 ["waiting for recovery/pause"]="Laukiama po pauzės",
 ["INI missing; settings unchanged"]="Nustatymų failas nerastas",
 ["finish typing first"]="Palaukite, kol baigs rašyti",
 ["finish recovery first"]="Palaukite, kol baigs atkūrimą",
 ["pause with F6 or stop with F7 first"]="Pirmiausia F6 arba F7",
 ["moving"]="Automobilis juda",
 ["intentional_stop"]="Numatytas sustojimas",
 ["obstructed"]="Aptikta kliūtis",
}
UI.statuses={
 ["Changes apply live; Save INI makes them permanent."]="Pakeitimai taikomi iškart. Išsaugokite, kad liktų kitam kartui.",
 ["Pending: pause/stop for controls; finish active chat/recovery."]="Pakeitimas laukia. Valdymui pakeisti paspauskite F6 arba F7.",
 ["Applied live. Click Save INI to keep changes."]="Pritaikyta. Paspauskite „Išsaugoti“, kad pakeitimai išliktų.",
 ["Saved INI. Pending changes still wait for a safe moment."]="Išsaugota. Laukiantys pakeitimai bus pritaikyti vėliau.",
 ["Saved INI; previous file is dangis_vr.ini.bak."]="Išsaugota. Ankstesni nustatymai liko atsarginėje kopijoje.",
 ["Page defaults selected. Save INI to keep them."]="Atkurti šio puslapio nustatymai. Nepamirškite išsaugoti.",
 ["Closed for chat/dialog/recovery. Ctrl+I opens again."]="Langas uždarytas. Vėl atidarysite paspaudę Ctrl + I.",
}
UI.messages={
 ["Turi buti masinos viduje!"]="Pirmiausia įsėskite į automobilį.",
 ["Irasymas pradetas! Grizk i starta uzdaryt kilpa!"]="Įrašymas pradėtas. Grįžkite į pradžią, kad uždarytumėte ratą.",
 ["Per mazai tasku - kelias neissaugotas!"]="Per mažai taškų. Maršrutas neišsaugotas.",
 ["Kelias issaugotas! Tasku: "]="Maršrutas išsaugotas. Taškų: ",
 ["Nepavyko issaugoti kelio!"]="Nepavyko išsaugoti maršruto.",
 ["Kilpa uzdaryta! Issaugota: "]="Ratas uždarytas. Išsaugota: ",
 ["Vaziavimas pradetas!"]="Važiavimas pradėtas.",
 ["Kelias ikrautas ir paleistas: "]="Maršrutas įkeltas: ",
 ["Nera irasyto kelio!"]="Nėra įrašyto maršruto.",
 ["Vaziavimas sustabdytas!"]="Važiavimas sustabdytas.",
 ["Viskas sustabdyta!"]="Viskas sustabdyta.",
 ["Vaziavimas sustabdytas - islejei masina!"]="Važiavimas sustabdytas: išlipote iš automobilio.",
 ["Kilpa baigta! Kartojama!"]="Ratas baigtas. Važiuojama iš naujo.",
 ["Kelias baigtas!"]="Maršrutas baigtas.",
 ["New session marked"]="Pažymėtas naujas prisijungimas.",
 ["Settings and phrases reloaded"]="Nustatymai ir frazės įkelti iš naujo.",
 ["Kartojimas IJUNGTAS!"]="Kartojimas įjungtas.",
 ["Kartojimas ISJUNGTAS!"]="Kartojimas išjungtas.",
 ["Pristabdyta!"]="Pristabdyta.",
 ["Tesiama!"]="Važiavimas tęsiamas.",
 ["Trajektorija IJUNGTA!"]="Trajektorija rodoma.",
 ["Trajektorija ISJUNGTA!"]="Trajektorija paslėpta.",
 ["Kliuciu debug ISJUNGTAS!"]="Kliūčių diagnostika išjungta.",
 ["Kliuciu debug PILNAS!"]="Išsami kliūčių diagnostika įjungta.",
 ["Kliuciu taskai IJUNGTI!"]="Kliūčių taškai rodomi.",
 ["Escape blocked - take over; F6 to retry"]="Kelias užblokuotas. Perimkite valdymą; F6 kartoja bandymą.",
 ["Recovery limit - take over; F6 to retry"]="Pasiekta bandymų riba. Perimkite valdymą; F6 kartoja.",
 ["Reverse blocked - take over; F6 to retry"]="Kelias atgal užblokuotas. Perimkite valdymą; F6 kartoja.",
 ["Telemetry ON (F5 - stop)"]="Duomenų įrašymas įjungtas. F5 sustabdo.",
 ["Telemetry: cannot preserve previous capture"]="Nepavyko išsaugoti ankstesnio duomenų įrašo.",
 ["Telemetry: cannot open capture"]="Nepavyko atidaryti duomenų įrašo.",
 ["Settings: finish chat/dialog/recovery first"]="Palaukite, kol baigsis pokalbis, patikrinimas ar atkūrimas.",
 ["Panel unavailable: cursor API missing"]="Nustatymų langas nepasiekiamas: nėra pelės funkcijos.",
 ["Settings panel error; see debug log"]="Nustatymų lango klaida. Informacija klaidų žurnale.",
 ["Dangis VR: route has invalid points, check debug log."]="Maršrute yra netinkamų taškų. Informacija klaidų žurnale.",
}
UI.letters={["ą"]={224,"a"},["č"]={232,"c"},["ę"]={230,"e"},["ė"]={235,"e"},["į"]={225,"i"},["š"]={240,"s"},["ų"]={248,"u"},["ū"]={251,"u"},["ž"]={254,"z"},["Ą"]={192,"A"},["Č"]={200,"C"},["Ę"]={198,"E"},["Ė"]={203,"E"},["Į"]={193,"I"},["Š"]={208,"S"},["Ų"]={216,"U"},["Ū"]={219,"U"},["Ž"]={222,"Z"}}
function UI.encode(text)
    text=tostring(text or ""):gsub("„",'"'):gsub("“",'"'):gsub("–","-"):gsub("—","-")
    for char,value in pairs(UI.letters) do text=text:gsub(char,UI.ascii and value[2] or string.char(value[1])) end
    return text
end
function UI.font(size,bold)
    local key=size..":"..tostring(bold)
    if not UI.fonts[key] then UI.fonts[key]=renderCreateFont("Segoe UI",size,bold and 1 or 0,186) end
    return UI.fonts[key]
end
function UI.text(text,x,y,size,color,maxWidth,bold)
    local font=UI.font(size or 10,bold)
    local encoded=UI.encode(text)
    if maxWidth and type(renderGetFontDrawTextLength)=="function" then
        while #encoded>0 and renderGetFontDrawTextLength(font,encoded)>maxWidth do
            encoded=encoded:sub(1,-2)
        end
    end
    renderFontDrawText(font,encoded,x,y,color or UI.colors.text,true)
end
function UI.card(x,y,w,h)
    renderDrawBox(x,y,w,h,UI.colors.bg)
    renderDrawBox(x,y,w,1,UI.colors.edge)
    renderDrawBox(x,y+h-1,w,1,UI.colors.edge)
    renderDrawBox(x,y,1,h,UI.colors.edge)
    renderDrawBox(x+w-1,y,1,h,UI.colors.edge)
end
function UI.state(value)
    if UI.states[value] then return UI.states[value] end
    value=tostring(value or "")
    if value:find("queued",1,true)==1 then return "Žinutė eilėje" end
    if value:find("typing",1,true) then return "Rašoma žinutė" end
    if value:find("blocked",1,true) then return "Laukiama laisvo kelio" end
    if value:find("pause",1,true) then return "Pristabdyta" end
    if value:find("sent",1,true) then return "Žinutė išsiųsta" end
    if value:find("skip",1,true) then return "Praleista" end
    if value:find("expired",1,true) then return "Baigėsi laukimo laikas" end
    if value:find("fail",1,true) or value:find("error",1,true) then return "Klaida; informacija žurnale" end
    return "Stebima būsena"
end
function UI.status(value)
    if UI.statuses[value] then return UI.statuses[value] end
    if UI.states[value] then return UI.states[value] end
    value=tostring(value or "")
    if value:find("Save failed",1,true) then return "Nepavyko išsaugoti. Patikrinkite failo rašymo teises." end
    if value:find("Backup failed",1,true) then return "Nepavyko sukurti atsarginės kopijos." end
    if value:find("line ",1,true) or value:find("delay minimum",1,true) then return "Netinkama reikšmė arba ribos. Patikrinkite nustatymus." end
    if value:find("reload deferred",1,true) then return "Įkėlimas atidėtas. Sustabdykite arba pristabdykite važiavimą." end
    return UI.state(value)
end
function UI.value(value,key)
    if type(value)=="boolean" then return value and "Įjungta" or "Išjungta" end
    if type(value)=="number" then
        local text=string.format("%.2f",value):gsub("0+$",""):gsub("%.$","")
        if key:find("seconds",1,true) then return text.." s" end
        if key=="driving.max_speed_kmh" then return value==0 and "Be papildomos ribos" or text.." km/h" end
        if key=="chat.reply_chance" or key=="rotation.second_message_chance"
            or key=="rotation.reverse_power" or key=="rotation.forward_power" then return text.." %" end
        if key=="driving.waypoint_radius" or key=="driving.lateral_tolerance" or key=="recovery.probe_distance"
            or key=="rotation.connect_distance" or key=="rotation.search_distance" then return text.." m" end
        if key=="recovery.reverse_max_speed" then return text.." m/s" end
        return text
    end
    return UI.states[value] or tostring(value)
end
function UI.translate(text)
    text=tostring(text):gsub("~n~"," / "):gsub("~[%w_]~",""):gsub("%s+"," ")
    if UI.states[text] then return UI.states[text] end
    if UI.messages[text] then return UI.messages[text] end
    for from,to in pairs(UI.messages) do
        if text:sub(1,#from)==from then return to..text:sub(#from+1) end
    end
    if text:find("Telemetry:",1,true) then return "Duomenų įrašymas sustabdytas. Informacija žurnale." end
    if text:find("Settings:",1,true) then return "Nustatymų klaida. Patikrinkite nustatymų failą." end
    return text
end
function UI.notify(text,duration)
    -- Continuous per-frame driving notices are represented by the dashboard.
    if duration and duration<=1000 then return end
    local notice={text=UI.translate(text),expires=os.clock()+(duration or 3000)/1000,color=tostring(text):find("~r~",1,true) and 0xFFFF887E or UI.colors.accent}
    UI.notices[1]=notice
end
function UI.drawNotices()
    if not UI.notices[1] then return end
    if os.clock()>UI.notices[1].expires then UI.notices={};return end
    local ok=pcall(function()
        local w,h=getScreenResolution();local width=math.min(640,w-32);local x=(w-width)/2
        UI.card(x,h-118,width,84)
        UI.text("Dangis",x+18,h-106,10,UI.notices[1].color,width-36,true)
        -- Wrap using measured font width rather than byte count.
        local words,line={},""
        for word in UI.notices[1].text:gmatch("%S+") do
            local candidate=line=="" and word or line.." "..word
            local len=type(renderGetFontDrawTextLength)=="function" and renderGetFontDrawTextLength(UI.font(11),UI.encode(candidate)) or #candidate*7
            if len>width-36 and line~="" then words[#words+1]=line;line=word else line=candidate end
        end
        words[#words+1]=line
        for i=1,math.min(2,#words) do UI.text(words[i],x+18,h-85+(i-1)*20,11,nil,width-36) end
    end)
    if not ok then UI.notices={} end
end
function UI.release()
    for _,font in pairs(UI.fonts) do if type(renderReleaseFont)=="function" then pcall(renderReleaseFont,font) end end
    UI.fonts={}
end
if type(addEventHandler)=="function" then
    addEventHandler("onD3DPresent",UI.drawNotices)
    addEventHandler("onD3DDeviceLost",UI.release)
end
return UI
