-- Dangis VR 5.78 rotation (apsukimas) incident state machine. No game APIs.
--
-- The main script feeds one sample per frame and submits the returned digital
-- command through ControlManager as owner ROTATE. Ordinary route driving is
-- never involved: playback stays paused for the whole incident and resumes
-- through the original v5.77 controller only after step() returns "ready".
--
-- Public interface (used by dangis_vr.lua):
--   R.new(options) / r:configure(options)   options = CONFIG.rotation
--   r:observe(now,car,heading,explicit,enabled,priorSteer[,x,y]) -> triggered
--   r:step(now,sample,errorDegrees) -> command[,signal]
--       signal "chat"  : ask main to queue one incident reaction, then r:chatQueued(now,ok)
--       signal "park"  : ask main for a safe pull-over side, then r:setPark(now,side,sample)
--       signal "plan"  : ask main for a recovery route plan, then r:setPlan(now,plan)
--       signal "jturn" : ask main for a plan (reverse spin), then r:setJturn(now,plan,side,sample)
--       signal "uturn" : ask main for a plan and a U-turn side, then r:setUturn(now,plan,side,sample)
--       signal "ready" : stable on the route (see R:handoffCheck); hand back to playback
--
-- Collision probe values in the sample are true (checked clear), false
-- (blocked, or the check failed) or R.PENDING (not finished yet). PENDING is
-- never treated as clear: decisions wait for it (bounded). A move in progress
-- whose rolling re-check is still running keeps its pedal only inside space a
-- clear check already confirmed: a leg within the distance its last clear
-- check covered (minus the stopping distance); a U-turn or reverse spin
-- within the sweep that was checked as a whole before it started, for at
-- most legPendingSeconds. Blocked or unknown always ends the push.
--
-- Every powered move is bounded by time, progress and distance (the reverse
-- spin also by its entry speed and its checked slide corridor) and releases
-- every key while the car is airborne. HOLD retries after holdTimeout if the
-- car never comes to rest.
--   r:finish(now)  successful handover; keeps the rolling incident memory
--   r:reset()      stop/new playback; forgets everything
--
-- Default (jturnEnabled): JTURN_CHECK (plan + room, no keys) -> JTURN (S with
-- full lock while the car still travels backwards, then W with the other lock
-- once it travels forwards) -> SETTLE -> ready; no room -> HOLD -> PLAN
-- (reverse-then-swing, forward U-turn, moves). With jturnEnabled = false:
-- Phases: FIGHT (bounded W) -> HOLD (stabilise, brake assist) -> [UTURN_CHECK
-- -> UTURN (W + full lock)] or [PLAN -> reverse-then-swing: REVERSE (S + full
-- lock) straight into UTURN] or [PLAN -> REVERSE/ALIGN legs separated by
-- STOP] -> SETTLE (straight wheels, hands over at once when stable) ->
-- APPROACH (only when still far from the line) -> ready. Pedals are held for
-- the whole move (see R:drive).
-- Three or more turns inside the window: short FIGHT -> HOLD -> PARK -> PARKED
-- (quiet period) -> PLAN. WAIT is a neutral, bounded retry. Every phase that
-- presses a key is bounded by time, distance and progress checks, and every
-- new disturbance interrupts the current manoeuvre immediately.
local R = {}
R.__index = R

local function angle(a,b) return (a-b+180)%360-180 end
local function neutral() return {gas=0,brake=0,steer=0,reverse=false} end
local function distance(ax,ay,bx,by) return math.sqrt(((ax or 0)-(bx or 0))^2+((ay or 0)-(by or 0))^2) end

R.defaults = {
    -- Exposed through [rotation] in dangis_vr.ini.
    window = 10.0,           -- rolling incident window (s)
    multiTurns = 3,          -- turns inside the window that count as "overwhelming"
    firstFight = 0.5,        -- W reaction after the first turn (s, upper bound)
    repeatFight = 3.0,       -- total W reaction budget for a repeated-turn incident (s)
    multiResist = 0.6,       -- extra short resistance when the incident becomes "multi" (s)
    stableSeconds = 0.3,     -- required continuous stability before planning (s)
    parkEnabled = true,
    parkQuiet = 8.0,         -- quiet period while parked before resuming (s)
    retryMax = 8.0,          -- longest neutral wait between retries (s)
    connectDistance = 10.0,  -- hand over to playback within this distance of the route (m)
    searchDistance = 28.0,   -- recorded points further away are not candidates on the first attempt (m); widened after failures
    routeSwitching = true,
    switchPenalty = 12.0,
    chatEnabled = true,
    chatCooldown = 25.0,
    secondChance = 25,
    uturnEnabled = true,     -- turn round in one forward sweep when the arc is clear
    jturnEnabled = true,     -- reverse spin (J-turn) right after the turn instead of the W reaction
    reversePower = 100,      -- % of the time S is held during reverse legs (100 = held)
    forwardPower = 100,      -- % for forward legs and the drive back to the route
    probeBudget = 100,       -- collision rays per frame for recovery checks (main script)
    -- Internal bounds (not exposed; conservative constants). Speeds in m/s.
    minQuiet = 0.4, stableSpeed = 3.0, stableRate = 25.0, stableSlip = 35.0,
    brakeAssistSpeed = 2.5,
    fightMaxForward = 8.0, fightMaxRate = 200.0,
    chatMaxWait = 9.0,
    alignTolerance = 25.0,
    -- v5.77's player-input check briefly (1-3 frames) reads a key the bot has
    -- just released as the player's. Shorter than this, losing the keyboard
    -- to MANUAL only pauses the manoeuvre (keys released, phase kept).
    manualGrace = 0.2,
    legReverseSeconds = 3.0, legReverseMeters = 4.5,
    legForwardSeconds = 2.5, legForwardMeters = 5.5,
    legMinProgressDegrees = 6.0,
    -- Pedal holding: W (forwards) or S (backwards) stays pressed for the
    -- whole move, together with the full A/D lock. Above the ceiling the
    -- pedal is only released (never braked) until the car is coastBand below
    -- it again; ceiling + runawayMargin ends the move.
    -- Short moves (reverse legs, forward legs): over 2-5 m the pedal stays
    -- down almost the whole way; the ceiling keeps the stopping distance
    -- short so the car can use the room it has. The one-sweep U-turn has
    -- the whole sweep confirmed and may go faster.
    reverseMaxSpeed = 7.0, forwardMaxSpeed = 7.0, uturnMaxSpeed = 6.5, coastBand = 1.5, runawayMargin = 4.0,
    -- The slow sweeps on the tight circle (slow U-turn, the swing of
    -- reverse-then-swing) stay below the ordinary U-turn.
    uturnTightMaxSpeed = 5.0,
    -- Drive back to the route (W held): ceiling while still turning / when lined up.
    approachTurnSpeed = 7.0, approachMaxSpeed = 12.0,
    -- Reverse-then-swing (three-point turn): reverse this far with the lock
    -- (shortest that works), then swing forwards round in one sweep.
    threePointShort = 3.0, threePointLong = 7.0,
    maxLegs = 16, manoeuvreTimeout = 40.0, stopTimeout = 2.5,
    approachTimeout = 15.0, approachProgressSeconds = 3.0,
    -- Reverse spin (J-turn): S with full lock straight after the turn (no W)
    -- until the car is round to jturnSwitchAngle from the route direction,
    -- then W with the opposite lock swings the nose the rest of the way and
    -- drives on, without stopping. Its room is checked first (at most
    -- jturnCheckSeconds); the whole spin lasts at most jturnSeconds.
    jturnSeconds = 4.0, jturnCheckSeconds = 0.6, jturnMaxSpeed = 40.0, jturnSwitchAngle = 100.0,
    -- A spin from a slow car stays within this distance of where it started
    -- (m); a fast one within its checked slide corridor (R.jturnLength).
    jturnSlowReach = 14.0,
    -- Airborne during a powered move: keys released; longer than this ends it (s).
    airborneSeconds = 0.5,
    -- SETTLE straight after a turn that was straightened early (fast yaw):
    -- the heading may still be converging for this long (s).
    settleConvergeSeconds = 1.5,
    -- A recorded reverse section is joined from (nearly) a stop: the control
    -- writer's foot brake works down to 1 m/s, so the handoff accepts 1.2.
    reverseHandoffSpeed = 1.2,
    -- While the bot itself steers a turning move, a heading change counts as
    -- a new external rotation only when it is faster than a car can turn by
    -- itself (deg/s): an admin flip is practically instantaneous.
    ownTurnRate = 900.0,
    -- HOLD that never gets stable (the car is being pushed or keeps
    -- sliding): after this long it retries (neutral wait, then again) (s).
    holdTimeout = 20.0,
    -- One-sweep U-turn: offered once per turn, as soon as the car is no longer
    -- sliding backwards.
    uturnReadySpeed = 3.5, uturnTimeout = 7.0,
    parkSteerSeconds = 1.2, parkStraightenSeconds = 0.8, parkMaxMeters = 7.0,
    parkSpeed = 2.5, parkTimeout = 5.0,
    settleTimeout = 12.0,
    -- Handoff to the v5.77 controller: every condition held continuously for
    -- handoffDwell. A stop is not required; the car keeps driving.
    handoffHeading = 30.0,      -- aim-point heading error (deg)
    handoffRouteHeading = 60.0, -- heading vs. the route direction at the connection: never the wrong way (deg)
    handoffRate = 45.0,         -- smoothed yaw rate (deg/s)
    handoffLateral = 2.0,       -- sideways speed (m/s)
    handoffMaxSpeed = 14.0,     -- higher speeds are braked down first (m/s)
    handoffDwell = 0.1,         -- (s)
    -- Collision checks still pending: decisions wait at most this long, a move
    -- in progress at most legPendingSeconds, then the path counts as blocked.
    probePendingTimeout = 3.0, legPendingSeconds = 0.6,
    -- Failed attempts: every retryLongEvery-th failure waits retryLongWait.
    retryLongEvery = 6, retryLongWait = 20.0,
}
R.PENDING = "pending"

-- Length (m) of the slide corridor a reverse spin needs at `backSpeed`
-- (m/s): the main script checks it before the spin, the spin is ended if it
-- travels further. Shared so both always agree.
function R.jturnLength(backSpeed)
    local v = math.max(0, backSpeed or 0)
    return math.min(70, v*v/12+3)
end

local function merged(options)
    local cfg = {}
    for key,value in pairs(R.defaults) do cfg[key] = value end
    if type(options) == "table" then
        for key,value in pairs(options) do
            if R.defaults[key] ~= nil and type(value) == type(R.defaults[key]) then cfg[key] = value end
        end
    end
    return cfg
end

R.serial = 0
function R.new(options) return setmetatable({cfg=merged(options)},R) end
function R:configure(options) self.cfg = merged(options) end

-- Forget everything, including the incident memory (stop, start, no vehicle).
function R:reset()
    local cfg = self.cfg
    for key in pairs(self) do self[key] = nil end
    self.cfg = cfg or merged()
end

-- Successful handover. The incident memory stays so that another turn inside
-- the window counts as a consecutive rotation, not as a new first rotation.
function R:finish(now)
    local keep = {cfg=self.cfg, memory=self.memory, previous=self.previous, history=self.history}
    for key in pairs(self) do self[key] = nil end
    for key,value in pairs(keep) do self[key] = value end
    if self.memory then self.memory.finishedAt = now end
end

-- Incident memory or nil once the window has passed without a turn.
function R:incident(now)
    local m = self.memory
    if not m then return nil end
    local turns = m.turns
    while turns[1] and now-turns[1] > self.cfg.window do table.remove(turns,1) end
    if #turns == 0 and not self.phase then self.memory = nil; return nil end
    return m
end

function R:windowCount(now)
    local m = self:incident(now)
    return m and #m.turns or 0
end

local RANK = {single=1, double=2, multi=3}

-- Cancel any manoeuvre: neutral stabilisation from this moment.
function R:hold(now)
    self.planGen = (self.planGen or 0) + 1
    self.reactUntil = nil
    self.phase = "HOLD"
    self.lastEvent = now
    self.stableSince = nil
    self.direction = nil
    self.target = nil
    self.settleSince = nil
    self.progressAt = nil
    self.plan = nil
    self.afterStop, self.stopReason = nil, nil
    self.legStart, self.legKind = nil, nil
    self.pulseDir, self.pulseUntil, self.pulseRest = 0, 0, 0
    self.parkStage = nil
    self.reverseKey = nil
    self.legShort, self.lastLegKey, self.lastLegShort, self.lastLegStuck = nil, nil, nil, nil
    self.handoffSince, self.handoffWhy = nil, nil
    self.pendingSince, self.legPendingSince, self.checkSince = nil, nil, nil
    self.holdSince = now
end

-- The incident level only rises while an incident is active: three turns
-- inside the window make it "multi" until the incident ends (a handover
-- followed by a quiet window), even when the earlier turns have left the
-- window meanwhile. That is deliberate: an incident that was overwhelming
-- stays handled as one (pull over, wait), it does not flip back.
function R:noteTurn(now, explicit)
    local cfg = self.cfg
    local m = self:incident(now)
    if not m then
        R.serial = R.serial + 1
        m = {id=R.serial, turns={}, fightUsed=0, startedAt=now, total=0, level="single", localOnly=true}
        self.memory = m
    end
    m.turns[#m.turns+1] = now
    m.total = m.total + 1
    m.lastTurn = now
    m.localOnly = m.localOnly and explicit == true
    local n = #m.turns
    local level = n >= cfg.multiTurns and "multi" or (n >= 2 and "double" or "single")
    if RANK[level] < RANK[m.level] then level = m.level end
    m.level = level
    local allowance
    if level == "single" then allowance = cfg.firstFight
    elseif level == "double" then allowance = math.max(cfg.firstFight, cfg.repeatFight)
    else
        if not m.multiCap then
            m.multiCap = math.min(m.fightUsed + cfg.multiResist, math.max(cfg.firstFight, cfg.repeatFight) + cfg.multiResist)
        end
        allowance = m.multiCap
    end
    m.fightAllowance = allowance
    self.level = level
    local active = self.phase ~= nil
    self.started = self.started or now
    self.count = (self.count or 0) + 1
    self:hold(now)
    self.wantChat = true
    self.uturnTried = false
    self.approachBlock = nil
    -- Keep the clock of a running episode so W time is never under-counted.
    if not active or not self.lastStep then self.lastStep = now end
    if cfg.jturnEnabled then
        -- No W reaction: reverse spin straight away (overwhelmed: brake and
        -- pull over instead, from HOLD).
        self.jturnTried, self.planUturnTried = false, false
        if level ~= "multi" then
            self.phase = "JTURN_CHECK"
            self.checkSince = now
            self.jturnAsked = false
        end
        return level
    end
    if m.fightUsed < allowance - 0.01 then
        self.phase = "FIGHT"
        self.fightSince = now
    end
    return level
end

-- Moves in which the bot itself turns the car (see R:observe).
local OWN_TURN = {JTURN=true, UTURN=true, REVERSE=true, ALIGN=true, APPROACH=true, PARK=true}

-- x/y are optional: a position jump between samples is a teleport, not a turn.
function R:observe(now,car,heading,explicit,enabled,priorSteer,x,y)
    local previous = self.previous
    local dt = previous and now-previous.at or 0
    local valid = previous and previous.car == car and dt > 0 and dt <= 0.35
    if valid and x and y and previous.x and previous.y then
        local jump = distance(x,y,previous.x,previous.y)
        if jump > math.max(25, 90*dt) then valid = false; self.teleportAt = now end
    end
    self.rate = valid and math.abs(angle(heading,previous.heading))/dt or math.huge
    -- Smoothed yaw rate (0.15 s time constant) for the handoff decision; a
    -- single quiet frame inside a slide must not look like stability.
    if valid then
        local a = 1-math.exp(-dt/0.15)
        self.rateAvg = self.rateAvg and self.rateAvg+(math.min(self.rate,720)-self.rateAvg)*a or math.min(self.rate,720)
    else
        self.rateAvg = nil
    end
    self.previous = {at=now,car=car,heading=heading,x=x,y=y}
    if not valid or not enabled then self.history = {} end
    local history = self.history or {}
    self.history = history
    local triggered = explicit and enabled
    if valid and enabled then
        -- Our own steering in a turning move can turn the car quickly too;
        -- then only a change faster than ownTurnRate counts.
        local own = OWN_TURN[self.phase or ""] and priorSteer ~= nil and priorSteer ~= 0
        local minRate = own and self.cfg.ownTurnRate or 0
        local change = math.abs(angle(heading,previous.heading))
        triggered = triggered or (change >= 120 and change/dt >= minRate)
        for _,sample in ipairs(history) do
            local span = now-sample.at
            local swing = math.abs(angle(heading,sample.heading))
            if span <= 0.25 and swing >= 140 and (span <= 0 or swing/span >= minRate) then triggered = true end
        end
    end
    while history[1] and now-history[1].at > 0.25 do table.remove(history,1) end
    history[#history+1] = {at=now,heading=heading}
    if triggered then
        self:noteTurn(now, explicit)
        self.history = {{at=now,heading=heading}}
    elseif self.phase and not valid then
        -- No recovery drive command from stale samples, a teleport or a different vehicle.
        self:hold(now)
    end
    return triggered
end

-- Failures keep ownership but release every key. Retry at a bounded cadence.
function R:retry(now,reason)
    self.attempts = (self.attempts or 0) + 1
    self:hold(now)
    self.phase = "WAIT"
    self.retryAt = now + math.min(self.cfg.retryMax, 0.5 + self.attempts*0.3)
    -- Repeated failures in the same incident: a longer, still automatic, pause.
    if self.attempts % self.cfg.retryLongEvery == 0 then
        self.retryAt = now + self.cfg.retryLongWait
        reason = tostring(reason) .. "; repeated failures, longer pause"
    end
    self.reason = reason
    return neutral()
end

-- Controlled braking only: W while rolling backwards, S while rolling
-- forwards; released below the threshold so neither pedal can start a move.
function R:brakeAssist(sample, threshold)
    local cmd = neutral()
    local fs = sample.forwardSpeed
    if sample.airborne or fs == nil then return cmd end
    if (sample.slip or 0) > 60 and (sample.speed or 0) > 8 then return cmd end
    if fs < -threshold then cmd.gas = 255
    elseif fs > threshold then cmd.brake = 255 end
    return cmd
end

-- Throttle duty: 100 % holds the key for the whole leg; lower values pulse
-- it in 0.5 s windows (works for both the keyboard and the gamepad backend).
function R:powered(now, percent)
    if percent >= 100 then return true end
    if percent <= 0 then return false end
    return ((now-(self.legStart or self.approachStart or now)) % 0.5) < 0.5*percent/100
end

-- Pedal for a manoeuvre (direction 1 forwards, -1 backwards): the key is
-- held for the whole move (W forwards, S backwards; the same key first brakes
-- a roll the wrong way, exactly like a driver would). Above maxSpeed it is
-- released, never braked, until the car is coastBand below maxSpeed again.
function R:drive(now, cmd, sample, direction, maxSpeed, power)
    local fs = sample.forwardSpeed
    local along
    if direction > 0 then along = fs or sample.speed elseif fs then along = -fs end
    if along and along > maxSpeed then self.coasting = true
    elseif not along or along < maxSpeed - self.cfg.coastBand then self.coasting = false end
    if self.coasting or not self:powered(now, power) then return cmd end
    if direction > 0 then
        cmd.gas = 255
    elseif fs ~= nil or sample.speed < 1.5 then
        -- Direction unknown: only engage reverse from (near) standstill.
        cmd.reverse = true
    end
    return cmd
end

-- A move keeps its pedal while a rolling re-check is still running, as long
-- as the car stays inside the distance the last clear check confirmed
-- (minus the stopping distance). Outside it: no pedal until the check ends.
function R:confirm(sample, meters)
    local c = self.confirmed
    local left = c and (c.meters - distance(sample.x,sample.y,c.x,c.y)) or 0
    self.confirmed = {x=sample.x, y=sample.y, meters=math.max(meters, left)}
end
-- Stopping distance at the sample's speed with the vehicle's hard braking
-- (sample.brakeDecel, m/s^2: 8 x the profile's braking_scale).
local function stopping(sample)
    local v = sample.speed or 0
    return v*v/(2*(sample.brakeDecel or 8))
end
R.stopping = stopping

function R:onConfirmed(sample)
    local c = self.confirmed
    if not c then return false end
    return distance(sample.x,sample.y,c.x,c.y) + stopping(sample) + 0.2 < c.meters
end

local PENDING = R.PENDING
-- Probe value -> "clear", "pending" or "blocked" (anything unknown is blocked).
local function state(value)
    if value == true then return "clear" end
    if value == PENDING then return "pending" end
    return "blocked"
end
R.probeState = state

-- Forward leg clearance: the full-lock arc for the current lock when the
-- main script supplies it, otherwise the straight corridor.
function R:forwardOk(sample, short)
    if short then return state(sample.shortClear) end
    local t = sample.forwardClearFor
    if type(t) == "table" and self.direction and t[self.direction] ~= nil then return state(t[self.direction]) end
    return state(sample.clear)
end

-- A move in progress whose clearance check has not finished: stop pushing,
-- keep the wheels, and give up the move if the answer takes too long.
function R:legPending(now)
    self.legPendingSince = self.legPendingSince or now
    return now-self.legPendingSince > self.cfg.legPendingSeconds
end

-- Sideways speed: from the sample when the main script measured it,
-- otherwise estimated from the slip angle.
local function lateralOf(sample)
    if sample.lateralSpeed ~= nil then return math.abs(sample.lateralSpeed) end
    local slip = math.min(90, sample.slip or 0)
    return (sample.speed or 0)*math.sin(math.rad(slip))
end
R.lateralOf = lateralOf

-- Motion stability alone (no position or heading): no yaw, no sideways
-- slide, on the ground, not rolling backwards.
function R:stable(sample)
    local cfg = self.cfg
    if sample.airborne then return false, "airborne" end
    if (self.rateAvg or math.huge) > cfg.handoffRate then return false, "yaw" end
    if lateralOf(sample) > cfg.handoffLateral then return false, "sliding" end
    if (sample.forwardSpeed or sample.speed) < -0.3 then return false, "rolling backwards" end
    return true
end

-- Handoff to the v5.77 controller. True only when the car points along the
-- route towards the aim point, travels the way it points, is near the line,
-- does not slide or yaw, is not airborne and is at a manageable speed, all
-- continuously for handoffDwell. ignoreDistance: only stability is judged
-- (SETTLE far from the line, before APPROACH).
function R:handoffCheck(now, sample, err, ignoreDistance)
    local cfg = self.cfg
    local fs = sample.forwardSpeed or sample.speed
    local why
    if err == nil or math.abs(err) > cfg.handoffHeading then why = "heading"
    elseif sample.routeHeadingError ~= nil and math.abs(sample.routeHeadingError) > cfg.handoffRouteHeading then why = "route direction"
    elseif not ignoreDistance and (sample.connectDistance or 0) > cfg.connectDistance then why = "distance"
    elseif sample.airborne then why = "airborne"
    elseif (self.rateAvg or math.huge) > cfg.handoffRate then why = "yaw"
    elseif lateralOf(sample) > cfg.handoffLateral then why = "sliding"
    elseif fs < -0.3 then why = "rolling backwards"
    elseif sample.speed > cfg.handoffMaxSpeed then why = "too fast"
    elseif self.plan and self.plan.back and sample.speed > cfg.reverseHandoffSpeed then why = "reverse section needs a stop"
    end
    if why then self.handoffSince = nil; self.handoffWhy = why; return false, why end
    self.handoffSince = self.handoffSince or now
    self.handoffWhy = nil
    return now-self.handoffSince >= cfg.handoffDwell
end

function R:stopThen(now, nextPhase, reason)
    self.phase = "STOP"
    self.stopSince = now
    self.afterStop = nextPhase
    self.stopReason = reason
    self.legStart = nil
    return neutral()
end

-- Common guards for every powered move. Returns "neutral" (release every key
-- this frame) or false plus a reason to end the move, or true to continue.
function R:motionGuard(now, sample)
    if sample.airborne then
        self.airSince = self.airSince or now
        if now-self.airSince > self.cfg.airborneSeconds then return false, "airborne" end
        return "neutral"
    end
    self.airSince = nil
    if sample.connectDistance and sample.connectDistance > self:reach()+5 then return false, "route out of reach" end
    return true
end

-- Search distance the current plan was chosen with (widened after failures).
function R:reach()
    return (self.plan and self.plan.searchDistance) or self.cfg.searchDistance
end

-- Where driving straight on to the route was blocked in this incident.
function R:noteApproachBlocked(sample)
    local b = self.approachBlock
    if b and distance(sample.x,sample.y,b.x,b.y) <= 4 then b.count = b.count+1
    else self.approachBlock = {x=sample.x, y=sample.y, count=1} end
end
function R:approachBlockedHere(sample)
    local b = self.approachBlock
    return b ~= nil and distance(sample.x,sample.y,b.x,b.y) <= 4
end

function R:startSettle(now, err)
    self.phase = "SETTLE"
    self.settleSince = now
    self.settleEntryErr = err and math.abs(err) or nil
    self.settleStarted = self.settleStarted or now
    self.handoffSince, self.handoffWhy = nil, nil
end

function R:enterParked(now)
    if self.memory then self.memory.parked = true end
    self.phase = "PARKED"
    self.parkedSince = now
    self.parkedChatAsked = false
end

function R:afterStable(now)
    local m = self.memory or {}
    if self.level == "multi" then
        if self.cfg.parkEnabled and not m.parked then
            self.phase = "PARK_PLAN"
            return "park"
        end
        self:enterParked(now)
        return nil
    end
    if self.wantChat then
        self.wantChat = false
        self.phase = "CHAT"
        self.chatSince = now
        return "chat"
    end
    self.phase = "PLAN"
    return "plan"
end

-- Main reports whether an incident reaction was queued.
function R:chatQueued(now, ok)
    if self.phase == "CHAT" then
        self.chatOk = ok
        if not ok then self.phase = "PLAN"; return "plan" end
    elseif self.phase == "PARKED" then
        self.parkedChatOk = ok
    end
    return nil
end

function R:setPark(now, side, sample)
    if self.memory then self.memory.parked = true end
    self.wantChat = true
    if not side then self:enterParked(now); return nil end
    self.phase = "PARK"
    self.parkSide = side < 0 and -128 or 128
    self.parkStage = "OUT"
    self.parkStart, self.legStart = now, now
    self.parkX, self.parkY = sample and sample.x or 0, sample and sample.y or 0
    self.parkHeading = sample and sample.heading or 0
    return nil
end

-- side: +-128 the quicker sweep, +-64 the slow sweep on the tight circle.
function R:startUturn(now, side, sample, tight)
    self.direction = side < 0 and -128 or 128
    self.uturnTight = tight or math.abs(side) < 128
    self.phase = "UTURN"
    self.coasting, self.thenUturn = false, nil
    self.uturnNeedsCheck = nil
    self.uturnStart, self.progressAt = now, now
    self.progressHeading = sample and sample.heading
    self.legs, self.noProgress, self.manoeuvreStart = 0, 0, now
    self.legStart = now
    self.legPendingSince = nil
end

-- Main answers a "uturn" signal with a plan and either the side whose whole
-- turning arc was confirmed clear, false/nil (no room: the normal stop and
-- reverse-and-turn follow) or R.PENDING (checks still running: UTURN_CHECK
-- keeps braking the crawl and reads sample.uturnSide every frame).
function R:setUturn(now, plan, side, sample)
    self.planGen = (self.planGen or 0) + 1
    if not plan then return nil end
    if side == PENDING then
        self.plan = plan
        self.phase = "UTURN_CHECK"
        self.checkSince = now
        return nil
    end
    if type(side) ~= "number" then return nil end
    self.plan = plan
    self:startUturn(now, side, sample)
    return nil
end

-- Main answers a "jturn" signal with a plan and R.PENDING (the spin checks
-- run over the next frames; JTURN_CHECK reads sample.jturnSide), or without
-- a plan (no route: stabilise and plan as usual).
function R:setJturn(now, plan, side, sample)
    self.planGen = (self.planGen or 0) + 1
    if not plan or side == nil then return self:jturnFallback(now, plan and "no reverse spin for a reverse section" or "no route for a reverse spin") end
    self.plan = plan
    if type(side) == "number" then self:startJturn(now, side, sample) end
    return nil
end

function R:startJturn(now, side, sample)
    self.direction = side < 0 and -128 or 128
    self.phase = "JTURN"
    self.jturnStart, self.progressAt = now, now
    self.progressHeading = sample and sample.heading
    self.legX, self.legY = sample and sample.x or 0, sample and sample.y or 0
    self.legStart = now
    self.coasting, self.legPendingSince = false, nil
    self.reverseKey = self.direction
    self.jturnSwing, self.uturnTight = false, true
    local back = sample and math.max(0, -(sample.forwardSpeed or -(sample.speed or 0))) or 0
    self.jturnEntrySpeed = sample and sample.speed or 0
    self.jturnReach = back >= 8 and R.jturnLength(back)+2.5 or self.cfg.jturnSlowReach
    self.airSince = nil
end

-- No room for the spin, or it did not finish: stabilise (W only brakes a
-- backwards roll) and plan; reverse-then-swing is tried before the forward
-- U-turn.
function R:jturnFallback(now, reason)
    local plan = self.plan
    self:hold(now)
    self.jturnTried = true
    self.uturnTried = true
    self.reason = reason
    self.plan = plan
    return nil
end

function R:startApproach(now, cd)
    self.phase = "APPROACH"
    self.coasting = false
    self.approachStart, self.progressAt, self.bestConnect = now, now, cd or 0
    self.pulseDir, self.pulseUntil, self.pulseRest = 0, 0, 0
    self.handoffSince, self.handoffWhy, self.legPendingSince = nil, nil, nil
end

function R:setPlan(now, plan)
    self.planGen = (self.planGen or 0) + 1
    if not plan then self:retry(now, "no reachable route"); return nil end
    self.plan = plan
    self.phase = "PLAN"
    self.direction = nil
    self.legs, self.noProgress = 0, 0
    self.manoeuvreStart = now
    self.settleStarted = nil
    self.flipUsed = false
    self.threeTried = false
    self.thenUturn = nil
    self.pendingSince = nil
    return nil
end

-- Overshoot: the remaining error now points against the locked turn side.
function R:overshoot(err)
    return self.direction and err*self.direction < 0 and math.abs(err) < 100 and math.abs(err) > self.cfg.alignTolerance
end

function R:chooseDirection(err, sample)
    local preferred = err < 0 and -128 or 128
    local other = -preferred
    local function reverseOk(direction)
        return type(sample.reverseClearFor) == "table" and state(sample.reverseClearFor[direction]) == "clear"
    end
    -- The rear swings to the side we steer away from. If that side is blocked
    -- (e.g. a wall on the left) and the other side is free, back up with the
    -- opposite lock instead; with 100+ degrees still to turn either way works
    -- (below that the overshoot guard would immediately turn it back).
    if math.abs(err) >= 100 and not reverseOk(preferred) and reverseOk(other) then
        preferred = other
        self.sideSwitched = true
        self.flipUsed = true
    end
    self.direction = preferred
end

-- Picks the next manoeuvre leg. Order: the wanted leg; reversing with the
-- opposite lock when the rear would hit something on this side (100+ degrees
-- still to turn); the other pedal; backing straight out; then the same set as
-- short (1.2 m) moves for tight streets. A leg that could not move the car
-- is never repeated identically. Nothing possible: neutral retry.
-- Returns the (neutral) command and true while a needed collision check is
-- still pending: the caller stays where it is and asks again next frame.
function R:startLeg(now, sample, preferred, err)
    local cfg = self.cfg
    if (self.legs or 0) >= cfg.maxLegs or now-(self.manoeuvreStart or now) > cfg.manoeuvreTimeout then
        return self:retry(now, "manoeuvre limit")
    end
    local nominal = type(sample.reverseClearFor) == "table" and sample.reverseClearFor or {}
    local short = type(sample.shortReverseFor) == "table" and sample.shortReverseFor or {}
    local d = self.direction
    -- The lock may be flipped once per plan; flipping back and forth would undo the turn.
    local canFlip = err ~= nil and math.abs(err) >= 100 and not self.flipUsed
    local options = {}
    local function add(kind, key, isShort) options[#options+1] = {kind=kind, key=key, short=isShort} end
    for _, isShort in ipairs({false, true}) do
        if preferred == "ALIGN" then add("ALIGN", nil, isShort) end
        add("REVERSE", d, isShort)
        if canFlip then add("REVERSE", -d, isShort) end
        if preferred ~= "ALIGN" then add("ALIGN", nil, isShort) end
        add("REVERSE", 0, isShort)
        -- Straight forward: the way out when something sits right behind the
        -- car and every turning move would swing its rear into it.
        add("ALIGN", 0, isShort)
    end
    local chosen
    -- Waiting for an unfinished check is bounded; after that it counts as blocked.
    local waitPending = now-(self.pendingSince or now) <= cfg.probePendingTimeout
    for _, o in ipairs(options) do
        local st
        if o.kind == "ALIGN" and o.key == 0 then st = state(o.short and sample.straightShortClear or sample.straightClear)
        elseif o.kind == "ALIGN" then st = self:forwardOk(sample, o.short)
        else st = state(o.short and short[o.key] or (not o.short and nominal[o.key])) end
        if st == "clear" and self.lastLegStuck and o.kind == self.legKind and o.key == self.lastLegKey and o.short == self.lastLegShort then st = "blocked" end
        if st == "pending" and waitPending then
            -- A better option is still being checked: wait for it instead of
            -- settling for a worse one (or giving up).
            self.pendingSince = self.pendingSince or now
            return neutral(), true
        end
        if st == "clear" then chosen = o; break end
    end
    self.pendingSince = nil
    if not chosen then
        return self:retry(now, self.lastLegStuck and "manoeuvre made no progress" or "no clear manoeuvre")
    end
    if chosen.kind == "REVERSE" and chosen.key == -d and d then
        self.direction = -d
        self.sideSwitched = true
        self.flipUsed = true
    end
    self.reverseKey = chosen.kind == "REVERSE" and (chosen.key == 0 and 0 or self.direction) or self.direction
    self.legShort = chosen.short
    self.phase = chosen.kind
    self.legKind = chosen.kind
    self.lastLegKey = chosen.kind == "REVERSE" and (chosen.key == 0 and 0 or self.direction) or (chosen.key == 0 and 0 or nil)
    self.alignKey = chosen.kind == "ALIGN" and chosen.key or nil
    self.lastLegShort = chosen.short
    self.flippedThisLeg = false
    self.legPendingSince = nil
    self.legStart = now
    self.legX, self.legY = sample.x, sample.y
    self.legHeading = sample.heading
    self.legs = (self.legs or 0) + 1
    self.coasting = false
    self.confirmed = nil
    -- The decision checked 2.5 m behind / 3 m ahead (1.3 m for short moves).
    self:confirm(sample, chosen.short and 1.3 or (chosen.kind == "REVERSE" and 2.5 or 3.0))
    return neutral()
end

function R:endLeg(now, sample, reason)
    local moved = distance(sample.x,sample.y,self.legX,self.legY)
    local turned = (sample.heading and self.legHeading) and math.abs(angle(sample.heading,self.legHeading)) or moved*10
    -- A straight reverse makes room rather than turning: distance is its progress.
    if ((self.reverseKey == 0 and self.phase == "REVERSE") or (self.alignKey == 0 and self.phase == "ALIGN")) and moved >= 1.0 then turned = math.huge end
    if moved < 0.3 or turned < self.cfg.legMinProgressDegrees then
        self.noProgress = (self.noProgress or 0) + 1
    else
        self.noProgress = 0
    end
    local kind = self.phase
    self.lastLegStuck = moved < (self.legShort and 0.15 or 0.3)
    if self.noProgress >= 2 then return self:stopThen(now, "RETRY", reason or "manoeuvre made no progress") end
    return self:stopThen(now, kind == "REVERSE" and "ALIGN" or "REVERSE", reason)
end

function R:step(now,sample,errorDegrees)
    local cmd = neutral()
    local cfg = self.cfg
    if not self.phase then return cmd end
    local dt = math.max(0, math.min(0.2, now-(self.lastStep or now)))
    self.lastStep = now
    local m = self.memory
    if sample.allowed then
        self.manualSince = nil
    elseif sample.owner == "MANUAL" then
        self.manualSince = self.manualSince or now
        if now-self.manualSince <= cfg.manualGrace then return cmd end
    end
    if not sample.allowed then
        -- Our own chat reaction owns the keyboard; waiting phases simply wait.
        local waiting = self.phase == "FIGHT" or self.phase == "HOLD" or self.phase == "CHAT"
            or self.phase == "PARKED" or self.phase == "WAIT" or self.phase == "PLAN" or self.phase == "PARK_PLAN"
        if sample.owner == "CHAT" and waiting then
            if self.phase == "FIGHT" and m then
                m.fightUsed = m.fightUsed + dt
                if m.fightUsed >= (m.fightAllowance or 0) then self.phase = "HOLD"; self.stableSince = nil end
            end
            return cmd
        end
        self:hold(now)
        return cmd
    end

    if self.phase == "REACT" then -- legacy phase name kept for external tools
        self:hold(now)
    end

    if self.phase == "FIGHT" then
        m = m or {fightUsed=0, fightAllowance=0}
        m.fightUsed = m.fightUsed + dt
        if m.fightUsed >= (m.fightAllowance or 0) then
            self.phase = "HOLD"; self.stableSince = nil
            return self:brakeAssist(sample, cfg.brakeAssistSpeed)
        end
        if sample.fightBlocked == PENDING then return cmd end -- no W until the space ahead is known
        if sample.fightBlocked then
            m.fightUsed = math.max(m.fightUsed, m.fightAllowance or 0)
            self.reason = "fight stopped: obstacle ahead"
            self.phase = "HOLD"; self.stableSince = nil
            return cmd
        end
        local spinning = now-(self.lastEvent or now) > 0.12 and (self.rate or 0) > cfg.fightMaxRate
        if sample.airborne or spinning or ((sample.slip or 0) > 60 and (sample.speed or 0) > 8) then return cmd end
        if (sample.forwardSpeed or 0) < cfg.fightMaxForward then cmd.gas = 255 end
        return cmd
    end

    if self.phase == "WAIT" then
        if now >= self.retryAt then self:hold(now) end
        return cmd
    end

    if self.phase == "JTURN_CHECK" then
        -- Ask once for a plan; the spin's room is checked over a few frames
        -- while the car keeps sliding (no keys meanwhile).
        if not self.jturnAsked then self.jturnAsked = true; return cmd, "jturn" end
        local late = now-(self.checkSince or now) > cfg.jturnCheckSeconds
        local side = sample.jturnSide
        -- An answer that arrives after the time limit describes a car that
        -- has slid on meanwhile: not used.
        if type(side) == "number" and errorDegrees and not late and not sample.airborne then self:startJturn(now, side, sample); return cmd end
        if (side == PENDING or (side == nil and not errorDegrees)) and not late then return cmd end
        self:jturnFallback(now, side == PENDING and "reverse spin check incomplete" or "no room for a reverse spin")
        return cmd
    end

    if self.phase == "JTURN" then
        if errorDegrees == nil then self:jturnFallback(now, "no route target"); return cmd end
        local ok, why = self:motionGuard(now, sample)
        if ok == "neutral" then return cmd end
        if not ok then self:jturnFallback(now, why); return cmd end
        -- Straighten a little early while the car still rotates fast.
        local lead = math.max(cfg.alignTolerance, math.min(60, (self.rateAvg or 0)*0.2))
        if math.abs(errorDegrees) <= lead or self:overshoot(errorDegrees) then
            -- Nose round: wheels straight; SETTLE hands over once it is stable
            -- (and accepts the heading still converging after an early straighten).
            self:startSettle(now, errorDegrees)
            return cmd
        end
        -- Bounded motion: no faster than it came in (a runaway ends it) and
        -- never beyond the area that was checked before it started.
        if (sample.speed or 0) > math.max(self.jturnEntrySpeed or 0, cfg.reverseMaxSpeed)+cfg.runawayMargin then
            self:jturnFallback(now, "reverse spin speeding up"); return cmd
        end
        if self.legX and distance(sample.x,sample.y,self.legX,self.legY) > (self.jturnReach or cfg.jturnSlowReach) then
            self:jturnFallback(now, "reverse spin left the checked area"); return cmd
        end
        if now-self.jturnStart > cfg.jturnSeconds then self:jturnFallback(now, "reverse spin did not finish"); return cmd end
        if sample.heading and self.progressHeading and math.abs(angle(sample.heading,self.progressHeading)) >= 10 then
            self.progressHeading, self.progressAt = sample.heading, now
        elseif now-self.progressAt > 1.2 then
            self:jturnFallback(now, "reverse spin not turning"); return cmd
        end
        -- Which part depends on how the car moves relative to itself: while
        -- it still travels backwards the opposite lock keeps turning it (and S
        -- adds speed only until it is jturnSwitchAngle round, after that S
        -- would brake the spin); once it travels forwards relative to itself
        -- (or has stalled sideways, round far enough), W with the turn-side
        -- lock carries on the turn and drives on.
        local fs = sample.forwardSpeed or -(sample.speed or 0)
        if self.jturnSwing then
            if fs < -2.0 and math.abs(errorDegrees) > cfg.jturnSwitchAngle then self.jturnSwing = false end
        elseif fs > 0.5 or (fs >= -1.0 and math.abs(errorDegrees) <= cfg.jturnSwitchAngle) then
            self.jturnSwing, self.coasting, self.legPendingSince = true, false, nil
        end
        if not self.jturnSwing then
            -- First part: the lock that swings the nose round while reversing.
            -- Blocked (or failed/unknown) space behind ends the spin at any
            -- speed: no more S; the fallback brakes the backwards slide.
            local rc = state(sample.reverseClear)
            if rc == "blocked" then self:jturnFallback(now, "rear blocked during the reverse spin"); return cmd end
            cmd.steer = -self.direction
            if math.abs(errorDegrees) <= cfg.jturnSwitchAngle then return cmd end -- momentum: S would only brake it
            if rc == "pending" then
                -- The whole spin was checked before it started; a rolling
                -- re-check still running keeps S for legPendingSeconds.
                self.legPendingSince = self.legPendingSince or now
                if now-self.legPendingSince > cfg.legPendingSeconds then return cmd end
            else
                self.legPendingSince = nil
            end
            return self:drive(now, cmd, sample, -1, cfg.jturnMaxSpeed, cfg.reversePower)
        end
        -- Second part: W with the opposite lock: the nose comes the rest of
        -- the way round and the car drives on (W first brakes what is left
        -- of the backwards slide).
        self.uturnTight = true
        local clear = state(sample.uturnClear)
        if clear == "blocked" then self:jturnFallback(now, "no room to swing round"); return cmd end
        cmd.steer = self.direction
        if clear == "pending" then
            self.legPendingSince = self.legPendingSince or now
            if now-self.legPendingSince > cfg.legPendingSeconds then return cmd end
        else
            self.legPendingSince = nil
        end
        return self:drive(now, cmd, sample, 1, cfg.uturnMaxSpeed, cfg.forwardPower)
    end

    if self.phase == "HOLD" then
        -- Right after the W reaction: if the car is no longer sliding
        -- backwards, ask whether a one-sweep U-turn fits (only once per turn).
        if cfg.uturnEnabled and self.level ~= "multi" and not self.uturnTried and not sample.airborne
            and now-(self.lastEvent or now) >= 0.15 and sample.speed <= cfg.uturnReadySpeed
            and (sample.forwardSpeed or 0) >= -0.5 and (self.rate or 0) <= 60 and (sample.slip or 0) <= 35 then
            self.uturnTried = true
            return neutral(), "uturn"
        end
        -- While a U-turn is still possible, keep braking the backwards roll
        -- with W down to a crawl, so the turn can start right away.
        local uturnPending = cfg.uturnEnabled and self.level ~= "multi" and not self.uturnTried
        cmd = self:brakeAssist(sample, uturnPending and 0.5 or cfg.brakeAssistSpeed)
        if self.rate <= cfg.stableRate and sample.speed <= cfg.stableSpeed and (sample.slip or 0) <= cfg.stableSlip then
            self.stableSince = self.stableSince or now
        else self.stableSince = nil end
        if now-self.lastEvent >= cfg.minQuiet and self.stableSince and now-self.stableSince >= cfg.stableSeconds then
            return neutral(), self:afterStable(now)
        end
        -- Never stable for a long time (pushed, sliding): retry with a
        -- neutral wait instead of holding on indefinitely.
        if now-(self.holdSince or now) > cfg.holdTimeout then return self:retry(now, "car does not come to rest") end
        return cmd
    end

    if self.phase == "UTURN_CHECK" then
        -- Swept-arc checks run over several frames; keep the car braked meanwhile.
        cmd = self:brakeAssist(sample, 0.5)
        local side = sample.uturnSide
        local tooLong = now-(self.checkSince or now) > cfg.probePendingTimeout
        if sample.connectDistance and sample.connectDistance > self:reach()+5 then side = false end -- pushed away meanwhile
        if type(side) == "number" and sample.speed <= cfg.uturnReadySpeed and (sample.forwardSpeed or 0) >= -0.5 then
            self:startUturn(now, side, sample)
            return neutral()
        end
        if side == PENDING and not tooLong then return cmd end
        if type(side) == "number" and not tooLong then return cmd end -- fits, but still rolling
        -- No room, or the checks could not finish: continue with the normal
        -- flow. The car was held braked meanwhile, so if it is still now the
        -- stability time already counts.
        self.reason = side == PENDING and "U-turn check incomplete" or "no room for a U-turn"
        local still = self.rate <= cfg.stableRate and sample.speed <= cfg.stableSpeed and (sample.slip or 0) <= cfg.stableSlip
        self.phase = "HOLD"; self.plan = nil
        self.stableSince = still and (self.stableSince or self.checkSince) or nil
        self.checkSince = nil
        return cmd
    end

    if self.phase == "PARK_PLAN" then return cmd end

    if self.phase == "CHAT" then
        if not sample.chatPending or now-(self.chatSince or now) > cfg.chatMaxWait then
            self.phase = "PLAN"
            return cmd, "plan"
        end
        return cmd
    end

    if self.phase == "PARKED" then
        cmd = self:brakeAssist(sample, 1.0)
        if self.wantChat and not self.parkedChatAsked then
            self.parkedChatAsked = true
            self.wantChat = false
            return cmd, "chat"
        end
        local quiet = now-((m and m.lastTurn) or self.parkedSince or now) >= cfg.parkQuiet
            and now-(self.parkedSince or now) >= 1
        local still = sample.speed <= 1.5 and (self.rate or 0) <= cfg.stableRate
        local chatDone = not sample.chatPending or now-(self.parkedSince or now) > cfg.parkQuiet+cfg.chatMaxWait
        if quiet and still and chatDone then
            self.phase = "PLAN"
            return neutral(), "plan"
        end
        return cmd
    end

    if self.phase == "STOP" then
        cmd = self:brakeAssist(sample, 0.6)
        local fs = sample.forwardSpeed
        local stopped = sample.speed <= 1.2 and (fs == nil or math.abs(fs) <= 1.0)
        local elapsed = now-(self.stopSince or now)
        if not stopped and elapsed < cfg.stopTimeout then return cmd end
        if not stopped and sample.speed > 1.5 then return self:retry(now, "could not stop") end
        local nextPhase, reason = self.afterStop, self.stopReason
        if nextPhase == "RETRY" then return self:retry(now, reason or "retry")
        elseif nextPhase == "PARKED" then self:enterParked(now); return neutral()
        elseif nextPhase == "SETTLE" then self:startSettle(now); return neutral()
        elseif nextPhase == "PLAN_REDO" then self.phase = "PLAN"; self.direction = nil; self.afterStop = nil; return neutral()
        elseif nextPhase == "REVERSE" or nextPhase == "ALIGN" then
            if errorDegrees == nil then return self:retry(now, "no route target") end
            if math.abs(errorDegrees) <= cfg.alignTolerance then self:startSettle(now); return neutral() end
            local leg, waiting = self:startLeg(now, sample, nextPhase, errorDegrees)
            if waiting then return cmd end -- stay stopped until the checks finish
            return leg
        end
        self.phase = "PLAN"
        return neutral()
    end

    if self.phase == "PARK" then
        local mg, mwhy = self:motionGuard(now, sample)
        if mg == "neutral" then return neutral() end
        if not mg then return self:stopThen(now, "RETRY", mwhy) end
        local moved = distance(sample.x,sample.y,self.parkX,self.parkY)
        local clear = state(sample.clear)
        if clear == "pending" and not self:legPending(now) then return cmd end
        if clear ~= "clear" or moved >= cfg.parkMaxMeters or now-(self.parkStart or now) > cfg.parkTimeout
            or sample.speed > cfg.parkSpeed+2.5 or (sample.slip or 0) > 50 then
            return self:stopThen(now, "PARKED")
        end
        self.legPendingSince = nil
        if self.parkStage == "OUT" then
            cmd.steer = self.parkSide
            if now-self.legStart >= cfg.parkSteerSeconds or moved >= 3.0 then self.parkStage = "IN"; self.legStart = now end
        else
            cmd.steer = -self.parkSide
            local back = (sample.heading and self.parkHeading) and math.abs(angle(sample.heading,self.parkHeading)) or 0
            if back <= 8 or now-self.legStart >= cfg.parkStraightenSeconds then return self:stopThen(now, "PARKED") end
        end
        local fs = sample.forwardSpeed or 0
        if fs >= -0.3 and fs < cfg.parkSpeed then cmd.gas = 255 end
        return cmd
    end

    -- All remaining phases need a route target from the plan.
    if errorDegrees == nil then return self:retry(now, "no route target") end
    -- Pushed (or slid) far away from the planned connection: that plan's
    -- reachability no longer applies; stop and plan again from here.
    if sample.connectDistance and sample.connectDistance > self:reach()+5 then
        if self.phase == "PLAN" then return self:retry(now, "route out of reach") end
        return self:stopThen(now, "RETRY", "route out of reach")
    end

    if self.phase == "PLAN" then
        if not self.plan then return cmd end
        -- Brake any remaining roll while deciding: the checks describe this spot.
        cmd = self:brakeAssist(sample, 0.6)
        -- Driving on was blocked from about here before: the car heads for
        -- the connection point itself (the line the planning checked as
        -- free), turning with manoeuvre legs first if needed. The heading
        -- error for that target arrives with the next frame.
        if self:approachBlockedHere(sample) and not self.plan.direct then
            self.plan.direct = true
            return cmd
        end
        if math.abs(errorDegrees) <= cfg.alignTolerance then self:startSettle(now); return neutral() end
        if not self.direction then
            -- Which way to turn depends on where the rear has room; wait for those checks.
            local t = type(sample.reverseClearFor) == "table" and sample.reverseClearFor or {}
            local waiting = (state(t[128]) == "pending" or state(t[-128]) == "pending")
                and now-(self.pendingSince or now) <= cfg.probePendingTimeout
            if waiting then self.pendingSince = self.pendingSince or now; return cmd end
            -- (pendingSince is kept: all waiting in PLAN shares one timeout)
            self:chooseDirection(errorDegrees, sample)
        end
        -- Reverse-then-swing: S with the lock until the forward sweep fits,
        -- then W round in one go (no stop in between). Checked as one path.
        if cfg.uturnEnabled and not self.threeTried and math.abs(errorDegrees) > 60 and not self.plan.back then
            local tp = sample.threePoint
            if tp == PENDING and now-(self.pendingSince or now) <= cfg.probePendingTimeout then
                self.pendingSince = self.pendingSince or now
                return cmd
            end
            self.threeTried = true
            if type(tp) == "table" and tp.meters and self.direction then
                self.phase = "REVERSE"
                self.legKind, self.reverseKey, self.lastLegKey = "REVERSE", self.direction, self.direction
                self.legShort, self.lastLegShort, self.flippedThisLeg, self.legPendingSince = false, false, false, nil
                self.legStart, self.legX, self.legY, self.legHeading = now, sample.x, sample.y, sample.heading
                self.legs = (self.legs or 0) + 1
                self.coasting, self.confirmed = false, nil
                self:confirm(sample, tp.meters + 0.5)
                self.thenUturn = tp.meters
                return neutral()
            end
        end
        -- Reverse spin mode: the forward one-sweep U-turn comes after
        -- reverse-then-swing (in the W-reaction mode HOLD offers it first).
        if cfg.jturnEnabled and cfg.uturnEnabled and not self.planUturnTried and not self.plan.back then
            local side = sample.uturnSide
            if side == PENDING and now-(self.pendingSince or now) <= cfg.probePendingTimeout then
                self.pendingSince = self.pendingSince or now
                return cmd
            end
            self.planUturnTried = true
            if type(side) == "number" then self.pendingSince = nil; self:startUturn(now, side, sample); return neutral() end
        end
        -- Reverse first: after a 180 degree turn the road we came along is behind us.
        local leg, pending = self:startLeg(now, sample, "REVERSE", errorDegrees)
        if pending then return cmd end
        return leg
    end

    if self.phase == "UTURN" then
        local mg, mwhy = self:motionGuard(now, sample)
        if mg == "neutral" then return neutral() end
        if not mg then return self:stopThen(now, "RETRY", mwhy) end
        if math.abs(errorDegrees) <= cfg.alignTolerance then
            -- Pointing along the route: straighten the wheels; SETTLE hands
            -- over at once when the car is stable (or drives on to the line).
            self:startSettle(now)
            return neutral()
        end
        if self:overshoot(errorDegrees) then return self:stopThen(now, "PLAN_REDO") end
        local clear = state(sample.uturnClear)
        if clear == "blocked" then return self:stopThen(now, "PLAN_REDO", "U-turn space closed") end
        if now-self.uturnStart > cfg.uturnTimeout or self.rate > 140 or (sample.slip or 0) > 50 then
            return self:stopThen(now, "PLAN_REDO", "U-turn not progressing")
        end
        local ceiling = self.uturnTight and cfg.uturnTightMaxSpeed or cfg.uturnMaxSpeed
        if sample.speed > ceiling + cfg.runawayMargin then return self:stopThen(now, "PLAN_REDO", "U-turn too fast") end
        local fs = sample.forwardSpeed or sample.speed
        -- Progress is judged only once the car actually rolls forwards.
        if fs < 1.0 or (sample.heading and self.progressHeading and math.abs(angle(sample.heading,self.progressHeading)) >= 15) then
            self.progressHeading, self.progressAt = sample.heading, now
        elseif now-self.progressAt > 1.5 then
            return self:stopThen(now, "PLAN_REDO", "U-turn not progressing")
        end
        cmd.steer = self.direction
        if self.uturnNeedsCheck then
            if clear == "clear" then
                self.uturnNeedsCheck = nil
            else
                -- (pending) W only brakes the backwards roll meanwhile.
                self.legPendingSince = self.legPendingSince or now
                if now-self.legPendingSince > cfg.probePendingTimeout then return self:stopThen(now, "PLAN_REDO", "U-turn check incomplete") end
                if (sample.forwardSpeed or 0) < -0.3 then cmd.gas = 255 end
                return cmd
            end
        end
        if clear == "pending" then
            -- The whole sweep was confirmed before the turn started; a rolling
            -- re-check that is still running keeps W for legPendingSeconds,
            -- then the car coasts on full lock until it completes.
            self.legPendingSince = self.legPendingSince or now
            local waited = now-self.legPendingSince
            if waited > cfg.probePendingTimeout then return self:stopThen(now, "PLAN_REDO", "U-turn check incomplete") end
            if waited > cfg.legPendingSeconds then
                if (sample.forwardSpeed or 0) < -1.0 then cmd.gas = 255 end -- still brake a backwards roll
                return cmd
            end
        else
            self.legPendingSince = nil
        end
        return self:drive(now, cmd, sample, 1, ceiling, cfg.forwardPower)
    end

    if self.phase == "SETTLE" then
        -- Wheels straight. Brake only what stands in the way of a clean
        -- handoff (too fast, sliding, rolling backwards); a stable car keeps
        -- its speed and is handed over without stopping.
        -- 35 degrees, or right after an early straighten the error it started
        -- with (+5) while that is still converging.
        local limit = 35
        if self.settleEntryErr and now-(self.settleSince or now) < cfg.settleConvergeSeconds then
            limit = math.max(35, math.min(70, self.settleEntryErr+5))
        end
        if math.abs(errorDegrees) > limit then
            if now-(self.settleStarted or now) > cfg.settleTimeout then return self:retry(now, "could not settle") end
            return self:stopThen(now, "PLAN_REDO", "heading drifted while settling")
        end
        local fs = sample.forwardSpeed or sample.speed
        local back = self.plan and self.plan.back
        if fs < -0.3 then cmd.gas = 255 -- brake a backwards roll (released at -0.3: never starts a move)
        elseif fs > 1.0 and (back or sample.speed > cfg.handoffMaxSpeed or lateralOf(sample) > cfg.handoffLateral) then cmd.brake = 255 end
        local cd = sample.connectDistance
        local far = cd ~= nil and cd > cfg.connectDistance
        -- A recorded reverse section is joined only from near it: driving
        -- forwards (APPROACH) would take the car away from it.
        if far and back then return self:stopThen(now, "RETRY", "reverse section too far to join") end
        local steady, unsteady = self:stable(sample)
        if not steady then
            -- Calm the car down first; nothing else happens while it slides or yaws.
            self.handoffSince, self.handoffWhy = nil, unsteady
            if now-(self.settleStarted or now) > cfg.settleTimeout then return self:retry(now, "could not settle: " .. unsteady) end
            return cmd
        end
        local ok, why = self:handoffCheck(now, sample, errorDegrees, far)
        if ok then
            if far then self:startApproach(now, cd); return neutral() end
            return neutral(), "ready"
        end
        if why == "heading" or why == "route direction" then
            -- Stable but not aligned enough: steer in gently while rolling.
            self:startApproach(now, cd)
            return neutral()
        end
        if now-(self.settleStarted or now) > cfg.settleTimeout then return self:retry(now, "could not settle: " .. tostring(why)) end
        return cmd
    end

    if self.phase == "APPROACH" then
        local cd = sample.connectDistance
        if not cd then return self:stopThen(now, "RETRY", "route target lost") end
        local mg, mwhy = self:motionGuard(now, sample)
        if mg == "neutral" then return neutral() end
        if not mg then return self:stopThen(now, "RETRY", mwhy) end
        if math.abs(errorDegrees) > 70 then return self:stopThen(now, "PLAN_REDO") end
        -- The v5.77 corridor and the stopping distance at the current speed.
        local clear = state(sample.clear)
        local ahead = sample.aheadClear == nil and "clear" or state(sample.aheadClear)
        -- Only the path the car drives counts (straight ahead for the stopping
        -- distance, with the front corners): a wall or kerb alongside the
        -- body, which the car is not driving into, does not block it.
        if ahead == "blocked" then
            self:noteApproachBlocked(sample)
            return self:stopThen(now, "RETRY", "approach blocked")
        end
        clear = ahead
        if now-self.approachStart > cfg.approachTimeout then return self:stopThen(now, "RETRY", "approach timeout") end
        local zone = cd <= cfg.connectDistance
        if zone or cd < self.bestConnect-0.5 then self.bestConnect, self.progressAt = math.min(self.bestConnect, cd), now
        elseif now-self.progressAt > cfg.approachProgressSeconds then return self:stopThen(now, "RETRY", "approach made no progress") end
        if lateralOf(sample) > 2.5 or ((sample.slip or 0) > 50 and sample.speed > 3) then
            -- Lost grip on the way back (its own steering pulses yaw the car,
            -- so only a real sideways slide counts): straighten and calm down.
            self:startSettle(now)
            return neutral()
        end
        if self:handoffCheck(now, sample, errorDegrees) then return neutral(), "ready" end
        -- Steer by the aim point; when that is fine but the car does not
        -- travel the route's way at the connection (a bend or a crossing),
        -- steer by the route direction instead. Only both together count as
        -- lined up (then the wheels stay straight for the dwell).
        local routeErr = sample.routeHeadingError
        local routeBad = routeErr ~= nil and math.abs(routeErr) > cfg.handoffRouteHeading
        local steerErr = errorDegrees
        if routeBad and math.abs(errorDegrees) <= cfg.handoffHeading then steerErr = routeErr end
        local aligned = zone and math.abs(errorDegrees) <= cfg.handoffHeading and not routeBad
        if not aligned and math.abs(steerErr) > 8 then
            local wanted = steerErr < 0 and -128 or 128
            if self.pulseDir == 0 and now >= self.pulseRest then
                self.pulseDir = wanted
                self.pulseUntil = now + math.min(0.3, 0.1+math.abs(steerErr)*0.004)
            end
        end
        if self.pulseDir ~= 0 then
            if not aligned and now < self.pulseUntil and steerErr*self.pulseDir > 0 then cmd.steer = self.pulseDir
            else self.pulseDir = 0; self.pulseRest = now+0.15 end
        end
        if clear == "pending" then
            if self:legPending(now) then return self:stopThen(now, "RETRY", "approach check incomplete") end
            return cmd -- coast until the corridor ahead is confirmed
        end
        self.legPendingSince = nil
        -- W held; lower ceiling while still turning towards the line.
        local ceiling = math.abs(errorDegrees) > 25 and cfg.approachTurnSpeed or cfg.approachMaxSpeed
        if self.handoffWhy == "too fast" then ceiling = math.min(ceiling, cfg.handoffMaxSpeed - cfg.coastBand) end
        return self:drive(now, cmd, sample, 1, ceiling, cfg.forwardPower)
    end

    if self.phase == "REVERSE" or self.phase == "ALIGN" then
        local mg, mwhy = self:motionGuard(now, sample)
        if mg == "neutral" then return neutral() end
        if not mg then return self:stopThen(now, "RETRY", mwhy) end
        if self:overshoot(errorDegrees) then return self:stopThen(now, "PLAN_REDO") end
        if math.abs(errorDegrees) <= cfg.alignTolerance then return self:stopThen(now, "SETTLE") end
        if self.rate > 140 or (sample.slip or 0) > 50 then return self:stopThen(now, "RETRY", "manoeuvre unstable") end
        local moved = distance(sample.x,sample.y,self.legX,self.legY)
        local elapsed = now-self.legStart
        if self.phase == "REVERSE" then
            -- Reverse-then-swing: far enough back (counting the distance W
            -- needs to stop the car), swing round forwards now. W first brakes
            -- the backwards roll, then drives the sweep.
            if self.thenUturn and moved + stopping(sample) + 0.2 >= self.thenUturn then
                local side = self.direction
                self.thenUturn = nil
                self:startUturn(now, side, sample, true)
                -- The swing starts from where the reverse really ended:
                -- no forward power until that pose is checked again.
                self.uturnNeedsCheck = true
                cmd.steer = self.direction
                if (sample.forwardSpeed or 0) < 0 then cmd.gas = 255 end
                return cmd
            end
            local rc = state(sample.reverseClear)
            if rc == "blocked" then
                -- Rear about to meet something on this side: keep reversing
                -- but swing the rear the other way (opposite lock), if free.
                local clearFor = (self.legShort and sample.shortReverseFor or sample.reverseClearFor) or {}
                if self.reverseKey ~= 0 and self.direction and state(clearFor[-self.direction]) == "clear"
                    and math.abs(errorDegrees) >= 100 and not self.flipUsed then
                    self.direction = -self.direction
                    self.reverseKey = self.direction
                    self.lastLegKey = self.direction
                    self.sideSwitched = true
                    self.flipUsed = true
                    self.thenUturn = nil
                    rc = "clear"
                else
                    self.thenUturn = nil
                    return self:endLeg(now, sample, "reverse blocked")
                end
            end
            local legMeters = self.thenUturn or (self.legShort and 1.2 or cfg.legReverseMeters)
            if elapsed >= cfg.legReverseSeconds or moved >= legMeters + 0.3 then self.thenUturn = nil; return self:endLeg(now, sample) end
            if sample.speed > cfg.reverseMaxSpeed + cfg.runawayMargin then self.thenUturn = nil; return self:endLeg(now, sample, "reverse too fast") end
            cmd.steer = self.reverseKey == 0 and 0 or -self.direction
            if rc == "clear" then
                self.legPendingSince = nil
                self:confirm(sample, 0.6)
            elseif not self:onConfirmed(sample) then
                -- Past the confirmed space and the re-check is still running: no S.
                if self:legPending(now) then self.thenUturn = nil; return self:endLeg(now, sample, "reverse check incomplete") end
                if (sample.forwardSpeed or 0) < -cfg.reverseMaxSpeed - cfg.coastBand then cmd.gas = 255 end
                return cmd
            end
            return self:drive(now, cmd, sample, -1, cfg.reverseMaxSpeed, cfg.reversePower)
        end
        local fc
        if self.alignKey == 0 then fc = state(self.legShort and sample.straightShortClear or sample.straightClear)
        else fc = self:forwardOk(sample, self.legShort) end
        if fc == "blocked" then return self:endLeg(now, sample, "forward blocked") end
        if elapsed >= cfg.legForwardSeconds or moved >= (self.legShort and 1.2 or cfg.legForwardMeters) then return self:endLeg(now, sample) end
        if sample.speed > cfg.forwardMaxSpeed + cfg.runawayMargin then return self:endLeg(now, sample, "forward too fast") end
        cmd.steer = self.alignKey == 0 and 0 or self.direction
        if fc == "clear" then
            self.legPendingSince = nil
            self:confirm(sample, 0.6)
        elseif not self:onConfirmed(sample) then
            if self:legPending(now) then return self:endLeg(now, sample, "forward check incomplete") end
            if (sample.forwardSpeed or 0) < -1.0 then cmd.gas = 255 end
            return cmd -- no W until the space ahead is confirmed
        end
        return self:drive(now, cmd, sample, 1, cfg.forwardMaxSpeed, cfg.forwardPower)
    end

    return cmd
end

return R
