-- Dangis VR 5.77.6 passage check for ordinary driving. No game APIs: the main
-- script injects the line and ground tests (the rotation-recovery probes).
--
-- The path the car is about to drive (route line, plus a side offset and the
-- way into and back out of it) is a list of points. Each piece between two
-- points is checked with body-height lines along the car's centre and both
-- sides, and with ground samples where the path leaves the recorded line.
-- Every piece ends up in one of three states:
--   CLEAR     every check ran and nothing is in the way
--   BLOCKED   something solid is in the way (distance along the piece known)
--   UNKNOWN   not verified: no collision API, a failed query, not checked yet
--             (frame budget used up) or the answer is too old
-- UNKNOWN is never CLEAR. The result is the distance from the car's front that
-- is verified clear, and why it ends there.
--
-- Answers are cached per piece (keyed by its geometry) and refreshed in the
-- background before they expire; the number of line-of-sight calls per frame
-- is bounded.
local P = {}
P.__index = P
P.CLEAR, P.BLOCKED, P.UNKNOWN = "clear", "blocked", "unknown"

-- deps.line(ax,ay,az,bx,by,bz,allowance) -> true | false | nil | "more", calls, hit
-- deps.ground(x,y,zref) -> true | false | nil, height, calls
-- deps.clock() -> seconds
function P.new(deps)
    return setmetatable({line = deps.line, ground = deps.ground, clock = deps.clock, cache = {},
        stats = {calls = 0, frameCalls = 0, maxFrameCalls = 0, frames = 0}}, P)
end

function P:reset()
    self.cache = {}
end

local function key(a, b, piece)
    return string.format("%.1f:%.1f:%.1f:%.1f:%s:%d:%s", a.x, a.y, b.x, b.y, piece.tag or "", #piece.heights,
        b.ground and "g" or "")
end

-- The checks of one piece, in order (cheap centre line first).
local function checks(a, b, piece)
    local list = {}
    local dx, dy = b.x - a.x, b.y - a.y
    local len = math.sqrt(dx * dx + dy * dy)
    if len < 0.05 then return list, len end
    local lx, ly = -dy / len, dx / len
    for _, h in ipairs(piece.heights) do
        for _, side in ipairs({0, 1, -1}) do
            local w = side * piece.width
            list[#list+1] = {a.x + lx * w, a.y + ly * w, a.z + h, b.x + lx * w, b.y + ly * w, b.z + h}
        end
    end
    if b.ground then list[#list+1] = {g = true, b.x, b.y, b.zref or b.z} end
    return list, len
end

-- Runs (part of) one piece's checks within `allowance` calls. Returns the
-- calls used. entry.state becomes CLEAR / BLOCKED / UNKNOWN when finished.
function P:work(entry, allowance, now)
    local used = 0
    while entry.i <= #entry.checks do
        if used >= allowance then return used end
        local c = entry.checks[entry.i]
        local ok, calls, extra
        if c.g then
            ok, extra, calls = self.ground(c[1], c[2], c[3])
            calls = calls or 1
            if ok == true and type(extra) == "number" and entry.zref
                and (extra < c[3] - entry.drop or extra > c[3] + entry.rise) then
                ok = false
            end
            if ok == false then entry.hit = {x = c[1], y = c[2], what = "no ground"} end
        else
            ok, calls, extra = self.line(c[1], c[2], c[3], c[4], c[5], c[6], allowance - used)
            if ok == false then
                entry.hit = extra or {x = c[4], y = c[5]}
                local len = math.sqrt((c[4] - c[1])^2 + (c[5] - c[2])^2)
                local t = len > 0 and (((entry.hit.x or c[4]) - c[1]) * (c[4] - c[1]) + ((entry.hit.y or c[5]) - c[2]) * (c[5] - c[2])) / (len * len) or 0
                entry.t = math.min(entry.t or 1, math.max(0, math.min(1, t)))
            end
        end
        calls = (type(calls) == "number" and calls >= 1) and calls or 1
        used = used + calls
        if ok == "more" then return used end
        if ok == nil then
            entry.state, entry.at = P.UNKNOWN, now
            entry.reason = (extra == "api" and "collision API unavailable")
                or (extra == "unfinished" and "check could not be finished (too many surfaces)") or "collision query failed"
            entry.failed = true
            return used
        end
        if ok == false then
            entry.state, entry.at = P.BLOCKED, now
            entry.reason = c.g and "no ground under the path" or "solid obstacle"
            return used
        end
        entry.i = entry.i + 1
    end
    entry.state, entry.at, entry.reason = P.CLEAR, now, nil
    return used
end

-- plan = {points={ {x,y,z[,ground,zref]}... }, width=, heights={...},
--   need=metres to verify, budget=calls, ttl=function(s) -> seconds,
--   drop=, rise= (ground tolerance), tag=geometry tag}
-- points[1] is the car's front; s is measured from it.
-- Returns {state=, clear=metres, reason=, hit=, pending=, calls=}.
function P:evaluate(plan)
    local now = self.clock()
    local budget = plan.budget or 40
    local used = 0
    local pts = plan.points
    local result = {state = P.CLEAR, clear = 0, reason = nil}
    local s = 0
    local decided = false
    local refresh = {}
    for i = 1, #pts - 1 do
        if s >= plan.need then break end
        local a, b = pts[i], pts[i + 1]
        local piece = {width = plan.width, heights = b.heights or plan.heights, tag = plan.tag}
        local k = key(a, b, piece)
        local entry = self.cache[k]
        local ttl = plan.ttl and plan.ttl(s) or 0.5
        if entry and entry.state and now - entry.at > ttl then
            -- Too old to be an answer: a finished refresh replaces it, else
            -- the refresh still running (or a new check) is what counts.
            entry = entry.next
            if entry and entry.state then entry.next = nil end
            self.cache[k] = entry
        end
        if entry and entry.failed and now - entry.at > 0.1 then
            entry = nil; self.cache[k] = nil          -- retry a failed query next frame
        end
        if not entry then
            local list, len = checks(a, b, piece)
            entry = {checks = list, i = 1, len = len, zref = b.zref or a.zref, drop = plan.drop or 1.5, rise = plan.rise or 1.0,
                created = now}
            if #list == 0 then entry.state, entry.at = P.CLEAR, now end
            self.cache[k] = entry
        end
        if entry.state and now - entry.at > ttl * 0.5 and not entry.next then refresh[#refresh+1] = {k, a, b, piece} end
        if not entry.state then
            if used < budget then used = used + self:work(entry, budget - used, now) end
        end
        if not decided then
            if entry.state == P.CLEAR then
                s = s + entry.len
                result.clear = s
            elseif entry.state == P.BLOCKED then
                result.state, result.reason, result.hit = P.BLOCKED, entry.reason, entry.hit
                result.offset = b.offset
                result.clear = s + entry.len * (entry.t or 0)
                decided = true
            else
                result.state = P.UNKNOWN
                result.reason = entry.state == P.UNKNOWN and entry.reason or "not checked yet (scan budget)"
                result.pending = entry.state == nil
                decided = true
            end
        end
        if decided then break end
    end
    -- The path ended (route end, reverse section) before `need`: nothing
    -- beyond it is driven by the route, so it is not a shortfall.
    if not decided and result.clear < plan.need then result.ended = true end
    -- Background refreshes of answers in use, nearest first.
    for _, r in ipairs(refresh) do
        if used >= budget then break end
        local k, a, b, piece = r[1], r[2], r[3], r[4]
        local old = self.cache[k]
        local list, len = checks(a, b, piece)
        local nextEntry = old.next or {checks = list, i = 1, len = len, zref = b.zref or a.zref, drop = plan.drop or 1.5,
            rise = plan.rise or 1.0, created = now}
        old.next = nextEntry
        used = used + self:work(nextEntry, budget - used, now)
        if nextEntry.state then self.cache[k] = nextEntry end
    end
    -- Forget pieces far behind or unused for a while.
    local n = 0
    for k, entry in pairs(self.cache) do
        n = n + 1
        if now - (entry.at or entry.created or now) > 3.0 then self.cache[k] = nil end
    end
    if n > 400 then self.cache = {} end
    result.calls = used
    local st = self.stats
    st.calls = st.calls + used
    st.frames = st.frames + 1
    st.frameCalls = used
    if used > st.maxFrameCalls then st.maxFrameCalls = used end
    return result
end

-- Highest speed (m/s) from which the car can stop within `dist` metres:
-- v^2/(2a) + v*reaction = dist - margin.
function P.speedFor(dist, decel, reaction, margin)
    local d = math.max(0, dist - (margin or 0))
    return decel * (-reaction + math.sqrt(reaction * reaction + 2 * d / decel))
end

-- Distance needed to stop from `speed`.
function P.stopDistance(speed, decel, reaction, margin)
    speed = math.max(0, speed)
    return speed * speed / (2 * decel) + speed * reaction + (margin or 0)
end

return P
