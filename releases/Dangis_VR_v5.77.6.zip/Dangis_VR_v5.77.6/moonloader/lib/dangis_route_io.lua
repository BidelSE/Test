-- Dangis VR 5.77.6 route files: strict parsing and checked saving.
--
-- File format (unchanged since v5.49, one point per line):
--   {x}:{y}:{z}:{speed}:{heading}:{FWD|BACK}
-- Older files are still read: the 5-field form (no drive mode) and the
-- 3-field form {x}:{y}:{speed}. Saved files end with "#end <points>": older
-- versions ignore that line, and it lets a truncated file be recognised.
--
-- A file is rejected as a whole (never silently patched) when a line is not
-- one of those forms, a number is not finite (nan, inf, 1e999), a value is
-- outside the ranges below, a drive mode is unknown, or the end marker does
-- not match the number of points.
--
-- Saving never deletes the last valid route before a verified backup exists:
--   1. the new route is written to <name>.txt.tmp and read back;
--   2. a valid current <name>.txt is copied to <name>.txt.bak (read back);
--   3. only then <name>.txt is replaced by the new file.
-- Loading uses <name>.txt, else a complete <name>.txt.tmp (end marker
-- required), else <name>.txt.bak.
local IO = {}

IO.LIMITS = {xy = 20000.0, z = 10000.0, speed = 200.0, heading = 3600.0}
IO.MIN_POINTS = 2
IO.MAX_POINTS = 200000

-- File operations; tests replace entries to inject failures.
IO.fs = {
    open = function(path, mode) return io.open(path, mode) end,
    remove = function(path) return os.remove(path) end,
    rename = function(from, to) return os.rename(from, to) end,
}

local BACK = {BACK=true, B=true, R=true, REV=true, REVERSE=true, ["1"]=true, TRUE=true}
local FWD = {FWD=true, FORWARD=true, F=true, ["0"]=true, FALSE=true, [""]=true}

function IO.finite(value)
    return type(value) == "number" and value == value and value ~= math.huge and value ~= -math.huge
end

-- "FWD"/"BACK" for a known drive token (string, boolean or 0/1), else nil.
function IO.driveToken(value)
    if value == true or value == 1 then return "BACK" end
    if value == false or value == 0 or value == nil then return "FWD" end
    local text = tostring(value):upper():match("^%s*(.-)%s*$")
    if BACK[text] then return "BACK" end
    if FWD[text] then return "FWD" end
    return nil
end

local function number(text)
    local value = tonumber((tostring(text):match("^%s*(.-)%s*$")))
    if not IO.finite(value) then return nil end
    return value
end

function IO.validatePoint(p)
    if type(p) ~= "table" then return false, "not a point" end
    local L = IO.LIMITS
    for _, key in ipairs({"x", "y", "z", "speed", "heading"}) do
        if not IO.finite(p[key]) then return false, key .. " is not a finite number" end
    end
    if math.abs(p.x) > L.xy or math.abs(p.y) > L.xy then return false, "coordinates outside the map" end
    if math.abs(p.z) > L.z then return false, "height outside the map" end
    if math.abs(p.speed) > L.speed then return false, "speed out of range" end
    if math.abs(p.heading) > L.heading then return false, "heading out of range" end
    if p.reverse ~= nil and type(p.reverse) ~= "boolean" then return false, "bad reverse flag" end
    if p.drive ~= nil and (type(p.drive) ~= "string" or not IO.driveToken(p.drive)) then return false, "unknown drive mode" end
    return true
end

function IO.validate(route)
    if type(route) ~= "table" then return false, "no route" end
    if #route < IO.MIN_POINTS then return false, "fewer than " .. IO.MIN_POINTS .. " points" end
    if #route > IO.MAX_POINTS then return false, "too many points" end
    for i, p in ipairs(route) do
        local ok, err = IO.validatePoint(p)
        if not ok then return false, "point " .. i .. ": " .. err end
    end
    return true
end

local function point(x, y, z, speed, heading, drive)
    return {x=x, y=y, z=z, speed=speed, heading=heading, drive=drive, reverse=drive == "BACK"}
end

-- Returns route, info or nil, reason. info.marker tells whether the file
-- carried the end marker (files from 5.77.6 on).
function IO.parse(text)
    if type(text) ~= "string" then return nil, "no data" end
    local route, marker, lineNumber = {}, nil, 0
    for raw in (text .. "\n"):gmatch("([^\n]*)\n") do
        lineNumber = lineNumber + 1
        local line = raw:gsub("\r$", "")
        if line:match("^%s*$") then
            -- blank lines are ignored (also the file's final newline)
        elseif marker then
            return nil, "line " .. lineNumber .. ": data after the end marker"
        else
            local count = line:match("^#end%s+(%d+)%s*$")
            if count then
                marker = tonumber(count)
            else
                local f = {}
                for field in line:gmatch("{([^{}]*)}") do f[#f+1] = field end
                local rebuilt = #f > 0 and ("{" .. table.concat(f, "}:{") .. "}") or nil
                if rebuilt ~= line then return nil, "line " .. lineNumber .. ": malformed" end
                local p
                if #f == 6 or #f == 5 then
                    local x, y, z, speed, heading = number(f[1]), number(f[2]), number(f[3]), number(f[4]), number(f[5])
                    local drive = "FWD"
                    if #f == 6 then drive = IO.driveToken(f[6]) end
                    if not (x and y and z and speed and heading) then
                        return nil, "line " .. lineNumber .. ": a value is not a finite number"
                    end
                    if not drive then return nil, "line " .. lineNumber .. ": unknown drive mode" end
                    p = point(x, y, z, speed, heading, drive)
                elseif #f == 3 then
                    local x, y, speed = number(f[1]), number(f[2]), number(f[3])
                    if not (x and y and speed) then return nil, "line " .. lineNumber .. ": a value is not a finite number" end
                    p = point(x, y, 0, speed, 0, "FWD")
                else
                    return nil, "line " .. lineNumber .. ": expected 3, 5 or 6 fields"
                end
                local ok, err = IO.validatePoint(p)
                if not ok then return nil, "line " .. lineNumber .. ": " .. err end
                route[#route+1] = p
                if #route > IO.MAX_POINTS then return nil, "too many points" end
            end
        end
    end
    if marker and marker ~= #route then
        return nil, string.format("end marker says %d points, file has %d (truncated)", marker, #route)
    end
    local ok, err = IO.validate(route)
    if not ok then return nil, err end
    return route, {marker = marker ~= nil, count = #route}
end

-- Same text as earlier versions (tostring of each value) plus the marker.
function IO.serialize(route)
    local lines = {}
    for i, p in ipairs(route) do
        lines[i] = string.format("{%s}:{%s}:{%s}:{%s}:{%s}:{%s}", p.x, p.y, p.z, p.speed, p.heading,
            IO.driveToken(p.drive or p.reverse) or "FWD")
    end
    lines[#lines+1] = "#end " .. #route
    return table.concat(lines, "\n") .. "\n"
end

function IO.read(path)
    local ok, file = pcall(IO.fs.open, path, "r")
    if not ok or not file then return nil end
    local readOk, text = pcall(file.read, file, "*a")
    pcall(file.close, file)
    if not readOk or type(text) ~= "string" then return nil end
    return text
end

-- Writes text and reads it back; every step's result is checked.
function IO.writeVerified(path, text)
    local ok, file, openErr = pcall(IO.fs.open, path, "w")
    if not ok or not file then return false, "cannot open " .. path .. ": " .. tostring(openErr or file) end
    local wOk, written, writeErr = pcall(file.write, file, text)
    local fOk, flushed, flushErr = pcall(file.flush, file)
    local cOk, closed, closeErr = pcall(file.close, file)
    if not (wOk and written) then return false, "write failed: " .. tostring(writeErr or written) end
    if not (fOk and flushed) then return false, "flush failed: " .. tostring(flushErr or flushed) end
    if not (cOk and closed) then return false, "close failed: " .. tostring(closeErr or closed) end
    if IO.read(path) ~= text then return false, "read-back of " .. path .. " differs" end
    return true
end

local function exists(path)
    local ok, file = pcall(IO.fs.open, path, "r")
    if ok and file then pcall(file.close, file); return true end
    return false
end

-- Moves `from` to `to` (to may exist); falls back to a verified copy.
local function replace(from, to, text)
    IO.fs.remove(to)
    local ok = IO.fs.rename(from, to)
    if ok and IO.read(to) == text then return true end
    if exists(to) and IO.read(to) ~= text then IO.fs.remove(to) end
    local copied, err = IO.writeVerified(to, text)
    if not copied then return false, err end
    IO.fs.remove(from)
    return true
end

-- Returns true, notes or false, reason. On failure the previous valid route
-- is still in <path> (or, if replacing it failed half-way, in <path>.bak and
-- the new one in <path>.tmp; loading picks a valid one).
function IO.save(path, route)
    local ok, err = IO.validate(route)
    if not ok then return false, "invalid route, not saved: " .. err end
    local text = IO.serialize(route)
    local tmp, bak, bakTmp = path .. ".tmp", path .. ".bak", path .. ".bak.tmp"
    local wrote, writeErr = IO.writeVerified(tmp, text)
    if not wrote then IO.fs.remove(tmp); return false, writeErr end
    local notes = {}
    local oldText = IO.read(path)
    local oldValid = oldText and IO.parse(oldText) ~= nil
    if oldValid then
        local copied, copyErr = IO.writeVerified(bakTmp, oldText)
        local moved, moveErr = false, copyErr
        if copied then moved, moveErr = replace(bakTmp, bak, oldText) end
        if not moved then
            IO.fs.remove(bakTmp); IO.fs.remove(tmp)
            return false, "backup failed, previous route kept: " .. tostring(moveErr)
        end
    elseif oldText then
        notes[#notes+1] = "previous file was invalid and was not backed up"
    end
    local replaced, replaceErr = replace(tmp, path, text)
    if not replaced then
        -- The previous route is in .bak (verified) and the new one in .tmp.
        if oldValid and not exists(path) then IO.writeVerified(path, oldText) end
        return false, "could not replace route file: " .. tostring(replaceErr)
    end
    return true, notes
end

-- Returns route, source ("main"/"tmp"/"bak") and a list of problems found,
-- or nil and the problems.
function IO.load(path)
    local problems = {}
    local function try(file, label, needMarker)
        local text = IO.read(file)
        if not text then return nil end
        local route, info = IO.parse(text)
        if route and needMarker and not info.marker then
            problems[#problems+1] = label .. ": no end marker (unfinished save), ignored"
            return nil
        end
        if not route then problems[#problems+1] = label .. ": " .. tostring(info) end
        return route
    end
    local route = try(path, "route file")
    if route then return route, "main", problems end
    route = try(path .. ".tmp", "unfinished save (.tmp)", true)
    if route then return route, "tmp", problems end
    route = try(path .. ".bak", "backup (.bak)")
    if route then return route, "bak", problems end
    return nil, problems
end

return IO
