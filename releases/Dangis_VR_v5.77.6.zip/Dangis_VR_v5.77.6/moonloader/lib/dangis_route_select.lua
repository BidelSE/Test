-- Dangis VR 5.78 recovery route selection. Pure geometry, no game APIs.
--
-- Used only while a rotation incident owns the controls. It never changes the
-- active route during ordinary driving and never invents a connection: a
-- candidate is accepted only when the injected reachability probe confirms a
-- straight, car-wide, obstacle-free corridor with ground under it (for the
-- route that was already active, an unavailable probe keeps the v5.77
-- behaviour of trusting the bounded nearby rejoin).
--
--   S.choose(entries, car, options) -> plan or nil, report
--     entries : {{name=, route=, current=bool, from=index}, ...}
--     car     : {x=, y=, z=, heading=}
--     options : searchDistance, switchPenalty, turnWeight, lockName,
--               penalties={name=extra}, reachable=function(car,point)->true|false|nil,
--               maxProbes, currentAhead
--   S.track(plan, x, y) -> index, connectDistance
--   S.aim(plan, x, y, heading) -> errorDegrees, aimX, aimY
local S = {}

local atan2 = math.atan2 or math.atan
local function angle(a,b) return (a-b+180)%360-180 end
local function heading(dx,dy) return (math.deg(atan2(-dx,dy))+360)%360 end
local function dist(ax,ay,bx,by) return math.sqrt((ax-bx)^2+(ay-by)^2) end
S.heading = heading

function S.isBack(point)
    if type(point) ~= "table" then return false end
    local mode = point.drive or point.mode or point.reverse
    if mode == true or mode == 1 then return true end
    mode = tostring(mode or ""):upper()
    return mode == "BACK" or mode == "B" or mode == "R" or mode == "REV" or mode == "REVERSE" or mode == "1" or mode == "TRUE"
end

-- Finite coordinates only (NaN and +-inf are rejected).
local function finite(v) return type(v) == "number" and v == v and v > -1e7 and v < 1e7 end
S.finite = finite
local function valid(point)
    return type(point) == "table" and finite(point.x) and finite(point.y)
end

-- Direction of travel at i on its own drive-mode leg and the length of that
-- leg still ahead (bounded). Nil when the point has no usable tangent.
function S.tangent(route, i, limit)
    local p = route[i]
    if not valid(p) then return nil end
    local back = S.isBack(p)
    local dx, dy
    for j = i+1, math.min(#route, i+40) do
        local q = route[j]
        if not valid(q) or S.isBack(q) ~= back then break end
        if dist(p.x,p.y,q.x,q.y) >= 1.5 then dx, dy = q.x-p.x, q.y-p.y; break end
    end
    if not dx then
        for j = i-1, math.max(1, i-40), -1 do
            local q = route[j]
            if not valid(q) or S.isBack(q) ~= back then break end
            if dist(p.x,p.y,q.x,q.y) >= 1.5 then dx, dy = p.x-q.x, p.y-q.y; break end
        end
    end
    if not dx then return nil end
    local length = math.sqrt(dx*dx+dy*dy)
    local ahead, previous = 0, p
    limit = limit or 60
    for j = i+1, #route do
        local q = route[j]
        if not valid(q) or S.isBack(q) ~= back then break end
        ahead = ahead + dist(previous.x,previous.y,q.x,q.y)
        previous = q
        if ahead >= limit then break end
    end
    return dx/length, dy/length, ahead, back
end

-- Point roughly `meters` further along the same drive-mode leg.
function S.ahead(route, i, meters)
    local p = route[i]
    local back = S.isBack(p)
    local travelled, previous, index = 0, p, i
    for j = i+1, #route do
        local q = route[j]
        if not valid(q) or S.isBack(q) ~= back then break end
        local step = dist(previous.x,previous.y,q.x,q.y)
        if travelled+step >= meters then
            local t = step > 0.0001 and (meters-travelled)/step or 0
            return previous.x+(q.x-previous.x)*t, previous.y+(q.y-previous.y)*t, j
        end
        travelled, previous, index = travelled+step, q, j
    end
    return previous.x, previous.y, index
end

local function candidatesFor(entry, car, options, out)
    local route = entry.route
    if type(route) ~= "table" or #route < 2 then return end
    local first, last = 1, #route
    if entry.current then
        first = math.max(1, math.min(#route, entry.from or 1))
        last = math.min(#route, first + (entry.ahead or options.currentAhead or 512))
    end
    local radius = options.searchDistance or 28
    local found = {}
    for i = first, last do
        local p = route[i]
        if valid(p) then
            local d = dist(car.x,car.y,p.x,p.y)
            if d <= radius then
                local tx, ty, aheadLength, back = S.tangent(route, i, 60)
                -- Other routes: only forward legs with real road ahead of the
                -- connection; never a reverse section, a route end or a stub.
                local usable = tx ~= nil and (entry.current or (not back and aheadLength >= (options.minLegAhead or 25)))
                if usable then
                    local face = heading(tx,ty) + (back and 180 or 0)
                    local turn = math.abs(angle(car.heading, face))
                    -- A point the car has already passed along the route direction costs more.
                    local along = (car.x-p.x)*tx + (car.y-p.y)*ty
                    if back then along = -along end
                    local passed = along > 2 and along*0.5 or 0
                    local score = d + turn/180*(options.turnWeight or 30) + passed
                        + (entry.current and 0 or (options.switchPenalty or 12))
                        + ((options.penalties and options.penalties[entry.name]) or 0)
                    if options.lockName and entry.name ~= options.lockName then score = score + (options.switchPenalty or 12) end
                    found[#found+1] = {entry=entry, index=i, distance=d, turn=turn, score=score, back=back, x=p.x, y=p.y, z=p.z or car.z}
                end
            end
        end
    end
    table.sort(found, function(a,b) return a.score < b.score end)
    -- Keep a few well separated options per route (a route may pass twice).
    local kept = {}
    for _, item in ipairs(found) do
        local separate = true
        for _, other in ipairs(kept) do
            if math.abs(other.index-item.index) < 12 then separate = false; break end
        end
        if separate then kept[#kept+1] = item; out[#out+1] = item end
        if #kept >= 6 then break end
    end
end

function S.choose(entries, car, options)
    options = options or {}
    local all = {}
    for _, entry in ipairs(entries or {}) do candidatesFor(entry, car, options, all) end
    table.sort(all, function(a,b)
        if math.abs(a.score-b.score) > 0.001 then return a.score < b.score end
        return (a.entry.current and 1 or 0) > (b.entry.current and 1 or 0)
    end)
    local report = {}
    local rejected = {}
    local probes = 0
    for _, item in ipairs(all) do
        local verdict
        local key = tostring(item.entry.name) .. "#" .. item.index
        if options.skip and options.skip[key] then
            -- Rejected on an earlier attempt from about here: other
            -- candidates get their turn instead of the same top choices.
            verdict = "skipped (rejected on an earlier attempt)"
        elseif probes >= (options.maxProbes or 8) then
            verdict = "not probed"
        else
            probes = probes + 1
            local ok, reason = nil, "probe unavailable"
            if options.reachable then ok, reason = options.reachable(car, item) end
            if ok == true then verdict = "reachable"
            elseif ok == nil and item.entry.current then verdict = "accepted (v5.77 bounded rejoin; probe unavailable)"
            else
                verdict = "rejected: " .. tostring(reason or (ok == nil and "reachability unknown" or "blocked"))
                rejected[#rejected+1] = key
            end
        end
        report[#report+1] = string.format("%s#%d d=%.1f turn=%.0f score=%.1f %s", tostring(item.entry.name), item.index,
            item.distance, item.turn, item.score, verdict)
        if verdict == "reachable" or verdict:find("^accepted") then
            local plan = {name=item.entry.name, route=item.entry.route, current=item.entry.current == true,
                index=item.index, back=item.back, score=item.score, distance=item.distance, turn=item.turn}
            return plan, report, rejected
        end
    end
    if #all == 0 then report[#report+1] = "no recorded point within search distance" end
    return nil, report, rejected
end

-- Follow the chosen connection as the car moves, within the contiguous
-- drive-mode leg it belongs to (never across a recorded reverse section or
-- into a later pass of the same mode).
function S.track(plan, x, y)
    local route = plan.route
    local back = plan.back
    local lo, hi = plan.index, plan.index
    while lo > math.max(1, plan.index-15) and valid(route[lo-1]) and S.isBack(route[lo-1]) == back do lo = lo-1 end
    while hi < math.min(#route, plan.index+80) and valid(route[hi+1]) and S.isBack(route[hi+1]) == back do hi = hi+1 end
    local best, bestD = plan.index, math.huge
    for i = lo, hi do
        local p = route[i]
        if valid(p) and S.isBack(p) == back then
            local d = dist(x,y,p.x,p.y)
            if d < bestD then best, bestD = i, d end
        end
    end
    plan.index = best
    -- Distance to the polyline, not just to the nearest sample.
    local cd = bestD
    for _, j in ipairs({best-1, best}) do
        local a, b = route[j], route[j+1]
        if valid(a) and valid(b) and S.isBack(a) == back and S.isBack(b) == back then
            local dx, dy = b.x-a.x, b.y-a.y
            local len2 = dx*dx+dy*dy
            if len2 > 0.0001 then
                local t = math.max(0, math.min(1, ((x-a.x)*dx+(y-a.y)*dy)/len2))
                cd = math.min(cd, dist(x,y,a.x+dx*t,a.y+dy*t))
            end
        end
    end
    plan.connectDistance = cd
    return best, cd
end

-- Signed heading error to the aim point; positive means turn right
-- (same convention as the v5.77 rotation target).
function S.aim(plan, x, y, carHeading)
    local cd = plan.connectDistance or 0
    local meters = math.max(8, math.min(22, 6 + cd*0.8))
    -- direct (set after driving on was blocked): head for the connection
    -- point itself - the straight, car-wide line the reachability check
    -- verified - until close to the route, then aim along it as usual.
    if plan.direct and cd > 8 then meters = 0 end
    local ax, ay = S.ahead(plan.route, plan.index, meters)
    local desired
    if (ax-x)^2+(ay-y)^2 < 4 then
        -- At the end of the leg or route: aim along its last direction.
        local tx, ty = S.tangent(plan.route, plan.index, 10)
        if not tx then return nil end
        desired = heading(tx, ty)
        ax, ay = x+tx*10, y+ty*10
    else
        desired = heading(ax-x, ay-y)
    end
    if plan.back then desired = desired + 180 end
    return (carHeading-desired+180)%360-180, ax, ay
end

return S
